#define SALE_MAXVALUE	255

#define GOODPOST	1
#define BADPOST		2
#define GOODSALE	3
#define BADSALE		4
