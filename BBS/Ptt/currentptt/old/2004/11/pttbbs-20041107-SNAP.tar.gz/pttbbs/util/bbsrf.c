/* $Id: bbsrf.c 2189 2004-09-10 00:49:47Z victor $ */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/param.h>
#include <sys/types.h>
#include <pwd.h>
#include <syslog.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include "config.h"

#ifdef Solaris
    #include <utmpx.h>
    #define U_FILE UTMPX_FILE
#else
    #include <utmp.h>
    #define U_FILE UTMP_FILE
#endif

#ifdef FreeBSD
    #define UTMP_FILE _PATH_UTMP
#endif

#ifndef Solaris
    #if MAXHOSTNAMELEN < UT_HOSTSIZE
	#define MAX_HOMENAME_LEN MAXHOSTNAMELEN
    #else
	#define MAX_HOMENAME_LEN UT_HOSTSIZE
    #endif
#else
    /* according to /usr/include/utmpx.h ... */
    #define MAX_HOMENAME_LEN 256
#endif

/* fill the hid with from hostname */
void gethid(char *hid, char *tty)
{
    int fd;
    char *tp;
#ifdef Solaris
    struct utmpx data;
#else
    struct utmp data;
#endif

    gethostname(hid, MAX_HOMENAME_LEN);
    hid[MAX_HOMENAME_LEN] = '\0';
    tp = strrchr(tty, '/') + 1;
    if (tp && strlen(tp) == 5)
    {
	fd = open(U_FILE, O_RDONLY);
	if (fd < 0)
	    syslog(LOG_ERR, "%s: %m", U_FILE);
	else
	{
	    while (read(fd, &data, sizeof(data)) == sizeof(data))
		if (strcmp(data.ut_line, tp) == 0)
		{
		    if (data.ut_host[0]) {
			strncpy(hid, data.ut_host, MAX_HOMENAME_LEN);
			hid[MAX_HOMENAME_LEN] = '\0';
		    }
		    break;
		}
	    close(fd);
	}
    }
}

/*
   show ban file
   if filename exist, print it out, sleep 1 second, and return 0;
   otherwise, return -1.
 */
int showbanfile(char *filename)
{
    FILE *fp;
    char buf[256];

    fp = fopen(filename, "r");
    if (fp)
    {
	while (fgets(buf, sizeof(buf), fp))
	    fputs(buf, stdout);
	printf("\n============================="
	       "=============================\n");
	fclose(fp);
	sleep(1);
    }
    return fp ? 0 : -1;
}

int main(void)
{
    int uid, rtv = 0;
    char *tty, ttybuf[32], hid[MAX_HOMENAME_LEN + 1];

#ifndef Solaris
    openlog("bbsrf", LOG_PID | LOG_PERROR, LOG_USER);
#else
    openlog("bbsrf", LOG_PID, LOG_USER);
#endif
    chdir(BBSHOME);
    uid = getuid();

    while (1)
    {
	if (!showbanfile(BAN_FILE))
	{
	    rtv = 1;
	    break;
	}
	else if (uid != BBSUID)
	{
	    syslog(LOG_ERR, "UID DOES NOT MATCH");
	    rtv = -1;
	    break;
	}
	else if (!getpwuid(uid))
	{
	    syslog(LOG_ERR, "YOU DONT EXIST");
	    rtv = -1;
	    break;
	}
	else
	{
	    tty = ttyname(0);
	    if (tty)
	    {
		strcpy(ttybuf, tty);
		gethid(hid, ttybuf);
	    }
	    else
	    {
		strcpy(ttybuf, "notty");
		strcpy(hid, "unknown");
	    }
	    execl(BBSPROG, "mbbsd", hid, ttybuf, NULL);
	    syslog(LOG_ERR, "execl(): %m");
	    rtv = -1;
	}
	break;
    }
    return rtv;
}
