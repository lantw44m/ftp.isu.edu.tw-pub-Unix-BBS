#!/usr/bin/perl
# $Id: class.list.pl 1079 2003-07-27 07:42:17Z in2 $
use Frontier::Client;
use Frontier::RPC2;
use MIME::Base64;
use Data::Dumper;
do 'host.pl';

$bid = $ARGV[0] || 0;

$server = Frontier::Client->new(url => $server_url);
$result = $server->call('class.list', $bid);

print Dumper($result);
