#!/usr/bin/perl
# $Id: index.pl 1152 2003-09-02 10:31:50Z  $
use CGI qw/:standard/;
use lib qw/./;
use LocalVars;

sub main
{
    print redirect("/blog.pl/$1/")
	if( $ENV{REDIRECT_REQUEST_URI} =~ m|/\?(.*)| );

    return redirect("/blog.pl/$BLOGdefault/");
}

main();
1;

