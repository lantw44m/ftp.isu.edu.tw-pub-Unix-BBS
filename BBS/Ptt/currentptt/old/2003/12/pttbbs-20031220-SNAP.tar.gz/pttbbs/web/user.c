#include "mod_ptt.h"

int bbs_user(request_rec *r, void *args)
{
   return OK;
}
