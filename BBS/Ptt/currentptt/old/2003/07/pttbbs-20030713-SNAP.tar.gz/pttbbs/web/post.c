#include "mod_ptt.h"

int bbs_post(request_rec *r, void *args)
{
   return OK;
}
