#!/usr/bin/perl
# $Id: index.pl 1105 2003-08-17 01:07:30Z in2 $
use CGI qw/:standard/;
use lib qw/./;

sub main
{
    print redirect("/blog.pl/$1/")
	if( $ENV{REDIRECT_REQUEST_URI} =~ m|/\?(.*)| );

    return redirect("/blog.pl/$BLOGdefault/");
}

main();
1;

