void
str_lower(dst, src)
  char *dst, *src;
{
  int ch;

  do
  {
    ch = *src++;
	/* JeffHung.20000714: only for ACSII? */
    if (ch >= 'A' && ch <= 'Z')
      ch |= 0x20;
    *dst++ = ch;
  } while (ch);
}
