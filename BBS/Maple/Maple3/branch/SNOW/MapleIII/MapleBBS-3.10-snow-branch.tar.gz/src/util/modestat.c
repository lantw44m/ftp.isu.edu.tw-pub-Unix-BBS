/*-------------------------------------------------------*/
/* util/modestat.c	( NTHU CS MapleBBS Ver 3.00 )	 */
/*-------------------------------------------------------*/
/* target : �έp�ϥΪ̰ʺA                               */
/* create : 95/11/21				 	 */
/* update : 97/11/21				 	 */
/*-------------------------------------------------------*/
/* syntax : modestat [update|log_filename]               */
/*-------------------------------------------------------*/


#include <stdio.h>
#include <time.h>

#define _MODES_C_
#if 0
#define DEBUG
#endif

#include "bbs.h"

static MODELOG statics;
static char datemsg[32];



/* ----------------------------------------------------- */
/* record routines					 */
/* ----------------------------------------------------- */


int
rec_count(fpath, size)
  char *fpath;
  int size;
{
  struct stat st;

  if (stat(fpath, &st) == -1)
    return 0;
  return (st.st_size / size);
}


int
rec_fetch(fpath, data, size, id)
  char *fpath;
/* char *data; */
  void *data;			/* Thor: ���Q�ݨ� warning */
  int size, id;
{
  int fd;
  int ret;

  ret = -1;

  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    if (lseek(fd, (off_t) (size * id), SEEK_SET) >= 0)
    {
      if (read(fd, data, size) == size)
	ret = 0;
    }
    close(fd);
  }
  return ret;
}


int
rec_append(fpath, data, size)
  char *fpath;
/* char *data; */
  void *data;			/* Thor: ���Q�ݨ� warning */
  int size;
{
  int fd;

  if ((fd = open(fpath, O_WRONLY | O_CREAT | O_APPEND, 0600)) < 0)
    /* Thor:�`�N    ^^^^^ */
    return -1;

  /* flock(fd, LOCK_EX); */
  write(fd, data, size);
  /* flock(fd, LOCK_UN); */
  close(fd);

  return 0;
}


char *
Ctime(clock)
  time_t *clock;
{
  struct tm *t = localtime(clock);
  static char week[] = "��@�G�T�|����";

  /* sprintf(datemsg, "%d�~%2d��%2d��%3d:%02d:%02d �P��%.2s", */
  sprintf(datemsg, "%d�~%2d��%2d�� �P��%.2s",
    t->tm_year - 11, t->tm_mon + 1, t->tm_mday, &week[t->tm_wday << 1]);
  return (datemsg);
}

int
rec_update(fpath, data, size, pos)
  char *fpath;
/* char *data; */
  void *data;			/* Thor: ���Q�ݨ� warning */
  int size, pos;
{
  int fd;

#if 0
  if ((fd = open(fpath, O_WRONLY)) < 0)
#endif

    /* Thor: ���[CREAT�|�L�kwrite, �]���y���Xwrite���ɮ� */
    if ((fd = open(fpath, O_WRONLY | O_CREAT, 0600)) < 0)

      return -1;

  /* flock(fd, LOCK_EX); */
  /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
  f_exlock(fd);

  lseek(fd, (off_t) (size * pos), SEEK_SET);
  write(fd, data, size);

  /* flock(fd, LOCK_UN); */
  /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
  f_unlock(fd);

  close(fd);

  return 0;
}


void
add(MODELOG * m)
{
  register int i;

#ifdef DEBUG
  printf("Add entry at %s\n", ctime(&m->logtime));
#endif

  statics.usercount += m->usercount;
  for (i = 0; i < 30; i++)
  {
    statics.used_time[i] += m->used_time[i];
    statics.count[i] += m->count[i];
   
#ifdef DEBUG
    printf("i: %d count: %d\n", i, m->count[i]);
#endif
  }
}

void
update_log()
{
  MODELOG mlog;
  struct tm *t;
  int c, samehour = 0;
  register int i;
  UMODELOG m;
  int fd;
  int y, d, h = -1;

  memset(&mlog, 0, sizeof(MODELOG));
  if (c = rec_count(FN_MODE_LOG, sizeof(MODELOG)))
  {
    rec_fetch(FN_MODE_LOG, &mlog, sizeof(MODELOG), c - 1);

    t = localtime(&mlog.logtime);
    y = t->tm_year;
    d = t->tm_yday;
    h = t->tm_hour;
  }

  rename(FN_MODE_CUR, FN_MODE_TMP);
  if ((fd = open(FN_MODE_TMP, O_RDONLY)) >= 0)
  {
    while (read(fd, &m, sizeof(UMODELOG)) == sizeof(UMODELOG))
    {
      t = localtime(&m.logtime);

      if (h != t->tm_hour || d != t->tm_yday || y != t->tm_year)
      {
	if (h != -1)		/* not first entry */
	{
	  mlog.logtime = m.logtime;
	  if (samehour)
	  {
	    rec_update(FN_MODE_LOG, &mlog, sizeof(MODELOG), c - 1);
	    samehour = 0;
	  }
	  else
	    rec_append(FN_MODE_LOG, &mlog, sizeof(MODELOG));

	}

	y = t->tm_year;
	d = t->tm_yday;
	h = t->tm_hour;

	memset(&mlog, 0, sizeof(MODELOG));
      }

      mlog.usercount++;
      for (i = 0; i < 30; i++)
      {
	if (m.used_time[i] > 0)
	{
	  mlog.used_time[i] += m.used_time[i];
	  mlog.count[i]++;
	}
      }
    }

    close(fd);
    unlink(FN_MODE_TMP);
    
    if (mlog.usercount)			/* the last hour */
    {
      mlog.logtime = m.logtime;
      rec_append(FN_MODE_LOG, &mlog, sizeof(MODELOG));
    }
  }

}

main(argc, argv)
  char *argv[];
{
  char *fname;
  FILE *fp;
  MODELOG mlog;
  struct tm *t;
  int day = -1, d, num;

  if (argc < 2)
  {
    chdir(BBSHOME);
    fname = FN_MODE_LOG;
  }
  else if (!stricmp(argv[1], "update"))
  {
      chdir(BBSHOME);
    update_log();
    exit(0);
  }
  else
    fname = argv[1];


  if ((fp = fopen(fname, "rb")) == NULL)
  {
    perror("Can't open file");
    exit(1);
  }

  do
  {
    memset(&mlog, 0, sizeof(MODELOG));
    if (fread(&mlog, sizeof(MODELOG), 1, fp))
      t = localtime(&mlog.logtime);
    else
      t = NULL;

    if (!t || (d = t->tm_yday) != day)
    {

#ifdef DEBUG
      printf("d: %d  day: %d\n", d, day);
#endif

      if (day >= 0)
      {
	register int i, c;
	static char buf[80];

	for (i = c = 0; i <= M_MAX; i++)
	{
	  struct tm *tt;

          /* Thor.980101:�ק令���i�H���total time & count */
          time_t t =0;
#ifdef DEBUG
	  printf("%d: %d\n", i, statics.count[i]);
#endif

	  if (statics.count[i])
	    /*statics.used_time[i] /= statics.count[i];*/
	    t = statics.used_time[i] / statics.count[i];

	  /* tt = localtime(&statics.used_time[i]); */
	  tt = localtime(&t);
	  /* sprintf(buf + (c * 22), "%-12s%02d��%02d��  ", ModeTypeTable[i], tt->tm_min, tt->tm_sec); */
	  sprintf(buf + (c * 37), "%-12s%02d��%02d��(%7d/%5d)  ", ModeTypeTable[i], tt->tm_min, tt->tm_sec, statics.used_time[i], statics.count[i]);

	  /*if (++c == 3)*/
	  if (++c == 2)
	  {
	    printf(buf);
	    printf("\n");
	    c = 0;
	  }
	}
	printf("�@ %d �����, %d �H��\n", num, statics.usercount);
      }

      num = 0;
      memset(&statics, 0, sizeof(MODELOG));

      if (t)
      {
	day = d;
	printf("[%s]\n", Ctime(&mlog.logtime));
      }
    }

    if (t)
      add(&mlog);
    num++;

  } while (!feof(fp));


  fclose(fp);
  exit(0);
}
