/*-------------------------------------------------------*/
/* alphacall.c       ( NTHU CS MapleBBS Ver 3.00 )       */
/*-------------------------------------------------------*/
/* author : yshuang@dragon2.net                          */
/* target : BBS �����ǩI 0943/0946 �p�� Alphacall        */
/*                       0948 �j���q�H/0941 ���ذ��     */
/* create : 98/12/01                                     */
/* update : 99/01/06                                     */
/*-------------------------------------------------------*/


#include "bbs.h"


#include <stdlib.h>   
#include <netdb.h>
#include <sys/uio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


#define	SERVER_0943	"www.pager.com.tw"
#define	SERVER_0948	"www.fitel.net.tw"
#define SERVER_0941     "www.chips.com.tw"

#define CGI_0943	"/tpn/tpnasp/dowebcall.asp"
#define CGI_0948	"/cgi-bin/ip.exe"
#define CGI_0941        "/cgi-bin/paging1.pl"

#define REFER_0943	"http://www.pager.com.tw/tpn/webcall/webcall.asp"
#define REFER_0948	"http://www.fitel.net.tw/html/svc03.htm#top"
#define REFER_0941      "http://www.chip2.com.tw:9100/WEB2P/page_1.htm"

#define LOG_0943	"run/0943.log"
#define LOG_0946	"run/0946.log"	
#define LOG_0948	"run/0948.log"
#define LOG_0941        "run/0941.log"

#define	WEBPORT		80
#define PORT_0941       9100
#define PARA		"Connection: Keep-Alive\nUser-Agent: Mozilla/4.5b1 [en] (X11; I; FreeBSD 2.2.7-STABLE i386)\nContent-type: application/x-www-form-urlencoded\nAccept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, image/png, */*\nAccept-Encoding: gzip\nAccept-Language: en\nAccept-Charset: iso-8859-1,*,utf-8\n"


void 
alpha0943()
{
  int sockfd;
  char *CoId="0943", ID[6], Name[32], FriendPassword[32];
  char Msg[64], trn[512], result[1024], sendform[512];
  struct sockaddr_in serv_addr; 
  struct hostent *hp;

#if 0
  memset(trn, 0, 512);
  memset(sendform, 0, 512);
  memset(result, 0, 4096);
  memset(buf, 0, 2048);
  memset(Name, 0, 32);
  memset(ID, 0, 16);
  memset(Msg, 0, 64);
#endif

  clear();
  
  if ((!vget(0, 0, "�п�J�z�n�ǩI�����X�G0943-", ID, 7, DOECHO) &&
       !vget(1, 0, "�п�J�z�n�ǩI���N���G", Name, 32, DOECHO)) ||
         !vget(2, 0, "�п�J�ǩI�T���G", Msg, 64, DOECHO))
  {
    vmsg("���ǩI");
    return;
  }

  move(3, 0);
  prints("�A�ҭn�ǩI�����X�G%s", ID);
  move(4, 0);
  prints("�A�ҭn�ǩI���T���G%s", Msg);

  if (vans(msg_sure_ny) != 'y')
  {
    vmsg("���ǩI");
    return;
  }

  sprintf(result, "User %s called 0943%s Name = %s\nMsg = %s\n",
            cuser.userid, ID, Name, Msg);
  f_cat(LOG_0943, result);
	
  sprintf(trn,"CoId=%s&ID=%s&Name=%s&FriendPassword=%s&&Year=1998&Month=12&Day=04&Hour=13&Minute=08&Msg=%s",
	    CoId, ID, Name, FriendPassword, Msg);
	
  sprintf(sendform, "POST %s HTTP/1.0\nReferer: %s\n%sContent-length:%d\n\n%s",
            CGI_0943, REFER_0943, PARA, strlen(trn), trn);
  		
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0)
    return; 

  memset((char *)&serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;

  if ((hp = gethostbyname(SERVER_0943)) == NULL) 
    return;

  memcpy(&serv_addr.sin_addr, hp->h_addr, hp->h_length);
	
  serv_addr.sin_port = htons(WEBPORT);
	
  if (connect(sockfd, (struct sockaddr *) &serv_addr, sizeof serv_addr))
  {
    sprintf(result,"�L�k�s�u�A�ǩI����\n");
    f_cat(LOG_0943, result);
    vmsg("�L�k�P���A�����o�s���A�ǩI����");
    return;
  }
  else
  {
    outz("���A���w�g�s���W�A�еy��");
    refresh();
  }

  write(sockfd, sendform, strlen(sendform));
  shutdown(sockfd, 1);
	
  while (read(sockfd, result, sizeof(result)) > 0)
  {
    if (strstr(result, "���T") != NULL)
    {
      close(sockfd);
      f_cat(LOG_0943, result);
      vmsg("���Q�e�X�ǩI");
      return;
    }
    f_cat(LOG_0943, result);
    memset(result, 0, sizeof(result));
  }      
  
  close(sockfd);
  vmsg("�L�k���Q�e�X�ǩI");
  return;
}


void 
alpha0946()
{
  int sockfd;
  char *CoId="0946", ID[6], Name[32], FriendPassword[32];
  char Msg[64], trn[512], result[1024], sendform[512];
  struct sockaddr_in serv_addr; 
  struct hostent *hp;

#if 0
  memset(trn, 0, 512);
  memset(sendform, 0, 512);
  memset(result, 0, 4096);
  memset(buf, 0, 2048);
  memset(Name, 0, 32);
  memset(ID, 0, 16);
  memset(Msg, 0, 64);
#endif

  clear();
  
  if ((!vget(0, 0, "�п�J�z�n�ǩI�����X�G0946-", ID, 7, DOECHO) &&
       !vget(1, 0, "�п�J�z�n�ǩI���N���G", Name, 32, DOECHO)) ||
         !vget(2, 0, "�п�J�ǩI�T���G", Msg, 64, DOECHO))
  {
    vmsg("���ǩI");
    return;
  }

  move(3, 0);
  prints("�A�ҭn�ǩI�����X�G%s", ID);
  move(4, 0);
  prints("�A�ҭn�ǩI���T���G%s", Msg);

  if (vans(msg_sure_ny) != 'y')
  {
    vmsg("���ǩI");
    return;
  }

  sprintf(result, "User %s called 0946%s Name = %s\nMsg = %s\n",
            cuser.userid, ID, Name, Msg);
  f_cat(LOG_0946, result);
	
  sprintf(trn,"CoId=%s&ID=%s&Name=%s&FriendPassword=%s&&Year=1998&Month=12&Day=04&Hour=13&Minute=08&Msg=%s",
	    CoId, ID, Name, FriendPassword, Msg);
	
  sprintf(sendform, "POST %s HTTP/1.0\nReferer: %s\n%sContent-length:%d\n\n%s",
            CGI_0943, REFER_0943, PARA, strlen(trn), trn);
  		
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0)
    return; 

  memset((char *)&serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  
  if ((hp = gethostbyname(SERVER_0943)) == NULL) 
    return;

  memcpy(&serv_addr.sin_addr, hp->h_addr, hp->h_length);
  serv_addr.sin_port = htons(WEBPORT);
	
  if (connect(sockfd, (struct sockaddr *) &serv_addr, sizeof serv_addr))
  {
    sprintf(result,"�L�k�s�u�A�ǩI����\n");
    f_cat(LOG_0946, result);
    vmsg("�L�k�P���A�����o�s���A�ǩI����");
    return;
  }
  else
  {
    outz("���A���w�g�s���W�A�еy��");
    refresh();
  }

  write(sockfd, sendform, strlen(sendform));
  shutdown(sockfd, 1);
	
  while (read(sockfd, result, sizeof(result)) > 0)
  {
    if (strstr(result, "���T") != NULL)
    {
      close(sockfd);
      f_cat(LOG_0946, result);
      vmsg("���Q�e�X�ǩI");
      return;
    }
    f_cat(LOG_0946, result);
    memset(result, 0, sizeof(result));
  }      
  
  close(sockfd);
  vmsg("�L�k���Q�e�X�ǩI");
  return;
}


void
chips()
{
  int i, sockfd;
  char PAGER_NO[6],TRAN_MSG[16];
  char trn[512],sendform[512];
  char ch,result[2048];
  struct sockaddr_in serv_addr;
  struct hostent *hp;

#if 0
  bzero(PAGER_NO,6);
  bzero(TRAN_MSG,16);
  bzero(sendform,512);
  bzero(trn,512);
#endif
  
  clear();
  
  if (!vget(0, 0, "�п�J�z�n�ǩI�����X�G0941-", PAGER_NO, 7, DOECHO) ||
       !vget(1, 0, "�п�J�ǩI�T���G", TRAN_MSG, 17, DOECHO))
  {
    vmsg("���ǩI");
    return;
  }

  move(2, 0);
  prints("�A�ҭn�ǩI�����X�G%s", PAGER_NO);
  move(3, 0);
  prints("�A�ҭn�ǩI���T���G%s", TRAN_MSG);
  
  if (vans(msg_sure_ny) != 'y')
  {
    vmsg("���ǩI");
    return;
  }
  
  sprintf(trn,"PAGER_NO=%s&PASSWD=&MSG_TYPE=NUMERIC&TRAN_MSG=%s&NOW=on&year=1999&month=01&day=06&hour=00&min=00",PAGER_NO,TRAN_MSG);
  
  sprintf(sendform, "POST %s HTTP/1.0\nReferer: %s\n%sContent-length:%d\n\n%s",
  	   CGI_0941, REFER_0941, PARA, strlen(trn), trn);
  	   
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0)
    return;
    
  memset((char *)&serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  
  if ((hp = gethostbyname(SERVER_0941)) == NULL)
    return;
    
  memcpy(&serv_addr.sin_addr, hp->h_addr, hp->h_length);
  serv_addr.sin_port = htons(PORT_0941);
  
  if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof serv_addr))
  {
    vmsg("�L�k�s�u�A�ǩI����");
    return;
  }
  else
  {
    outz("���A���w�g�s���W�A�еy��");
    refresh();
  }
  
  write(sockfd, sendform, strlen(sendform));

  shutdown(sockfd, 1);
  
  i = 0;
  while (read(sockfd, &ch, 1))
    result[i++] = ch;
  result[i]='\0';
  
  close(sockfd);
  f_cat(LOG_0941, result);

  return;    
}


void 
fitel()
{
  int i, sockfd;
  char svc_no[6], message[60], trn[512];
  char *pwd_in = "%ABP%BEP%B4%C1%B6%A1%A1A%A4%F0%BB%DD%BF%E9%A4J";
  char *sender_name = "+", *reminder_option = "OFF";
  char *isp_code = "1", result[2048], sendform[512];
  char ch, res[9], *result_ptr;
  struct sockaddr_in serv_addr; 
  struct hostent *hp;

#if 0
  bzero(trn,512);
  bzero(sendform,512);
  bzero(result,2048);
  bzero(buf,2048);
  bzero(svc_no,16);
  bzero(message,64);
#endif

  clear();
  
  if (!vget(0, 0, "�п�J�z�n�ǩI�����X�G0948-", svc_no, 7, DOECHO) ||
       !vget(1, 0, "�п�J�ǩI�T���G", message, 61, DOECHO))
  {
    vmsg("���ǩI");
    return;
  }

  move(2, 0);		
  prints("�A�ҭn�ǩI�����X�G%s", svc_no);
  move(3, 0);
  prints("�A�ҭn�ǩI���T���G%s", message);

  if (vans(msg_sure_ny) != 'y')
  {
    vmsg("���ǩI");
    return;
  }

  sprintf(trn, "svc_no=%s&pwd_in=%s&isp_code=%s&sender_name=%s&message=%s&reminder_option=%s&year=87&month=08&day=27&hour=00&min=00\n",
           svc_no, pwd_in, isp_code, sender_name, message, reminder_option);

  sprintf(sendform, "POST %s HTTP/1.0\nReferer: %s\n%sContent-length:%d\n\n%s",
           CGI_0948, REFER_0948, PARA, strlen(trn), trn);
			
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0)
    return; 
	
  memset((char *)&serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
	
	
  if ((hp = gethostbyname(SERVER_0948)) == NULL) 
    return;

  memcpy(&serv_addr.sin_addr, hp->h_addr, hp->h_length);
  serv_addr.sin_port = htons(WEBPORT);
	
  if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof serv_addr))
  {
    vmsg("�L�k�s�u�A�ǩI����");
    return;
  }
  else
  {
    outz("���A���w�g�s���W�A�еy��");
    refresh();
  }

  write(sockfd, sendform, strlen(sendform));

  shutdown(sockfd, 1);

  i = 0;
  while (read(sockfd, &ch, 1))
    result[i++] = ch;
  result[i]='\0';

  close(sockfd);
  f_cat(LOG_0948, result);

  memset(res, 0, 9);
  if (result_ptr = str_str(result, "<title>"))
    str_ncpy(res, result_ptr + 7, 9);

  sprintf(result, "User %s called 0948%s\nMessage = %s\n%s\n\n",
    cuser.userid, svc_no, message, res);

  f_cat(LOG_0948, result);
  vmsg(res);

  return;
}


/*-------------------------------------------------------*/
/* author : lkchu@dragon2.net                            */
/* target : �j���p�Ҭd�]�{��                             */
/* create : 98/12/01                                     */
/* update : 98/12/10                                     */
/*-------------------------------------------------------*/


int
uee()
{   
   int myno, i, is_num = 0, getdata = 0, k;
   char buf[128], input[9], univ[128], fpath[128], logname[80];
   FILE *fp, *flog;


   if (!vget(b_lines, 0, "�п�J����Ҹ��X�Ωm�W�G", input, 9, DOECHO))
     return 0;

   if (input[0] >= '0' && input[0] <= '9')
   {
     if ((myno = atoi(input)) <= 0)    
     {
       vmsg("�z�ҿ�J�����X�����T");
       return 0;
     }
     is_num = 1;
   }
 
   chdir(BBSHOME);

   for (i = 0; i < 4; i++)
   {
     sprintf(fpath, "tmp/87/fa0%d.txt", i + 1);
     fp = fopen(fpath, "r");
     while (fgets(buf, sizeof(buf), fp))
     {
       if (buf[0] == ' ')	/* �ǮզW�� */
       {
         char *a1, *a2;
         
         a1 = (char *)strtok(buf, "  \t");
         a2 = (char *)strtok(NULL, "  \t");
         sprintf(univ, "%s %s", a1 + 4, a2);
       }
       else			/* ���X�[�m�W */
       {
 
         if (is_num)		/* �θ��X�d�� */
         {

           char *data;

  	   /* data = (char *)strtok(buf, "    \t"); */
  	   data = buf;
           for (k = 0; k < ( strlen(buf) + 4 )/ 17 ; k++)           
           {
      	     if (!str_ncmp(data, input, 7))
             {
               /* sprintf(cname, "%s", data + 7); */
               move(0, 0);
               clrtobot();
               move(10, 0);
               prints("
                       ����Ҹ��X�G%d   �m�W�G%.8s \033[1;31m
                       ���߱z���� \033[33m%s\033[m", myno, data + 7, univ);

               vmsg(NULL);
	       fclose(fp);
               return 0; 
             }
	     
	     data += 17;
	     
	   }

         } 
         else		/* �Ωm�W�d */
         {

           char *data;

  	   /* data = (char *)strtok(buf, "    \t"); */

  	   data = buf;
           for (k = 0; k < (strlen(buf) + 4)/ 17 ; k++) 
           {
      	     if (!str_ncmp(data + 7, input, strlen(input) ))
             {
	       /* str_ncpy(cname, data, 8); */
               if (getdata == 0)
               {
                 sprintf(logname, "tmp/query.%d", getpid() );
                 flog = fopen(logname, "w");

                 fprintf(flog, "        -----=================\033[1;36m�m�W�G[\033[37m%s\033[36m] �d�ߵ��G\033[m==============-----\n", input);
               }
               getdata++;

	       strtok(data, "\n\r");
               fprintf(flog, "\033[1;35m���X�G%.7s �m�W�G%.8s \033[31m���߱z���� \033[33m%s\033[m\n", data, data + 7, univ);

             }
	     
	     data += 17;
	   }


         }
       }
     }
     fclose(fp);  
   }
   
   if (!getdata)
     vmsg("�ܩ�p�A�䤣��z�������Ǯ�");
   else
   {
     fclose(flog);
     more(logname, NULL);
     unlink(logname);
   }
/*
     vmsg(NULL);
*/
         
   return 0;     

}       

