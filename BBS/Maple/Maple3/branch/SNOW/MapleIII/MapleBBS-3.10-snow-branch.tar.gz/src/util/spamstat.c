/*-------------------------------------------------------*/
/* util/spamstat.c	( NTHU CS MapleBBS Ver 3.00 )	 */
/*-------------------------------------------------------*/
/* target : �έp����B�g�B��B�~�������D		 */
/* create : 95/03/29				 	 */
/* update : 97/03/29				 	 */
/*-------------------------------------------------------*/
/* syntax : spamstat [day]				 */
/*-------------------------------------------------------*/


#include <stdio.h>
#include <time.h>
#include "config.h"


static char *spam_f[] = {"recv", "send", "news", "link"};
static char *spam_t[] = {"���H", "�H�H", "��i", "��X"};


static int spam_n[4];


static char spam_x[] = "dwmy";	/* day, week, month, year */


static char *myfile[] = {"day", "week", "month", "year"};
static int mycount[4] = {7, 4, 12};
static int mytop[] = {10, 50, 100, 100};
static char *mytitle[] = {"��Q", "�g���Q", "���", "�~�צ�"};


#define HASHSIZE 2048		/* 2's power */
#define TOPCOUNT 256


static
struct postrec
{
  char author[13];		/* author name */
  char board[13];		/* board name */
  char title[66];		/* title name */
  time_t date;			/* last post's date */
  int number;			/* post number */
  struct postrec *next;		/* next rec */
}      *bucket[HASHSIZE];


static
struct posttop
{
  char author[13];		/* author name */
  char board[13];		/* board name */
  char title[66];		/* title name */
  time_t date;			/* last post's date */
  int number;			/* post number */
}       top[TOPCOUNT], *tp;


static SpamStat top[TOPCOUNT], *tp;


typedef struct SpamHash
{
  int type;			/* 1: from, 2: to, 3: subject */
  int hash;
  int snum;
  char *data;
  struct SpamHash *next;
}        SpamHash;


typedef struct
{
  int type;
  int hash;
  int snum;
  char data[80];
}      SpamTop;


/* ----------------------------------------------------- */
/* splay-tree sort					 */
/* ----------------------------------------------------- */


typedef	struct SplayTree SplayTree;
typedef	struct SplayList SplayList;


struct SplayTree
{
  char *data;
  SplayTree *lchild, *rchild;
};


struct SplayList	/* record path to root */
{
  SplayTree *tree;
  SplayList *next;
};


SplayTree *splay_root;			/* splay tree root */
SplayList *splay_stack;			/* splay stack entry */


static void
splay_push(node)
  SplayTree *node;
{
  SplayList *p, *q;

  p = splay_stack;
  splay_stack = q = (SplayList *) malloc(sizeof(SplayList));
  q->tree = node;
  q->next = p;
}


static SplayTree *
splay_pop(void)
{
  SplayList *p;
  SplayTree *ans;

  ans = NULL;
  if (p = splay_stack)
  {
    ans = p->tree;
    splay_stack = p->next;
    free(p);
  }
  return ans;
}


/* splay tree node constructor */


static SplayTree *
splay_new(data)
  char *data;
{
  SplayTree *node;

  node = malloc(sizeof(SplayTree));
  node->data = data;
  node->lchild = node->rchild = NULL;
  return node;
}


static void
splay(SplayTree * pw)
{
  SplayTree *pw1, *pw2;

  pw1 = splay_pop();
  while (pw2 = splay_pop())
  {
    if (pw2->lchild == pw1 && pw1->lchild == pw)
    {                           /* LL */
      pw1->lchild = pw->rchild;
      pw2->lchild = pw1->rchild;
      pw->rchild = pw1;
      pw1->rchild = pw2;
    }

    if (pw2->rchild == pw1 && pw1->rchild == pw)
    {                           /* RR */
      pw1->rchild = pw->lchild;
      pw2->rchild = pw1->lchild;
      pw->lchild = pw1;
      pw1->lchild = pw2;
    }

    if (pw2->rchild == pw1 && pw1->lchild == pw)
    {                           /* RL */
      pw1->lchild = pw->rchild;
      pw2->rchild = pw->lchild;
      pw->lchild = pw2;
      pw->rchild = pw1;
    }

    if (pw2->lchild == pw1 && pw1->rchild == pw)
    {                           /* LR */
      pw1->rchild = pw->lchild;
      pw2->lchild = pw->rchild;
      pw->lchild = pw1;
      pw->rchild = pw2;
    }

    if (pw1 = splay_pop())      /* parent of parent2 exists */
    {
      if (pw1->lchild == pw2)
        pw1->lchild = pw;
      else
        pw1->rchild = pw;
    }
    else
    {                           /* parent2 is root (splay_root) */
      splay_root = pw;
      return;
    }
  }

  /* pw1 = splay_root = parent of pw */

  if (splay_root->lchild == pw)
  {                             /* L */
    splay_root->lchild = pw->rchild;
    pw->rchild = splay_root;
    splay_root = pw;
  }
  else
  {                             /* R */
    splay_root->rchild = pw->lchild;
    pw->lchild = splay_root;
    splay_root = pw;
  }
}


/* Add a node to binary word tree */


static void
splay_add(data)
  SpamHash *data;
{
  if (!splay_root)
    splay_root = tree_new_word(word);
  else
  {
    word_tree *pw0, *pw;
    int result;

    pw = splay_root;
    while (pw)
    {
      splay_root(pw0 = pw);     /* store path on words_stack for splay */
      if ((result = compare(word, pw->word)) >= 0)
        pw = pw->rchild;
      else
        pw = pw->lchild;
    }
    if (result >= 0)
      pw = pw0->rchild = tree_new_word(word);
    else      pw = pw0->lchild = tree_new_word(word);
    if (pw != splay_root)            /* root not splayed */
      splay(pw);
  }
}


/* ----------------------------------------------------- */
/* hash structure : array + link list			 */
/* ----------------------------------------------------- */


static int
hash_str(key)
  char *key;
{
  int ch, value;

  for (value = 0; ch = *key; key++)
  {
    value = (value << 5) - value + ch;
  }

  return value;
}


static void
hash_add(str, type, snum, hash)
  char *str;
  int type;
  int snum;
  int hash;
{
  struct SpamHash *p, *q;

  if (!hash)
    hash = hash_str(str);
  p = bucket[hash & (HASHSIZE - 1)];
  q = NULL;
  while (p)
  {
    if (p->type == type && p->hash == hash && !strcmp(p->str, str))
    {
      p->snum += snum;
      return;
    }

    q = p;
    p = p->next;
  }

  p = (SpamHash *) malloc(sizeof(SpamHash));
  p->type = type;
  p->hash = hash;
  p->snum = snum;
  p->data = strdup(str);
  p->next = NULL;

  if (q == NULL)
    bucket[hash] = p;
  else
    q->next = p;
}


static void
hash_load(fpath)
  char *fpath;
{
  FILE *fp;
  SpamTop x;

  if (fp = fopen(fpath, "r"))
  {
    while (fread(&x, sizeof(SpamTop), 1, fp) == 1)
    {
      hash_add(x.data, x.type, x.snum, x.hash);
    }
    fclose(fp);
  }
}


static void
hash_save(fp, fx)
{
  int i;
  SpamHash *pp;

  /* traverse hashing table */

  for (i = 0; i < HASHSIZE; i++)
  {
    if (pp = bucket[i])
    {
      do
      {
	splay_add(pp);
      } while (pp = pp->next);

      bucket[i] = NULL;
    }
  }

}


static void
hash_free()
{
  int i;
  SpamHash *pp, *next;

  for (i = 0; i < HASHSIZE; i++)
  {
    if (pp = bucket[i])
    {
      do
      {
	next = pp->next;
	free(pp->data);
	free(pp);
      } while (pp = next);

      bucket[i] = NULL;
    }
  }

  memset(spam_n, 0, sizeof(spam_n));
}


static int
sort(pp, count)
  struct postrec *pp;
{
  int i, j;

  for (i = 0; i <= count; i++)
  {
    if (pp->number > top[i].number)
    {
      if (count < TOPCOUNT - 1)
	count++;
      for (j = count - 1; j >= i; j--)
	memcpy(&top[j + 1], &top[j], sizeof(struct posttop));

      memcpy(&top[i], pp, sizeof(struct posttop));
      break;
    }
  }
  return count;
}


static void
spamstat(spamtype, mytype)
  int spamtype;
  int mytype;
{
  FILE *fp, *fx;
  char *log, *str, buf[64], buf2[64], *p;
  struct postrec *pp;
  SpamStat spam;
  int i, j;

  log = spam_f[spamtype];

  if (mytype < 0)
  {
    /* --------------------------------------- */
    /* load .post and statictic processing     */
    /* --------------------------------------- */

    sprintf(buf, "var/%s.old", log);
    unlink(buf);
    rename(log, buf);
    if (!(fp = fopen(buf, "r")))
      return;

    while (fread(&spam, sizeof(SpamStat), 1, fp) == 1)
    {
      hash_add(spam.from, 1, 1, 0);

      hash_add(spam.to, 2, 1, 0);

      str = spam.subject;
      if (str[0] == 'R' && str[1] == 'e' && str[2] == ':')
      {
	str += 3;
	if (*str == ' ')
	  str++;
      }
      hash_add(str, 3, 1, 0);

      if (str = strchr(spam.from, '@'))
	hash_add(str, 0, 1, 0);
    }
    fclose(fp);

    sprintf(buf, "var/%s-d.0", log);
    hash_load(buf);

    mytype = 0;
  }
  else
  {
    /* ---------------------------------------------- */
    /* load previous results and statictic processing */
    /* ---------------------------------------------- */

    j = spam_x[mytype];
    i = mycount[mytype];

    do
    {
      sprintf(buf2, "var/%s-%c.%d", log, j, i);
      sprintf(buf, "var/%s-%c.%d", log, j, --i);
      hash_load(buf);
      rename(buf, buf2);
    } while (i);
    mytype++;
  }

  /* ---------------------------------------------- */
  /* sort top 100 issue and save results            */
  /* ---------------------------------------------- */

  memset(top, 0, sizeof(top));
  for (i = j = 0; i < HASHSIZE; i++)
  {
    for (pp = bucket[i]; pp; pp = pp->next)
    {

#ifdef	DEBUG
      printf("Title : %s, Board: %s\nPostNo : %d, Author: %s\n"
	,pp->title
	,pp->board
	,pp->number
	,pp->author);
#endif

      j = sort(pp, j);
    }
  }

  sprintf(buf2, "%s-%c", log, spam_x[mytype]);
  sprintf(buf, "var/%s.0", buf2);
  if (fp = fopen(buf, "w"))
  {
    sprintf(buf, BBSHOME "/gem/@/@-%s", buf2);
    if (fx = fopen(buf, "w"))
    {
      hash_save(fp, fx,);
      fclose(fx);
    }
    fclose(fp);
  }

  /* free statistics */

  hash_free();

}


int
main(argc, argv)
  char *argv[];

{
  time_t now;
  struct tm *ptime;

  chdir(BBSHOME "/run");

  if (argc == 2)
  {
    spamstat(atoi(argv[1]));
    exit(0);
  }

  time(&now);
  ptime = localtime(&now);
  if (ptime->tm_hour == 0)
  {
    if (ptime->tm_mday == 1)
      spamstat(2);
    if (ptime->tm_wday == 0)
      spamstat(1);
    spamstat(0);
  }
  spamstat(-1);
  exit(0);
}
