/*
 * BBS implementation dependendent part
 * 
 * The only two interfaces you must provide
 * 
 * #include "inntobbs.h" int receive_article(); 0 success not 0 fail
 * 
 * if (storeDB(HEADER[MID_H], hispaths) < 0) { .... fail }
 * 
 * int cancel_article_front( char *msgid );	     0 success not 0 fail
 * 
 * char *ptr = (char*)DBfetch(msgid);
 * 
 * ���줧�峹���e (body)�b char *BODY, ���Y (header)�b char *HEADER[] SUBJECT_H,
 * FROM_H, DATE_H, MID_H, NEWSGROUPS_H, NNTPPOSTINGHOST_H, NNTPHOST_H,
 * CONTROL_H, PATH_H, ORGANIZATION_H
 */

/*
 * Sample Implementation
 * 
 * receive_article()         --> post_article()   --> bbspost_write_post();
 * cacnel_article_front(mid) --> cancel_article() --> bbspost_write_cancel();
 */


#ifndef PowerBBS
#include "innbbsconf.h"
#include "daemon.h"
#include "bbslib.h"
#include "inntobbs.h"

extern int Junkhistory;

static char *post_article ARG((char *, char *, char *, int (*) (), char *, char *));
static int cancel_article ARG((char *, char *, char *));


#ifndef	MapleBBS
report()
{
  /* Function called from record.o */
  /* Please leave this function empty */
}
#endif


#if defined(PalmBBS)

#ifndef PATH
#define PATH XPATH
#endif

#ifndef HEADER
#define HEADER XHEADER
#endif

#endif

/* process post write */

static int
bbspost_write_post(fh, board, filename)
  int fh;
  char *board;
  char *filename;
{
  register FILE *fhfd = fdopen(fh, "w");
  register char *fptr, *ptr;
  register int ch;

  if (fhfd == NULL)
  {
    bbslog("can't fdopen, maybe disk full\n");
    return -1;
  }

  fprintf(fhfd, "�o�H�H: %.57s, �ݪO: %s\n", FROM, board);
  fprintf(fhfd, "��  �D: %.70s\n", SUBJECT);
  fprintf(fhfd, "�o�H��: %.43s (%s)\n", SITE, DATE);
  fprintf(fhfd, "��H��: %.70s\n", PATH);

#ifndef	MapleBBS
  if (POSTHOST != NULL)
  {
    fprintf(fhfd, "Origin: %.70s\n", POSTHOST);
  }
#endif

  fprintf(fhfd, "\n");
  for (fptr = BODY, ptr = strchr(fptr, '\r'); ptr && (ch = *ptr); fptr = ptr + 1, ptr = strchr(fptr, '\r'))
  {
    *ptr = '\0';
    fputs(fptr, fhfd);
    *ptr = ch;
  }
  fputs(fptr, fhfd);

  /* fflush(fhfd); /* opus */
  fclose(fhfd);
  return 0;
}


#ifdef	KEEP_NETWORK_CANCEL
/* process cancel write */
bbspost_write_cancel(fh, board, filename)
  int fh;
  char *board, *filename;
{
  char *fptr, *ptr;
  FILE *fhfd = fdopen(fh, "w"), *fp;
  char buffer[256];

  if (fhfd == NULL)
  {
    bbslog("can't fdopen, maybe disk full\n");
    return -1;
  }

  fprintf(fhfd, "�o�H�H: %s, �H��: %s\n", FROM, board);
  fprintf(fhfd, "��  �D: %s\n", SUBJECT);
  fprintf(fhfd, "�o�H��: %.43s (%s)\n", SITE, DATE);
  fprintf(fhfd, "��H��: %.70s\n", PATH);
  if (HEADER[CONTROL_H] != NULL)
  {
    fprintf(fhfd, "Control: %s\n", HEADER[CONTROL_H]);
  }
  if (POSTHOST != NULL)
  {
    fprintf(fhfd, "Origin: %s\n", POSTHOST);
  }
  fprintf(fhfd, "\n");
  for (fptr = BODY, ptr = strchr(fptr, '\r'); ptr != NULL && *ptr != '\0'; fptr = ptr + 1, ptr = strchr(fptr, '\r'))
  {
    int ch = *ptr;
    *ptr = '\0';
    fputs(fptr, fhfd);
    *ptr = ch;
  }
  fputs(fptr, fhfd);
  if (POSTHOST != NULL)
  {
    fprintf(fhfd, "\n * Origin: �� %.26s �� From: %.40s\n", SITE, POSTHOST);
  }
  fprintf(fhfd, "\n---------------------\n");
  fp = fopen(filename, "r");
  if (fp == NULL)
  {
    bbslog("can't open %s\n", filename);
    return -1;
  }
  while (fgets(buffer, sizeof buffer, fp) != NULL)
  {
    fputs(buffer, fhfd);
  }
  fclose(fp);
  fflush(fhfd);
  fclose(fhfd);

  {
    fp = fopen(filename, "w");
    if (fp == NULL)
    {
      bbslog("can't write %s\n", filename);
      return -1;
    }
    fprintf(fp, "�o�H�H: %s, �H��: %s\n", FROM, board);
    fprintf(fp, "��  �D: %.70s\n", SUBJECT);
    fprintf(fp, "�o�H��: %.43s (%s)\n", SITE, DATE);
    fprintf(fp, "��H��: %.70s\n", PATH);
    if (POSTHOST != NULL)
    {
      fprintf(fhfd, "Origin: %s\n", POSTHOST);
    }
    if (HEADER[CONTROL_H] != NULL)
    {
      fprintf(fhfd, "Control: %s\n", HEADER[CONTROL_H]);
    }
    fprintf(fp, "\n");
    for (fptr = BODY, ptr = strchr(fptr, '\r'); ptr != NULL && *ptr != '\0'; fptr = ptr + 1, ptr = strchr(fptr, '\r'))
    {
      *ptr = '\0';
      fputs(fptr, fp);
    }
    fputs(fptr, fp);
    if (POSTHOST != NULL)
    {
      fprintf(fp, "\n * Origin: �� %.26s �� From: %.40s\n", SITE, POSTHOST);
    }
    fclose(fp);
  }
  return 0;
}
#endif				/* KEEP_NETWORK_CANCEL */


#ifndef	MapleBBS
bbspost_write_control(fh, board, filename)
  int fh;
  char *board;
  char *filename;
{
  char *fptr, *ptr;
  FILE *fhfd = fdopen(fh, "w");

  if (fhfd == NULL)
  {
    bbslog("can't fdopen, maybe disk full\n");
    return -1;
  }

  fprintf(fhfd, "Path: %s!%s\n", MYBBSID, HEADER[PATH_H]);
  fprintf(fhfd, "From: %s\n", FROM);
  fprintf(fhfd, "Newsgroups: %s\n", GROUPS);
  fprintf(fhfd, "Subject: %s\n", SUBJECT);
  fprintf(fhfd, "Date: %s\n", DATE);
  fprintf(fhfd, "Organization: %s\n", SITE);
  if (POSTHOST != NULL)
  {
    fprintf(fhfd, "NNTP-Posting-Host: %.70s\n", POSTHOST);
  }
  if (HEADER[CONTROL_H] != NULL)
  {
    fprintf(fhfd, "Control: %s\n", HEADER[CONTROL_H]);
  }
  if (HEADER[APPROVED_H] != NULL)
  {
    fprintf(fhfd, "Approved: %s\n", HEADER[APPROVED_H]);
  }
  if (HEADER[DISTRIBUTION_H] != NULL)
  {
    fprintf(fhfd, "Distribution: %s\n", HEADER[DISTRIBUTION_H]);
  }
  fprintf(fhfd, "\n");
  for (fptr = BODY, ptr = strchr(fptr, '\r'); ptr != NULL && *ptr != '\0'; fptr = ptr + 1, ptr = strchr(fptr, '\r'))
  {
    int ch = *ptr;
    *ptr = '\0';
    fputs(fptr, fhfd);
    *ptr = ch;
  }
  fputs(fptr, fhfd);


  fflush(fhfd);
  fclose(fhfd);
  return 0;
}
#endif				/* MapleBBS */


time_t datevalue;


#if defined(PhoenixBBS) || defined(SecretBBS) || defined(PivotBBS) || defined(MapleBBS)
/* for PhoenixBBS's post article and cancel article */
#include "bbs.h"


static char *
post_article(homepath, userid, board, writebody, pathname, firstpath)
  char *homepath;
  char *userid, *board;
  int (*writebody) ();
char *pathname, *firstpath;
{
  struct fileheader header;
  char *subject = SUBJECT;
  char index[MAXPATHLEN];
  static char name[16];
  char article[MAXPATHLEN];
  char buf[MAXPATHLEN], *ptr;
  FILE *fidx;
  int fh;
  time_t now;
  int linkflag;

  sprintf(index, "%s/.DIR", homepath);

#ifndef	MapleBBS
  if ((fidx = fopen(index, "r")) == NULL)
  {
    if ((fidx = fopen(index, "w")) == NULL)
    {
      bbslog(":Err: Unable to post in %s.\n", homepath);
      return NULL;
    }
  }
  fclose(fidx);
#endif

  now = time(NULL);
  while (1)
  {
    sprintf(name, "M.%d.A", ++now);
    sprintf(article, "%s/%s", homepath, name);
    fh = open(article, O_CREAT | O_EXCL | O_WRONLY, 0644);
    if (fh >= 0)
      break;
    if (errno != EEXIST)
    {
      bbslog(" Err: can't write or other errors\n");
      return NULL;
    }
  }

#ifdef DEBUG
  printf("post to %s\n", article);
#endif

  linkflag = 1;
  if (firstpath && *firstpath)
  {
    close(fh);
    unlink(article);

#ifdef DEBUGLINK
    bbslog("try to link %s to %s", firstpath, article);
#endif

    linkflag = link(firstpath, article);
    if (linkflag)
    {
      fh = open(article, O_CREAT | O_EXCL | O_WRONLY, 0644);
    }
  }
  if (linkflag)
  {
    if (writebody)
    {
      if ((*writebody) (fh, board, pathname) < 0)
	return NULL;
    }
    else
    {
      if (bbspost_write_post(fh, board, pathname) < 0)
	return NULL;
    }

#ifdef	MapleBBS
    if (firstpath)
      strcpy(firstpath, article);	/* opus : write back */
#else
    close(fh);
#endif
  }

  bzero((void *) &header, sizeof(header));

#ifndef	MapleBBS
  strcpy(header.filename, name);
  strncpy(header.owner, userid, IDLEN);
  strncpy(header.title, subject, STRLEN);
  header.filename[STRLEN - 1] = 'M';
  append_record(index, &header, sizeof(header));
#else

  strcpy(header.filename, name);
  if (userid[IDLEN])
    strcpy(&userid[IDLEN], ".");
  strcpy(header.owner, userid);
  strncpy(header.title, subject, TTLEN);
  {
    struct tm *ptime;
    ptime = localtime(&datevalue);
    sprintf(header.date, "%2d/%02d", ptime->tm_mon + 1, ptime->tm_mday);
  }

  if ((fh = open(index, O_WRONLY | O_CREAT, 0644)) < 0)
  {
    return NULL;
  }
  flock(fh, LOCK_EX);
  lseek(fh, 0, SEEK_END);
  write(fh, &header, sizeof(header));
  flock(fh, LOCK_UN);
  close(fh);
#endif

  return name;
}


static int
cancel_article(homepath, board, file)
  char *homepath;
  char *board, *file;
{
  struct fileheader header;
  struct stat state;
  char dirname[MAXPATHLEN];
  char buf[MAXPATHLEN];
  register long numents, size, time, now;
  register int fd, lower, ent;

  if (file == NULL ||		/* file[0] != 'M' || file[1] != '.' || */
    (time = atoi(file + 2)) <= 0)
    return 0;

  size = sizeof(header);
  sprintf(dirname, "%s/boards/%s/.DIR", homepath, board);
  if ((fd = open(dirname, O_RDWR)) == -1)
    return 0;
  flock(fd, LOCK_EX);
  fstat(fd, &state);
  ent = ((long) state.st_size) / size;
  lower = 0;
  while (1)
  {
    ent -= 8;
    if (ent <= 0 || lower >= 2)
      break;
    lseek(fd, size * ent, SEEK_SET);
    if (read(fd, &header, size) != size)
    {
      ent = 0;
      break;
    }
    now = atoi(header.filename + 2);
    lower = (now < time) ? lower + 1 : 0;
  }
  if (ent < 0)
    ent = 0;
  while (read(fd, &header, size) == size)
  {
    if (strcmp(file, header.filename) == 0)
    {
      sprintf(buf, "-%s", header.owner);
      strcpy(header.owner, buf);
      strcpy(header.title, "<< article canceled >>");
      lseek(fd, -size, SEEK_CUR);
      write(fd, &header, size);
      break;
    }
    now = atoi(header.filename + 2);
    if (now > time)
      break;
  }
  flock(fd, LOCK_UN);
  close(fd);
  return 0;
}

#elif defined(PalmBBS)
#undef PATH XPATH
#undef HEADER XHEADER
#include "server.h"

char *
post_article(homepath, userid, board, writebody, pathname, firstpath)
  char *homepath;
  char *userid, *board;
  int (*writebody) ();
char *pathname, *firstpath;
{
  PATH msgdir, msgfile;
  static PATH name;

  READINFO readinfo;
  SHORT fileid;
  char buf[MAXPATHLEN];
  struct stat stbuf;
  int fh;

  strcpy(msgdir, homepath);
  if (stat(msgdir, &stbuf) == -1 || !S_ISDIR(stbuf.st_mode))
  {
    /* A directory is missing! */
    bbslog(":Err: Unable to post in %s.\n", msgdir);
    return NULL;
  }
  get_filelist_ids(msgdir, &readinfo);

  for (fileid = 1; fileid <= BBS_MAX_FILES; fileid++)
  {
    int oumask;
    if (test_readbit(&readinfo, fileid))
      continue;
    fileid_to_fname(msgdir, fileid, msgfile);
    sprintf(name, "%04x", fileid);

#ifdef DEBUG
    printf("post to %s\n", msgfile);
#endif

    if (firstpath && *firstpath)
    {

#ifdef DEBUGLINK
      bbslog("try to link %s to %s", firstpath, msgfile);
#endif

      if (link(firstpath, msgfile) == 0)
	break;
    }
    oumask = umask(0);
    fh = open(msgfile, O_CREAT | O_EXCL | O_WRONLY, 0664);
    umask(oumask);
    if (writebody)
    {
      if ((*writebody) (fh, board, pathname) < 0)
	return NULL;
    }
    else
    {
      if (bbspost_write_post(fh, board, pathname) < 0)
	return NULL;
    }
    close(fh);
    break;
  }

#ifdef CACHED_OPENBOARD
  {
    char *bname;
    bname = strrchr(msgdir, '/');
    if (bname)
      notify_new_post(++bname, 1, fileid, stbuf.st_mtime);
  }
#endif

  return name;
}

cancel_article(homepath, board, file)
  char *homepath;
  char *board, *file;
{
  PATH fname;

#ifdef  CACHED_OPENBOARD
  PATH bdir;
  struct stat stbuf;

  sprintf(bdir, "%s/boards/%s", homepath, board);
  stat(bdir, &stbuf);
#endif

  sprintf(fname, "%s/boards/%s/%s", homepath, board, file);
  unlink(fname);
  /* kill it now! the function is far small then original..  :) */
  /* because it won't make system load heavy like before */

#ifdef CACHED_OPENBOARD
  notify_new_post(board, -1, hex2SHORT(file), stbuf.st_mtime);
#endif
}

#else
error("You should choose one of the systems: PhoenixBBS, PowerBBS, or PalmBBS")
#endif

#else

receive_article()
{
}

cancel_article_front(msgid)
  char *msgid;
{
}
#endif


/* process cancel write */

/* opus : a lot of modification here */

int
receive_article()
{
  register char *ngptr, *nngptr, *pathptr;
  register char **splitptr;
  register char *fname;
  register newsfeeds_t *nf;
  char userid[32];
  char xdate[32];
  char xpath[180];
  char boardhome[80];
  char hispaths[2048];
  char firstpath[MAXPATHLEN], *firstpathbase;
  register int hislen;

  if (FROM == NULL)
  {
    bbslog(":Err: article without usrid %s\n", MSGID);
    return 0;
  }

  firstpath[0] = *hispaths = hislen = 0;
  firstpathbase = firstpath;

  /*
   * try to split newsgroups into separate group and check if any duplicated
   */

  splitptr = (char **) BNGsplit(GROUPS);

  /* try to use hardlink */

  /*
   * for ( ngptr = GROUPS, nngptr = (char*) strchr(ngptr,','); ngptr != NULL
   * && *ngptr != '\0'; nngptr = (char*)strchr(ngptr,',')) {
   */

  /* for (ngptr = *splitptr; ngptr; ngptr = *(++splitptr)) /* opus */
  while (ngptr = *splitptr++)
  {
    char *boardptr, *nboardptr;

    /*
     * if (nngptr != NULL) { nngptr = '\0'; }
     */

    if (!*ngptr)
      continue;

    nf = (newsfeeds_t *) search_group(ngptr);
    if (nf == NULL)
    {
      /* bbslog( "unwanted \'%s\'\n", ngptr ); */
      /*
       * if( strstr( ngptr, "tw.bbs" ) != NULL ) { }
       */
      continue;
    }
    if (!(boardptr = nf->board) || !*boardptr)
      continue;
    if (nf->path == NULL || !*nf->path)
      continue;

    for (nboardptr = (char *) strchr(boardptr, ','); boardptr && *boardptr; nboardptr = (char *) strchr(boardptr, ','))
    {
      if (nboardptr)
      {
	*nboardptr = '\0';
      }
      if (*boardptr != '\t')
      {

#ifdef	MapleBBS
	sprintf(boardhome, "%s/boards/%s", BBSHOME, boardptr);
#else
	boardhome = (char *) fileglue("%s/boards/%s", BBSHOME, boardptr);
#endif
	if (!isdir(boardhome))
	{
	  bbslog(":Err: unable to write %s\n", boardhome);
	  continue;
	}

	if (!hislen)		/* opus : �Ĥ@�� */
	{
	  register char *user, *userptr;
	  register char *lesssym, *nameptrleft, *nameptrright;

	  user = (char *) strchr(FROM, '@');
	  lesssym = (char *) strchr(FROM, '<');
	  nameptrleft = nameptrright = NULL;
	  if (lesssym == NULL || lesssym >= user)
	  {
	    lesssym = FROM;
	    nameptrleft = strchr(FROM, '(');
	    if (nameptrleft != NULL)
	      nameptrleft++;
	    nameptrright = strrchr(FROM, ')');
	  }
	  else
	  {
	    nameptrleft = FROM;
	    nameptrright = strrchr(FROM, '<');
	    lesssym++;
	  }
	  if (user != NULL)
	  {
	    *user = '\0';
	    userptr = (char *) strchr(FROM, '.');
	    if (userptr != NULL)
	    {
	      *userptr = '\0';
	      strncpy(userid, lesssym, sizeof userid);
	      *userptr = '.';
	    }
	    else
	    {
	      strncpy(userid, lesssym, sizeof userid);
	    }
	    *user = '@';
	  }
	  else
	  {
	    strncpy(userid, lesssym, sizeof userid);
	  }
	  strcat(userid, ".");
	  datevalue = parsedate(DATE, NULL);

	  if (datevalue > 0)
	  {
	    memcpy(xdate, ctime(&datevalue), 24);
	    xdate[24] = '\0';
	    DATE = xdate;
	  }

#ifndef	MapleBBS
	  if (SITE && strcasecmp("Computer Science & Information Engineering NCTU", SITE) == 0)
	  {
	    SITE = "��j��u News Server";
	  }
	  else if (SITE && strcasecmp("Dep. Computer Sci. & Information Eng., Chiao Tung Univ., Taiwan, R.O.C", SITE) == 0)
	  {
	    SITE = "��j��u News Server";
	  }
	  else if (SITE == NULL || *SITE == '\0')
	  {
	    if (nameptrleft != NULL && nameptrright != NULL)
	    {
	      static char sitebuf[80];
	      char savech = *nameptrright;
	      *nameptrright = '\0';
	      strncpy(sitebuf, nameptrleft, sizeof sitebuf);
	      *nameptrright = savech;
	      SITE = sitebuf;
	    }
	    else
	      /* SITE = "(Unknown)"; */
	      SITE = "";
	  }
	  if (strlen(MYBBSID) > 70)
	  {
	    bbslog(" :Err: your bbsid %s too long\n", MYBBSID);
	    return 0;
	  }
#endif

	  sprintf(xpath, "%s!%.*s", MYBBSID, sizeof(xpath) - strlen(MYBBSID) - 2, PATH);
	  for (pathptr = PATH = xpath; pathptr && (pathptr = strstr(pathptr, ".edu.tw"));)
	  {
	    strcpy(pathptr, pathptr + 7);
	  }
	  xpath[71] = '\0';

#ifndef	MapleBBS
	  echomaillog();
#endif
	}

	/*
	 * if ( !isdir( boardhome )) { bbslog( ":Err: unable to write
	 * %s\n",boardhome); testandmkdir(boardhome); }
	 */
	if (fname = (char *) post_article(boardhome, userid, boardptr, bbspost_write_post, NULL, firstpath))
	{
	  register int flen;

	  fname = (char *) fileglue("%s/%s", boardptr, fname);
	  flen = strlen(fname) + 1;

#ifndef	MapleBBS
	  if (firstpath[0] == '\0')
	  {
	    sprintf(firstpath, "%s/boards/%s", BBSHOME, fname);
	    firstpathbase = firstpath + strlen(BBSHOME) + strlen("/boards/");
	  }
#endif

	  if (flen + hislen < sizeof(hispaths))
	  {
	    strcpy(hispaths + hislen, fname);
	    hislen += flen;
	    strcpy(hispaths + hislen - 1, " ");
	  }
	}
	else
	{
	  bbslog("fname is null %s\n", boardhome);
	  return -1;
	}

      }

      /* boardcont: */

      if (nboardptr)
      {
	*nboardptr = ',';
	boardptr = nboardptr + 1;
      }
      else
	break;

    }				/* for board1,board2,... */
    /*
     * if (nngptr != NULL) ngptr = nngptr + 1; else break;
     */

#ifndef	MapleBBS
    if (*firstpathbase)
      feedfplog(nf, firstpathbase, 'P');
#endif
  }

#ifndef	MapleBBS
  if (*hispaths)
    bbsfeedslog(hispaths, 'P');
#endif

  if (hislen || Junkhistory)
  {
    if (storeDB(HEADER[MID_H], hispaths) < 0)
    {
      bbslog("store DB fail\n");
      /* I suspect here will introduce duplicated articles */
      /* return -1; */
    }
  }
  return 0;
}


#ifndef	MapleBBS
receive_control()
{
  char *boardhome, *fname;
  char firstpath[MAXPATHLEN], *firstpathbase;
  char **splitptr, *ngptr;
  newsfeeds_t *nf;

  bbslog("control post %s\n", HEADER[CONTROL_H]);
  boardhome = (char *) fileglue("%s/boards/control", BBSHOME);
  testandmkdir(boardhome);
  *firstpath = '\0';
  if (isdir(boardhome))
  {
    fname = (char *) post_article(boardhome, FROM, "control", bbspost_write_control, NULL, firstpath);
    if (fname != NULL)
    {
      if (firstpath[0] == '\0')
	sprintf(firstpath, "%s/boards/control/%s", BBSHOME, fname);
      if (storeDB(HEADER[MID_H], (char *) fileglue("control/%s", fname)) < 0)
      {
      }
      bbsfeedslog(fileglue("control/%s", fname), 'C');
      firstpathbase = firstpath + strlen(BBSHOME) + strlen("/boards/");
      splitptr = (char **) BNGsplit(GROUPS);
      for (ngptr = *splitptr; ngptr != NULL; ngptr = *(++splitptr))
      {
	if (*ngptr == '\0')
	  continue;
	nf = (newsfeeds_t *) search_group(ngptr);
	if (nf == NULL)
	  continue;
	if (nf->board == NULL)
	  continue;
	if (nf->path == NULL)
	  continue;
	feedfplog(nf, firstpathbase, 'C');
      }
    }
  }
  return 0;
}
#endif				/* MapleBBS */


int
cancel_article_front(msgid)
  char *msgid;
{
  register char *ptr = (char *) DBfetch(msgid);
  register char *filelist;
  char histent[2048], filename[256];
  char firstpath[MAXPATHLEN], *firstpathbase;

  if (ptr == NULL)
  {
    return 0;
  }

  strncpy(histent, ptr, sizeof histent);
  if (filelist = strchr(histent, '\t'))
  {
    filelist++;
  }

  for (ptr = filelist; ptr && *ptr;)
  {
    register char *file;
    register FILE *fp;

    for (; *ptr && isspace(*ptr); ptr++);
    if (*ptr == '\0')
      break;
    file = ptr;
    for (ptr++; *ptr && !isspace(*ptr); ptr++);
    if (*ptr != '\0')
    {
      *ptr++ = '\0';
    }
    sprintf(filename, "%s/boards/%s", BBSHOME, file);
    if (fp = fopen(filename, "r"))
    {
      char buffer[1024];
      register char *xfrom, *boardhome;

      while (fgets(buffer, sizeof buffer, fp))
      {
	if (buffer[0] == '\n')
	  break;
	if (xfrom = strchr(buffer, '\n'))
	  *xfrom = '\0';
	if (strncmp(buffer, "�o�H�H: ", 8) == 0)
	{
	  if (xfrom = strrchr(buffer, ','))
	    *xfrom = '\0';
	  xfrom = buffer + 8;
	  break;
	}
      }
      fclose(fp);
      if (!strncmp(HEADER[FROM_H], xfrom, 57))
      {
	bbslog("Invalid cancel %s, path: %s!%s\n", FROM, MYBBSID, PATH);
	return 0;
      }

#ifdef	KEEP_NETWORK_CANCEL
      *firstpath = '\0';
      bbslog("cancel post %s\n", filename);
      boardhome = (char *) fileglue("%s/boards/deleted", BBSHOME);
      testandmkdir(boardhome);
      if (isdir(boardhome))
      {
	char subject[1024];
	char *fname;
	if (POSTHOST)
	{
	  sprintf(subject, "cancel by: %.1000s", POSTHOST);
	}
	else
	{
	  char *body, *body2;
	  body = strchr(BODY, '\r');
	  if (body != NULL)
	    *body = '\0';
	  body2 = strchr(BODY, '\n');
	  if (body2 != NULL)
	    *body = '\0';
	  sprintf(subject, "%.1000s", BODY);
	  if (body != NULL)
	    *body = '\r';
	  if (body2 != NULL)
	    *body = '\n';
	}
	if (*subject)
	  SUBJECT = subject;
	fname = (char *) post_article(boardhome, FROM, "deleted", bbspost_write_cancel, filename, firstpath);
	if (fname != NULL)
	{
	  if (firstpath[0] == '\0')
	  {
	    sprintf(firstpath, "%s/boards/deleted/%s", BBSHOME, fname);
	    firstpathbase = firstpath + strlen(BBSHOME) + strlen("/boards/");
	  }
	  if (storeDB(HEADER[MID_H], (char *) fileglue("deleted/%s", fname)) < 0)
	  {
	    /* should do something */
	    bbslog("store DB fail\n");
	    /* return -1; */
	  }
	  bbsfeedslog(fileglue("deleted/%s", fname), 'D');

#ifdef OLDDISPATCH
	  {
	    char board[256];
	    newsfeeds_t *nf;
	    char *filebase = filename + strlen(BBSHOME) + strlen("/boards/");
	    char *filetail = strrchr(filename, '/');
	    if (filetail != NULL)
	    {
	      strncpy(board, filebase, filetail - filebase);
	      nf = (newsfeeds_t *) search_board(board);
	      if (nf != NULL && nf->board && nf->path)
	      {
		feedfplog(nf, firstpathbase, 'D');
	      }
	    }
	  }
#endif
	}
	else
	{
	  bbslog(" fname is null %s %s\n", boardhome, filename);
	  return -1;
	}
      }
#else
      /* bbslog("**** %s should be removed\n", filename); */
      unlink(filename);
#endif

      if (xfrom = strrchr(file, '/'))
      {
	*xfrom++ = '\0';
	cancel_article(BBSHOME, file, xfrom);
      }
    }
  }

#ifndef	MapleBBS
  if (*firstpath)
  {
    char **splitptr, *ngptr;
    newsfeeds_t *nf;
    splitptr = (char **) BNGsplit(GROUPS);
    for (ngptr = *splitptr; ngptr != NULL; ngptr = *(++splitptr))
    {
      if (*ngptr == '\0')
	continue;
      nf = (newsfeeds_t *) search_group(ngptr);
      if (nf == NULL)
	continue;
      if (nf->board == NULL)
	continue;
      if (nf->path == NULL)
	continue;
      feedfplog(nf, firstpathbase, 'D');
    }
  }
#endif

  return 0;
}
