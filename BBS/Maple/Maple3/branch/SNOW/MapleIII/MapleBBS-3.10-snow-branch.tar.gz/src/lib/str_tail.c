char *
str_tail(str)
  char *str;
{
  while (*str)
  {
    str++;
  }
  return str;
}
