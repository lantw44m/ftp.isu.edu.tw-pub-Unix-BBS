/*-------------------------------------------------------*/
/* util/modestat.c	( NTHU CS MapleBBS Ver 3.00 )	 */
/*-------------------------------------------------------*/
/* target : �έp�ϥΪ̰ʺA	 */
/* create : 95/11/21				 	 */
/* update : 97/11/21				 	 */
/*-------------------------------------------------------*/
/* syntax : modestat [log_filename]				 */
/*-------------------------------------------------------*/


#include <stdio.h>
#include <time.h>

#define _MODES_C_

#include "bbs.h"

static char datemsg[32];

char *
Ctime(clock)
  time_t *clock;
{
  struct tm *t = localtime(clock);
  static char week[] = "��@�G�T�|����";

  /* sprintf(datemsg, "%d�~%2d��%2d��%3d:%02d:%02d �P��%.2s", */
  sprintf(datemsg, "%d�~%2d��%2d�� �P��%.2s",
    t->tm_year - 11, t->tm_mon + 1, t->tm_mday, &week[t->tm_wday << 1]);
  return (datemsg);
}


main(argc, argv)
  char *argv[];
{
  char *fname;
  FILE *fp;
  UMODELOG mlog;
	register int i, c;
 char buf[80];
  time_t sum;

  if (argc < 2)
  {
    chdir(BBSHOME);
    fname = FN_MODE_CUR;
  }
  else
    fname = argv[1];

  if ((fp = fopen(fname, "rb")) == NULL)
  {
    perror("Can't open file");
    exit(1);
  }

  while (!feof(fp))
  {
    if(! fread(&mlog, sizeof(UMODELOG), 1, fp)) break;

	for (i = c = 0, sum = 0; i <= M_MAX; i++)
	{
	  struct tm *tt;

     sum += mlog.used_time[i];
	  tt = localtime(&mlog.used_time[i]);
	  sprintf(buf + (c * 22), "%-12s%02d��%02d��  ", ModeTypeTable[i], tt->tm_min, tt->tm_sec);

	  if (++c == 3)
	  {
	    printf(buf);
	    printf("\n");
	    c = 0;
	  }
	}
	printf("�`�@���d�ɶ�: %s\n", Ctime(&sum));
  }


  fclose(fp);
  exit(0);
}
