#include "bbs.h"

int main(int argc , char **argv)
{
  int cmd;
  cmd = XO_MOVE - XO_TALL;
  printf("cmd:%x %d\n" , cmd , cmd);

}