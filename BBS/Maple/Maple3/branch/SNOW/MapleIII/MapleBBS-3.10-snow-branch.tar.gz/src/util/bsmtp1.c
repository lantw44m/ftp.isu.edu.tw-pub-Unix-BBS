/*-------------------------------------------------------*/
/* util/bsmtp.c		( NTHU CS MapleBBS Ver 3.00 )	 */
/*-------------------------------------------------------*/
/* target : deliver mail to smtp host for bbs	 	 */
/* create : 95/03/29				 	 */
/* update : 97/03/29				 	 */
/*-------------------------------------------------------*/
/* syntax : bdeliver [smtp_host]			 */
/*-------------------------------------------------------*/


#include "bbs.h"


#include <sys/wait.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <netdb.h>


#define SMTP_PORT	25
#define	SMTP_PERIOD	(4 * 60)

#define	SMTP_TIMEOUT	(5 * 60)
#define	SEND_TIMEOUT	(5 * 60)


#define	DEBUG


#define	TCP_BUFSIZ	2048	/* 4096 */
#define	TCP_LINSIZ	256


#define	TCP_READ	0
#define	TCP_WRITE	1


#define	MAIL_XMIT	"run/.MY"
#define	MAIL_UUFILE	"run/.MU"
#define	MAIL_LOGFILE	"run/bsmtp.dbg"
#define	MAIL_POOLSIZE	32768


static int msize, mleng;
static char *mpool;


/* ----------------------------------------------------- */
/* operation log and debug information			 */
/* ----------------------------------------------------- */


static FILE *flog;		/* log file */


static void
logit(msg)
  char *msg;
{
  time_t now;
  struct tm *p;

  time(&now);
  p = localtime(&now);
  fprintf(flog, "%02d/%02d %02d:%02d:%02d %s\n",
    p->tm_mon + 1, p->tm_mday,
    p->tm_hour, p->tm_min, p->tm_sec, msg);
}


static void
log_init()
{
  flog = fopen(MAIL_LOGFILE, "a");

#ifdef	DEBUG
  logit("START");
#endif
}


/* ----------------------------------------------------- */
/* buffered TCP I/O routines				 */
/* ----------------------------------------------------- */


static int tcp_pos;
static char tcp_pool[TCP_BUFSIZ];


static int
tcp_wait(sock, mode)
  int sock;
  int mode;
{
  fd_set fset, xset, *rptr, *wptr;
  struct timeval tv;

  FD_ZERO(&fset);
  FD_ZERO(&xset);
  FD_SET(sock, &fset);
  FD_SET(sock, &xset);
  tv.tv_sec = 240;
  tv.tv_usec = 0;

  if (mode == TCP_WRITE)
  {
    rptr = NULL;
    wptr = &fset;
  }
  else
  {
    wptr = NULL;
    rptr = &fset;
  }

  if (select(sock + 1, rptr, wptr, &xset, &tv) <= 0)
  {
    logit("timeout");
    return -1;
  }

  if (FD_ISSET(sock, &xset))
  {
    logit("except");
    return -1;
  }

  return 0;
}


static int			/* return 0 for success */
xwrite(fd, data, size)
  int fd;
  char *data;
  int size;
{
  int len, try;

  if (tcp_wait(fd, TCP_WRITE))
    return -1;

  try = 0;
  while (size > 0)
  {
    len = write(fd, data, size);
    if (len <= 0)
    {
      sleep(5);			/* retry 12 turns & 60 sec. */
      if (++try < 12)
	continue;
      break;
    }
    data += len;
    size -= len;
  }
  return size;
}


static int
tcp_command(sock, cmd, code)
  register int sock;
  register char *cmd;
  register int code;		/* expected return value, 3-letter "220" */
{
  register int len, ret;
  char buf[1024];

  if (cmd != NULL)
  {
    len = strlen(cmd);
    if (tcp_wait(sock, TCP_WRITE))
      return -1;

    ret = write(sock, cmd, len);
    if (ret < len)
    {
      logit("Error in write() to SMTP host");
      return -1;
    }
  }

  if (tcp_wait(sock, TCP_READ))
    return -1;

  cmd = buf;
  len = read(sock, cmd, sizeof(buf));

  if (len < 3)
  {
    logit("Error in read() from SMTP host");
    return -1;
  }

  cmd[len - 2] = '\0';
  if (code == atoi(cmd))
    return 0;

  logit(cmd);

  return -1;
}


static int
tcp_puts(sock, msg, len)
  int sock;
  char *msg;
  int len;
{
  int pos;
  char *head, *tail;

  pos = tcp_pos;

  head = tcp_pool;
  tail = head + pos;
  memcpy(tail, msg, len);
  memcpy(tail + len, "\r\n", 2);
  pos += (len + 2);
  len = 0;

  if (pos >= TCP_BUFSIZ - TCP_LINSIZ)
  {
    len = xwrite(sock, head, pos);
    pos = 0;
  }

  tcp_pos = pos;
  return len;
}


static int
tcp_flush(sock)
  int sock;
{
  int pos;
  char *head, *tail;

  pos = tcp_pos;
  head = tcp_pool;
  tail = head + pos;
  memcpy(tail, "\r\n.\r\n", 5);
  return xwrite(sock, head, pos + 5);
}


/* ----------------------------------------------------- */
/* DNS MX routines					 */
/* ----------------------------------------------------- */


#include <arpa/nameser.h>
#include <resolv.h>


extern int errno;
extern int h_errno;


typedef struct
{
  unsigned char d[4];
}      ip_addr;


/*
 * *  The standard udp packet size PACKETSZ (512) is not sufficient for some *
 * nameserver answers containing very many resource records. The resolver *
 * may switch to tcp and retry if it detects udp packet overflow. *  Also
 * note that the resolver routines res_query and res_search return *  the
 * size of the *un*truncated answer in case the supplied answer buffer *  it
 * not big enough to accommodate the entire answer.
 */


#ifndef MAXPACKET
# define MAXPACKET 8192		/* max packet size used internally by BIND */
#endif


typedef union
{
  HEADER hdr;
  u_char buf[MAXPACKET];
}     querybuf;			/* response of DNS query */


#define	MAX_MXLIST	1024


static void
dns_init()
{
  res_init();
  _res.retrans = 5;
  _res.options |= RES_USEVC;
}


#if 0
static inline
getshort(x)
  unsigned char *x;
{
  return (x[0] << 8) + x[1];
}
#endif


static unsigned short
getshort(c)
  unsigned char *c;
{
  unsigned short u;

  u = c[0];
  return (u << 8) + c[1];
}


static int
dns_query(host, qtype, ans)
  char *host;
  int qtype;
  querybuf *ans;
{
  querybuf buf;

  qtype = res_mkquery(QUERY, host, C_IN, qtype, (char *) NULL, 0, NULL,
    (char *) &buf, sizeof(buf));

  if (qtype >= 0)
  {
    qtype = res_send((char *) &buf, qtype, ans, sizeof(querybuf));

    /* avoid problems after truncation in tcp packets */

    if (qtype > sizeof(querybuf))
      qtype = sizeof(querybuf);
  }

  return qtype;
}


static void
dns_mx(domain, mxlist)
  char *domain;
  char *mxlist;
{
  querybuf ans;
  int n, ancount, qdcount;
  unsigned char *cp, *eom;
  int pref, type;

  *mxlist = 0;

logit("dns_mx");
logit(domain);

  n = dns_query(domain, T_MX, &ans);

  if (n < 0)
    return;

  /* find first satisfactory answer */

  cp = (u_char *) &ans + sizeof(HEADER);
  eom = (u_char *) &ans + n;

  for (qdcount = ntohs(ans.hdr.qdcount); qdcount--; cp += n + QFIXEDSZ)
  {
    if ((n = dn_skipname(cp, eom)) < 0)
      return;
  }

  ancount = ntohs(ans.hdr.ancount);
  domain = mxlist + MAX_MXLIST - MAXDNAME - 2;

  while (--ancount >= 0 && cp < eom)
  {
    if ((n = dn_expand(&ans, eom, cp, mxlist, MAXDNAME)) < 0)
      break;

logit(mxlist);

    cp += n;

    type = getshort(cp);
    n = getshort(cp + 8);
    cp += 10;

    if (type == T_MX)
    {
      /* pref = getshort(cp); */
      if ((dn_expand(&ans, eom, cp + 2, mxlist, MAXDNAME)) < 0)
	break;

logit("MX");
logit(mxlist);

      while (*mxlist)
	mxlist++;
      *mxlist++ = ':';

      if (mxlist >= domain)
	break;
    }

    cp += n;
  }

  *mxlist = 0;
}


static int
dns_ipx(host, sin)
  char *host;
  struct sockaddr_in *sin;
{
  querybuf ans;
  int n, ancount, qdcount;
  unsigned char *cp, *eom;
  char buf[MAXDNAME];
  int pref, type;

logit(host);

  n = dns_query(host, T_A, &ans);
  if (n < 0)
    return n;

  /* find first satisfactory answer */

  cp = (u_char *) & ans + sizeof(HEADER);
  eom = (u_char *) & ans + n;

  for (qdcount = ntohs(ans.hdr.qdcount); qdcount--; cp += n + QFIXEDSZ)
  {
    if ((n = dn_skipname(cp, eom)) < 0)
      return n;
  }

  ancount = ntohs(ans.hdr.ancount);

  while (--ancount >= 0 && cp < eom)
  {
    if ((n = dn_expand(&ans, eom, cp, buf, MAXDNAME)) < 0)
      return -1;

logit("ipx2");
logit(buf);

    cp += n;

    type = getshort(cp);
    n = getshort(cp + 8);
    cp += 10;

    if (type == T_A)
    {
      int sock;
      ip_addr *ip;

      ip = (ip_addr *) & (sin->sin_addr.s_addr);

      ip->d[0] = cp[0];
      ip->d[1] = cp[1];
      ip->d[2] = cp[2];
      ip->d[3] = cp[3];

      sock = socket(AF_INET, SOCK_STREAM, 0);
      if (sock < 0)
	return sock;

      if (!connect(sock, (struct sockaddr *) sin, sizeof(*sin)))
{
logit("conn OK");
	return sock;
}

      close(sock);
    }

    cp += n;
  }

  return -1;
}


/* ----------------------------------------------------- */
/* SMTP routines					 */
/* ----------------------------------------------------- */


static void
smtp_close(sock)
  int sock;
{
  tcp_command(sock, "QUIT\r\n", 221);
  shutdown(sock, 2);
  close(sock);
}


static int
smtp_open(site)
  char *site;
{
  int sock;
  struct sockaddr_in sin;
  char *str, *ptr, buf[256], mxlist[MAX_MXLIST];

  memset((char *) &sin, 0, sizeof(sin));
  sin.sin_family = AF_INET;
  sin.sin_port = htons(SMTP_PORT);

logit(site);

  dns_mx(site, str = mxlist);

#ifdef	DEBUG
  logit(mxlist);
#endif

  if (!*str)
    str = site;

  for (;;)
  {
    ptr = str;
    while (sock = *ptr)
    {
      if (sock == ':')
      {
	*ptr++ = '\0';
	break;
      }
      ptr++;
    }

    if (!*str)
      break;

    sock = dns_ipx(str, &sin);
    if (sock >= 0)
    {
      tcp_command(sock, NULL, 220);

      sprintf(buf, "HELO %s\r\n", MYHOSTNAME);
      if (!tcp_command(sock, buf, 250))
	return sock;

      smtp_close(sock);
      break;
    }

    str = ptr;
  }

#if 0
  host = gethostbyname(site);
  if (host == NULL)
    sin.sin_addr.s_addr = inet_addr(site);
  else
    memcpy(&sin.sin_addr.s_addr, host->h_addr, host->h_length);
#endif

  return -1;
}


/* ----------------------------------------------------- */
/* SMTP deliver						 */
/* ----------------------------------------------------- */
/* > 0 : sucess						 */
/* = 0 : ignore it					 */
/* -1 : SMTP host error, try it later			 */
/* -2 : withdraw back to user				 */
/* ----------------------------------------------------- */


static int
smtp_send(sock, mqueue)
  int sock;
  MailQueue *mqueue;
{
  int fd, fsize, method, ch, len;
  char *fpath, *data, *ptr, *body, buf[512];
  struct stat st;

  data = mpool;

#if 0
  strcpy(data, "<<�H�󤺮e�O�Ū��A�άO�ɮ׿��~�A�G�L�k�H�X�C>>\n");
  mleng = strlen(data);
#endif

  method = mqueue->method;
  fpath = mqueue->filepath;

file_open:

  fd = open(fpath, O_RDONLY);
  if (fd < 0)
  {
    goto file_error;
  }

  if (fstat(fd, &st) || !S_ISREG(st.st_mode) || (fsize = st.st_size) <= 0)
  {
    close(fd);

file_error:

    if (method & MQ_EXPUNGE)
      unlink(fpath);
    return 0;
  }

  ptr = buf;

  if (method & MQ_UUENCODE)
  {
    close(fd);

    unlink(MAIL_UUFILE);
    sprintf(ptr, "/bin/uuencode %s %s.uu > %s",
      fpath, mqueue->sender, MAIL_UUFILE);
    system(ptr);

    if (method & MQ_EXPUNGE)
      unlink(fpath);

    fpath = MAIL_UUFILE;
    method = MQ_EXPUNGE;
    goto file_open;
  }

  body = mpool;
  if (msize <= fsize)
  {
    len = fsize + (fsize >> 2);
    body = (char *) realloc(body, len);
    if (body == NULL)
      return -1;
    mpool = body;
    msize = len;
  }

  fsize = read(fd, body, fsize);
  close(fd);
  if (fsize <= 0)
  {
    goto file_error;
  }

  mleng = fsize;
  body[fsize] = '\0';

  /* --------------------------------------------------- */
  /* setup "From "					 */
  /* --------------------------------------------------- */

  if (method & MQ_JUSTIFY)	/* �����{�ҫH�� */
    sprintf(ptr, "bbs@%s", MYHOSTNAME);
  else
    sprintf(ptr, "%s.bbs@%s", mqueue->sender, MYHOSTNAME);

  /* --------------------------------------------------- */
  /* negotiation with mail server			 */
  /* --------------------------------------------------- */

  data = tcp_pool;

  sprintf(data, "MAIL FROM:<%s>\r\n", ptr);
  if (tcp_command(sock, data, 250))
    return -1;

  sprintf(data, "RCPT TO:<%s>\r\n", mqueue->rcpt);
  if (tcp_command(sock, data, 250))
  {
    tcp_command(sock, "RSET\r\n", 250);	/* reset SMTP host */

    sprintf(buf, "Error in RCPT: <%s> by <%s> [%s]",
      mqueue->rcpt, mqueue->sender, fpath);
    logit(buf);

#if 0
    if (method & MQ_EXPUNGE)
      unlink(fpath);
#endif

    return -2;
  }

  strcpy(data, "DATA\r\n");
  if (tcp_command(sock, data, 354))
  {
    tcp_command(sock, "RSET\r\n", 250);	/* reset SMTP host */

    return -2;			/* or to return 0 ? */
  }

  /* --------------------------------------------------- */
  /* begin of mail header				 */
  /* --------------------------------------------------- */

  sprintf(data, "To: %s\r\nSubject: %s\r\nX-Forwarded-By: %s (%s)\r\nX-Disclaimer: [%s] �糧�H���e�����t�d\r\n\r\n",
    mqueue->rcpt, mqueue->subject, mqueue->sender, mqueue->username, BOARDNAME);
  tcp_pos = strlen(data);

  if (method & MQ_JUSTIFY)	/* �����{�ҫH�� */
  {
    ptr = data + tcp_pos;
    sprintf(ptr, " ID: %s (%s)  E-mail: %s\r\n\r\n",
      mqueue->sender, mqueue->username, mqueue->rcpt);
    tcp_pos += strlen(ptr);
  }

  /* --------------------------------------------------- */
  /* begin of mail body					 */
  /* --------------------------------------------------- */

  ptr = body;
  for (;;)
  {
    ch = *ptr;
    if (ch == '\n' || ch == '\r' || ch == '\0')
    {
      len = ptr - body;
      if (ch == '\0' && len == 0)
	break;

      if (*body == '.' && len == 1)
	len = tcp_puts(sock, "..", 2);
      else
	len = tcp_puts(sock, body, len);

      if (len)			/* server down or busy */
      {
	return -1;
      }

      if (ch == '\0')
	break;

      ptr++;
      if (*ptr == '\n' && ch == '\r')
	ptr++;

      body = ptr;
    }
    else
    {
      ptr++;
    }
  }
  tcp_flush(sock);

  tcp_command(sock, NULL, 250);

  if (method & MQ_EXPUNGE)
    unlink(fpath);

  /* �O���H�H */

  sprintf(buf, "%-13s%c> %s", mqueue->sender,
    (method & MQ_JUSTIFY ? '=' : '-'), mqueue->rcpt);
  logit(buf);

  return fsize;
}


/* ----------------------------------------------------- */
/* chrono ==> file name (32-based)			 */
/* 0123456789ABCDEFGHIJKLMNOPQRSTUV			 */
/* ----------------------------------------------------- */


static char radix32[32] = {
  '0', '1', '2', '3', '4', '5', '6', '7',
  '8', '9', 'A', 'B', 'C', 'D', 'E', 'F',
  'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
  'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
};


static void
archiv32(chrono, fname)
  register time_t chrono;	/* 32 bits */
  register char *fname;		/* 7 chars */
{
  register char *str;

  str = fname + 7;
  *str = '\0';
  for (;;)
  {
    *(--str) = radix32[chrono & 31];
    if (str == fname)
      return;
    chrono >>= 5;
  }
}


static void
str_stamp(str, chrono)
  char *str;
  time_t *chrono;
{
  register struct tm *ptime;

  ptime = localtime(chrono);
  /* Thor.990329: y2k */
  sprintf(str, "%02d/%02d/%02d",
    ptime->tm_year % 100, ptime->tm_mon + 1, ptime->tm_mday);
}


/* ----------------------------------------------------- */
/* drawback to user					 */
/* ----------------------------------------------------- */


static void
str_lower(dst, src)
  char *dst, *src;
{
  register int ch;

  do
  {
    ch = *src++;
    if (ch >= 'A' && ch <= 'Z')
      ch |= 0x20;
    *dst++ = ch;
  } while (ch);
}


static char *
Ctime(clock)
  time_t *clock;
{
  static char datemsg[32];
  struct tm *t = localtime(clock);
  static char week[] = "��@�G�T�|����";

  sprintf(datemsg, "%d�~%2d��%2d��%3d:%02d:%02d �P��%.2s",
    t->tm_year - 11, t->tm_mon + 1, t->tm_mday,
    t->tm_hour, t->tm_min, t->tm_sec, &week[t->tm_wday << 1]);
  return (datemsg);
}


static int
draw_back(mqueue)
  MailQueue *mqueue;
{
  HDR mhdr;
  char buf[512], *ptr, userid[IDLEN + 1];
  int fd, fx;
  time_t chrono;
  FILE *fp;

  /* check if the userid is in our bbs now */

  str_lower(userid, mqueue->sender);
  sprintf(buf, "usr/%c/%s/.DIR", *userid, userid);
  fx = open(buf, O_WRONLY | O_CREAT | O_APPEND, 0600);
  if (fx < 0)
  {
    sprintf(buf, "BBS user <%s> not existed", userid);
    logit(buf);
    return -1;
  }

#ifdef	DEBUG
  logit(buf);
#endif

  /* allocate a file for the new mail */

  ptr = strchr(buf, '.');
  *ptr++ = '@';
  *ptr++ = '/';
  *ptr++ = '@';
  chrono = time(NULL);

  for (;;)
  {
    archiv32(chrono, ptr);
    fd = open(buf, O_WRONLY | O_CREAT | O_EXCL, 0600);
    if (fd >= 0)
      break;

    if (errno != EEXIST)
    {
      close(fx);
      sprintf(buf, "ERR create user <%s> file", userid);
      logit(buf);
      return -1;
    }

    chrono++;
  }

  /* copy the queue-file to the specified file */

  if ((fp = fdopen(fd, "w")) == NULL)
  {
    logit("Err fdopen()");
    close(fx);
    close(fd);
    return -1;
  }

#ifdef	DEBUG
  logit(buf);			/* file name */
#endif

  memset(&mhdr, 0, sizeof(HDR));
  mhdr.chrono = chrono;
  mhdr.xmode = MAIL_INCOME;
  strcpy(mhdr.xname, ptr - 1);
  strcpy(mhdr.owner, "SYSOP");
  strcpy(mhdr.nick, "�����l�t");
  str_stamp(mhdr.date, &mhdr.chrono);
  sprintf(mhdr.title, "�h�H�q���G%.60s", mqueue->subject);

  fprintf(fp, "�@��: SYSOP (�����l�t)\n���D: %s\n�ɶ�: %s\n",
    mhdr.title, ctime(&mhdr.chrono));

  fprintf(fp, "%s (%s) �z�n�G\n", mqueue->sender, mqueue->username);
  fprintf(fp, "�x�ݦb %s �H�X���H��A���D�O�G\n  %s�A\n���H�H�O�G<%s>\n"
    "�L�k���Q�H�F�C�i�ध�`����]�O E-mail address �����A�άO\n"
    "�����ö�B�������L�k���H���C�S�N��H�h�^�p�U�A�ƽЬd�ӡC\n--\n\n",
    Ctime(&mqueue->mailtime), mqueue->subject, mqueue->rcpt);

  fwrite(mpool, mleng, 1, fp);
  fclose(fp);

  /* append the record to the MAIL control file */

  write(fx, &mhdr, sizeof(HDR));
  close(fx);
  sprintf(buf, "back: [%s] <%s> %s",
    mqueue->sender, mqueue->rcpt, mqueue->subject);
  logit(buf);
  return 0;
}


/* ----------------------------------------------------- */
/* timeout routines                                      */
/* ----------------------------------------------------- */


static jmp_buf ap_jmp;


static void
ap_timeout(sig)
  int sig;
{
  logit("Timeout");
  longjmp(ap_jmp, sig);
}


/* ----------------------------------------------------- */
/* mail queue						 */
/* ----------------------------------------------------- */


#if 0
typedef struct
{
  MailQueue mhead;
  int mstat;
  struct MailData *next;
}      MailData;


typedef struct MailHost
{
  char host[64];
  MailData *data;
  struct MailHost *next;
}        MailHost;


MailHost *mh_root;
#endif


static int
mq_cmp(x, y)
  MailQueue *x, *y;
{
  int cmp;

  cmp = strcasecmp(x->host, y->host);
  if (!cmp)
    cmp = y->mailtime - x->mailtime;
  return cmp;
}


static void
smtp()
{
  int cc, count, bytes, xmit, back, qfile;
  MailQueue *mq, *mq_pool;
  char *host, *fqdn, buf[256];
  struct stat st;

  static char str_null[] = "\0x7f";

  cc = open(MAIL_XMIT, O_RDONLY);
  if (cc < 0)
    return;

  if (fstat(cc, &st) || (count = st.st_size) <= 0)
  {
    close(cc);
    return;
  }

  mq_pool = (MailQueue *) malloc(count);
  count = read(cc, mq_pool, count) / sizeof(MailQueue);
  close(cc);

  if (count)
  {
    mq = mq_pool + count;

    /* locate mail host */

    while (--mq >= mq_pool)
    {
      host = mq->rcpt;

logit(host);

      for (;;)
      {
	cc = *host++;

	if (cc == '@')
	  break;

	if (cc == '\0')
	{
	  host = str_null;
	  break;
	}
      }
      mq->host = host;
    }

    /* sort mail queue according to mail host */

    if (count > 1)
      qsort(mq_pool, count, sizeof(MailQueue), mq_cmp);

    /* deliver the mails */

    mq = mq_pool + count;

    cc = qfile = -1;
    back = count = bytes = 0;
    fqdn = str_null;

    while (--mq >= mq_pool)
    {
      host = mq->host;
      if (host == str_null)
      {
	draw_back(mq);
	continue;
      }

      if (strcasecmp(host, fqdn))
      {
	if (cc >= 0)
	  smtp_close(cc);

	cc = -1;

	if (setjmp(ap_jmp) == 0)
	{
	  signal(SIGALRM, ap_timeout);
	  alarm(SMTP_TIMEOUT);

	  cc = smtp_open(fqdn = host);
	  alarm(0);
	}
      }

      if (cc < 0)
      {
	draw_back(mq);
	continue;
      }

#ifdef	DEBUG
      logit(mq->subject);
#endif

      xmit = -1;

      if (setjmp(ap_jmp) == 0)
      {
	signal(SIGALRM, ap_timeout);
	alarm(SEND_TIMEOUT);

	xmit = smtp_send(cc, mq);

	alarm(0);
      }

#ifdef	DEBUG
      logit(mq->filepath);
#endif

      if (xmit > 0)
      {
	bytes += xmit;
	count++;
      }
      else if (xmit == -1)	/* server side error, drop it */
      {
	smtp_close(cc);
	cc = xmit;
	draw_back(mq);
	back++;
      }
      else if (xmit == -2)	/* user side error, draw back */
      {
	draw_back(mq);
	back++;

#if 0
	if (mq->mailtime < queue_time)
	{
	  draw_back(mq);
	  back++;
	}
	else
	{			/* try it later */
	  if (qfile < 0)
	    qfile = open(MAIL_QUEUE, O_WRONLY | O_CREAT | O_APPEND, 0600);
	  write(qfile, &mqueue, sizeof(mqueue));
	}
#endif
      }

    }

    if (cc >= 0)
      smtp_close(cc);

    if (qfile >= 0)
      close(qfile);

  sprintf(buf, "send: %d, byte: %d, back:%d",
    count, bytes, back);
  logit(buf);
  fflush(flog);
  }

  free(mq_pool);
}


/* ----------------------------------------------------- */
/* main routines					 */
/* ----------------------------------------------------- */


static void
term()
{
  fclose(flog);
  exit(0);
}


main()
{
#if 0
  close(0);
  close(1);
  close(2);

  if (fork())
    exit(0);
#endif

  setgid(BBSGID);
  setuid(BBSUID);
  chdir(BBSHOME);
  umask(077);

  mpool = (char *) malloc(msize = MAIL_POOLSIZE);

  log_init();

  signal(SIGTERM, term);

#if 0
  signal(SIGBUS, term);
  signal(SIGSEGV, term);
#else
  signal(SIGBUS, SIG_IGN);
  signal(SIGSEGV, SIG_IGN);
#endif

  dns_init();

  for (;;)
  {
    smtp();
    term();
    sleep(SMTP_PERIOD);
    /* rename(MAIL_QUEUE, MAIL_XMIT); */
  }
}
