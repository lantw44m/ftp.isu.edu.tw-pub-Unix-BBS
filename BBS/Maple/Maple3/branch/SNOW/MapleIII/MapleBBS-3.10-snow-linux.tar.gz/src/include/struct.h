/*-------------------------------------------------------*/
/* struct.h	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : all definitions about data structure	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#ifndef _STRUCT_H_
#define _STRUCT_H_


#define STRLEN   80		/* Length of most string data */
#define BTLEN    48		/* Length of board title */
#define BMLEN    36		/* Length of board managers */
#define TTLEN    72		/* Length of title */
#define FNLEN    28		/* Length of filename  */
#define IDLEN	 12		/* Length of board / user id */
#define PASSLEN  14		/* Length of encrypted passwd field */


#define	BFLAG(n)	(1 << n)/* 32 bit-wise flag */


typedef char const *STRING;
typedef unsigned char uschar;	/* length = 1 */
typedef unsigned int usint;	/* length = 4 */
typedef struct UTMP UTMP;


/* ----------------------------------------------------- */
/* �ϥΪ̱b�� .ACCT struct : 512 bytes			 */
/* ----------------------------------------------------- */


typedef struct
{
  int userno;			/* unique positive code */
  char userid[IDLEN + 1];
  char passwd[PASSLEN];
  uschar signature;
  char realname[20];
  char username[24];
  usint userlevel;
  int numlogins;
  int numposts;
  usint ufo;
  time_t firstlogin;
  time_t lastlogin;
  time_t staytime;		/* �`�@���d�ɶ� */
  time_t tcheck;		/* time to check mbox/pal */
  char lasthost[32];
  int numemail;			/* �H�o Inetrnet E-mail ���� */
  time_t tvalid;		/* �q�L�{�ҡB��� mail address ���ɶ� */
  char email[60];
  char address[60];
  char justify[60];		/* FROM of replied justify mail */
  char vmail[60];		/* �q�L�{�Ҥ� email */
  char ident[140 - 20];
  time_t vtime;			/* validate time */
}      ACCT;


typedef struct			/* 16 bytes */
{
  time_t uptime;
  char userid[IDLEN];
}      SCHEMA;


#ifdef	HAVE_REGISTER_FORM

typedef struct	/* ���U���� (Register From) 256 bytes */
{
  int userno;
  time_t rtime;
  char userid[IDLEN + 1];
  char agent[IDLEN + 1];
  char realname[20];
  char career[50];
  char address[60];
  char phone[20];
  char reply[72];
}      RFORM;

#endif


/* ----------------------------------------------------- */
/* User Flag Option : flags in ACCT.ufo			 */
/* ----------------------------------------------------- */


#define	UFO_COLOR	BFLAG(0)	/* true if the ANSI color mode open */
#define	UFO_MOVIE	BFLAG(1)	/* true if show movie */
#define	UFO_BRDNEW	BFLAG(2)	/* �s�峹�Ҧ� */
#define UFO_BNOTE	BFLAG(3)	/* ��ܶi�O�e�� */
#define UFO_VEDIT	BFLAG(4)	/* ²�ƽs�边 */

#define UFO_PAGER	BFLAG(5)	/* �����I�s�� */
#define	UFO_QUIET	BFLAG(6)	/* ���f�b�H�ҡA�ӵL������ */
#define UFO_PAL		BFLAG(7)	/* true if show pals only */
#define	UFO_ALOHA	BFLAG(8)	/* �W���ɥD�ʳq���n�� */

#define	UFO_MOTD	BFLAG(9)	/* ²�ƶi���e�� */

#define UFO_CLOAK	BFLAG(19)	/* true if cloak was ON */
#define UFO_ACL		BFLAG(20)	/* true if ACL was ON */

#define	UFO_MPAGER	BFLAG(10)	/* lkchu.990428: �q�l�l��ǩI */
#define	UFO_NWLOG	BFLAG(11)	/* lkchu.990510: ���s��ܬ��� */
#define UFO_NTLOG	BFLAG(12)	/* lkchu.990510: ���s��Ѭ��� */


/* ----------------------------------------------------- */
/* bit 24-27 : client/server or telnet BBS		 */
/* ----------------------------------------------------- */

#define	UFO_BBTP	BFLAG(24)	/* ON : client/server */
#define	UFO_SPARE	BFLAG(25)	/* ready for connection */

/* these are flags in UTMP.ufo */

#define	UFO_BIFF	BFLAG(27)	/* ���s�H�� */
#define	UFO_SOCKET	BFLAG(28)	/* true if socket port active */
#define	UFO_REJECT	BFLAG(29)	/* true if reject any body */

/* special purpose */

#define	UFO_FCACHE	BFLAG(30)	/* ���n�� */
#define	UFO_MQUOTA	BFLAG(31)	/* �H�c�����ݲM�z���H�� */

#define UFO_UTMP_MASK	(UFO_BIFF)	
/* Thor.980805: �w�qufo���Hutmp->ufo�����L��flag, �ѨM�Pcuser.ufo���P�B�����D */

#include "hdr.h"


/* ----------------------------------------------------- */
/* control of board vote : 256 bytes			 */
/* ----------------------------------------------------- */


typedef struct VoteControlHeader
{
  time_t chrono;		/* �벼�}��ɶ� */  /* Thor:�� key */
 						/* �ӥB match HDR chrono */
  time_t bstamp;		/* �ݪO���ѥN�X */  /* Thor:�� key */
  time_t vclose;		/* �벼�����ɶ� */
  char xname[17];		/* �D�ɦW */ /* Thor: match HDR��xname */
  char vsort;			/* �}�����G�O�_�Ƨ� */
  char vpercent;		/* �O�_��ܦʤ���� */
  char cdate[9];		/* ������� */ /* Thor.990329: �u�����, y2k */
  int maxblt;			/* �C�H�i��X�� */
  char owner[130];		/* �|��H */
  char date[9];			/* �}�l��� */ /* Thor: match HDR��date*/
  char title[TTLEN + 1];	/* �벼�D�D */
}           VCH;


typedef char vitem_t[32];	/* �벼�ﶵ */


/* filepath : brd/<board>/.VCH, brd/<board>/@/... */


/* ----------------------------------------------------- */
/* Mail-Queue struct : 256 bytes			 */
/* ----------------------------------------------------- */


typedef struct
{
  time_t mailtime;		/* �H�H�ɶ� */
  char method;
  char sender[IDLEN + 1];
  char username[24];
  char subject[TTLEN + 1];
  char rcpt[60];
  char filepath[77];
  char *niamod;			/* reverse domain */
}      MailQueue;


#define	MQ_UUENCODE	0x01	/* �� uuencode �A�H�X */
#define	MQ_JUSTIFY	0x02	/* �����{�ҫH�� */


/* ----------------------------------------------------- */
/* PAL : friend struct : 64 bytes			 */
/* ----------------------------------------------------- */


typedef struct
{
  char userid[IDLEN + 1];
  char ftype;
  char ship[46];
  int userno;
}      PAL;


#define	PAL_BAD	0x02	/* �n�� vs �l�� */


/* ----------------------------------------------------- */
/* structure for call-in message : 100 bytes		 */
/* ----------------------------------------------------- */


typedef struct
{
  time_t btime;
  UTMP *caller;			/* who call-in me ? */
  int sender;			/* calling userno */
  int recver;			/* called userno */
  char userid[IDLEN + 1];
  char msg[71];			/* ���T */
}      BMW;			/* bbs message write */


/* ----------------------------------------------------- */
/* Structure used in UTMP file : 128 bytes		 */
/* ----------------------------------------------------- */


struct UTMP
{
  pid_t pid;			/* process ID */
  int userno;			/* user number in .PASSWDS */

  time_t idle_time;		/* active time for last event */
  usint mode;			/* bbsmode */
  usint ufo;			/* the same as userec.ufo */
  u_long in_addr;		/* Internet address */
  int sockport;			/* socket port for talk */
  UTMP *talker;			/* who talk-to me ? */

  BMW *mslot[BMW_PER_USER];

  char userid[IDLEN + 1];	/* user's ID */
  char mateid[IDLEN + 1];	/* partner's ID */
  char username[24];

  char from[34];		/* remote host */

#ifdef	PREFORK
  int bgen;			/* generation */
#endif
};


/* ----------------------------------------------------- */
/* BOARDS struct : 128 bytes				 */
/* ----------------------------------------------------- */


typedef struct BoardHeader
{
  char brdname[IDLEN + 1];	/* board ID */
  char title[BTLEN + 1];
  char BM[BMLEN + 1];		/* BMs' uid, token '/' */

  uschar bvote;			/* �@���X���벼�|�椤 */

  time_t bstamp;		/* �إ߬ݪO���ɶ�, unique */
  usint readlevel;		/* �\Ū�峹���v�� */
  usint postlevel;		/* �o���峹���v�� */
  usint battr;			/* �ݪO�ݩ� */
  time_t btime;			/* .DIR �� st_mtime */
  int bpost;			/* �@���X�g post */
  time_t blast;			/* �̫�@�g post ���ɶ� */
}           BRD;


#define	BRD_NOZAP	0x01	/* ���i zap */
#define	BRD_NOTRAN	0x02	/* ����H */
#define	BRD_NOCOUNT	0x04	/* ���p�峹�o���g�� */
#define	BRD_NOSTAT	0x08	/* ���ǤJ�������D�έp */
#define	BRD_NOVOTE	0x10	/* �����G�벼���G�� [sysop] �O */
#define	BRD_ANONYMOUS	0x20	/* �ΦW�ݪO */
#define BRD_NOFORWARD   0x40    /* lkchu.981201: ���i��H */


/* ----------------------------------------------------- */
/* Class image						 */
/* ----------------------------------------------------- */


#define CLASS_INIFILE   "Class"
#define CLASS_IMGFILE	"run/class.img"


#define	CH_END	-1
#define	CH_TTLEN	64


typedef	struct
{
  int count;
  char title[CH_TTLEN];
  short chno[0];
} ClassHeader;


/* ----------------------------------------------------- */
/* cache.c ���B�Ϊ���Ƶ��c				 */
/* ----------------------------------------------------- */


typedef struct
{
  int shot[MOVIE_MAX]; /* Thor.980805: �i���٭n�A�[1,�]�X�z�d��0..MOVIE_MAX */
  char film[MOVIE_SIZE];
} FCACHE;


#define	FILM_SIZ	4000	/* max size for each film */


#define	FILM_WELCOME	0
#define	FILM_GOODBYE	1
#define	FILM_APPLY	2	/* new account */
#define	FILM_TRYOUT	3
#define	FILM_POST	4
#define	FILM_GEM	5	/* help message */
#define	FILM_BOARD	6
#define	FILM_CLASS	7
#define	FILM_PAL	8
#define	FILM_MAIL	9
#define	FILM_ULIST	10
#define	FILM_VOTE	11
#define	FILM_MORE	12
#define	FILM_EDIT	13
#define FILM_BMW        14
#define	FILM_MOVIE	15	/* normal movies */


typedef struct
{
  UTMP uslot[MAXACTIVE];	/* UTMP slots */
  usint count;			/* number of active session */
  usint offset;			/* offset for last active UTMP */

  double sysload[3];
  int avgload;

  BMW *mbase;			/* sequential pointer for BMW */
  BMW mpool[BMW_MAX];

#if 0
  int cs_gen;			/* generation number for CS version */
  int tn_gen;			/* generation number for TN version */
#endif

} UCACHE;


typedef struct
{
  BRD bcache[MAXBOARD];
  int number;
  time_t uptime;
} BCACHE;


/* ----------------------------------------------------- */
/* screen.c ���B�Ϊ���Ƶ��c				 */
/* ----------------------------------------------------- */


/* #define ANSILINELEN (160) */	/* Maximum Screen width in chars */ 
/* ���] 160 �ӴN���ΤF�A�̦h�i�H�� 255 */
#define ANSILINELEN (176)       /* Maximum Screen width in chars */
/* Thor.991017: ��bobolon�n�D�W�� 176 */   

/* Screen Line buffer modes */


#define SL_MODIFIED	(1)	/* if line has been modifed, screen output */
#define SL_STANDOUT	(2)	/* if this line contains standout code */
#define SL_ANSICODE	(4)	/* if this line contains ANSI code */


typedef struct screenline
{
  uschar oldlen;		/* previous line length */
  uschar len;			/* current length of line */
  uschar width;			/* padding length of ANSI codes */
  uschar mode;			/* status of line, as far as update */
  uschar smod;			/* start of modified data */
  uschar emod;			/* end of modified data */
  uschar sso;			/* start of standout data */
  uschar eso;			/* end of standout data */
  uschar data[ANSILINELEN];
}          screenline;


typedef struct LinkList
{
  struct LinkList *next;
  char data[0];
}        LinkList;


/* ----------------------------------------------------- */
/* xover.c ���B�Ϊ���Ƶ��c				 */
/* ----------------------------------------------------- */


typedef struct OverView
{
  int pos;			/* current position */
  int top;			/* top */
  int max;			/* max */
  
  int key;			/* key */
  /* Thor.000104:����:for gem, board permission & state */   
  
  char *xyz;			/* staff */
  struct OverView *nxt;		/* next */
  char dir[0];			/* data path */
}        XO;


typedef struct
{
  int key;
  int (*func) ();
}      KeyFunc;


typedef struct
{
  XO *xo;
  KeyFunc *cb;
  int mode;
} XZ;


typedef struct
{
  time_t chrono;
  int recno;
}      TagItem;


#ifdef MODE_STAT
typedef struct
{
  time_t logtime;
  time_t used_time[30];
} UMODELOG;


typedef struct
{
  time_t logtime;
  time_t used_time[30];
  int count[30];
  int usercount;
} MODELOG;
#endif


#if 0
/* ----------------------------------------------------- */
/* util/spamstat.c ���B�Ϊ���Ƶ��c			 */
/* ----------------------------------------------------- */


typedef struct
{
  int count;
  int xfrom;		/* hash code of from */
  int xto;
  int xtitle;
  char from[80];
  char to[80];
  char title[80];
} SpamStat;
#endif


#endif				/* _STRUCT_H_ */
