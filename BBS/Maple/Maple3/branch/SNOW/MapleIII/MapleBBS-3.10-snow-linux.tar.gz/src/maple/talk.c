/*-------------------------------------------------------*/
/* talk.c	( NTHU CS MapleBBS Ver 3.00 )		 */
/*-------------------------------------------------------*/
/* target : talk/query/friend(pal) routines	 	 */
/* create : 95/03/29				 	 */
/* update : 97/03/29				 	 */
/*-------------------------------------------------------*/


#define	_MODES_C_
#define	PAL_MAX		200	/* �n�ͦW��W�� */


#include "bbs.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#ifdef REDHAT
#undef LINUX
#endif
/* Thor.981221: RedHat���Цb�� #undef LINUX */

static int pal_count;
static int *pal_pool;


extern UCACHE *ushm;
extern XZ xz[];


#ifdef EVERY_Z
extern int vio_fd;		/* Thor.0725: ��talk,chat�i��^z�@�ǳ� */
extern int holdon_fd;
#endif


typedef struct
{
  int curcol, curln;
  int sline, eline;
}      talk_win;


typedef UTMP *pickup;


void my_query();


/* ----------------------------------------------------- */
/* �O�� pal �� user number				 */
/* ----------------------------------------------------- */

#define PICKUP_WAYS	4

static int pickup_way;

static char page_requestor[40];


char *
bmode(up, simple)
  UTMP *up;
  int simple;
{
  static char modestr[32];
  int mode;
  char *word;

  word = ModeTypeTable[mode = up->mode];
  if (simple)
    return (word);

  if (mode < M_TALK || mode > M_QUERY)
    return (word);

  if (mode != M_QUERY && !HAS_PERM(PERM_SEECLOAK) && (up->ufo & UFO_CLOAK))
    return (word); /* Thor.980805: ����: �������H���|�Q���D���talk */

  sprintf(modestr, "%s [%s]", word, up->mateid);
  return (modestr);
}


/* ----------------------------------------------------- */
/* �n�ͦW��G�d�ߪ��A�B�ͽ˴y�z				 */
/* ----------------------------------------------------- */


/* Thor: �Ǧ^�� -> 0 for good, 1 for normal, 2 for bad */


#if 0
static int
pal_belong(userid, uno)
  char *userid;
  int uno;
{
  PAL *head, *tail;
  char *fimage, fpath[64];
  int fsize, ans;

  ans = 1;			/* �䤣�쬰 normal */

  if (*userid)
  {
    usr_fpath(fpath, userid, FN_PAL);

    fimage = f_map(fpath, &fsize);
    if (fimage != (char *) -1)
    {
      head = (PAL *) fimage;
      tail = (PAL *) (fimage + fsize);
      do
      {
	if (uno == head->userno)
	{
	  ans = head->ftype;	/* Thor: �쬰 2-, �{�����Ǧ^ */
	  break;
	}
      } while (++head < tail);
      munmap(fimage, fsize);
    }
  }

  return ans;
}
#endif


static int
can_override(up)
  UTMP *up;
{
  int self, ufo, can, fd;
  char fpath[64];
  PAL *pal;

  if (up->userno == (self = cuser.userno))
    return NA;

  if (HAS_PERM(PERM_SYSOP | PERM_ACCOUNTS))	/* �����B�b���޲z�� */
    return YEA;

  ufo = up->ufo;

  if (ufo & UFO_QUIET)		/* �������� */
    return NA;

  if (!(ufo & (UFO_PAGER | UFO_REJECT)))
    return YEA;			/* �I�s���S�����A��L�l�� */

  if ((ufo & UFO_PAGER) && !(ufo & UFO_FCACHE))
    return NA;

#if 0
  self = pal_belong(up->userid, self);
#endif

  can = 1;			/* �䤣�쬰 normal */

  usr_fpath(fpath, up->userid, FN_PAL);
  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    mgets(-1);
    while (pal = mread(fd, sizeof(PAL)))
    {
      if (self == pal->userno)
      {
	can = pal->ftype;
	break;
      }
    }
    close(fd);
  }

  return (ufo & UFO_PAGER)
    ? can == 0			/* �u���n�ͥi�H */
    : can < 2 /* �u�n���O�l�� */ ;
}


/* ----------------------------------------------------- */
/* �n�ͦW��G�s�W�B�R���B�ק�B���J�B�P�B		 */
/* ----------------------------------------------------- */


int
is_pal(userno)
  int userno;
{
  int count, *cache, datum, mid;

  if (cache = pal_pool)
  {
    for (count = pal_count; count > 0;)
    {
      datum = cache[mid = count >> 1];
      if (userno == datum)
	return 1;
      if (userno > datum)
      {
	cache += (++mid);
	count -= mid;
      }
      else
      {
	count = mid;
      }
    }
  }
  return 0;
}


static int
int_cmp(a, b)
  int *a;
  int *b;
{
  return *a - *b;
}


void
pal_cache()
{
  int count, fsize, ufo;
  int *plist, *cache;
  PAL *phead, *ptail;
  char *fimage, fpath[64];

  if (cache = pal_pool)
    free(cache);

  cache = NULL;
  count = 0;
  ufo = cuser.ufo & ~(/* UFO_BIFF |*/ UFO_REJECT | UFO_FCACHE);
  /* Thor.980805: �� BIFF�n���S���Ӥj���Y */

  usr_fpath(fpath, cuser.userid, FN_PAL);
  fimage = f_img(fpath, &fsize);
  if (fimage != NULL)
  {
    if (fsize > PAL_MAX * sizeof(PAL))
    {
      sprintf(fpath, "%-13s%d\n", cuser.userid, fsize);
      f_cat("run/pal", fpath);
      fsize = PAL_MAX * sizeof(PAL);
    }

    count = fsize / sizeof(PAL);
    if (count)
    {
      cache = plist = (int *) malloc(count * sizeof(int));
      phead = (PAL *) fimage;
      ptail = (PAL *) (fimage + fsize);
      do
      {
	if (phead->ftype & PAL_BAD)
	{
	  ufo |= UFO_REJECT;
	  count--;
	}
	else
	{
	  *plist++ = phead->userno;
	}
      } while (++phead < ptail);

      if (count > 0)
      {
	ufo |= UFO_FCACHE;
	if (count > 1)
	  xsort(cache, count, sizeof(int), int_cmp);
      }
      else
      {
	free(cache);
	cache = NULL;
      }
    }
    free(fimage);
  }

  pal_pool = cache;
  pal_count = count;
  /* cuser.ufo = ufo; */
  if (cutmp)
  {
    ufo = (ufo & ~UFO_UTMP_MASK) | (cutmp->ufo & UFO_UTMP_MASK);
    /* Thor.980805: �ѨM cutmp.ufo�M cuser.ufo���P�B���D */
    cutmp->ufo = ufo;
  }
  cuser.ufo = ufo;
}


void
pal_sync(fpath)
  char *fpath;
{
  int fd, size;
  struct stat st;
  char buf[64];

  if (!fpath)
  {
    fpath = buf;
    usr_fpath(fpath, cuser.userid, FN_PAL);
  }

  if ((fd = open(fpath, O_RDWR, 0600)) < 0)
    return;

  outz("�� ��ƾ�z�]�֤��A�еy�� \033[5m...\033[m");
  refresh();

  if (!fstat(fd, &st) && (size = st.st_size) > 0)
  {
    PAL *pbase, *phead, *ptail;
    int userno;

    pbase = phead = (PAL *) malloc(size);
    size = read(fd, pbase, size);
    if (size >= sizeof(PAL))
    {
      ptail = (PAL *) ((char *) pbase + size);
      while (phead < ptail)
      {
	userno = phead->userno;
	if (userno > 0 && userno == acct_userno(phead->userid))
	{
	  phead++;
	  continue;
	}

	ptail--;
	if (phead >= ptail)
	  break;
	memcpy(phead, ptail, sizeof(PAL));
      }

      size = (char *) ptail - (char *) pbase;
      if (size > 0)
      {
	if (size > sizeof(PAL))
	{
	  if (size > 128 * sizeof(PAL))
	    vmsg("�z���n�ͦW��Ӧh�A�е��[��z");
	  xsort(pbase, size / sizeof(PAL), sizeof(PAL), str_cmp);
	}

	/* Thor.0709: �O�_�n�[�W�������Ъ��n�ͪ��ʧ@? */

	lseek(fd, 0, SEEK_SET);
	write(fd, pbase, size);
	ftruncate(fd, size);
      }
    }
    free(pbase);
  }
  close(fd);

  if (size <= 0)
    unlink(fpath);

  /* Thor.990507: �M�@�U"��ƾ�z�]�֤�" */ 
  move(b_lines, 0);      
  clrtoeol();    
}


/* ----------------------------------------------------- */
/* �n�ͦW��G��榡�ާ@�ɭ��y�z				 */
/* ----------------------------------------------------- */


static int pal_add();


static void
pal_item(num, pal)
  int num;
  PAL *pal;
{
  prints("%6d %-3s%-14s%s\n", num, pal->ftype & PAL_BAD ? "��" : "",
    pal->userid, pal->ship);
}


static int
pal_body(xo)
  XO *xo;
{
  PAL *pal;
  int num, max, tail;

  move(3, 0);
  clrtobot();
  max = xo->max;
  if (max <= 0)
  {
    if (vans("�n��s�B�Ͷ�(Y/N)�H[N] ") == 'y')
      return pal_add(xo);
    return XO_QUIT;
  }

  pal = (PAL *) xo_pool;
  num = xo->top;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  do
  {
    pal_item(++num, pal++);
  } while (num < max);

  return XO_NONE;
}


static int
pal_head(xo)
  XO *xo;
{
  vs_head("�n�ͦW��", str_site);
  outs("\
  [��]���} a)�s�W c)�ק� d)�R�� m)�H�H s)��z w)�����ǩI [��]�d�� [h]elp\n\
\033[44m  �s��    �N ��         ��       ��                                           \033[m");
  return pal_body(xo);
}


static int
pal_load(xo)
  XO *xo;
{
  xo_load(xo, sizeof(PAL));
  return pal_body(xo);
}


static int
pal_init(xo)
  XO *xo;
{
  xo_load(xo, sizeof(PAL));
  return pal_head(xo);
}


static void
pal_edit(pal, echo)
  PAL *pal;
  int echo;
{
  if (echo == DOECHO)
    memset(pal, 0, sizeof(PAL));
  vget(b_lines, 0, "�ͽˡG", pal->ship, sizeof(pal->ship), echo);
  pal->ftype = vans("�l��(Y/N)�H[N] ") == 'y' ? PAL_BAD : 0;
}


static int
pal_add(xo)
  XO *xo;
{
  ACCT acct;
  int userno;

  if (xo->max >= PAL_MAX)
  {
    vmsg("�z���n�ͦW��Ӧh�A�е��[��z");
    return XO_FOOT;
  }

  userno = acct_get(msg_uid, &acct);

  /* jhlin : for board_moderator, temporarily */

#if 1				/* Thor.0709: �����Х[�J */
  /* if (is_pal(userno)) */
  if ((xo->dir[0] == 'u') && is_pal(userno))
              /* lkchu.981201: �u���b moderator board �~�i���Х[�J */
  {
    vmsg("�W�椤�w�����n��");
    return XO_FOOT;
  }
  else if (userno == cuser.userno)      /* lkchu.981201: �n�ͦW�椣�i�[�ۤv */
  {
    vmsg("�ۤv�����[�J�n�ͦW�椤");
    return XO_FOOT;
  }
#endif

  if ((userno > 0) /* && !pal_state(cutmp, userno, NULL) */ )
  {
    PAL pal;

    pal_edit(&pal, DOECHO);
    strcpy(pal.userid, acct.userid);
    pal.userno = userno;
    rec_add(xo->dir, &pal, sizeof(PAL));
#ifdef	HAVE_ALOHA
    if ((xo->dir[0] == 'u') && (pal.userno != cuser.userno) && !(pal.ftype & PAL_BAD))
    {
      char fpath[64];
      BMW bmw;

      /* bmw.caller = cutmp; */		/* lkchu.981201: frienz �� utmp �L�� */
      bmw.recver = cuser.userno;
      strcpy(bmw.userid, cuser.userid);
      usr_fpath(fpath, pal.userid, FN_FRIEND_BENZ);
      rec_add(fpath, &bmw, sizeof(BMW));
    }
#endif
    xo->pos = XO_TAIL /* xo->max */ ;
    xo_load(xo, sizeof(PAL));
  }

#if 1				/* Thor.0709: �n�ͦW��P�B */
  pal_cache();
#endif

  return pal_head(xo);
}


#ifdef HAVE_ALOHA
int
cmpbmw(benz)
  BMW *benz;
{
    return benz->recver == cuser.userno;
}
#endif


static int
pal_delete(xo)
  XO *xo;
{
  if (vans(msg_del_ny) == 'y')
  {
#ifdef HAVE_ALOHA
    if (xo->dir[0] == 'u')
    {
      PAL *pal;

      pal = (PAL *) xo_pool + (xo->pos - xo->top);
      if (!(pal->ftype & PAL_BAD))
      {
        char fpath[64];

        usr_fpath(fpath, pal->userid, FN_FRIEND_BENZ);
        rec_del(fpath, sizeof(BMW), 0, cmpbmw, NULL);
      }
    }
#endif

    if (!rec_del(xo->dir, sizeof(PAL), xo->pos, NULL, NULL))
    {

#if 1				/* Thor.0709: �n�ͦW��P�B */
      pal_cache();
#endif

      return pal_load(xo);
    }
  }
  return XO_FOOT;
}


static int
pal_change(xo)
  XO *xo;
{
  PAL *pal, mate;
  int pos, cur;
#ifdef HAVE_ALOHA
  char old_ftype, fpath[64];
#endif
  
  pos = xo->pos;
  cur = pos - xo->top;
  pal = (PAL *) xo_pool + cur;

#ifdef HAVE_ALOHA
  old_ftype = pal->ftype;
  usr_fpath(fpath, pal->userid, FN_FRIEND_BENZ);
#endif
    
  mate = *pal;
  pal_edit(pal, GCARRY);
  if (memcmp(pal, &mate, sizeof(PAL)))
  {
    rec_put(xo->dir, pal, sizeof(PAL), pos);
    move(3 + cur, 0);
    pal_item(++pos, pal);
  }

#ifdef HAVE_ALOHA
  if (xo->dir[0] == 'b')	/* lkchu.981201: moderator board */
    return XO_FOOT;
  
  if ( !(old_ftype & PAL_BAD) && (pal->ftype & PAL_BAD) )
      /* lkchu.981201: �쥻�O�n��, �令�l�ͭn rec_del */
  {
    rec_del(fpath, sizeof(BMW), 0, cmpbmw, NULL);
  }
  else if ( (old_ftype & PAL_BAD) && !(pal->ftype & PAL_BAD) )
      /* lkchu.981201: �쥻�O�l��, �令�n�ͭn rec_add */
  {
    BMW bmw;

    /* bmw.caller = cutmp; */	/* lkchu.981201: frienz �� utmp �L�� */
    bmw.recver = cuser.userno;
    strcpy(bmw.userid, cuser.userid);
    rec_add(fpath, &bmw, sizeof(BMW));
  }  
#endif

  return XO_FOOT;
}


static int
pal_mail(xo)
  XO *xo;
{
  PAL *pal;
  char *userid;

  pal = (PAL *) xo_pool + (xo->pos - xo->top);
  userid = pal->userid;
  if (*userid)
  {
    vs_bar("�H  �H");
    prints("���H�H�G%s", userid);
    my_send(userid);
  }
  return pal_head(xo);
}


static int
pal_sort(xo)
  XO *xo;
{
  pal_sync(xo->dir);
  return pal_load(xo);
}


static int
pal_query(xo)
  XO *xo;
{
  PAL *pal;

  pal = (PAL *) xo_pool + (xo->pos - xo->top);
  move(1, 0);
  clrtobot();
  /* move(2, 0); *//* Thor.0810: �i�H���[��? */
  /* if(*pal->userid) *//* Thor.0806:�����n���@�U, ���ӨS�t */
  my_query(pal->userid, 1);
  return pal_head(xo);
}


static int
pal_help(xo)
  XO *xo;
{
  film_out(FILM_PAL, -1);
  return pal_head(xo);
}


KeyFunc pal_cb[] =
{
  XO_INIT, pal_init,
  XO_LOAD, pal_load,
  XO_HEAD, pal_head,
  XO_BODY, pal_body,

  'a', pal_add,
  'c', pal_change,
  'd', pal_delete,
  'm', pal_mail,
  'r', pal_query,
  Ctrl('Q'), pal_query,
  's', pal_sort,
#if 1
  'w' | XO_DL, "bin/bbcall.so:pal_bbc",
#endif

  'h', pal_help
};


int
t_pal()
{
  XO *xo;
  char fpath[64];

  usr_fpath(fpath, cuser.userid, FN_PAL);
  xz[XZ_PAL - XO_ZONE].xo = xo = xo_new(fpath);
  xover(XZ_PAL);
  pal_cache();
  free(xo);

  return 0;
}


#if 0
int
t_pal()
{
  XO *xo;

  xo = pal_xo;
  if (xo == NULL)
  {
    char fpath[64];

    usr_fpath(fpath, cuser.userid, FN_PAL);
    pal_xo = xo = xo_new(fpath);
  }
  xover(XZ_PAL);
  pal_cache();
  return 0;
}
#endif


/* ----------------------------------------------------- */
/* �T���C��: ��榡�ާ@�ɭ��y�z by lkchu                 */
/* ----------------------------------------------------- */


static void bmw_edit();


static void
bmw_item(num, bmw)
  int num;
  BMW *bmw;
{
  struct tm *ptime = localtime(&bmw->btime);

  if (bmw->sender == cuser.userno)
  {
    /* lkchu.990206: �n�ͼs�� */
    if (*bmw->userid == (char) NULL)
      strcpy(bmw->userid, "���a�n��");
      
    prints("%5d %02d:%02d �e�� %-13s%s\n", num, ptime->tm_hour, ptime->tm_min,
      bmw->userid, bmw->msg);
  }
  else
  {
    /* lkchu.990206: �n�ͼs�� */
    if(*bmw->userid == (char) NULL)
    {
      UTMP *up = utmp_find(bmw->sender);
      strcpy(bmw->userid, up->userid);
    }

    prints("%5d \033[32m%02d:%02d ���� %-13s%s\033[m\n", num, ptime->tm_hour, ptime->tm_min,
      bmw->userid, bmw->msg);
  }
}


static int
bmw_body(xo)
  XO *xo;
{
  BMW *bmw;
  int num, max, tail;

  move(3, 0);
  clrtobot();
  max = xo->max;
  if (max <= 0)
  {
    vmsg("���e�õL���T�I�s");
    return XO_QUIT;
  }

  bmw = (BMW *) xo_pool;
  num = xo->top;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  do
  {
    bmw_item(++num, bmw++);
  } while (num < max);

  return XO_NONE;
}


static int
bmw_head(xo)
  XO *xo;
{
  vs_head("��ݰT��", str_site);
  outs("\
  [��]���}  [d]�R��  [m]�H�H  [w]�ְT  [s]��s  [��]�d��  [h]elp\n\
\033[44m �s�� �� �� ���O �N ��        ��       �e                                     \033[m");
  return bmw_body(xo);
}


static int
bmw_load(xo)
  XO *xo;
{
  xo_load(xo, sizeof(BMW));
  return bmw_body(xo);
}


static int
bmw_init(xo)
  XO *xo;
{
  xo_load(xo, sizeof(BMW));
  return bmw_head(xo);
}


static int
bmw_delete(xo)
  XO *xo;
{
  if (vans(msg_del_ny) == 'y')
    if (!rec_del(xo->dir, sizeof(BMW), xo->pos, NULL, NULL))
      return bmw_load(xo);

  return XO_FOOT;
}


static int
bmw_mail(xo)
  XO *xo;
{
  BMW *bmw;
  char *userid;

  bmw = (BMW *) xo_pool + (xo->pos - xo->top);
  userid = bmw->userid;
  if (*userid)
  {
    vs_bar("�H  �H");
    prints("���H�H�G%s", userid);
    my_send(userid);
  }
  return bmw_head(xo);
}


static int
bmw_query(xo)
  XO *xo;
{
  BMW *bmw;

  bmw = (BMW *) xo_pool + (xo->pos - xo->top);
  move(1, 0);
  clrtobot();
  /* move(2, 0); *//* Thor.0810: �i�H���[��? */
  /* if(*pal->userid) *//* Thor.0806:�����n���@�U, ���ӨS�t */
  my_query(bmw->userid, 1);
  return bmw_head(xo);
}


static int
bmw_write(xo)
  XO *xo;
{
  if (HAS_PERM(PERM_PAGE))
  {
    UTMP *up;
    BMW *benz;

    benz = (BMW *) xo_pool + (xo->pos - xo->top);
    if ((up = utmp_find(benz->sender)) && can_override(up))
        /* lkchu.990104: ���H�e�� bmw �]�i�H�^ */
    {
      if ((up->ufo & UFO_CLOAK) && !HAS_PERM(PERM_SEECLOAK))
      {
        return XO_NONE;		/* lkchu.990111: �����o */
      }
      else
      {
        BMW bmw;
        char buf[20];

        sprintf(buf, "��[%s]", up->userid);
        bmw_edit(up, buf, &bmw, 0);
      }
    }
  }
  return XO_NONE;
}


static int
bmw_help(xo)
  XO *xo;
{
  film_out(FILM_BMW, -1);
  return bmw_head(xo);
}


KeyFunc bmw_cb[] =
{
  XO_INIT, bmw_init,
  XO_LOAD, bmw_load,
  XO_HEAD, bmw_head,
  XO_BODY, bmw_body,
  
  'd', bmw_delete,
  'm', bmw_mail,
  'w', bmw_write,
  'r', bmw_query,
  Ctrl('Q'), bmw_query,
  's', bmw_init,
  
  'h', bmw_help
};


int
t_bmw()
{
  xover(XZ_BMW);
  return 0;
}


#ifdef HAVE_MODERATED_BOARD
/* ----------------------------------------------------- */
/* �O�ͦW��Gmoderated board				 */
/* ----------------------------------------------------- */


#define FN_FIMAGE	"fimage"


static void
bm_image()
{
  int fd;
  char fpath[80];

  brd_fpath(fpath, currboard, FN_PAL);
  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    struct stat st;
    PAL *pal, *up;
    int count;

    fstat(fd, &st);
    if (pal = (PAL *) malloc(count = st.st_size))
    {
      count = read(fd, pal, count) / sizeof(PAL);
      if (count > 0)
      {
	int *userno;
	int c = count;

	userno = (int *) up = pal;
	do
	{
	  *userno++ = up->userno;
	  up++;
	} while (--c);

	if (count > 1)		/* Thor: �h�ƧǦ��q���鰷�d... */
	  xsort(pal, count, sizeof(int), int_cmp);

	brd_fpath(fpath, currboard, FN_FIMAGE);
	if ((count = open(fpath, O_WRONLY | O_CREAT | O_TRUNC, 0600)) >= 0)
	{
	  write(count, pal, (char *) userno - (char *) pal);
	  close(count);
	}
      }
      else  /* Thor.980811: lkchu patch: �P friend �P�B */
      {
	brd_fpath(fpath, currboard, FN_FIMAGE);
        unlink(fpath);
      }
      free(pal);
    }
    close(fd);
  }
}


int
bm_belong(board)
  char *board;
{
  int fsize, count, result;
  char fpath[80];

  result = 0;

  brd_fpath(fpath, board, FN_FIMAGE);	/* Thor: fimage�n�� sort�L! */
  board = f_img(fpath, &fsize);

  if (board != NULL)
  {
    count = fsize / sizeof(int);
    if (count > 0)
    {
      int userno, *up;
      int datum, mid;

      userno = cuser.userno;
      up = (int *) board;

      while (count > 0)
      {
	datum = up[mid = count >> 1];
	if (userno == datum)
	{
	  result = BRD_R_BIT | BRD_W_BIT;
	  break;
	}
	if (userno > datum)
	{
	  up += (++mid);
	  count -= mid;
	}
	else
	{
	  count = mid;
	}
      }
    }
    free(board);
  }
  return result;
}


int
XoBM(xo)
  XO *xo;
{
  if ((bbstate & STAT_BOARD) && (bbstate & STAT_MODERATED))
    /* && (cbhdr.readlevel == PERM_SYSOP)) */
    /*
     * Thor.1020: bbstate�� STAT_MODERATED�N�N���ŦXMODERATED BOARD,
     * ���ݦAcheck readlevel PERM_SYSOP
     */
  {
    XO *xt;
    char fpath[80];

    brd_fpath(fpath, currboard, FN_PAL);
    xz[XZ_PAL - XO_ZONE].xo = xt = xo_new(fpath);
    xover(XZ_PAL);		/* Thor: �ixover�e, pal_xo �@�w�n ready */

    /* build userno image to speed up, maybe upgreade to shm */

    bm_image();

    free(xt);

    return XO_INIT /* or post_init(xo) */ ;
  }
  return XO_NONE;
}
#endif


/* ------------------------------------- */
/* �u��ʧ@				 */
/* ------------------------------------- */


static void
showplans(userid)
  char *userid;
{
  int i;
  FILE *fp;
  char buf[256];

  usr_fpath(buf, userid, fn_plans);
  if (fp = fopen(buf, "r"))
  {
    outs("  [�W��]�G\n");
    i = MAXQUERYLINES;
    while (i-- && fgets(buf, sizeof(buf), fp))
    {
      outx(buf);
    }
    fclose(fp);
  }
}


static void
do_query(acct, paling)
  ACCT *acct;
  int paling;			/* �O�_���b�]�w�n�ͦW�� */
{
  UTMP *up;
  int userno;
  char *userid;

  utmp_mode(M_QUERY);
  userno = acct->userno;
  userid = acct->userid;
  strcpy(cutmp->mateid, userid);

  prints("%s(%s) �W�� %d ���A�峹 %d �g�A%s�q�L�����{��\n",
    userid, acct->username, acct->numlogins, acct->numposts,
    acct->userlevel & PERM_VALID ? "�w�g" : "�|��");

  prints("�W��(%s)�Ӧ�(%s)", Ctime(&acct->lastlogin), acct->lasthost);

#if defined(REALINFO) && defined(QUERY_REALNAMES)
  if (HAS_PERM(PERM_BASIC))
    prints("�u��m�W: %s\n", acct->realname);
#endif

  /* ���]�W�� login �w�L 6 �p�ɡA�K���b���W�A��� utmp_find */

  outs("\n[�ʺA] ");
  up = (acct->lastlogin < time(0) - 6 * 3600) ? NULL : utmp_find(userno);
  /* outs(up ? bmode(up, 1) : "���b���W"); */
  outs(up && (HAS_PERM(PERM_SEECLOAK) || !(up->ufo & UFO_CLOAK))? bmode(up, 1) : "���b���W"); 
  /* Thor.981108: ������ cigar �����������n�D, ���L�� finger�٬O�i�H�ݨ�:p */

#if 0
  /* Query �ɥi�P�ɬݨ�ͽ˴y�z�δc�� */

  if ((!paling) && (state = pal_state(cutmp, userno, ship)))
  {
    prints(" [%s��] %s", state > 0 ? "�n" : "�l", ship);
  }
#endif

  prints(" [�H�c] %s", m_query(userid) ? "���s�H��" : "���ݹL�F");

  showplans(userid);
  vmsg(NULL);

  move(b_lines, 0);
  clrtoeol();
}


void
my_query(userid, paling)
  char *userid;
  int paling;			/* �O�_���b�]�w�n�ͦW�� */
{
  ACCT acct;

  if (acct_load(&acct, userid) >= 0)
  {
    do_query(&acct, paling);
  }
  else
  {
    vmsg(err_uid);
  }
}


/* ----------------------------------------------------- */
/* BMW : bbs message write routines			 */
/* ----------------------------------------------------- */


#define	BMW_FORMAT	"\033[1;33;46m��%s \033[37;45m %s \033[m"
#define	BMW_LOCAL_MAX	8


static BMW bmw_lslot[BMW_LOCAL_MAX];
static int bmw_locus;

#if 0	/* lkchu.990428: �s�����w���ɶ���� */
#ifdef BMW_TIME
/* Thor.980911: BMW with time */
/* Thor.980913: ����: �ѩ� call-in�o�ͱ`�b�Ƭ���,�i�H"��"���̤p���ӭp��r�� */
static time_t uptime = -1;
static char timemsg[8] = "(00:00)";
static char *
bmw_timemsg()
{
  time_t now = time(0);
  struct tm *ptime = localtime(&now); 
  if(now > uptime)
  {
    sprintf(timemsg, "(%02d:%02d)", ptime->tm_hour, ptime->tm_min);
    uptime = now + 60 - ptime->tm_sec; /* Thor.980913: �U����s�ɶ� */
  }
  return timemsg;
}
#endif
#endif

static int
bmw_send(callee, bmw)
  UTMP *callee;
  BMW *bmw;
{
  BMW *mpool, *mhead, *mtail, **mslot;
  int i;
  pid_t pid;
  time_t texpire;

  if ((callee->userno != bmw->recver) || (pid = callee->pid) <= 0)
    return 1;

  /* sem_lock(BSEM_ENTER); */

  /* find callee's available slot */

  mslot = callee->mslot;
  i = 0;

  for (;;)
  {
    if (mslot[i] == NULL)
      break;

    if (++i >= BMW_PER_USER)
    {
      /* sem_lock(BSEM_LEAVE); */
      return 1;
    }
  }

  /* find available BMW slot in pool */

  texpire = time(&bmw->btime) - BMW_EXPIRE;

  mpool = ushm->mpool;
  mhead = ushm->mbase;
  if (mhead < mpool)
    mhead = mpool;
  mtail = mpool + BMW_MAX;

  do
  {
    if (++mhead >= mtail)
      mhead = mpool;
  } while (mhead->btime > texpire);

  *mhead = *bmw;
  ushm->mbase = mslot[i] = mhead;
  /* Thor.981206: �ݪ`�N, �Yushm mapping���P, 
                  �h���P�� bbsd ��call�|core dump,
                  ���D�o�]��offset, ���L���F -i, ���ӬO�D���n */


  /* sem_lock(BSEM_LEAVE); */
  return kill(pid, SIGUSR2);
}


static void
bmw_edit(up, hint, bmw, cc)
  UTMP *up;
  char *hint;
  BMW *bmw;
  int cc;
{
  uschar *str;
  screenline sl[2];

  if (up)
    bmw->recver = up->userno;	/* ���O�U userno �@�� check */

  if (!cc)
    save_foot(sl);

  str = bmw->msg;
  str[0] = cc;
  str[1] = '\0';

  if (vget(b_lines - 1, 0, hint, str, 49 /* 60 */, GCARRY) &&
                                     /* lkchu.990103: �s�����u���\ 48 �Ӧr�� */
    vans("�T�w�n�e�X�m���T�n��(Y/N)�H[Y] ") != 'n')
  {
#if 0
    FILE *fp;
#endif
    char *userid, fpath[64];

    bmw->caller = cutmp;
    bmw->sender = cuser.userno;
    strcpy(bmw->userid, userid = cuser.userid);

    if (up)
    {
      if (bmw_send(up, bmw))
	vmsg(MSG_USR_LEFT);
    }

    /* lkchu.981230: �Q�� xover ��X bmw */
    if (up)
      strcpy(bmw->userid, up->userid);	
				/* lkchu.990103: �Y�O�ۤv�e�X�� bmw, �s��誺 userid */
    else
      *bmw->userid = '\0';	/* lkchu.990206: �n�ͼs���]�� NULL */
      
    time(&bmw->btime);
    usr_fpath(fpath, userid, FN_BMW);
    rec_add(fpath, bmw, sizeof(BMW));
    strcpy(bmw->userid, userid);

#if 0
    /* Thor.0722: msg file�[�W�ۤv������ */

    usr_fpath(fpath, userid, FN_BMW);
    if (fp = fopen(fpath, "a"))
    {

#ifndef BMW_TIME
      fprintf(fp, "��%s�G%s\n", up ? up->userid : "���a�n��", str);
#else  
      /* Thor.980821: ���T�O���[�W�ɶ� */
      fprintf(fp, "��%s%s�G%s\n", up ? up->userid : "���a�n��", bmw_timemsg(),  str);
#endif

      fclose(fp);
    }
#endif
  }

  if (!cc)
    restore_foot(sl);
}


/* lkchu.981201: ��ܽu�W�ϥΪ̶ǰT�� */
static int
bmw_choose()
{
  UTMP *up, *ubase, *uceil;
  int self, seecloak;
  char userid[IDLEN + 1];

  if (cutmp->mode & M_SMAIL)
  {
    vmsg("�H�H�ɡA����ϥΦ��\\��");
    return 0; 
  }
  
  ll_new();

  self = cuser.userno;
  seecloak = HAS_PERM(PERM_SEECLOAK);
  ubase = up = ushm->uslot;
  uceil = ubase + ushm->count;
  do
  {
    if (up->pid && up->userno != self && str_cmp(up->userid, STR_GUEST) &&
      (seecloak || !(up->ufo & UFO_CLOAK)))
      ll_add(up->userid);
  } while (++up <= uceil);

  if (!vget(1, 0, "�п�J�N��(���ť���C�X���W�ϥΪ�)�G", userid, IDLEN + 1, GET_LIST))
  {
    vmsg(err_uid);
    return 0;
  }
  
  up = ubase;
  do
  {
    if (!str_cmp(userid, up->userid))
    {
     if (HAS_PERM(PERM_PAGE) && can_override(up))
     {
       BMW bmw;
       char buf[20];

       sprintf(buf, "��[%s]", up->userid);
       bmw_edit(up, buf, &bmw, 0);
     }
     
     return 0;
    
    }    
  } while (++up <= uceil);

  return 0;
}


void
bmw_reply()
{
  int userno, max, pos, cc, mode;
  UTMP *up, *uhead;
  BMW bmw;
  screenline sl[2];
  char buf[128];

  max = bmw_locus - 1;

  save_foot(sl); /* Thor.981222: �Q�M��message */

  if (max < 0)
  {
    vmsg("���e�õL���T�I�s");
    restore_foot(sl); /* Thor.981222: �Q�M��message */
    return;
  }
  
  mode = bbsmode;               /* lkchu.981201: save current mode */
  utmp_mode(M_BMW_REPLY);

#if 0  /* Thor.981222: �Q�M��message */
  save_foot(sl);
#endif

  move(b_lines - 1, 0);
  outs("\033[34;46m ���T�^�� \033[31;47m (��)\033[30m���} \033[31m(������)\033[30m�s�� \033[31m(Enter)\033[30m��ܽu�W�ϥΪ̦��� \033[31m(��L)\033[30m�^�� \033[m");

  cc = 12345;
  pos = max;

  uhead = ushm->uslot;

  for (;;)
  {
    if (cc == 12345)
    {
      bmw = bmw_lslot[pos];
      sprintf(buf, BMW_FORMAT, bmw.userid, bmw.msg);
      outz(buf);
    }

    cc = vkey();

    if (cc == '\n')	/* lkchu.981201: �� Enter ��ܽu�W user */
    {
      screenline slp[b_lines + 1];
      
      vs_save(slp);
      bmw_choose();
      memcpy(&slp[b_lines - 1], &sl, sizeof(screenline) * 2);
                         /* lkchu.981201: �� foot ���έ��� restore */
      vs_restore(slp);
      utmp_mode(mode);      /* lkchu.981201: restore bbsmode */
      return;
    }

    if (cc == KEY_UP)
    {
      if (pos > 0)
      {
	pos--;
	cc = 12345;
      }
      continue;
    }

    if (cc == KEY_DOWN)
    {
      if (pos < max)
      {
	pos++;
	cc = 12345;
      }
      continue;
    }

    if (cc == KEY_RIGHT)
    {
      if (pos != max)
      {
	pos = max;
	cc = 12345;
      }
      continue;
    }

    if (cc == KEY_LEFT)
      break;

    if (isprint2(cc))
    {
      userno = bmw.sender; /* Thor.980805: ����t�Ψ�M�^�� */
      if(!userno)
      {
        /* vmsg("�t�ΰT���L�k�^��"); */
        vmsg("�z�ä��O��誺�n�͡A�L�k�^���W���q��");
				/* lkchu.981201: �n�ͥi�^�� */
                                          
        break;
      }

      up = bmw.caller;
      if ((up < uhead) || (up > /* (void *) */ uhead + ushm->offset))
				/* lkchu.981201: comparison of distinct pointer types */
      {
	vmsg(MSG_USR_LEFT);
	break;
      }

      /* userno = bmw.sender; */ /* Thor.980805: ����t�Φ^�� */
      if (up->userno != userno)
      {
	up = utmp_find(userno);
	if (!up)
	{
	  vmsg(MSG_USR_LEFT);
	  break;
	}
      }

      /* bmw_edit(up, "���^���G", &bmw, cc); */
      /* Thor.981214: ���Ϧ^�����P�˲V */
      sprintf(buf,"��[%s]", up->userid);
      bmw_edit(up, buf, &bmw, cc); 
      break;
    }
  }

  restore_foot(sl);
  utmp_mode(mode);      /* lkchu.981201: restore bbsmode */
}


/* ----------------------------------------------------- */
/* Thor.0607: system assist user login notify		 */
/* ----------------------------------------------------- */


#define MSG_CC "\033[32m[�s�զW��]\033[m\n"


int
pal_list(reciper)
  int reciper;
{
  int userno, fd;
  char buf[32], fpath[64];
  ACCT acct;

  userno = 0;

  for (;;)
  {
    switch (vget(1, 0, "A)�W�[ D)�R�� F)�n�� G)�s�� M)�w�� Q)�����H[M] ", buf, 2, LCECHO))
    {
    case 'a':
      while (acct_get("�п�J�N��(�u�� ENTER �����s�W): ", &acct) > 0)
      {
	if (!ll_has(acct.userid))
	{
	  ll_add(acct.userid);
	  reciper++;
	  ll_out(3, 0, MSG_CC);
	}
      }
      break;

    case 'd':

      while (reciper)
      {
	if (!vget(1, 0, "�п�J�N��(�u�� ENTER �����R��): ",
	    buf, IDLEN + 1, GET_LIST))
	  break;
	if (ll_del(buf))
	  reciper--;
	ll_out(3, 0, MSG_CC);
      }
      break;

    case 'g':
      if (userno = vget(b_lines, 0, "�s�ձ���G", buf, 16, DOECHO))
	str_lower(buf, buf);

    case 'f':
      usr_fpath(fpath, cuser.userid, FN_PAL);
      if ((fd = open(fpath, O_RDONLY)) >= 0)
      {
	PAL *pal;
	char *userid;

	mgets(-1);
	while (pal = mread(fd, sizeof(PAL)))
	{
	  userid = pal->userid;
	  if (!ll_has(userid) && (pal->userno != cuser.userno) &&
	    !(pal->ftype & PAL_BAD) &&
	    (!userno || str_str(pal->ship, buf)))
	  {
	    ll_add(userid);
	    reciper++;
	  }
	}
	close(fd);
      }
      ll_out(3, 0, MSG_CC);
      userno = 0;
      break;

    case 'q':
      return 0;

    default:
      return reciper;
    }
  }
}


#if 0
int
aloha_sync()
{
  char buf[64];
  int fd;
  struct tm *p = localtime(&cuser.lastlogin);
    
  /* lkchu.990106: 19981209 ���e�~���ഫ */
  if (p->tm_year > 98) 
    return 0;
  else if (p->tm_year == 98 && p->tm_mon > 10 && p->tm_mday > 7)
    return 0;
    
  outz("�� ��ƾ�z�]�֤��A�еy�� \033[5m...\033[m");
  usr_fpath(buf, cuser.userid, FN_PAL);
  if ((fd = open(buf, O_RDONLY)) >= 0)
  {
    PAL *pal;

    mgets(-1);
    while (pal = mread(fd, sizeof(PAL)))
    {
      if ((pal->userno != cuser.userno) && !(pal->ftype & PAL_BAD))
      {
        char fpath[64];
        BMW bmw;

        /* bmw.caller = cutmp; */  /* lkchu.981201: frienz �� utmp �L�� */
        bmw.recver = cuser.userno;
        strcpy(bmw.userid, cuser.userid);
        usr_fpath(fpath, pal->userid, FN_FRIEND_BENZ);
        rec_add(fpath, &bmw, sizeof(BMW));
      }
    }
    close(fd);
  }  
    
  return 0; 
}
#endif

  
#ifdef	HAVE_ALOHA
void
aloha()
{
  UTMP *up, *ubase, *uceil;
  int fd;
  char fpath[64];
  BMW *bmw, benz;
  int userno;
  struct stat st;
  
  /* lkchu.981201: �n�ͳq�� */

  usr_fpath(fpath, cuser.userid, FN_FRIEND_BENZ);

  if (((fd = open(fpath, O_RDONLY)) >= 0) && !fstat(fd, &st) && (st.st_size > 0))
  {
    benz.caller = cutmp;
    /* benz.sender = cuser.userno; */
    benz.sender = 0; /* Thor.980805: �t�Ψ�M����V call in */
    strcpy(benz.userid, cuser.userid);
    sprintf(benz.msg, "�� ����i%s���� [�n�ͤW��] ��", BOARDNAME);

    ubase = ushm->uslot;
    uceil = (void *) ubase + ushm->offset;

    mgets(-1);
    while (bmw = mread(fd, sizeof(BMW)))
    {
      /* Thor.1030:�u�q���B�� */


      userno = bmw->recver;
      /* up = bmw->caller; */
      up = utmp_find(userno);	/* lkchu.981201: frienz ���� utmp �L�� */
      
      if (up >= ubase && up <= uceil &&
	up->userno == userno && !(cuser.ufo & UFO_CLOAK) && (up->ufo & UFO_ALOHA))
                                 /* Thor.980804: �����W�����q��, �����S�v */
                                 /* lkchu.981201: ���n���}�u�n�ͤW���q���v�~�q�� */
#if 0  
        /* Thor.980805: ���|�^���F, ��V call-in */
        && is_pal(userno) && 
        userno != cuser.userno && !(cuser.ufo & UFO_QUIET))
        /* Thor.980707: ���M�ۤv */ /* Thor.980804: �������ۮɤ��q��,�H���^�� */
#endif
      {
        if (is_pal(userno))           /* lkchu.980806: �n�ͤ~�i�H reply */
          benz.sender = cuser.userno;
        else
          benz.sender = 0;

	benz.recver = userno;
	bmw_send(up, &benz);
      }
    }
    close(fd);
  }
}
#endif


#ifdef LOGIN_NOTIFY
extern LinkList *ll_head;


int
t_loginNotify()
{
  LinkList *wp;
  BMW bmw;
  char fpath[64];

  /* �]�w list ���W�� */

  vs_bar("�t�Ψ�M����");

  ll_new();

  if (pal_list(0))
  {
    wp = ll_head;
    bmw.caller = cutmp;
    bmw.recver = cuser.userno;
    strcpy(bmw.userid, cuser.userid);

    /* Thor.980629: �pbug, �i�H��M�ۤv, �i��call-in�ۤv:P */

    do
    {
      usr_fpath(fpath, wp->data, FN_BENZ);
      rec_add(fpath, &bmw, sizeof(BMW));
    } while (wp = wp->next);

    vmsg("��M�]�w����, �B�ͤW���ɧN�ɤѨϷ|�q���z,�Фŭ��г]�w!");

    /* Thor.1030 : �Y���O�B�ʹN���q����...... �H�Kcallin ����� */
  }
  return 0;
}


void
loginNotify()
{
  UTMP *up, *ubase, *uceil;
  int fd;
  char fpath[64];
  BMW *bmw, benz;
  int userno;

  usr_fpath(fpath, cuser.userid, FN_BENZ);

  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    vs_bar("�t�Ψ�M����");

#if 0
    move(10, 0);
    clrtobot();
    outs("�� �����Ϫ̡G�y���g���H�Q��z�@�K�K\n");
#endif

    benz.caller = cutmp;
    /* benz.sender = cuser.userno; */
    benz.sender = 0; /* Thor.980805: �t�Ψ�M����V call in */
    strcpy(benz.userid, cuser.userid);
    sprintf(benz.msg, "�� ����i%s���� [�t�Ψ�M] ��", BOARDNAME);

    ubase = ushm->uslot;
    uceil = (void *) ubase + ushm->offset;

    mgets(-1);
    while (bmw = mread(fd, sizeof(BMW)))
    {
      /* Thor.1030:�u�q���B�� */

      up = bmw->caller;
      userno = bmw->recver;

      if (up >= ubase && up <= uceil &&
	up->userno == userno && !(cuser.ufo & UFO_CLOAK) ) 
                                 /* Thor.980804: �����W�����q��, �����S�v */
#if 0  
        /* Thor.980805: ���|�^���F, ��V call-in */
        && is_pal(userno) && 
        userno != cuser.userno && !(cuser.ufo & UFO_QUIET))
        /* Thor.980707: ���M�ۤv */ /* Thor.980804: �������ۮɤ��q��,�H���^�� */
#endif
      {
        benz.sender = is_pal(userno) ? cuser.userno : 0; 
                      /* lkchu.980806: �n�ͤ~�i�H reply */
	benz.recver = userno;
	bmw_send(up, &benz);

        prints("*");  /* Thor.980707: ���q���쪺���Ҥ��P */
      }

      prints("%-13s", bmw->userid);

    }
    close(fd);
    unlink(fpath);
    vmsg(NULL);
  }
}
#endif


/* Thor: for ask last call-in messages */

/* lkchu: ���T�^�U�s���� */
int
t_recall()
{
  xover(XZ_BMW);
  return 0;
}


#if 0
int
t_recall()
{
  char buf[80];

  usr_fpath(buf, cuser.userid, FN_BMW);	/* Thor.1127: �t�X BMW */
  /* Thor.980405: �^�U�ɶ��K�x�s���T  */

  /* return more(buf, -1) ? -1 : bmw_save(), 0; */
  return more(buf, NULL); /* Thor.990204: �u�n���O XEASY�N�i�H�F:p */
  
}
#endif


#ifdef LOG_TALK
void
talk_save()
{
  char fpath[64];
  
  usr_fpath(fpath, cuser.userid, FN_TALK_LOG);

  if (!(cuser.ufo & UFO_NTLOG))
  {
    char buf[64];
    HDR fhdr;
    
    usr_fpath(buf, cuser.userid, fn_dir);
    hdr_stamp(buf, HDR_LINK, &fhdr, fpath);
    strcpy(fhdr.title, "[�� �� ��] ��Ѭ���");
    strcpy(fhdr.owner, cuser.userid);
    fhdr.xmode = MAIL_READ | MAIL_NOREPLY;
    rec_add(buf, &fhdr, sizeof(fhdr)); 

  } 
  unlink(fpath);
  return;


#if 0
  /* lkchu.981201: ��i�p�H�H�c��/�M��/�O�d */
  if (dashf(fpath))
  {
    
    switch (vans("������Ѭ����B�z (M)�Ƨѿ� (C)�M���H[M] "))
    {
    case 'c':
      unlink(fpath);
      break;
      
    default:
      {
        char buf[64];
        HDR fhdr;
        
        usr_fpath(buf, cuser.userid, fn_dir);
        hdr_stamp(buf, HDR_LINK, &fhdr, fpath);
        strcpy(fhdr.title, "[�� �� ��] ��Ѭ���");
        strcpy(fhdr.owner, cuser.userid);
        fhdr.xmode = MAIL_READ | MAIL_NOREPLY;
        rec_add(buf, &fhdr, sizeof(fhdr)); 

        unlink(fpath);
      }
      break;
    }      
  }
#endif

}
#endif


#ifdef LOG_BMW
void
bmw_save()
{
  int fd;
  char fpath[64];
  
  usr_fpath(fpath, cuser.userid, FN_BMW);
  fd = f_open(fpath);	/* lkchu.990428: �Y size �� 0 �|�Q unlink �� */

  if (fd >= 0)
  {
    if (!(cuser.ufo & UFO_NWLOG))
    {
      FILE *fout;
      char buf[80], folder[80];
      HDR fhdr;
      
      usr_fpath(folder, cuser.userid, fn_dir);
      if (fout = fdopen(hdr_stamp(folder, 0, &fhdr, buf), "w"))
      {        
        BMW bmw;
        
        while (read(fd, &bmw, sizeof(BMW)) == sizeof(BMW)) 
        {
          struct tm *ptime = localtime(&bmw.btime);
          
          fprintf(fout, "%s%s(%02d:%02d)�G%s\033[m\n", 
            bmw.sender == cuser.userno ? "��" : "\033[32m��",
            bmw.userid, ptime->tm_hour, ptime->tm_min, bmw.msg);
        }
        fclose(fout);
      }
      /* close(fd); */
      
      fhdr.xmode = MAIL_READ | MAIL_NOREPLY;
      strcpy(fhdr.title, "[�� �� ��] ���T����");
      strcpy(fhdr.owner, cuser.userid);
      rec_add(folder, &fhdr, sizeof(fhdr));

      /* unlink(fpath); */
    }  
    
    close(fd);
    unlink(fpath);

  }
  
#if 0   
  /* lkchu.981201: ��i�p�H�H�c��/�M��/�O�d */
  if (fd >= 0)
  {
    switch (vans("�����W�����T�B�z (M)�Ƨѿ� (K)�O�d (C)�M���H[M] "))
    {
    case 'c':
      close(fd);
      unlink(fpath);
      break;

    case 'k':
      close(fd);
      break;
      
    case 'm':
    default:
      {
        FILE *fout;
        char buf[80], folder[80];
        HDR fhdr;
        
        usr_fpath(folder, cuser.userid, fn_dir);
        if (fout = fdopen(hdr_stamp(folder, 0, &fhdr, buf), "w"))
        {        
          BMW bmw;
          
          while (read(fd, &bmw, sizeof(BMW)) == sizeof(BMW)) 
          {
            struct tm *ptime = localtime(&bmw.btime);
            
            fprintf(fout, "%s%s(%02d:%02d)�G%s\033[m\n", 
              bmw.sender == cuser.userno ? "��" : "\033[32m��",
              bmw.userid, ptime->tm_hour, ptime->tm_min, bmw.msg);
          }
          fclose(fout);
        }
        close(fd);
        
        fhdr.xmode = MAIL_READ | MAIL_NOREPLY;
	strcpy(fhdr.title, "[�� �� ��] ���T����");
	strcpy(fhdr.owner, cuser.userid);
        rec_add(folder, &fhdr, sizeof(fhdr));

        unlink(fpath);
      }
      break;
    }      
  }
#endif


}
#endif


void
bmw_rqst()
{
  int i, j, userno, locus;
  BMW bmw[BMW_PER_USER], *mptr, **mslot;

  /* download BMW slot first */

  i = j = 0;
  userno = cuser.userno;
  mslot = cutmp->mslot;

  while (mptr = mslot[i])
  {
    mslot[i] = NULL;
    if (mptr->recver == userno)
    {
      bmw[j++] = *mptr;
    }
    mptr->btime = 0;

    if (++i >= BMW_PER_USER)
      break;
  }

  /* process the request */

  if (j)
  {
    char buf[128];
#if 0
    FILE *fp;
#endif

    locus = bmw_locus;
    i = locus + j - BMW_LOCAL_MAX;
    if (i >= 0)
    {
      locus -= i;
      memcpy(bmw_lslot, bmw_lslot + i, locus * sizeof(BMW));
    }

#if 0   /* lkchu.981230: �Q�� xover ��X bmw */
    usr_fpath(buf, cuser.userid, FN_BMW);
    fp = fopen(buf, "a");
#endif

    i = 0;
    do
    {
      mptr = &bmw[i];

#if 0   /* lkchu.981230: �Q�� xover ��X bmw */

#ifndef BMW_TIME
      fprintf(fp, "\033[32m��%s�G%s\033[m\n", mptr->userid, mptr->msg);
#else  
      /* Thor.980821: ���T�O���[�W�ɶ� */
      fprintf(fp, "\033[32m��%s%s�G%s\033[m\n", mptr->userid, bmw_timemsg(), mptr->msg);
#endif

#endif

      /* lkchu.981230: �Q�� xover ��X bmw */
      usr_fpath(buf, cuser.userid, FN_BMW);
      rec_add(buf, &bmw[i], sizeof(BMW)); 
                  
      bmw_lslot[locus++] = *mptr;
    } while (++i < j);

    bmw_locus = locus;
#if 0   /* lkchu.981230: �Q�� xover ��X bmw */
    fclose(fp);
#endif

    sprintf(buf, BMW_FORMAT, mptr->userid, mptr->msg);

    /* Thor.980827: ���F����C�L�@�b(more)�ɼ��T�ӫ�C�L�W�L�d���H, 
                    �G�s�U��Ц�m */
    cursor_save(); 

    outz(buf);
    /* Thor.980827: ���F����C�L�@�b(more)�ɼ��T�ӫ�C�L�W�L�d���H, 
                    �G�٭��Ц�m */
    cursor_restore();

    refresh();
    bell();
  }

#ifdef	LINUX
  signal(SIGUSR2, bmw_rqst);
#endif
}


/* ----------------------------------------------------- */
/* talk sub-routines					 */
/* ----------------------------------------------------- */


static void
talk_nextline(twin)
  talk_win *twin;
{
  int curln;

  curln = twin->curln + 1;
  if (curln > twin->eline)
    curln = twin->sline;
  if (curln != twin->eline)
  {
    move(curln + 1, 0);
    clrtoeol();
  }
  move(curln, 0);
  clrtoeol();
  twin->curcol = 0;
  twin->curln = curln;
}


static void
talk_char(twin, ch)
  talk_win *twin;
  int ch;
{
  int col, ln;

  col = twin->curcol;
  ln = twin->curln;

  if (isprint2(ch))
  {
    if (col < 79)
    {
      move(ln, col);
      twin->curcol = ++col;
    }
    else
    {
      talk_nextline(twin);
      twin->curcol = 1;
    }
    outc(ch);
  }
  else if (ch == '\n')
  {
    talk_nextline(twin);
  }
  else if (ch == Ctrl('H'))
  {
    if (col)
    {
      twin->curcol = --col;
      move(ln, col);
      outc(' ');
      move(ln, col);
    }
  }
  else if (ch == Ctrl('G'))
  {
    bell();
  }
}


static void
talk_string(twin, str)
  talk_win *twin;
  uschar *str;
{
  int ch;

  while (ch = *str)
  {
    talk_char(twin, ch);
    str++;
  }
}


#ifdef	TALK_USER_LIST
static char *talk_uent_buf;


static int
talk_utmp(up)
  UTMP *up;
{
  char buf[STRLEN];
  int mch;
  int visible = !(up->ufo & UFO_CLOAK);	/* 0 or 1 */

  if (HAS_PERM(PERM_SEECLOAK) || visible)
  {
    switch (up->mode)
    {
    case M_CLASS:
      mch = 'G';
      break;
    case M_TALK:
      mch = 'T';
      break;
    case M_CHAT:
      mch = 'C';
      break;
    case M_READA:
      mch = 'R';
      break;
    case M_POST:
      mch = 'P';
      break;
    case M_SMAIL:
    case M_RMAIL:
    case M_MAIL:
      mch = 'M';
      break;
    default:
      mch = '-';
    }
    sprintf(buf, "*%s(%c), ", up->userid, mch);
    strcpy(talk_uent_buf, buf + visible);
    talk_uent_buf += strlen(buf) - visible;
  }
  return 0;
}


static void
talk_ulist(twin)
  talk_win *twin;
{
  char bigbuf[MAXACTIVE * 20];

  talk_string(twin, "\n�� �W�u���͡G\n");
  talk_uent_buf = bigbuf;
  if (apply_ulist(talk_utmp) == -1)
  {
    strcpy(bigbuf, "�S������ϥΪ̤W�u\n");
  }
  strcpy(talk_uent_buf, "\n");
  talk_string(twin, bigbuf);
}
#endif				/* TALK_USER_LIST */


static void
talk_speak(fd)
  int fd;
{
  talk_win mywin, itswin;
  uschar data[80];
  char buf[80];
  int i, ch;
#ifdef  LOG_TALK
  char mywords[80], itswords[80], itsuserid[40];
  FILE *fp;
    
  /* lkchu: make sure that's empty */
  mywords[0] = itswords[0] = '\0';
  
  strcpy(itsuserid, page_requestor);
  strtok(itsuserid, " (");
#endif

  utmp_mode(M_TALK);

  ch = 58 - strlen(page_requestor);

  sprintf(buf, "%s�i%s", cuser.userid, cuser.username);

  i = ch - strlen(buf);
  if (i >= 0)
  {
    i = (i >> 1) + 1;
  }
  else
  {
    buf[ch] = '\0';
    i = 1;
  }
  memset(data, ' ', i);
  data[i] = '\0';

  memset(&mywin, 0, sizeof(mywin));
  memset(&itswin, 0, sizeof(itswin));

  i = b_lines >> 1;
  mywin.eline = i - 1;
  itswin.curln = itswin.sline = i + 1;
  itswin.eline = b_lines - 1;

  clear();
  move(i, 0);
  prints("\033[1;46;37m  �ͤѻ��a  \033[45m%s%s�j ��  %s%s\033[m",
    data, buf, page_requestor, data);
#if 1
  outz("\033[34;46m ��ͼҦ� \033[31;47m (^A)\033[30m�﫳�Ҧ� \033[31m(^C,^D)\033[30m������� \033[31m(^P)\033[30m�����I�s�� \033[31m(^Z)\033[30m�ֱ��C�� \033[31m(^G)\033[30m�͹� \033[m");
#endif
  move(0, 0);

#ifdef LOG_TALK                            /* lkchu.981201: ��ѰO�� */
  usr_fpath(buf, cuser.userid, FN_TALK_LOG);
  if (fp = fopen(buf, "a+"))
    fprintf(fp, "�i %s �P %s ����ѰO�� �j\n", cuser.userid, page_requestor);
#endif

  add_io(fd, 60);

  for (;;)
  {
    ch = igetch();

    if (ch == KEY_ESC)
    {
      igetch();
      igetch();
      continue;
    }

#ifdef EVERY_Z
    /* Thor.0725: talk��, ctrl-z */
    if (ch == Ctrl('Z'))
    {
      char buf[IDLEN + 1];
      /* Thor.0731: �Ȧs mateid, �]�����i��query�O�H�ɷ|�α�mateid */
      strcpy(buf, cutmp->mateid);

      /* Thor.0727: �Ȧs vio_fd */
      holdon_fd = vio_fd;
      vio_fd = 0;
      every_Z();
      /* Thor.0727: �٭� vio_fd */
      vio_fd = holdon_fd;
      holdon_fd = 0;

      /* Thor.0731: �٭� mateid, �]�����i��query�O�H�ɷ|�α�mateid */
      strcpy(cutmp->mateid, buf);
      continue;
    }
#endif

    if (ch == Ctrl('D') || ch == Ctrl('C'))
      break;

    if (ch == I_OTHERDATA)
    {
      ch = recv(fd, data, 80, 0);
      if (ch <= 0)
	break;
#if 1
      if (data[0] == Ctrl('A'))
      { /* Thor.990219: �I�s�~���ѽL */
#if 0
        extern int BWboard();
        if(BWboard(fd,1)==-2)
#endif
        if(DL_func("bin/bwboard.so:vaBWboard",fd,1)==-2)
          break;
        continue;
      }
#endif
      for (i = 0; i < ch; i++)
      {
	talk_char(&itswin, data[i]);
#ifdef	LOG_TALK
        switch (data[i])
        {
        case '\n':
	  /* lkchu.981201: ������N�� itswords �L�X�M�� */
	  if (itswords[0] != '\0')
  	  {
  	    fprintf(fp, "\033[32m%s�G%s\033[m\n", itsuserid, itswords);
	    itswords[0] = '\0';
	  }
	  break;

        case Ctrl('H'):	/* lkchu.981201: backspace */
          itswords[str_len(itswords) - 1] = '\0';
          break;
          
        default:
	  if (str_len(itswords) < sizeof(itswords))
  	  {
  	    strncat(itswords, (char *)&data[i], 1);
	  }
	  else	/* lkchu.981201: itswords �˺��F */
	  {
  	    fprintf(fp, "\033[32m%s�G%s%c\033[m\n", itsuserid, itswords, data[i]);
	    itswords[0] = '\0';
	  }
	  break;
	}
#endif

      }
    }
#if 1
    else if (ch == Ctrl('A'))
    { /* Thor.990219: �I�s�~���ѽL */
      /* extern int BWboard(); */
      data[0] = ch;
      if (send(fd, data, 1, 0) != 1)
	break;
      /* if (BWboard(fd,0)==-2) */
      if(DL_func("bin/bwboard.so:vaBWboard",fd,0)==-2)
        break;
    }
#endif
    else if (isprint2(ch) || ch == '\n' || ch == Ctrl('H') || ch == Ctrl('G'))
    {
      data[0] = ch;
      if (send(fd, data, 1, 0) != 1)
	break;

#ifdef LOG_TALK				/* lkchu: �ۤv������ */
      switch (ch)
      {
      case '\n':
        if (mywords[0] != '\0')
        {
          fprintf(fp, "%s�G%s\n", cuser.userid, mywords);
  	  mywords[0] = '\0';
        }
        break;
      
      case Ctrl('H'):
        mywords[str_len(mywords) - 1] = '\0';
        break;
      
      default:
        if (str_len(mywords) < sizeof(mywords))
	{
          strncat(mywords, (char *)&ch, 1);
        }
        else
        {
          fprintf(fp, "%s�G%s%c\n", cuser.userid, mywords, ch);
	  mywords[0] = '\0';
	}
        break;
      }
#endif

      talk_char(&mywin, ch);

#ifdef EVERY_BIFF 
      /* Thor.980805: ���H�b�����enter�~�ݭncheck biff */ 
      if(ch=='\n')
      {
        static int old_biff; 
        int biff = cutmp->ufo & UFO_BIFF; 
        if (biff && !old_biff) 
          talk_string(&mywin, "�� ��! �l�t�ӫ��a�F!\n"); 
        old_biff = biff; 
      }
#endif
    }

#ifdef	TALK_USER_LIST
    else if (ch == Ctrl('U') || ch == Ctrl('W'))
    {
      talk_ulist(&mywin);
    }
#endif

    else if (ch == Ctrl('P') && HAS_PERM(PERM_BASIC))
    {
      /* cuser.ufo = (cutmp->ufo ^= UFO_PAGER); */
      cuser.ufo ^= UFO_PAGER;
      cutmp->ufo ^= UFO_PAGER;
      /* Thor.980805: �ѨM ufo ���P�B���D */

      talk_string(&mywin,
	(cuser.ufo & UFO_PAGER) ? "�� �����I�s��\n" : "�� ���}�I�s��\n");
    }
  }

#ifdef LOG_TALK
  fclose(fp);
#endif

  add_io(0, 60);
}


#if 0
static int
xsocket()
{
  int sock, val;

  sock = socket(AF_INET, SOCK_STREAM, 0);
  if (sock >= 0)
  {
    val = 64;
    setsockopt(sock, SOL_SOCKET, SO_SNDBUF, &val, sizeof(val));
    setsockopt(sock, SOL_SOCKET, SO_RCVBUF, &val, sizeof(val));
  }
  return sock;
}
#endif


static void
talk_hangup(sock)
  int sock;
{
  cutmp->sockport = 0;
  add_io(0, 60);
  close(sock);
}


static char *talk_reason[] =
{
  "�藍�_�A�ڦ��Ʊ������A talk",
  "�ڲ{�b�ܦ��A�е��@�|��A call ��",
  "�{�b�����L�ӡA���@�U�ڷ|�D�� page �A",
  "�ڲ{�b���Q talk �� ...",
  "�A�u���ܷСA�ڹ�b���Q��A talk"

#ifdef EVERY_Z
  ,"�ڪ��L�ڥ����۩M�O�H���ܩO�A�S���Ū��L�ڤF"
  /* Thor.0725: for chat&talk ��^z �@�ǳ� */
#endif
};


/* return 0: �S�� talk, 1: �� talk, -1: ��L */


static int
talk_page(up)
  UTMP *up;
{
  int sock, msgsock;
  struct sockaddr_in sin;
  pid_t pid;
  int ans, length;
  char buf[60];
#if     defined(__OpenBSD__)
  struct hostent *h;
#endif

#if 0
  /* Thor.0523: ���� 500�H�H�W, �T��{��user talk */
  if (ushm->number > 500 && !HAS_PERM(PERM_VALID))
  {
    vmsg("�ثe�u�W�H�ƤӦh�A�z���q�L�{�ҡA�L�k�ϥΦ��\\��");
    return 0;
  }
#endif

#ifdef EVERY_Z
  /* Thor.0725: �� talk & chat �i�� ^z �@�ǳ� */
  if (holdon_fd)
  {
    vmsg("�z�������@�b�٨S�����C");
    return 0;
  }
#endif

  pid = up->mode;

  if (pid >= M_BBTP && pid <= M_CHAT)
  {
    vmsg("���L�v���");
    return 0;
  }

  if (!(pid = up->pid) || kill(pid, 0))
  {
    vmsg(MSG_USR_LEFT);
    return 0;
  }

  /* showplans(up->userid); */

  if (vans("�T�w�n�M�L/�o�ͤѶ�(Y/N)?[N] ") != 'y')
    return 0;

  sock = socket(AF_INET, SOCK_STREAM, 0);
  if (sock < 0)
    return 0;

#if     defined(__OpenBSD__)                    /* lkchu */

  if (!(h = gethostbyname(MYHOSTNAME)))
    return -1;  
  memset(&sin, 0, sizeof(sin));
  sin.sin_family = AF_INET;
  sin.sin_port = 0;
  memcpy(&sin.sin_addr, h->h_addr, h->h_length);                

#else

  sin.sin_family = AF_INET;
  sin.sin_port = 0;
  sin.sin_addr.s_addr = INADDR_ANY;
  memset(sin.sin_zero, 0, sizeof(sin.sin_zero));

#endif

  length = sizeof(sin);
  if (bind(sock, (struct sockaddr *) &sin, length) < 0 || getsockname(sock, (struct sockaddr *) &sin, &length) < 0)
  {
    close(sock);
    return 0;
  }

  cutmp->sockport = sin.sin_port;
  strcpy(cutmp->mateid, up->userid);
  up->talker = cutmp;
  utmp_mode(M_PAGE);
  kill(pid, SIGUSR1);

  clear();
  prints("���שI�s %s ...\n�i�� Ctrl-D ����", up->userid);

  listen(sock, 1);
  add_io(sock, 20);
  do
  {
    msgsock = igetch();

    if (msgsock == Ctrl('D'))
    {
      talk_hangup(sock);
      return -1;
    }

    if (msgsock == I_TIMEOUT)
    {

#if 0  /* Thor.990201: ����: ���Υ[�F, �]�� tv_sec�C�����|���]����ȦAselect */
#ifdef LINUX
      add_io(sock, 20);		/* added 4 linux... achen */
#endif
#endif

      move(0, 0);
      outs("�A");
      bell();

      if (kill(pid, SIGUSR1)) 
      /* Thor.990201:����:���o��kill,�]�u�O�ݬݹ��O���O�٦b�u�W�Ӥw:p
                          ���osignal�����G talk_rqst���|�A�Q�s */
      {
	talk_hangup(sock);
	vmsg(MSG_USR_LEFT);
	return -1;
      }
    }
  } while (msgsock != I_OTHERDATA);

  msgsock = accept(sock, NULL, NULL);
  talk_hangup(sock);
  if (msgsock == -1)
    return -1;

  length = read(msgsock, buf, sizeof(buf));
  ans = buf[0];
  if (ans == 'y')
  {
    sprintf(page_requestor, "%s (%s)", up->userid, up->username);

    /*
     * Thor.0814: �`�N! �b�����@�����P�n�����i�ౡ�p, �p�G askia ��page
     * starlight, ���b starlight �^���e�o���W���}, �� page backspace,
     * backspace�|���^���e, �p�G starlight �^���F, starlight �N�|�Q accept,
     * �Ӥ��O backspace.
     * 
     * ���ɦb�ù�����, �ݨ쪺 page_requestor�|�O backspace, �i�O�ƹ�W,
     * talk����H�O starlight, �y�����P�n��!
     * 
     * �Ȯɤ����ץ�, �H�@����ߪ̪��g�@:P
     */

    talk_speak(msgsock);
  }
  else
  {
    char *reply;

    if (ans == ' ')
    {
      reply = buf;
      reply[length] = '\0';
    }
    else
      reply = talk_reason[ans - '1'];

    move(4, 0);
    outs("�i�^���j");
    outs(reply);
  }

  close(msgsock);
  cutmp->talker = NULL;
#ifdef  LOG_TALK
  if (ans == 'y')
    talk_save();          /* lkchu.981201: talk �O���B�z */
#endif
  vmsg("��ѵ���");
  return 1;
}


/*-------------------------------------------------------*/
/* ��榡��Ѥ���					 */
/*-------------------------------------------------------*/


static pickup ulist_pool[MAXACTIVE];
#ifdef	FRIEND_FIRST
static int friend_num;		/* lkchu.990510: �O���ثe���W�n�ͼ� */
#endif
static ulist_head(), ulist_init();
static XO ulist_xo;


static char *msg_pickup_way[PICKUP_WAYS] =
{
  "���N�ƦC",
  "���ͥN��",
  "�ȳ~�G�m",
  "���ͰʺA"
};


static int
ulist_body(xo)
  XO *xo;
{
  pickup *pp;
  UTMP *up;
  int n, cnt, max, ufo, self, userno, sysop, diff, pal, fcolor;
  char buf[8];

  pal = cuser.ufo;
  max = xo->max;
  if (max <= 0)
  {
    if (pal & UFO_PAL == 0)	/* impossible */
    {
      vmsg("nobody");
      return XO_QUIT;
    }

    if (vans("�ثe�S���B�ͤW���A�n�ݬݨ�L�ϥΪ̶�(Y/N)?[Y]") != 'n')
    {
      cuser.ufo = pal ^ UFO_PAL;
      return ulist_init(xo);
    }

    return XO_QUIT;
  }

  pal &= UFO_PAL;
  cnt = xo->top;
  pp = &ulist_pool[cnt];
  self = cuser.userno;
  sysop = HAS_PERM(PERM_SYSOP | PERM_ACCOUNTS);

  n = 2;
  while (++n < b_lines)
  {
    move(n, 0);
    if (cnt++ < max)
    {
      up = *pp++;
      if (userno = up->userno)
      {
	if (diff = up->idle_time)
	  sprintf(buf, "%2d", diff);
	else
	  buf[0] = '\0';

	fcolor = pal;
	if (!fcolor)
	{
	  fcolor = (userno == self) ? 1 : is_pal(userno);
	}

	ufo = up->ufo;
	if (ufo & UFO_QUIET)
	{
	  diff = 'Q';
	}
	else if (ufo & UFO_PAGER)
	{
	  /* diff = '*'; */		
	  diff = can_override(up) ? 'o' : '*';
	}
	else
	{
	  diff = ' ';
	}

	prints("%5d%c%c %s%-13s%-19.18s%s%-19.18s%-17.17s%s",
	  cnt, (ufo & UFO_CLOAK ? ')' : ' '), diff,
	  fcolor > 0 ? "\033[1;33m" : "", up->userid,
	  up->username, fcolor > 0 ? "\033[m" : "",
	  (diff == ' ' || diff == 'o' || sysop) ? up->from : "*",
	                  /* lkchu.19990609: �n�ͥi�H�ݨ� from */
	  bmode(up, 0), buf);
      }
      else
      {
	outs("      < ������ͥ������} >");
      }
    }
    clrtoeol();
  }

  return XO_NONE;
}


static int
ulist_cmp_userid(i, j)
  UTMP **i, **j;
{
  return str_cmp((*i)->userid, (*j)->userid);
}


static int
ulist_cmp_host(i, j)
  UTMP **i, **j;
{
  return (*i)->in_addr - (*j)->in_addr;
}


static int
ulist_cmp_mode(i, j)
  UTMP **i, **j;
{
  return (*i)->mode - (*j)->mode;
}


static int (*ulist_cmp[]) () =
{
  ulist_cmp_userid,
  ulist_cmp_host,
  ulist_cmp_mode
};


static int
ulist_init(xo)
  XO *xo;
{
  UTMP *up, *uceil;
  pickup *pp;
  int max, filter, seecloak, userno, self;
#ifdef	FRIEND_FIRST
  pickup *qq, o_pool[MAXACTIVE];
#endif

  pp = ulist_pool;		/* lkchu.990510: ����n�� */
#ifdef	FRIEND_FIRST
  qq = o_pool;			/* lkchu.990510: ��䥦 user */
#endif
  self = cuser.userno;
  filter = cuser.ufo & UFO_PAL;

  seecloak = HAS_PERM(PERM_SEECLOAK);

  up = ushm->uslot;
  uceil = (void *) up + ushm->offset;

#if 0
  if ((uceil < up) || (uceil > up + MAXACTIVE - 1))
  {
    uceil = up + MAXACTIVE - 1;
  }
#endif

  max = 0;

  do
  {
    userno = up->userno;
    if (userno <= 0)
      continue;

#ifdef	FRIEND_FIRST
    if ( /* (userno == self) || */ (	/* (up->mode >= 0) && (up->mode <= M_MAX) && */
	(seecloak || !(up->ufo & UFO_CLOAK)) /* && (!filter || is_pal(userno)) */))
    {
      if (is_pal(userno) || (userno == self))
        *pp++ = up;
      else if (!filter)
        *qq++ = up;
#else
    if ((userno == self) || (	/* (up->mode >= 0) && (up->mode <= M_MAX) && */
	(seecloak || !(up->ufo & UFO_CLOAK)) && (!filter || is_pal(userno))))
    {
      *pp++ = up;
#endif
    }
  } while (++up <= uceil);


#ifdef	FRIEND_FIRST
  friend_num = pp - ulist_pool;		/* lkchu.990510: �O���ثe���W�n�ͼ� */
  xo->max = max = friend_num + qq - o_pool;
#else
  xo->max = max = pp - ulist_pool;
#endif

  if (xo->pos >= max)
    xo->pos = xo->top = 0;

  if ((max > 1) && (pickup_way))
  {
#ifdef	FRIEND_FIRST
    /* lkchu.990510: �n�ͻP��L�ϥΪ̤��} sorting */
    xsort(ulist_pool, friend_num, sizeof(pickup), ulist_cmp[pickup_way - 1]);
    xsort(o_pool, qq - o_pool, sizeof(pickup), ulist_cmp[pickup_way - 1]);
#else
    xsort(ulist_pool, max, sizeof(pickup), ulist_cmp[pickup_way - 1]);
#endif
  }

#ifdef	FRIEND_FIRST
  /* lkchu.990510: merge two pools */
  memcpy(pp, &o_pool, sizeof(UTMP) * (qq - o_pool));
#endif

  return ulist_head(xo);
}


static int
ulist_neck(xo)
  XO *xo;
{
  move(1, 0);
  prints("[\033[1m%s\033[m] f)�n�� t)��� r)�d�� a)��� w)�ְT m)�H�H s)��s TAB)���� h)�D�U\n"
    "\033[44m No. %cP �N��         %-19s%-19s%-14s���m \033[m",
    msg_pickup_way[pickup_way],
    HAS_PERM(PERM_SEECLOAK) ? 'C' : ' ',
    xo->key ? "�m�W" : "�ʺ�",
    "�G�m", "�ʺA");

  return ulist_body(xo);
}


static int
ulist_head(xo)
  XO *xo;
{
  vs_head("���ͦC��", str_site);
  return ulist_neck(xo);
}


static int
ulist_toggle(xo)
  XO *xo;
{
  int ans, max;

  ans = vans("�ƦC�覡 1)���N 2)�N�� 3)�ӷ� 4)�ʺA ") - '1';
  /* if (ans >= 0 && ans <= PICKUP_WAYS && ans != pickup_way) */
  if (ans >= 0 && ans < PICKUP_WAYS && ans != pickup_way)
  /* Thor.980705: from 0 .. PICKUP_WAYS-1 */
  {
#if 0
    pickup_way = ans;
    if (ans == 0)
      return XO_FOOT;
#endif
    /* Thor.990202: �����ܤ~��s */
#if 0
    if (ans == pickup_way)
      return XO_FOOT;
#endif
    pickup_way = ans;

    max = xo->max;

    if (max <= 1)
      return XO_FOOT;

    /* Thor.990218: ���N�ƦC�h��xsort */
    if(ans)
    {
#ifdef	FRIEND_FIRST
      /* lkchu.990510: �n�ͳ����P�䥦�ϥΪ̤��} sorting */
      xsort(ulist_pool, friend_num, sizeof(pickup), ulist_cmp[ans - 1]);
      xsort(ulist_pool + friend_num, max - friend_num, sizeof(pickup), ulist_cmp[ans - 1]);
#else
      xsort(ulist_pool, max, sizeof(pickup), ulist_cmp[ans - 1]);      
#endif
    }
    ulist_neck(xo);
  }

  return XO_FOOT;
}


static int
ulist_pal(xo)
  XO *xo;
{
  cuser.ufo ^= UFO_PAL;
  /* Thor.980805: �`�N ufo �P�B���D */
  return ulist_init(xo);
}


static int
ulist_search(xo, step)
  XO *xo;
  int step;
{
  int num, pos, max;
  pickup *pp;
  static char buf[IDLEN + 1];

  if (vget(b_lines, 0, msg_uid, buf, IDLEN + 1, GCARRY))
  {
    int buflen;
    char bufl[IDLEN + 1];

    str_lower(bufl, buf);
    buflen = strlen(bufl); /* Thor: ���w�j��0 */
    
    pos = num = xo->pos;
    max = xo->max;
    pp = ulist_pool;
    do
    {
      pos += step;
      if (pos < 0) /* Thor.990124: ���] max ����0 */
        pos = max - 1;
      else if (pos >= max)
	pos = 0;

      /* Thor.990124: id �h�q�Y match */
      /* if (str_ncmp(pp[pos]->userid, bufl, buflen)==0 */
      
      if (str_str(pp[pos]->userid, bufl) /* lkchu.990127: �䳡�� id �n������n�� :p */
       || str_str(pp[pos]->username, bufl)) /* Thor.990124: �i�H�� ���� nickname */
      {
	move(b_lines, 0);
	clrtoeol();
	return pos + XO_MOVE;
      }

    } while (pos != num);
  }

  return XO_FOOT;
}

static int
ulist_search_forward(xo)
  XO *xo;
{
  return ulist_search(xo, 1); /* step = +1 */
}

static int
ulist_search_backward(xo)
  XO *xo;
{
  return ulist_search(xo, -1); /* step = -1 */
}

#if 0
static int
ulist_search(xo)
  XO *xo;
{
  int num, pos, max;
  pickup *pp;
  static char buf[IDLEN + 1];

  if (vget(b_lines, 0, msg_uid, buf, IDLEN + 1, GCARRY))
  {
    str_lower(buf, buf);
    pos = num = xo->pos;
    max = xo->max;
    pp = ulist_pool;
    do
    {
      if (++pos >= max)
	pos = 0;
      if (str_str(pp[pos]->userid, buf))
      {
	move(b_lines, 0);
	clrtoeol();
	return pos + XO_MOVE;
      }
    } while (pos != num);
  }

  return XO_FOOT;
}
#endif


static int
ulist_makepal(xo)
  XO *xo;
{
  if (cuser.userlevel)
  {
    UTMP *up;
    int userno;

    up = ulist_pool[xo->pos];
    userno = up->userno;
    if (userno > 0 && !is_pal(userno)   /* �|���C�J�n�ͦW�� */
         && (userno != cuser.userno))	/* lkchu.981217: �ۤv���i���n�� */
					
    {
      PAL pal;
      char buf[80];

      strcpy(buf, up->userid);

      pal_edit(&pal, DOECHO);
      pal.userno = userno;
      strcpy(pal.userid, buf);
      usr_fpath(buf, cuser.userid, FN_PAL);
      rec_add(buf, &pal, sizeof(PAL));
#ifdef	HAVE_ALOHA
      if (!(pal.ftype & PAL_BAD))
      {
        BMW bmw;

        /* bmw.caller = cutmp; */	/* lkchu.981201: frienz �� utmp �L�� */
        bmw.recver = cuser.userno;
        strcpy(bmw.userid, cuser.userid);
        usr_fpath(buf, pal.userid, FN_FRIEND_BENZ);
        rec_add(buf, &bmw, sizeof(BMW));
      }
#endif
      pal_cache();
      ulist_body(xo);
      return XO_FOOT;
    }
  }
  return XO_NONE;
}


static int
ulist_mail(xo)
  XO *xo;
{
  char userid[IDLEN + 1];

  /* Thor.981022:�����S���v���H�H */
  if (!HAS_PERM(PERM_BASIC) /* !cuser.userlevel*/)
    return XO_NONE;

  strcpy(userid, ulist_pool[xo->pos]->userid);
  if (*userid)
  {
    vs_bar("�H  �H");
    prints("���H�H�G%s", userid);
    my_send(userid);
    return ulist_head(xo);
  }

  vmsg(MSG_USR_LEFT);
  return XO_FOOT;
}


static int
ulist_query(xo)
  XO *xo;
{
  move(1, 0);
  clrtobot();
  my_query(ulist_pool[xo->pos]->userid, 0);
  ulist_neck(xo);
  return XO_FOOT;
}


static int
ulist_broadcast(xo)
  XO *xo;
{
  int num;
  pickup *pp;
  UTMP *up;
  BMW bmw;

  num = cuser.userlevel;
  if (!(num & PERM_SYSOP) &&
    (!(num & PERM_PAGE) || !(cuser.ufo & UFO_PAL)))
    return XO_NONE;

  num = xo->max;
  if (num < 1)
    return XO_NONE;

  bmw.caller = 0;
  bmw_edit(NULL, "���s���G", &bmw, 0);

  if (bmw.caller)
  {
    pp = ulist_pool;
    while (--num >= 0)
    {
      up = pp[num];
      if (can_override(up))
      {
	bmw.recver = up->userno;
	bmw_send(up, &bmw);
      }
    }
  }
  return XO_FOOT;
}


static int
ulist_talk(xo)
  XO *xo;
{
  if (HAS_PERM(PERM_PAGE))
  {
    UTMP *up;

    up = ulist_pool[xo->pos];
    if (can_override(up))
      return talk_page(up) ? ulist_head(xo) : XO_FOOT;
  }
  return XO_NONE;
}


static int
ulist_write(xo)
  XO *xo;
{
  if (HAS_PERM(PERM_PAGE))
  {
    UTMP *up;

    up = ulist_pool[xo->pos];
    if (can_override(up))
    {
      BMW bmw;
      char buf[20];

      sprintf(buf, "��[%s]", up->userid);
      bmw_edit(up, buf, &bmw, 0);
    }
  }
  return XO_NONE;
}


static int
ulist_edit(xo)			/* Thor: �i�u�W�d�ݤέק�ϥΪ� */
  XO *xo;
{
  ACCT acct;

  if (!HAS_PERM(PERM_SYSOP) ||
    acct_load(&acct, ulist_pool[xo->pos]->userid) < 0)
    return XO_NONE;

  vs_bar("�ϥΪ̳]�w");
  acct_setup(&acct, 1);
  return ulist_head(xo);
}


static int
ulist_kick(xo)
  XO *xo;
{
  if (HAS_PERM(PERM_SYSOP))
  {
    UTMP *up;
    pid_t pid;
    char buf[80];

    up = ulist_pool[xo->pos];
    if (pid = up->pid)
    {
      if (vans(msg_sure_ny) != 'y' || pid != up->pid)
	return XO_FOOT;

      sprintf(buf, "%s (%s)", up->userid, up->username);

      if ((kill(pid, SIGTERM) == -1) && (errno == ESRCH))
	up->pid = up->userno = 0;
      else
	sleep(3);		/* �Q�𪺤H�o�ɭԥ��b�ۧڤF�_ */

      blog("KICK ", buf);
      return ulist_init(xo);
    }
  }
  return XO_NONE;
}


#ifdef	HAVE_CHANGE_FROM
static int
ulist_fromchange(xo)
  XO *xo;
{
  char *str, buf[34];
  
  if (!cuser.userlevel)
    return XO_NONE;
  
  strcpy(buf, str = cutmp->from);
  vget(b_lines, 0, "�п�J�s���G�m�G", buf, sizeof(cutmp->from), GCARRY);
  if (strcmp(buf, str))
  {
    strcpy(str, buf);
    strcpy(cutmp->from, buf);
    ulist_body(xo);
  }

  return XO_FOOT;
}
#endif


static int
ulist_nickchange(xo)
  XO *xo;
{
  char *str, buf[24];

  if (!cuser.userlevel)
    return XO_NONE;

  strcpy(buf, str = cuser.username);
  vget(b_lines, 0, "�п�J�s���ʺ١G", buf, sizeof(cuser.username), GCARRY);
  if (strcmp(buf, str))
  {
    strcpy(str, buf);
    strcpy(cutmp->username, buf);
    ulist_body(xo);
  }
  return XO_FOOT;
}


static int
ulist_help(xo)
  XO *xo;
{
  film_out(FILM_ULIST, -1);
  return ulist_head(xo);
}


#if 0
static int
ulist_exotic(xo)
  XO *xo;
{
  UTMP *uhead, *utail, *uceil;
  char buf[80];

  if (!HAS_PERM(PERM_SYSOP))
    return XO_NONE;

  uhead = ushm->uslot;
  uceil = ushm->uceil;
  utail = uhead + MAXACTIVE - 1;
  sprintf(buf, "%s %p [%p, %p]\n", Now(), uceil, uhead, utail);
  f_cat("run/ushm.log", buf);

  ushm->uceil = utail;
  return ulist_init(xo);
}
#endif


static int
ulist_recall(xo)
  XO *xo;
{
  t_recall();
  return ulist_head(xo);
}


KeyFunc ulist_cb[] =
{
  XO_INIT, ulist_init,
  XO_LOAD, ulist_body,

  'f', ulist_pal,
  'a', ulist_makepal,
  't', ulist_talk,
  'w', ulist_write,
  'l', ulist_recall,		/* Thor: ���T�^�U */
  'r', ulist_query,
  'B', ulist_broadcast,
  's', ulist_init,		/* refresh status Thor: ��user�n�D */

#if 0
  'x', ulist_exotic,
#endif

  Ctrl('K'), ulist_kick,
  Ctrl('U'), ulist_edit,
  Ctrl('Q'), ulist_query,
  Ctrl('N'), ulist_nickchange,
#ifdef HAVE_CHANGE_FROM
  Ctrl('F'), ulist_fromchange,
#endif
  
#if 0
  '/', ulist_search,
#endif
  /* Thor.990125: �i�e��j�M, id or nickname */
  '/', ulist_search_forward,
  '?', ulist_search_backward,

  'm', ulist_mail,
  KEY_TAB, ulist_toggle,
  'h', ulist_help
};


/* ----------------------------------------------------- */
/* talk main-routines					 */
/* ----------------------------------------------------- */


int
t_pager()
{
  /* cuser.ufo = (cutmp->ufo ^= UFO_PAGER); */
  cuser.ufo ^= UFO_PAGER;
  cutmp->ufo ^= UFO_PAGER;  /* Thor.980805: �ѨM ufo���P�B���D */

  return 0;
}


int
t_query()
{
  ACCT acct;

  vs_bar("�d�ߺ���");
  if (acct_get(msg_uid, &acct) > 0)
  {
    move(2, 0);
    clrtobot();
    do_query(&acct, 0);
  }

  return 0;
}


#if 0
static int
talk_choose()
{
  UTMP *up, *ubase, *uceil;
  int self, seecloak;
  char userid[IDLEN + 1];

  ll_new();

  self = cuser.userno;
  seecloak = HAS_PERM(PERM_SEECLOAK);
  ubase = up = ushm->uslot;
  uceil = ushm->uceil;
  do
  {
    if (up->pid && up->userno != self &&
      (seecloak || !(up->ufo & UFO_CLOAK)))
      AddLinkList(up->userid);
  } while (++up <= uceil);

  if (!vget(1, 0, "�п�J�N���G", userid, IDLEN + 1, GET_LIST))
    return 0;

  up = ubase;
  do
  {
    if (!str_cmp(userid, up->userid))
      return up->userno;
  } while (++up <= uceil);

  return 0;
}


int
t_talk()
{
  int tuid, unum, ucount;
  UTMP *up;
  char ans[4];
  BMW bmw;

  if (ushm->count <= 1)
  {
    outs("�ثe�u�W�u���z�@�H�A���ܽЪB�ͨӥ��{�i" BOARDNAME "�j�a�I");
    return XEASY;
  }

  tuid = talk_choose();
  if (!tuid)
    return 0;

  /* ----------------- */
  /* multi-login check */
  /* ----------------- */

  move(3, 0);
  unum = 1;
  while ((ucount = utmp_count(tuid, 0)) > 1)
  {
    outs("(0) ���Q talk �F...\n");
    utmp_count(tuid, 1);
    vget(1, 33, "�п�ܤ@�Ӳ�ѹ�H [0]�G", ans, 3, DOECHO);
    unum = atoi(ans);
    if (unum == 0)
      return 0;
    move(3, 0);
    clrtobot();
    if (unum > 0 && unum <= ucount)
      break;
  }

  if (up = utmp_search(tuid, unum))
  {
    if (can_override(up))
    {
      ucount = vget(3, 0, "�T�w�n��ѶܡH T)alk W)rite Q)uit [T] ",
	ans, 3, LCECHO);

      if (ucount == 'q')
	return 0;

      if (tuid != up->userno)
      {
	vmsg(MSG_USR_LEFT);
	return 0;
      }

      if (ucount == 'w')
      {
	bmw_edit(up, "�����T�G", &bmw, 0);
      }
      else
      {
	talk_page(up);
      }
    }
    else
    {
      vmsg("��������I�s���F");
    }
  }

  return 0;
}
#endif


/* ------------------------------------- */
/* ���H�Ӧ���l�F�A�^���I�s��		 */
/* ------------------------------------- */


void
talk_rqst()
{
  UTMP *up;
  int mode, sock, ans, len, port;
  char buf[80];
  struct sockaddr_in sin;
  screenline sl[b_lines + 1];
#if     defined(__OpenBSD__)
  struct hostent *h;
#endif

#ifdef	LINUX
  /*
   * Linux �U�s�� page ���⦸�N�i�H�����X�h�G �o�O�ѩ�Y�Ǩt�Τ@ signal
   * �i�ӴN�|�N signal handler �]�w�����w�� handler, �������O default �O�N�{��
   * terminate. �ѨM��k�O�C�� signal �i�ӴN���] signal handler
   */

  signal(SIGUSR1, talk_rqst);
#endif

  up = cutmp->talker;
  if (!up)
    return;

  port = up->sockport;
  if (!port)
    return;

  mode = bbsmode;
  utmp_mode(M_TRQST);

  vs_save(sl);

  clear();
  sprintf(page_requestor, "%s (%s)", up->userid, up->username);

#ifdef EVERY_Z
  /* Thor.0725: �� talk & chat �i�� ^z �@�ǳ� */

  if (holdon_fd)
  {
    sprintf(buf, "%s �Q�M�z��A���L�z�u���@�i�L", page_requestor);
    vmsg(buf);
    buf[0] = ans = '6';		/* Thor.0725:�u���@�i�L */
    len = 1;
    goto over_for;
  }
#endif

  bell();
  prints("�z�Q�� %s ��ѶܡH(�Ӧ� %s)", page_requestor, up->from);
  for (;;)
  {
    ans = vget(1, 0, "==> Yes, No, Query�H[Y] ", buf, 3, LCECHO);
    if (ans == 'q')
    {
      my_query(up->userid, 0);
    }
    else
      break;
  }

  len = 1;

  if (ans == 'n')
  {
    move(2, 0);
    clrtobot();
    for (ans = 0; ans < 5; ans++)
      prints("\n (%d) %s", ans + 1, talk_reason[ans]);
    ans = vget(10, 0, "�п�J�ﶵ�Ψ�L���� [1]�G\n==> ",
      buf + 1, sizeof(buf) - 1, DOECHO);

    if (ans == 0)
      ans = '1';

    if (ans >= '1' && ans <= '5')
    {
      buf[0] = ans;
    }
    else
    {
      buf[0] = ans = ' ';
      len = strlen(buf);
    }
  }
  else
  {
    buf[0] = ans = 'y';
  }

#ifdef EVERY_Z
over_for:
#endif

  sock = socket(AF_INET, SOCK_STREAM, 0);

#if     defined(__OpenBSD__)                    /* lkchu */

  if (!(h = gethostbyname(MYHOSTNAME)))
    return;
  memset(&sin, 0, sizeof(sin));
  sin.sin_family = AF_INET;
  sin.sin_port = port;
  memcpy(&sin.sin_addr, h->h_addr, h->h_length);
                
#else

  sin.sin_family = AF_INET;
  sin.sin_port = port;
  sin.sin_addr.s_addr = INADDR_ANY /* INADDR_LOOPBACK */;
  memset(sin.sin_zero, 0, sizeof(sin.sin_zero));

#endif

  if (!connect(sock, (struct sockaddr *) & sin, sizeof(sin)))
  {
    send(sock, buf, len, 0);

    if (ans == 'y')
    {
      strcpy(cutmp->mateid, up->userid);
      talk_speak(sock);
    }
  }

  close(sock);
#ifdef  LOG_TALK
  if (ans == 'y')
    talk_save();          /* lkchu.981201: talk �O���B�z */
#endif
  vs_restore(sl);
  utmp_mode(mode);
}


void
talk_main()
{
  char fpath[64];
  
  xz[XZ_ULIST - XO_ZONE].xo = &ulist_xo;
  xz[XZ_ULIST - XO_ZONE].cb = ulist_cb;

  xz[XZ_PAL - XO_ZONE].cb = pal_cb;
  
  /* lkchu.981230: �Q�� xover ��X bmw */
  usr_fpath(fpath, cuser.userid, FN_BMW);
  xz[XZ_BMW - XO_ZONE].xo = xo_new(fpath);
  xz[XZ_BMW - XO_ZONE].cb = bmw_cb;
}
