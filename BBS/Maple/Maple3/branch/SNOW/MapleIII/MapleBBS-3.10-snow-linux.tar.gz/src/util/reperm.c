/*-------------------------------------------------------*/ 
/* util/reperm.c        ( NTHU CS MapleBBS Ver 3.10 )    */ 
/*-------------------------------------------------------*/ 
/* target : �۰ʭ��]�ϥΪ��v���{��                       */ 
/* author : opus.bbs@bbs.cs.nthu.edu.tw                  */ 
/* create : 96/10/07                                     */ 
/* update :   /  /                                       */ 
/*-------------------------------------------------------*/ 
/* syntax : reperm                                       */ 
/* input  : �Ԩ��{��		                         */ 
/* output : �Ԩ��{��                                     */ 
/*-------------------------------------------------------*/ 
  
/* Thor.991018: ���{���ΨӱN /tmp/new �ةҫ��w��id, 
                reset �Ҧ��v��, �ѤU PERM_DEFAULT (�Υ[�W PERM_VALID)
                �b�@�M�� run/manager.log �������v���ɯS�O���� */
    
#include "bbs.h"

main()
{
  FILE *fp;
  char *str, buf[128], fpath[128];
  int fd;
  ACCT acct;

  if (fp = fopen("/tmp/new", "r"))
  {
    while (fgets(buf, sizeof buf, fp))
    {
      fprintf(stderr, buf);

      str = strchr(buf + 1, ' ');
      *str = '\0';

      usr_fpath(fpath, buf + 1, ".ACCT");
      fd = open(fpath, O_RDWR);

      if (fd >= 0)
      {
	if (read(fd, &acct, sizeof(ACCT)) == sizeof(ACCT))
	{
	  if (acct.userlevel & PERM_VALID)
	    acct.userlevel = PERM_DEFAULT | PERM_VALID;
	  else
	    acct.userlevel = PERM_DEFAULT;
	  acct.ufo = UFO_COLOR | UFO_MOVIE | UFO_BNOTE;
	  lseek(fd, (off_t) 0, SEEK_SET);
	  write(fd, &acct, sizeof(ACCT));
	}
	close(fd);
      }
    }
    fclose(fp);
  }
}
