/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: mail_send_localmail.c,v 1.3 2000/09/30 16:18:13 jeffhung Exp $
 */

#define DEBUG_MAIL_SEND_LOCALMAIL

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */

#ifdef AS_ARNI_MODULE

int mod_mail_send_localmail(int ofd, char *sid, struct ARNI_ARGS *parg)
{
#ifdef DEBUG_MAIL_SEND_LOCALMAIL
	fprintf(stderr, "DEBUG(%s,%d):0:%s\n", __FILE__, __LINE__, parg->args[0].s);
	fprintf(stderr, "DEBUG(%s,%d):1:%s\n", __FILE__, __LINE__, parg->args[1].s);
	fprintf(stderr, "DEBUG(%s,%d):2:%s\n", __FILE__, __LINE__, parg->args[2].s);
	fprintf(stderr, "DEBUG(%s,%d):3:%s\n", __FILE__, __LINE__, parg->args[3].s);
#endif /* DEBUG_MAIL_SEND_LOCALMAIL */

	return mail_send_localmail(ofd, parg->args[0].s, parg->args[1].s,
	                           parg->args[2].s, parg->args[3].s);
}

#endif /* AS_ARNI_MODULE */


int mail_send_localmail(int ofd, char *fromid, char *toid, char *subject,
#ifdef AS_ARNI_MODULE
                        char *body)
#else /* AS_ARNI_MODULE */
                        char *fname)
#endif /* AS_ARNI_MODULE */
{
	int		touserno;
	char	lower_toid[IDLEN + 1];
	char    correct_fromid[IDLEN + 1];
	char    correct_toid[IDLEN + 1];
	char	idxfpath[MAXPATHLEN];
	HDR		mhdr;
	ACCT	from_acct;
	time_t	now;
	char	tmpfpath[MAXPATHLEN];
	FILE	*tmpfp;
#ifndef AS_ARNI_MODULE
	FILE	*bodyfp;
#endif /* AS_ARNI_MODULE */
	char	buf[GENERAL_BUFSIZE];

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

#ifdef  DEBUG_MAIL_SEND_LOCALMAIL
    fprintf(stderr, "DEBUG(%s:%d): toid: %s, fromid: %s\n",
            __FILE__, __LINE__, toid, fromid);
#endif  /* DEBUG_MAIL_SEND_LOCALMAIL */

	write(ofd, "MRR-RESULT:mail_send_localmail\n",
	      strlen("MRR-RESULT:mail_send_localmail\n"));

#ifdef	DEBUG_MAIL_SEND_LOCALMAIL
	fprintf(stderr, "DEBUG(%s:%d): Start mail_send_localmail\n",
	        __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_SEND_LOCALMAIL */
	/* prevent buffer overflow */
	if (strlen(toid) > IDLEN) {
		toid[IDLEN] = 0;
	}

#ifdef	DEBUG_MAIL_SEND_LOCALMAIL
	fprintf(stderr, "DEBUG(%s:%d): w3if_getCorrectUserID\n",
	        __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_SEND_LOCALMAIL */
	if (!(toid = w3if_getCorrectUserID(toid))) {

		write(ofd, "RESULT:no such user\nMRR-END:\n",
		      strlen("RESULT:no such user\nMRR-END:\n"));

		return -999; /* no such user */
	}
	strcpy(correct_toid, toid);
#ifdef	DEBUG_MAIL_SEND_LOCALMAIL
	fprintf(stderr, "DEBUG(%s:%d): w3if_getCorrectUserID done.\n", __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_SEND_LOCALMAIL */
	/* prevent buffer overflow */
	if (strlen(fromid) > IDLEN) {
		fromid[IDLEN] = 0;
	}

#ifdef  DEBUG_MAIL_SEND_LOCALMAIL
    fprintf(stderr, "DEBUG(%s:%d): toid: %s, fromid: %s\n",
            __FILE__, __LINE__, toid, fromid);
#endif  /* DEBUG_MAIL_SEND_LOCALMAIL */

	if (!(fromid = w3if_getCorrectUserID(fromid))) {

		write(ofd, "RESULT:no such user\nMRR-END:\n",
		      strlen("RESULT:no such user\nMRR-END:\n"));

		return -999; /* no such user */
	}
	strcpy(correct_fromid, fromid);
#ifdef	DEBUG_MAIL_SEND_LOCALMAIL
	fprintf(stderr, "DEBUG(%s:%d): correct_toid: %s, correct_fromid: %s\n",
	        __FILE__, __LINE__, correct_toid, correct_fromid);
#endif	/* DEBUG_MAIL_SEND_LOCALMAIL */

#ifdef	DEBUG_MAIL_SEND_LOCALMAIL
	fprintf(stderr, "DEBUG(%s:%d): acct_userno\n", __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_SEND_LOCALMAIL */
	if ((touserno = acct_userno(correct_toid)) <= 0) {

		write(ofd, "RESULT:no such user\nMRR-END:\n",
		      strlen("RESULT:no such user\nMRR-END:\n"));

		return -999; /* no such user */
	}

	/* create file to store mail header and content */
#ifdef	DEBUG_MAIL_SEND_LOCALMAIL
	fprintf(stderr, "DEBUG(%s:%d): acct_load\n", __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_SEND_LOCALMAIL */
	acct_load(&from_acct, correct_fromid);
	tmpnam(tmpfpath);
	if (!(tmpfp = fopen(tmpfpath, "w"))) {
		return -999; /* can not create temp file */
	}
	time(&now);
	fprintf(tmpfp, "�@��: %s (%s)\n"
	               "���D: %s\n"
	               "�ɶ�: %s\n",
	        from_acct.userid, subject, from_acct.username, ctime(&now));
#ifdef AS_ARNI_MODULE
#ifdef DEBUG_MAIL_SEND_LOCALMAIL
	fprintf(stderr, "DEBUG(%s,%d): body: %s\n", __FILE__, __LINE__, body);
#endif /* DEBUG_MAIL_SEND_LOCALMAIL */
	fprintf(tmpfp, "%s", body);
#else /* AS_ARNI_MODULE */
	if (!(bodyfp = fopen(fname, "r"))) {
		fclose(tmpfp);

		write(ofd, "RESULT:can not open mail body file\nMRR-END:\n",
		      strlen("RESULT:can not open mail body file\nMRR-END:\n"));

		return -999; /* can not open mail body file */
	}
	while (fgets(buf, GENERAL_BUFSIZE, bodyfp)) {
		fprintf(tmpfp, "%s", buf);
	}
	fclose(bodyfp);
#endif /* AS_ARNI_MODULE */
	fclose(tmpfp);

	str_lower(lower_toid, correct_toid);
	snprintf(idxfpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/.DIR",
	         lower_toid[0], lower_toid);
	hdr_stamp(idxfpath, HDR_LINK, &mhdr, tmpfpath);
	/* JeffHung.20000718: HDR_LINK means hard link */
	strncpy(mhdr.owner, from_acct.userid, 80 - 1);
	strncpy(mhdr.nick, from_acct.username, 50 - 1);
	strncpy(mhdr.title, subject, TTLEN);
	if (rec_add(idxfpath, &mhdr, sizeof(HDR)) != 0) {

		write(ofd, "RESULT:append mail record failed\nMRR-END:\n",
		      strlen("RESULT:append mail record failed\nMRR-END:\n"));

		return -999; /* append mail record failed */
	}
	unlink(tmpfpath);

	write(ofd, "RESULT:OK\nMRR-END:\n", strlen("RESULT:OK\nMRR-END:\n"));

	return 0; /* success */
}

