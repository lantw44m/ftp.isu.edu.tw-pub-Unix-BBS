/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 * $Id: chat_connect.c,v 1.8 2000/09/30 16:18:13 jeffhung Exp $
 */

#undef DEBUG_CHAT_CONNECT

#include "live.h"
#include "live_server.h"
#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"

int mod_chat_connect(int ofd, char *sid , struct LIVE_ARGS *args)
{
	char *userid , *chatid, *action , *message , *type;
  int i , index;
	userid  = args->args[0].s;
	chatid  = args->args[1].s;
	action  = args->args[2].s;
	message = args->args[3].s;
	type    = args->args[4].s;

  chat_connect(ofd , sid , userid, chatid, action, message, type);
}
static int printchatline( int ofd, char *msg )
{
	write( ofd , msg , strlen(msg));      
}

static inline int
recv_data(fd, ofd)
  int fd;
	int ofd;
{
  char buf[512];
	int len , buf_size;
  buf_size = sizeof(buf);
  memset(buf, 0 , buf_size);
	if ((len = recv(fd, buf, buf_size, 0)) <= 0)
    return -1;

  printchatline(ofd , buf);
	return 0;
}


/* ---------------------------------------------------------------- */
/* Argument: ofd      -> �ǹL�Ӫ�socket fd                          */
/*           sid     -> Session ID                                  */
/*           UserID  -> �ϥΪ�ID                                    */
/*           ChatID  -> chat�Ϊ�ID                                  */
/*           Action  -> �ϥΪ̰ʧ@                                  */
/*           Message -> �T��                                        */
/*           Type    -> �T������                                    */
/* ---------------------------------------------------------------- */

int chat_connect(int ofd, char *sid, char *UserID, char *ChatID ,char *Action, char *Message, char *Type)
{
	char buf[GENERAL_BUFSIZE], recv_buf[128];
  char out_buf[512];
	struct sockaddr_in sin;
  int fd;
	
  chdir(BBSHOME);

	sin.sin_family = AF_INET;
  sin.sin_port = htons(LIVE_SERVER_PORT);
  /* ����address any , �H��A�令��flixable*/
	sin.sin_addr.s_addr = INADDR_ANY; 
  memset(sin.sin_zero, 0, sizeof(sin.sin_zero));
  fd = socket(AF_INET, SOCK_STREAM, 0);
 

	if (fd < 0)
   return -1;

  if (connect(fd, (struct sockaddr *) & sin, sizeof sin))
  {
    close(fd);
    fprintf(stderr , "connect fail\n");
    return -1;
  }
  fprintf(stderr , "chat_connect:connect ok\n");
 
  snprintf(buf , GENERAL_BUFSIZE,
	         "MRR-REQUEST:chat_client\n"
					 "MRR-SID:%s\n"
					 "USERID:%s\n"
					 "CHATID:%s\n"
					 "ACTION:%s\n"
					 "MESSAGE:%s\n"
					 "TYPE:%s\n"
					 "MRR-END:%s\n",
					 sid,
					 UserID,
					 ChatID,
					 Action,
					 Message,
					 Type );
#ifdef DEBUG_CHAT_CONNECT
  fprintf(stderr , "writing to xchatd\n");
#endif
	write(fd , buf , strlen(buf));

	if( !strcasecmp(Action , "enter") )
	{
	  snprintf(out_buf , 128 , "MRR-RESULT:chat_connect\n"
		                         "NO-MSG:YES\n"
														 "MRR-END:\n");
    write(ofd , out_buf , strlen(out_buf) ); 
	  close(fd);
	}
	for(; recv_data(fd,ofd) >= 0 ; );
#ifdef DEBUG_CHAT_CONNECT
  fprintf(stderr , "closing xchatd\n");
#endif

/*  close(fd);   */
}
