/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: talk_kickusr.c,v 1.3 2000/09/30 16:18:13 jeffhung Exp $
 */

#undef DEBUG_TALK_KICKUSR

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"
#include <string.h>
#include <sys/types.h>
#include <signal.h>
#include "w3if_session.h"


int talk_kickusr(char *sid, pid_t kickpid)
{
	W3IF_SESSENTRY *psess = 0;
	W3IF_SESSENTRY *pkick = 0;
	int            i;
	UTMP           *up;
	char           buf[80];

#ifdef DEBUG_TALK_KICKUSR

	fprintf(stderr, "DEBUG(%s,%d): enter talk_kickusr()\n",
	        __FILE__, __LINE__);

#endif /* DEBUG_TALK_KICKUSR */

	chdir(BBSHOME);

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	psess = w3ifsession_get(sid);

	if (!psess) {
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;
	acct_load(&cuser, cutmp->userid);

	if (!HAS_PERM(PERM_SYSOP)) {
		return 999; /* no permission */
	}

#ifdef DEBUG_TALK_KICKUSR

	fprintf(stderr, "DEUBG(%s,%d): begin to find pkick by pid: %d\n",
	        __FILE__, __LINE__, (pid_t)kickpid);

#endif /* DEBUG_TALK_KICKUSR */

	for (i = 0; i < MAXACTIVE; ++i) {
		if (ushm->uslot[i].pid == kickpid) {
			up = &(ushm->uslot[i]);
			break;
		}
	}
	if (!up) {
		return 999; /* no such user */
	}

	sprintf(buf, "%s (%s)", up->userid, up->username);

	if (up->from[0] == W3IF_FROM_TAG) {
		/* this one come from web interface */

		if (!(pkick = w3ifsession_get_by_pid(kickpid))) {
			return 999; /* no such user */
		}

		up->pid = up->userno = 0;
		--(ushm->count);
		w3ifsession_delete(pkick->php_sid);
	}
	else {
		/* this one come from telnet interface */

		if ((kill(up->pid, SIGTERM) == -1) && (errno == ESRCH)) {
			up->pid = up->userno = 0;
		}
	}

	blog("KICK", buf);

	return 0;
}

