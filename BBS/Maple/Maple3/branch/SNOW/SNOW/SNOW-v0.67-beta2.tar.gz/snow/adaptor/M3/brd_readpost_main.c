/*
 *  $Id: brd_readpost_main.c,v 1.2 2000/09/30 08:05:11 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	fd;
	int	ret;

	if (argc != 3) {
		printf("Usage: %s <board-id> <post-file-name>\n", argv[0]);
		return 0;
	}

	fd = fileno(stdout);

	if ((ret = brd_readpost(fd, argv[1], argv[2])) < 0) {
		fprintf(stderr, "brd_readpost error(%d).\n", ret);
	}

	return 0;
}

