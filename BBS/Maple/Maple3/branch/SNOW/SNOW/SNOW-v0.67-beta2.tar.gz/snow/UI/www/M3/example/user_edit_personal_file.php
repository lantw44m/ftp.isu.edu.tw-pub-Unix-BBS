<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�s��ӤH�ɮ�");

$SNOW_PAGE_TITLE = "�s��ӤH�ɮ�";
$SNOW_PAGEAREA_MAIN = "user_edit_personal_file.m.php";
$SNOW_PAGEAREA_FUNC = "user_edit_personal_file.f.php";

include("bone.php");

?>