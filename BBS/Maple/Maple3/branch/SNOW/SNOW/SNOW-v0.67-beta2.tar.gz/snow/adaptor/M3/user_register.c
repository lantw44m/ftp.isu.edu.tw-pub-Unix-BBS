/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: user_register.c,v 1.3 2000/09/30 16:18:14 jeffhung Exp $
 */

static int uniq_userno(int fd)
{
	char   buf[4096];
	int    userno;
	int    size;
	SCHEMA *sp; /* record length 16 �i�㰣 4096 */

	userno = 1;

	while ((size = read(fd, buf, sizeof(buf))) > 0) {
		sp = (SCHEMA*)buf;
		do {
			if (sp->userid[0] == '\0') {
				lseek(fd, -size, SEEK_CUR);
				return userno;
			}
			++userno;
			size -= sizeof(SCHEMA);
			++sp;
		} while (size);
	}

	return userno;
}


int user_register(int ofd, char *newid, char *newpasswd, char *newnick,
                           char *newrealname, char *newaddress)
{
#ifdef LOGINASNEW

	SCHEMA slot;
	char   buf[MAXPATHLEN];
	int    fd;
	int    userno;

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	psess = w3ifsession_get(sid);

	if (!psess) {
		return -999; /* no such session */
	}

	/* JeffHung: ���Ӥw�g�H guest login �L�F�C */
	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;

	if (strlen(newid) > IDLEN) {
		newid[IDLEN] = 0;
	}

	if (is_badid(newid)) {
		return -999; /* �L�k�����o�ӥN���A�Шϥέ^��r���A�åB���n�]�t�Ů� */
	}

	usr_fpath(buf, newid, NULL);
	if (dashd(buf)) {
		return -999; /* ���N���w�g���H�ϥ� */
	}

	memset(&cuser, 0, sizeof(cuser));

	strncpy(cuser.userid, newuserid, sizeof(cuser.userid));

	if (strlen(newpasswd) > PASSLEN) {
		newpasswd[PASSLEN] = 0;
	}

	if ((strlen(newpasswd) < 3) || !strcmp(newpasswd, newid)) {
		return -999; /* �K�X��²��A���D�J�I�A�ܤ֭n 4 �Ӧr�A�Э��s��J */
	}

	strncpy(cuser.passwd, genpasswd(newpasswd), PASSLEN);

	if (strlen(newnick) < 2) {
		return -999; /* �ʺ٤ӵu */
	}
	strncpy(cuser.username, newnick, sizeof(cuser.username));

	if (strlen(newrealname) < 4) {
		return -999; /* �ʺ٤ӵu */
	}
	strncpy(cuser.realname, newrealname, sizeof(cuser.realname));

	if (strlen(newaddress) < 12) {
		return -999; /* �ʺ٤ӵu */
	}
	strncpy(cuser.address, newaddress, sizeof(cuser.address));

	cuser.userlevel = PERM_DEFAULT;
	/* Thor.980805: ����, �w�]�X��ufo *
	cuser.ufo = UFO_COLOR | UFO_MOVIE | UFO_BNOTE;
	cuser.numlogins = 1;

	/* dispatch unique userno */

	cuser.firstlogin = cuser.lastlogin = cuser.tcheck = slot.uptime = ap_start;
	memcpy(slot.userid, newid, IDLEN);

	fd = open(FN_SCHEMA, O_RDWR | O_CREAT, 0600);
	{
		/* flock(fd, LOCK_EX); */
		/* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
		f_exlock(fd);

		cuser.userno = userno = uniq_userno(fd);
		write(fd, &slot, sizeof(slot));

		/* flock(fd, LOCK_UN); */
		/* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
		f_unlock(fd);
	}
	close(fd);

	usr_fpath(buf, userid, NULL);
	mkdir(buf, 0755);
	strcat(buf, "/@");
	mkdir(buf, 0755);

	usr_fpath(buf, newid, fn_acct);
	fd = open(buf, O_WRONLY | O_CREAT, 0600);
	write(fd, &cuser, sizeof(cuser));
	close(fd);
	/* Thor.990416: �`�N: ���|�� .ACCT���׬O0��, �ӥB�u��@�ؿ�, �����[� */

	sprintf(buf, "%d", userno);
	blog("APPLY", buf);

	/* �ܨ������s�ϥΪ� */
	/* ... */

	return 0;

#else /* LOGINASNEW */

	return -999; /* ���t�Υثe�Ȱ��u�W���U, �Х� guest �i�J */

#endif /* LOGINASNEW */
}

