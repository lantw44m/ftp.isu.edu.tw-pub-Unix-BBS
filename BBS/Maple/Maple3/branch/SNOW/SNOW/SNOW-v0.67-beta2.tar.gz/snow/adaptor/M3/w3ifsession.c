/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: w3ifsession.c,v 1.4 2000/09/30 16:18:14 jeffhung Exp $
 */

#undef DEBUG_W3IFSESSION

#include "w3if_session.h"
#include <string.h>
#include "bbs.h"
#include "dao.h"
#include "w3ifglobal.h"


static W3IF_SESSTBL *sessshm = 0;




static W3IF_SESSTBL *w3ifsession_attach()
{
	return (sessshm = (W3IF_SESSTBL*)shm_attach(SESSSHM_KEY,
	                                            sizeof(W3IF_SESSTBL)));
}


int w3ifsession_insert(char *sid, UTMP *utmp_entry)
{
	int i;

	if (!sessshm) {
		if (!w3ifsession_attach()) {
			return -999; /* cannot attach sessshm */
		}
	}

	for (i = 0; i < MAXACTIVE; ++i) {
		if (!(sessshm->w3ifslot[i].utmp_entry)) {
			strncpy(sessshm->w3ifslot[i].php_sid, sid, 32);
			sessshm->w3ifslot[i].utmp_entry = utmp_entry;
			sessshm->w3ifslot[i].has_msg = 0;
			time(&(sessshm->w3ifslot[i].ap_start));
			++(sessshm->count);

			return 0;
		}
	} /* for (i) */

	return 999; /* no room */
}



W3IF_SESSENTRY *w3ifsession_get(char *sid)
{
	int i;

	if (!sessshm) {
		if (!w3ifsession_attach()) {
			return 0; /* cannot attach sessshm */
		}
	}

	for (i = 0; i < MAXACTIVE; ++i) {
#ifdef DEBUG_W3IFSESSION
		fprintf(stderr, "DEBUG(%s,%d):w3ifslot[%d].php_sid:%s\n",
		        __FILE__, __LINE__, i, sessshm->w3ifslot[i].php_sid);
#endif /* DEBUG_W3IFSESSION */
		if (sessshm->w3ifslot[i].utmp_entry &&
		    !strncmp(sessshm->w3ifslot[i].php_sid, sid, 32)) {
			return &(sessshm->w3ifslot[i]);
		}
	} /* for (i) */

	return 0; /* no such session */
}

W3IF_SESSENTRY *w3ifsession_get_by_pid(pid_t pid)
{
	int i;

	if (!sessshm) {
		if (!w3ifsession_attach()) {
			return 0; /* cannot attach sessshm */
		}
	}

	for (i = 0; i < MAXACTIVE; ++i) {
		if (sessshm->w3ifslot[i].utmp_entry) {
			if (sessshm->w3ifslot[i].utmp_entry->pid == pid) {
				return &(sessshm->w3ifslot[i]);
			}
		}
	} /* for (i) */

	return 0; /* no such session */
}

int w3ifsession_reinsert(char *sid, UTMP *utmp_entry)
{
	W3IF_SESSENTRY *psess;

	if (!sessshm) {
		if (!w3ifsession_attach()) {
			return -999; /* cannot attach sessshm */
		}
	}

	if (!(psess = w3ifsession_get(sid))) {
		return 999; /* no such session */
	}

	psess->utmp_entry = utmp_entry;
	psess->has_msg = 0;
	time(&(psess->ap_start));

	return 0;
}


int w3ifsession_delete(char *sid)
{
	W3IF_SESSENTRY *psess;

	if (!sessshm) {
		if (!w3ifsession_attach()) {
			return -999; /* cannot attach sessshm */
		}
	}

	if (!(psess = w3ifsession_get(sid))) {
		return 999; /* no such session */
	}

	psess->php_sid[0] = 0;
	psess->utmp_entry = 0;
	psess->has_msg = 0;
	psess->ap_start = 0;
	--(sessshm->count);

	return 0;
}


