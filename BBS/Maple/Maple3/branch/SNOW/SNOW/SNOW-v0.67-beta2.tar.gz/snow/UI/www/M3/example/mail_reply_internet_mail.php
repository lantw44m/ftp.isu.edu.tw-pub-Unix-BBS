<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�^�� Internet �H��");

$SNOW_PAGE_TITLE = "�^�� Internet �H��";
$SNOW_PAGEAREA_MAIN = "mail_reply_internet_mail.m.php";
$SNOW_PAGEAREA_FUNC = "mail_reply_internet_mail.f.php";

include("bone.php");

?>