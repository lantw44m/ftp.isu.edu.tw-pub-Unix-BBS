/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: mod_mail.h,v 1.3 2000/09/30 16:18:14 jeffhung Exp $
 */

#ifndef MOD_MAIL_H_INCLUDED
#define MOD_MAIL_H_INCLUDED

#include "w3if.h"
#include "mod_header.h"

/* talk_ulist.c */

/* declare �nexport��server��table name */
extern BBS_Mod_Request_Table mail_delete_table[];
extern BBS_Mod_Request_Table mail_delete_range_table[];
extern BBS_Mod_Request_Table mail_first_unread_mail_table[];
extern BBS_Mod_Request_Table mail_mbox_table[];
extern BBS_Mod_Request_Table mail_readmail_table[];
extern BBS_Mod_Request_Table mail_send_internetmail_table[];
extern BBS_Mod_Request_Table mail_send_localmail_table[];
extern BBS_Mod_Request_Table mail_toggle_mark_table[];

/* declare �nexport��server �� function */
int mail_delete_main(int fd, BBS_Mod_Request_Table *res_table);
int mail_delete_register(BBS_Mod_Pool_Table *pool);

int mail_delete_range_main(int fd, BBS_Mod_Request_Table *res_table);
int mail_delete_range_register(BBS_Mod_Pool_Table *pool);

int mail_first_unread_mail_main(int fd, BBS_Mod_Request_Table *res_table);
int mail_first_unread_mail_register(BBS_Mod_Pool_Table *pool);

int mail_mbox_main(int fd, BBS_Mod_Request_Table *res_table);
int mail_mbox_register(BBS_Mod_Pool_Table *pool);

int mail_readmail_main(int fd, BBS_Mod_Request_Table *res_table);
int mail_readmail_register(BBS_Mod_Pool_Table *pool);

int mail_send_internetmail_main(int fd, BBS_Mod_Request_Table *res_table);
int mail_send_internetmail_register(BBS_Mod_Pool_Table *pool);

int mail_send_localmail_main(int fd, BBS_Mod_Request_Table *res_table);
int mail_send_localmail_register(BBS_Mod_Pool_Table *pool);

int mail_toggle_mark_main(int fd, BBS_Mod_Request_Table *res_table);
int mail_toggle_mark_register(BBS_Mod_Pool_Table *pool);

#endif /* MOD_MAIL_H_INCLUDED */

