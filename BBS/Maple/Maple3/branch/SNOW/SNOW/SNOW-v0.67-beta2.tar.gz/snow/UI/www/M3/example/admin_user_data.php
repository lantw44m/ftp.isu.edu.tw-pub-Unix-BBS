<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�s��/�ק�ϥΪ̸��");

/*
 * Required Inputs: iUserID
 */

$SNOW_PAGE_TITLE = "�s��/�ק�ϥΪ̸��";
$SNOW_PAGEAREA_MAIN = "admin_user_date.m.php";
$SNOW_PAGEAREA_FUNC = "admin_user_data.f.php";

include("bone.php");

?>