/*
 *  $Id: talk_lib.c,v 1.1.1.1 2000/09/30 03:48:18 arlo Exp $
 */

#define _MODES_C_
#include "w3iflib.h"
#include "w3ifglobal.h"

#include "bbs.h"

#define PAL_MAX (200)

static int pal_count;
static int *pal_pool;

static int int_cmp(int *a, int *b)
{
	return *a - *b;
}

void pal_cache()
{
	int  count;
	int  fsize;
	int  ufo;
	int  *plist;
	int  *cache;
	PAL  *phead;
	PAL  *ptail;
	char *fimage;
	char fpath[MAXPATHLEN];

	if ((cache = pal_pool)) {
		free(cache);
	}
	cache = 0;
	count = 0;
	ufo = cuser.ufo & ~(UFO_REJECT | UFO_FCACHE);

	usr_fpath(fpath, cuser.userid, FN_PAL);
	fimage = f_img(fpath, &fsize);

	if (fimage) {
		if (fsize > PAL_MAX * sizeof(PAL)) {
			snprintf(fpath, MAXPATHLEN, "%-13s%d\n", cuser.userid, fsize);
			f_cat("run/pal", fpath);
			fsize = PAL_MAX * sizeof(PAL);
		}

		count = fsize / sizeof(PAL);
		if (count) {
			cache = plist = (int*)malloc(sizeof(int) * count);
			phead = (PAL*)fimage;
			ptail = (PAL*)(fimage + fsize);
			do {
				if (phead->ftype & PAL_BAD) {
					ufo |= UFO_REJECT;
					--count;
				}
				else {
					*plist++ = phead->userno;
				}
			} while (++phead < ptail);

			if (count > 0) {
				ufo |= UFO_FCACHE;
				if (count > 1) {
					xsort(cache, count, sizeof(int), int_cmp);
				}
			}
			else {
				free(cache);
				cache = 0;
			}
		}
		free(fimage);
	} /* if (fimage) */

	pal_pool = cache;
	pal_count = count;

	if (cutmp) {
		ufo = (ufo & ~UFO_UTMP_MASK) | (cutmp->ufo & UFO_UTMP_MASK);
		cutmp->ufo = ufo;
	}
	cuser.ufo = ufo;
}


int is_pal(int userno)
{
	int count;
	int *cache;
	int datum;
	int mid;

	/* JeffHung.20000829: a typical binary search */
	if (cache = pal_pool) {
		for (count = pal_count; count > 0; ) {
			datum = cache[mid = count >> 1];
			if (userno == datum) {
				return 1;
			}
			if (userno > datum) {
				cache += (++mid);
				count -= mid;
			}
			else {
				count = mid;
			}
		}
	}
	return 0;
}


char *
bmode(up, simple)
  UTMP *up;
  int simple;
{
  static char modestr[32];
  int mode;
  char *word;

  word = ModeTypeTable[mode = up->mode];
  if (simple)
    return (word);

  if (mode < M_TALK || mode > M_QUERY)
    return (word);

  if (mode != M_QUERY && !HAS_PERM(PERM_SEECLOAK) && (up->ufo & UFO_CLOAK))
    return (word); /* Thor.980805: ����: �������H���|�Q���D���talk */

  sprintf(modestr, "%s [%s]", word, up->mateid);
  return (modestr);
}

int can_override(UTMP *up)
{
  int self, ufo, can, fd;
  char fpath[64];
  PAL *pal;

  if (up->userno == (self = cuser.userno))
    return NA;

  if (HAS_PERM(PERM_SYSOP | PERM_ACCOUNTS))	/* �����B�b���޲z�� */
    return YEA;

  ufo = up->ufo;

  if (ufo & UFO_QUIET)		/* �������� */
    return NA;

  if (!(ufo & (UFO_PAGER | UFO_REJECT)))
    return YEA;			/* �I�s���S�����A��L�l�� */

  if ((ufo & UFO_PAGER) && !(ufo & UFO_FCACHE))
    return NA;

#if 0
  self = pal_belong(up->userid, self);
#endif

  can = 1;			/* �䤣�쬰 normal */

  usr_fpath(fpath, up->userid, FN_PAL);
  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    mgets(-1);
    while (pal = mread(fd, sizeof(PAL)))
    {
      if (self == pal->userno)
      {
	can = pal->ftype;
	break;
      }
    }
    close(fd);
  }

  return (ufo & UFO_PAGER)
    ? can == 0			/* �u���n�ͥi�H */
    : can < 2 /* �u�n���O�l�� */ ;
}

int
bm_belong(board)
  char *board;
{
  int fsize, count, result;
  char fpath[80];

  result = 0;

  brd_fpath(fpath, board, "fimage");   /* Thor: fimage�n�� sort�L! */
  board = f_img(fpath, &fsize);

  if (board != NULL)
  {
    count = fsize / sizeof(int);
    if (count > 0)
    {
      int userno, *up;
      int datum, mid;

      userno = cuser.userno;
      up = (int *) board;

      while (count > 0)
      {
        datum = up[mid = count >> 1];
        if (userno == datum)
        {
          result = BRD_R_BIT | BRD_W_BIT;
          break;
        }
        if (userno > datum)
        {
          up += (++mid);
          count -= mid;
        }
        else
        {
          count = mid;
        }
      }
    }
    free(board);
  }
  return result;
}
