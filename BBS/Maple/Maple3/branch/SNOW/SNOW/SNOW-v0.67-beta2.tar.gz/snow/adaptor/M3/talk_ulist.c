/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: talk_ulist.c,v 1.4 2000/09/30 16:18:14 jeffhung Exp $
 */

/* ----------------------------------------------------- */
/* �q�X�ثe�u�W���ϥΪ�                                  */
/* ----------------------------------------------------- */

#define	_MODES_C_	/* for ModeTypeTable */
#undef DEBUG_TALK_ULIST
#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include <stdlib.h> /* for malloc/free */

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */

#if 0 /* JeffHung.20000904: ���� lib/talk_lib.c */

#define PAL_MAX         200     /* �n�ͦW��W�� */

static int pal_count;
static int *pal_pool;

#endif /* 0 */

#define PICKUP_WAYS	5
static int pickup_way = 4 ;
typedef UTMP *pickup;

static pickup ulist_pool[MAXACTIVE];
#ifdef  FRIEND_FIRST
static int friend_num;          /* lkchu.990510: �O���ثe���W�n�ͼ� */
#endif


#ifdef AS_ARNI_MODULE

int mod_talk_ulist(int ofd, char *sid , struct ARNI_ARGS *args)
{
#ifdef DEBUG_TALK_ULIST
	fprintf(stderr, "DEBUG(%s,%d):entering mod_talk_ulist\n"
	        __FILE__, __LINE__);
#endif /* DEBUG_TALK_ULIST */
	return talk_ulist(ofd, args->args[0].s, args->args[1].i,
	                       args->args[2].i, args->args[3].i);
}

#endif /* AS_ARNI_MODULE */

#if 0 /* JeffHung.20000904: ���� lib/talk_lib.c */

int is_pal(int userno)
{
	int	count;
	int	*cache;
	int	datum;
	int	mid;

	if ((cache = pal_pool)) {
		for (count = pal_count; count > 0;) {
			datum = cache[mid = count >> 1];
			if (userno == datum) {
				return 1;
			}
			if (userno > datum) {
				cache += (++mid);
				count -= mid;
			}
			else {
				count = mid;
			}
		}
	}
	return 0;
}

static int int_cmp(int *a, int *b)
{
	return *a - *b;
}

      
void pal_cache()
{
	int		count;
	int		fsize;
	int		ufo;
	int		*plist;
	int		*cache;
	PAL		*phead;
	PAL		*ptail;
	char	*fimage;
	char	fpath[MAXPATHLEN];

	if ((cache = pal_pool)) {
		free(cache);
	}

	cache = NULL;
	count = 0;
	ufo = cuser.ufo & ~(UFO_REJECT | UFO_FCACHE);

	usr_fpath(fpath, cuser.userid, FN_PAL);
	fimage = f_img(fpath, &fsize);

	if (fimage != NULL) {
		if (fsize > PAL_MAX * sizeof(PAL)) {
			sprintf(fpath, "%-13s%d\n", cuser.userid, fsize);
			f_cat("run/pal", fpath);
			fsize = PAL_MAX * sizeof(PAL);
		}

		count = fsize / sizeof(PAL);
		if (count) {
			cache = plist = (int*)malloc(sizeof(int) * count);
			phead = (PAL*)fimage;
			ptail = (PAL*)(fimage + fsize);
			do {
				if (phead->ftype & PAL_BAD) {
					ufo |= UFO_REJECT;
					count--;
				}
				else {
					*plist++ = phead->userno;
				}
			} while (++phead < ptail);

			if (count > 0) {
				ufo |= UFO_FCACHE;
				if (count > 1) {
					xsort(cache, count, sizeof(int), int_cmp);
				}
			}
			else {
				free(cache);
				cache = NULL;
			}
		}
		free(fimage);
	}

	pal_pool = cache;
	pal_count = count;

	if (cutmp) {
		ufo = (ufo & ~UFO_UTMP_MASK) | (cutmp->ufo & UFO_UTMP_MASK);
		cutmp->ufo = ufo;
	}
	cuser.ufo = ufo;
}

#endif /* 0 */


static int ulist_body(int ofd, int Top, int Range, int Max)
{
	pickup	*pp;
	UTMP	*up;
	int		n;
	int		cnt;
	int		max;
	int		ufo;
	int		self;
	int		userno;
	int		sysop;
	int		diff;
	int		pal;
	char	buf[8];
	char	out_buf[GENERAL_BUFSIZE];

	pal = cuser.ufo;
	max = Max;
	if (max <= 0) {
		if ((pal & UFO_PAL) == 0) {
			/* impossible */
			printf("nobody");
			return XO_QUIT;
		}

#if	0
		printf("�ثe�S���B�ͤW��\n");
#endif	/* 0 */

		return -1;    
	}

	pal &= UFO_PAL;
	cnt = Top - 1;
	pp = &ulist_pool[cnt];
	self = cuser.userno;
	sysop = HAS_PERM(PERM_SYSOP | PERM_ACCOUNTS);

	n = 0;
	while (++n <= Range) {
		if (cnt++ < max) {
			up = *pp++;
			if ((userno = up->userno)) {
				if ((diff = up->idle_time)) {
					sprintf(buf, "%2d", diff);
				}
				else {
					buf[0] = '\0';
				}

				ufo = up->ufo;
				if (ufo & UFO_QUIET) {
					diff = 'Q';
				}
				else if (ufo & UFO_PAGER) {
					diff = can_override(up) ? 'o' : '*';
				}
				else {
					diff = ' ';
				}
#if 0
				printf("%5d%c%c %-13s%-19.18s%-19.18s%-17.17s%s",
				       cnt, (ufo & UFO_CLOAK ? ')' : ' '), diff,
				       up->userid,
				       up->username,
				       (diff == ' ' || diff == 'o' || sysop) ? up->from : "*",
				       bmode(up, 0), buf);
#endif	/* 0 */

/*
 *  Arlo.20000729: Display Part
 */
				write(ofd, "MRR-RESULT:talk_ulist\n",
				      strlen("MRR-RESULT:talk_ulist\n"));

				snprintf(out_buf, GENERAL_BUFSIZE,
				         "PID:%d\n"
				         "USERID:%s\n"
				         "USERNAME:%s\n"
				         "FROM:%s\n"
				         "MODE:%s\n"
				         "IDLE-TIME:%s\n",
				         up->pid,
				         up->userid,
				         up->username,
				         (diff == ' ' || diff == 'o' || sysop) ?
				             up->from : "*",
				         bmode(up, 0),
				         buf);
				write(ofd, out_buf,strlen(out_buf));
			}
			else {
#if	0
				printf("      < ������ͥ������} >");
#endif	/* 0 */
			}
		}
	}

	write(ofd, "MRR-END:\n", strlen("MRR-END:\n"));
	return 0;
}

/*
 *  �ƧǤ�k
 */

static int ulist_cmp_userid(UTMP **i, UTMP **j)
{
	return str_cmp((*i)->userid, (*j)->userid);
}


static int ulist_cmp_host(UTMP **i, UTMP **j)
{
	return (*i)->in_addr - (*j)->in_addr;
}


static int ulist_cmp_mode(UTMP **i, UTMP **j)
{
	return (*i)->mode - (*j)->mode;
}

static int ulist_cmp_pal(UTMP **i, UTMP **j)
{
	int	pal_diff = 0;

	if (((*i)->userno == cuser.userno) || is_pal((*i)->userno)) {
		--pal_diff;
	}

	if (((*j)->userno == cuser.userno) || is_pal((*j)->userno)) {
		++pal_diff;
	}

	if (pal_diff) {
		return pal_diff;
	}

	return str_cmp((*i)->userid, (*j)->userid);
}


static int (*ulist_cmp[]) () =
{
	ulist_cmp_userid,
	ulist_cmp_host,
	ulist_cmp_mode,
	ulist_cmp_pal
};


static int ulist_init(XO *xo)
{
	UTMP	*up;
	UTMP	*uceil;
	pickup	*pp;
	int		max;
	int		filter;
	int		seecloak;
	int		userno;
	int		self;
#ifdef	FRIEND_FIRST
	pickup	*qq;
	pickup	o_pool[MAXACTIVE];
#endif	/* FRIEND_FIRST */

	pp = ulist_pool;
#ifdef	FRIEND_FIRST
	qq = o_pool;	
#endif	/* FRIEND_FIRST */
	self = cuser.userno;
	filter = cuser.ufo & UFO_PAL;

	seecloak = HAS_PERM(PERM_SEECLOAK);

	up = ushm->uslot;
	uceil = (void*)up + ushm->offset;

	max = 0;

	do {
		userno = up->userno;
#ifdef	DEBUG_TALK_ULIST
		printf("up->userid:%s\n" , up->userid);
#endif	/* DEBUG_TALK_ULIST */
		if (userno <= 0) {
			continue;
		}

#ifdef	FRIEND_FIRST
		if (((seecloak || !(up->ufo & UFO_CLOAK)) /* &&
		     (!filter || is_pal(userno)) */ )) {
			if (is_pal(userno) || (userno == self)) {
				*pp++ = up;
			}
			else if (!filter) {
				*qq++ = up;
			}
#else	/* FRIEND_FIRST */
		if ((userno == self) ||
		    ((seecloak || !(up->ufo & UFO_CLOAK)) &&
		     (!filter || is_pal(userno)))) {
			*pp++ = up;
#endif	/* FRIEND_FIRST */
		}

	} while (++up <= uceil);


#ifdef	FRIEND_FIRST
	friend_num = pp - ulist_pool;
	xo->max = max = friend_num + qq - o_pool;
#else	/* FRIEND_FIRST */
	xo->max = max = pp - ulist_pool;
#endif	/* FRIEND_FIRST */

#ifdef	DEBUG_TALK_ULIST
	printf("ulist_init.max=%d\n" , xo->max);
#endif	/* DEBUG_TALK_ULIST */

	if (xo->pos >= max) {
		xo->pos = xo->top = 0;
	}

	if ((max > 1) && (pickup_way)) {
#ifdef	FRIEND_FIRST
		xsort(ulist_pool, friend_num, sizeof(pickup),
		      ulist_cmp[pickup_way - 1]);
		xsort(o_pool, qq - o_pool, sizeof(pickup), ulist_cmp[pickup_way - 1]);
#else	/* FRIEND_FIRST */
		xsort(ulist_pool, max, sizeof(pickup), ulist_cmp[pickup_way - 1]);
#endif	/* FRIEND_FIRST */
	}

#ifdef	FRIEND_FIRST
	memcpy(pp, &o_pool, sizeof(UTMP) * (qq - o_pool));
#endif	/* FRIEND_FIRST */

	/* JeffHung.20000817: no return value? */
}


/*
 *  fd      : output file descriptor
 *  username: User ID
 *  top     : begin number
 *  range   : how many item to list
 *  way     : list sort way
 *            1:���N 2:�N�� 3:�ӷ� 4:�ʺA 5:�n��
 */

int talk_ulist(int ofd, char *username, int top, int range, int way) 
{
	int	max;
	int	return_val;
	XO	*xo;

	chdir(BBSHOME);

#ifdef DEBUG_TALK_ULIST
	fprintf(stderr, "DEBUG(%s,%d):entering talk_ulist()\n"
	        __FILE__, __LINE__);
#endif /* DEBUG_TALK_ULIST */


	pickup_way = way - 1;
	xo = (XO*)malloc(sizeof(XO));

	ushm_init();

#ifdef	DEBUG_TALK_ULIST
	printf("ushm->uslot->userid:%s\n", ushm->uslot[0].userid);
#endif	/* DEBUG_TALK_ULIST */

	str_lower(username, username);
	if (acct_load(&cuser, username) < 0) {
		fprintf(stderr, "acct_load failed\n");
		return -1;
	}
	pal_cache();
	ulist_init(xo);

	max = xo->max;
#ifdef	DEBUG_TALK_ULIST  
	printf("max:%d\n", max); 
#endif	/* DEBUG_TALK_ULIST */
	return_val = ulist_body(ofd,top,range,max);
  
	if (return_val < 0) {
		return return_val;
	}
  
	return max;      
}


