/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: user_info_show.c,v 1.3 2000/09/30 16:18:14 jeffhung Exp $
 */

#include "bbs.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "w3if.h"
#include "w3if_session.h"
#include "dao.h"
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>



/*
 *  bit-wise display and setup
 */
static void bitmsg(char* msg, char* str, int level)
{
	int cc;

	printf(msg);
	while (cc = *str) {
		printf("%c", (level & 1) ? cc : '-');
		level >>= 1;
		str++;
	}

	printf("\n");
}

int user_info_show(int ofd, char* sid)
{
	W3IF_SESSENTRY *psess;
	int            totalogintime;
	char           buf[MAXPATHLEN];
	int            numails;
	char           obuf[GENERAL_BUFSIZE];
	int            len;
	int            ch;
	BRD            *bhdr;
	BRD            *tail;
	char           *list;
	extern BCACHE  *bshm;

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();
	bshm_init();

	psess = w3ifsession_get(sid);

	if (!psess) {
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;
	acct_load(&cuser, cutmp->userid);

	totalogintime = cuser.staytime / 60;

	usr_fpath(buf, cuser.userid, fn_dir);
	numails = rec_num(buf, sizeof(HDR));

	sprintf(obuf, "MRR-RESULT:user_info_show\n");
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "USERID:%s\n", cuser.userid);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "USERNAME:%s\n", cuser.username);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "REALNAME:%s\n", cuser.realname);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "ADDRESS:%s\n", cuser.address);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "EMAIL:%s\n", cuser.email);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "REGIST-DATE:%s", ctime(&(cuser.firstlogin)));
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "NUM-LOGINS:%d\n", cuser.numlogins);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "LOGIN-TIME:%d\n", totalogintime);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "NUM-POSTS:%d\n", cuser.numposts);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "MAILBOX:%d\n", numails);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "REGIST-INFO:%s\n",
	        ((cuser.userlevel & PERM_VALID) ?
	         (cuser.tvalid ? Ctime(&(cuser.tvalid))
	                       : "Registeration Expired") :
	         "Not Registered"));
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "JUSTIFY:%s\n", cuser.justify);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "VALID-EMAIL:%s\n", cuser.vmail);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "IDENT:%s\n", cuser.ident);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "LAST-HOST:%s\n", cuser.lasthost);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "NUM-MAILS:%d\n", cuser.numemail);
	write(ofd, obuf, strlen(obuf));
	sprintf(obuf, "TOTAL-LOGINTIME:%d\n", totalogintime);
	write(ofd, obuf, strlen(obuf));

	if (cuser.userlevel & PERM_BM) {
		sprintf(obuf, "AS-BM:");
		write(ofd, obuf, strlen(obuf));
		bm_list(cuser.userid);
		/*
		 *  ��� userid �O���ǪO���O�D
		 */
		len = strlen(cuser.userid);
		bhdr = bshm->bcache;
		tail = bhdr + bshm->number;

		do {
			list = bhdr->BM;
			ch = *list;
			if ((ch > ' ') && (ch < 128)) {
				do {
					if (!strncmp(list, cuser.userid, len)) {
						ch = list[len];
						if ((ch = 0 || ch == '/')) {
							sprintf(obuf, "%s ", bhdr->brdname);
							write(ofd, obuf, strlen(obuf));
							break;
						}
					}
					while (ch = *list++) {
						if (ch == '/') {
							break;
						}
					}
				} while (ch);
			}
		} while (++bhdr < tail);
		write(ofd, "\n", 1);
	}

#ifdef	NEWUSER_LIMIT

	if (cuser.lastlogin - cuser.firstlogin < 3 * 86400) {
		sprintf(obuf, "IS-NEWUSER:YES\n");
		write(ofd, obuf, strlen(obuf));
	}

#endif	/* NEWUSER_LIMIT */

	return 0;
}


