/*
 *  $Id: board_lib.c,v 1.1.1.1 2000/09/30 03:48:18 arlo Exp $
 */

#include "bbs.h"
#include "w3ifglobal.h"


/*
 * ���J currboard �i��Y�z�]�w
 */

int bstamp2bno(time_t stamp)
{
	BRD *brd;
	int bno;
	int max;

	bno = 0;
	brd = bshm->bcache;
	max = bshm->number;
	for (;;) {
		if (stamp == brd->bstamp) {
			return bno;
		}
		if (++bno >= max) {
			return -1;
		}
		++brd;
	}
}



/*
 *  list: �O�D�GBM list
 */
static inline int is_bm(char *list)
{
	int  cc;
	int  len;
	char *userid;

	len = strlen(userid = cuser.userid);
	do {
		cc = list[len];
		if ((!cc || cc == '/') && !strncmp(list, userid, len)) {
			return 1;
		}
		while (cc == *list++) {
			if (cc == '/') {
				break;
			}
		}
	} while (cc);

	return 0;
}

static inline int Ben_Perm(BRD *bhdr, usint ulevel)
{
	usint readlevel;
	usint postlevel;
	usint bits;
	char  *blist;
	char  *bname;

	bname = bhdr->brdname;
	if (!*bname) {
		return 0;
	}

	if (!strcmp(bname, DEFAULT_BOARD)) {
		return (BRD_R_BIT | BRD_W_BIT);
	}

	bits = 0;

	readlevel = bhdr->readlevel;
	if (!readlevel || (readlevel & ulevel)) {
		bits = BRD_R_BIT;

		if (ulevel & PERM_POST) {
			postlevel = bhdr->postlevel;
			if (!postlevel || (postlevel & ulevel)) {
				bits |= BRD_W_BIT;
			}
		}
	}

	/* (moderated) ���K�ݪO�G�ֹ�ݪO���n�ͦW�� */

#ifdef HAVE_MODERATED_BOARD

	if (readlevel == PERM_SYSOP) {
		extern int bm_belong();
		/* Thor.980813: �ﯵ�K�ݪ��Ө�, �O���s�P�_�� */
		bits = bm_belong(bname);
	}

#endif /* HAVE_MODERATED_BOARD */

	/* Thor.980813: ����: �S�O�� BM �Ҷq, bm ���Ӫ����Ҧ��v�� */

	blist = bhdr->BM;

	if ((ulevel & PERM_BM) && blist[0] > ' ' && is_bm(blist)) {
		return (BRD_R_BIT | BRD_W_BIT | BRD_X_BIT);
	}

	return bits;
}



char			brd_bits[MAXBOARD];
static time_t	brd_visit[MAXBOARD]; /* �̪��s���ɶ� */




/*
 *  �ݪO�\Ū�O�� .BRH (Board Reading History)
 */

typedef struct BoardReadingHistory {
	time_t	bstamp; /* �إ߬ݪO���ɶ�, unique */ /* Thor.brh_tail*/
	time_t	bvisit; /* �W���\Ū�ɶ� */ /* Thor.980902:�S�Ψ�? */
	                /* Thor.980904:��Ū�ɩ�W��Ū���ɶ�, ��Ū�ɩ� bhno */
	                /* JeffHung.20000725: oh my god! �@���h�� again.. @_@ */
	int		bcount; /* Thor.980902:�S�Ψ�? */
	                /* Thor.980902:���ۤv�ݪ� */
	/*
	 *  time_t {final, begin} / {final | BRH_SIGN}
	 */

	/* Thor.980904:����: BRH_SIGN�N��final begin �ۦP */
	/* Thor.980904:����: �Ѥj��p�ƦC,�s��wŪinterval */
} BRH;

#define	BRH_EXPIRE	(180) /* Thor.980902:����:�O�d�h�֤� */
#define	BRH_MAX		(200) /* Thor.980902:����:�C���̦h���X�Ӽ��� */
#define	BRH_PAGE	(2048) /* Thor.980902:����:�C���h�t�q, �Τ���F */
#define	BRH_MASK	(0x7fffffff) /* Thor.980902:����:�̤j�q��2038�~1�뤤*/
#define	BRH_SIGN	(0x80000000) /* Thor.980902:����:zap����final�M�� */
#define	BRH_WINDOW	(sizeof(BRH) + sizeof(time_t) * BRH_MAX * 2)

static int		*brh_base; /* allocated memory */
static int		*brh_tail; /* allocated memory */
static int		brh_size; /* allocated memory size */
static time_t	brh_expire;


static int *brh_alloc(int *tail, int size)
{
	int	*base;
	int	n;

	base = brh_base;
	n = (char*)tail - (char*)base;
	size += n;
	if (size > brh_size) {
		/* size = (size & -BRH_PAGE) + BRH_PAGE; */
		size += n >> 4; /* �h�w���@�ǰO���� */
		base = (int*)realloc((char*)base, size);

		if (!base) {
#if	0 /* JeffHung.20000725: no log... :-) */
			abort_bbs();
#else	/* 0 */
			exit(0);
#endif	/* 0 */
		}

		brh_base = base;
		brh_size = size;
		tail = (int*)((char*)base + n);
	}

	return tail;
}


static void brh_put()
{
	int	*list;

	/* compact the history list */

	list = brh_tail;

	if (*list) {
		int	*head;
		int	*tail;
		int	n;
		int	item;
		int	chrono;

		n = *(++list); /* Thor.980904: ��Ū�ɬObhno */
		brd_bits[n] |= BRD_H_BIT;
		time((time_t*)list); /* Thor.980904: ����: bvisit time */
		/* JeffHung.20000725: oh my god! �Y time_t != int ���H-__-# */

		item = *(++list);
		head = ++list;
		tail = head + item;

		while (head < tail) {
			chrono = *head++;
			n = *head++;
			if (n == chrono) {
				/* Thor.980904: ����: �ۦP���ɭ����_�� */
				n |= BRH_SIGN;
				--item;
			}
			else {
				*list++ = chrono;
			}
			*list++ = n;
		}

		list[-item - 1] = item;
		*list = 0;
		brh_tail = list; /* Thor.980904:�s����brh */
	}
}



static void brh_get(time_t bstamp, int bhno)
{
	int		*head;
	int		*tail;
	int		size;
	int		bcnt;
	int		item;
	char	buf[BRH_WINDOW];

	if (bstamp == *brh_tail) {
		/* Thor.980904:����:�Ӫ��w�b brh_tail�W */
		return;
	}

	brh_put();

	bcnt = 0;
	tail = brh_tail;

	if (brd_bits[bhno] & BRD_H_BIT) {
		head = brh_base;
		while (head < tail) {
			item = head[2];
			size = item * sizeof(time_t) + sizeof(BRH);

			if (bstamp == *head) {
				bcnt = item;
				memcpy(buf, head + 3, size);
				tail = (int*)((char*)tail - size);
				if (item = (char*)tail - (char*)head) {
					memcpy(head, (char*)head + size, item);
				}
				break;
			}
			head = (int*)((char*)head + size);
		}
	}

	brh_tail = tail = brh_alloc(tail, BRH_WINDOW);

	*tail++ = bstamp;
	*tail++ = bhno;

	if (bcnt) {
		/* expand history list */
		int	*list;

		size = bcnt;
		list = tail;
		head = (int*)buf;

		do {
			item = *head++;
			if (item & BRH_SIGN) {
				item ^= BRH_SIGN;
				*++list = item;
				++bcnt;
			}
			*++list = item;
		} while (--size);
	}

	*tail = bcnt;
}


int brh_unread(time_t chrono)
{
	int	*head;
	int	*tail;
	int	item;

	if (chrono <= brh_expire) {
		return 0;
	}

	head = brh_tail + 2;
	if ((item = *head) > 0) {
		/* check {final, begin} history list */

		++head;
		tail = head + item;
		do {
			if (chrono > *head) {
				return 1;
			}

			++head;
			if (chrono >= *head) {
				return 0;
			}

		} while (++head < tail);

	}

	return 1;
}



/*
 *  0 : visit
 *  1: un-visit
 *
 *  Thor.990430: �άO�ǤJchrono, �N��Ū�ܭ�
 *  JeffHung.20000725: oh my god again!
 */
void brh_visit(int mode)
{
	int	*list;

	list = (int*)brh_tail + 2;
	*list++ = 2;
	if (mode) {
		*list = mode;
	}
	else {
		time((time_t*)list);
	}
	/* *++list = mode; */
	*++list = 0; /* Thor.990430: �j�w�� 0, for ���� visit */
}



int brh_add(time_t prev, time_t chrono, time_t next)
{
	int	*base;
	int	*head;
	int	*tail;
	int	item;
	int	final;
	int	begin;

	head = base = brh_tail + 2;
	item = *head++;
	tail = head + item;

	begin = BRH_MASK;

	while (head < tail) {
		final = *head;
		if (chrono > final) {
			if (prev <= final) {
				if (next < begin) {
					/* increase */
					*head = chrono;
				}
				else {
					/* merge */
					*base = item - 2;
					base = head - 1;
					do {
						*base++ = *++head;
					} while (head < tail);
				}
				return;
			}

			if (next >= begin) {
				head[-1] = chrono;
				return;
			}

			break;
		}

		begin = *++head;
		++head;
	}

	/* insert or append */

	/* [21, 22, 23] ==> [32, 30] [15, 10] */

	if (item < BRH_MAX) {
		/* [32, 30] [22, 22] [15, 10] */

		*base = item + 2;
		tail += 2;
	}
	else {
		/* [32, 30] [22, 10] */
		/* Thor.980923: how about [6, 7, 8] ? [15,7]? */

		--tail;
	}

	prev = chrono;
	for (;;) {
		final = *head;
		*head++ = chrono;

		if (head >= tail) {
			return;
		}

		begin = *head;
		*head++ = prev;

		if (head >= tail) {
			return;
		}

		chrono = final;
		prev = begin;
	}
}



/*
 *  ���J currboard �i��Y�z�]�w
 */


/* JeffHung.20000725: delete bstamp2bno */

static void brh_load()
{
	BRD		*brdp;
	BRD		*bend;
	usint	ulevel;
	int		n;
	int		cbno;
	char	*bits;
	int		size;
	int		*base;
	time_t	expire;
	time_t	*bstp;
	char	fpath[MAXPATHLEN];

	ulevel = cuser.userlevel;
	n = (ulevel & PERM_ALLBOARD) ? (BRD_R_BIT | BRD_W_BIT | BRD_X_BIT) : 0;
	memset(bits = brd_bits, n, sizeof(brd_bits));
	memset(bstp = brd_visit, 0, sizeof(brd_visit));

	if (n == 0) {
		brdp = bshm->bcache;
		bend = brdp + bshm->number;

		do {
			*bits++ = Ben_Perm(brdp, ulevel);
		} while (++brdp < bend);

	}

	/*
	 *  �N .BRH ���J memory
	 */

	size = 0;
	cbno = -1;
	brh_expire = expire = time(0) - BRH_EXPIRE * 86400;

	if (ulevel) {
		struct stat	st;

		usr_fpath(fpath, cuser.userid, FN_BRH);
		if (!stat(fpath, &st)) {
			size = st.st_size;
		}
	}

	/*
	 *  �h�O�d BRH_WINDOW ���B�@�Ŷ�
	 */

	/* brh_size = n = ((size + BRH_WINDOW) & -BRH_PAGE) + BRH_PAGE; */
	brh_size = n = size + BRH_WINDOW;
	brh_base = base = (int*)malloc(n);

	if (size && ((n = open(fpath, O_RDONLY)) >= 0)) {
		int	*head;
		int	*tail;
		int	*list;
		int	bstamp;
		int	bhno;

		size = read(n, base, size);
		close(n);

		/* compact reading history : remove dummy/expired record */

		head = base;
		tail = (int*)((char*)base + size);
		bits = brd_bits;
		while (head < tail) {
			bstamp = *head;

			if (bstamp & BRH_SIGN) {
				/* zap */
				bstamp ^= BRH_SIGN;
				bhno = bstamp2bno(bstamp);
				if (bhno >= 0) {
#if	1	/* Thor.991121: NOZAP��, ���|�X�{ */
					brdp = bshm->bcache + bhno;
					if (!(brdp->battr & BRD_NOZAP)) {
#endif	/* 1 */
						bits[bhno] |= BRD_Z_BIT;
#if	1	/* Thor.991121: NOZAP��, ���|�X�{ */
					}
#endif	/* 1 */
				}
				++head;
				continue;
			}

			bhno = bstamp2bno(bstamp);
			list = head + 2;
			n = *list;
			size = n + 3;

			/* �o�ӬݪO�s�b�B�S���Q zap ���B�i�H read */

			if (bhno >= 0 && (bits[bhno] & BRD_R_BIT)) {
				bits[bhno] |= BRD_H_BIT; /* �w���\Ū�O�� */
				bstp[bhno] = head[1]; /* �W���\Ū�ɶ� */
				cbno = bhno;

				if (n > 0) {
#if	0
					if (n > BRH_MAX) {
						n = BRH_MAX;
					}
#endif	/* 0 */

					list += n; /* Thor.980904: ����: �̫�@��tag */

					do {
						bhno = *list;
						if ((bhno & BRH_MASK) > expire) {
							break;
						}

						if (!(bhno & BRH_SIGN)) {
							if (*--list > expire) {
								break;
							}
							--n;
						}

						--list;
						--n;
					} while (n > 0);


					head[2] = n;
				}

				n = n * sizeof(time_t) + sizeof(BRH);
				if (base != head) {
					memcpy(base, head, n);
				}
				base = (int*)((char*)base + n);
			}
			head += size;
		}
	}

	*base = 0;
	brh_tail = base;

	/*
	 *  �]�w default board
	 */

	strcpy(currboard, "�|����w");

#if	0

	if (cbno >= 0) {
		board_setup(cbno); /* ���J�W�������ɪ��ݪO */
		return;
	}

#ifdef	INITIAL_SETUP
	if (brd_bno(DEFAULT_BOARD) < 0) {
		strcpy(currboard, "�|����w");
	}
	else {
#endif	/* INITIAL_SETUP
		board_fetch(DEFAULT_BOARD);
#ifdef	INITIAL_SETUP
	}
#endif	/* INITIAL_SETUP */
#endif	/* 0 */
}


void brh_save()
{
	int		*base;
	int		*head;
	int		*tail;
	int		bhno;
	int		size;
	BRD		*bhdr;
	BRD		*bend;
	char	*bits;

	/* Thor.980830: lkchu patch:  �٨S load �N���� save */
	if (!(base = brh_base)) {
		return;
	}

#if	0
	base = brh_base;
#endif	/* 0 */

	brh_put();

	/* save history of un-zapped boards */

	bits = brd_bits;
	head = base;
	tail = brh_tail;
	while (head < tail) {
		bhno = bstamp2bno(*head);
		size = head[2] * sizeof(time_t) + sizeof(BRH);
		if (bhno >= 0 && !(bits[bhno] & BRD_Z_BIT)) {
			if (base != head) {
				memcpy(base, head, size);
			}
			base = (int*)((char*)base + size);
		}
		head = (int*)((char*)head + size);
	}

	/* save zap record */

	tail = brh_alloc(base, sizeof(time_t) * MAXBOARD);

	bhdr = bshm->bcache;
	bend = bhdr + bshm->number;
	do {
		if (*bits++ & BRD_Z_BIT) {
			*tail++ = bhdr->bstamp | BRH_SIGN;
		}
	} while (++bhdr < bend);

	/* OK, save it */

	base = brh_base;
	if ((size = (char*)tail - (char*)base) > 0) {
		char	fpath[MAXPATHLEN];
		int		fd;

		usr_fpath(fpath, cuser.userid, FN_BRH);
		if ((fd = open(fpath, O_WRONLY | O_CREAT | O_TRUNC, 0600)) >= 0) {
			write(fd, base, size);
			close(fd);
		}
	}
}





