<SCRIPT LANGUAGE="JavaScript">
<!--

function selectedRadio()
{
	var i;
	var o;

	for (i = 0; i < document.fPageChanger.iItem.length; ++i) {
		if (document.fPageChanger.iItem[i].checked) {
			return document.fPageChanger.iItem[i];
		}
	}
	return false;
}

function actMailToggleMark()
{
	var o = selectedRadio();

	if (o != false) {
		//alert("_mail_toggle_mark.php?iFilename=" + o.value);
		location = "_mail_toggle_mark.php?iFilename=" + o.value;
	}
}

// ��Ĥ@��
function pg2first()
{
}

// ��W�@��
function pg2prev()
{
}

// ��U�@��
function pg2next()
{
}

// ��̥���
function pg2last()
{
}

//-->
</SCRIPT>
<FORM METHOD="POST" NAME="fPageChanger" ACTION="mail_mbox.php">
	<INPUT TYPE="hidden" NAME="iPageTop" VALUE="">
	<INPUT TYPE="hidden" NAME="iPageSize" VALUE="">
	<P>
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo" onChange="document.fPageChanger.iDirectGo2.selectedIndex = document.fPageChanger.iDirectGo.selectedIndex;">
		<!-- �N�W�U�� <SELECT> �P�B -->
			<OPTION VALUE="1" SELECTED>1</OPTION>
			<OPTION VALUE="2">2</OPTION>
		</SELECT>
		��</P>
	<TABLE WIDTH="100%" BORDER="1">
		<TR> 
			<TH>�s��</TH>
			<TH>&nbsp;</TH>
			<TH>���</TH>
			<TH>�@��</TH>
			<TH>�H����D</TH>
		</TR>
		<?php

		debug_print(serialize($result));
		$mbox = $result["mail_mbox"];
		debug_print(serialize($mbox));

		for ($i = 0; $i < count($mbox); ++$i) {
			printf("<TR>\n");
			printf("<TD>%d <INPUT TYPE=\"radio\" NAME=\"iItem\" VALUE=\"%s\"></TD>\n",
			       $mbox[$i]["INDEX"][0], $mbox[$i]["FILENAME"][0]);
			printf("<TD>%s%s</TD>\n", $mbox[$i]["MARK"][0], $mbox[$i]["TAG"][0]);
			printf("<TD>%s</TD>\n", $mbox[$i]["DATE"][0]);
			printf("<TD><A HREF=\"talk_query_user.php\">%s</A></TD>\n", $mbox[$i]["AUTHOR"][0]);
			printf("<TD><A HREF=\"mail_read_mail.php?iFilename=%s\">%s</A></TD>\n",
			       $mbox[$i]["FILENAME"][0], $mbox[$i]["SUBJECT"][0]);
			printf("</TR>\n");
		}

		?>
		<!--
		<TR> 
			<TD>1
				<INPUT TYPE="radio" NAME="iItem" VALUE="radiobutton">
			</TD>
			<TD>r</TD>
			<TD>05/22</TD>
			<TD><A HREF="talk_query_user.php">SYSOP</A></TD>
			<TD><A HREF="mail_read_mail.php">�� �z�w�g�q�L�����{�ҤF�I</A></TD>
		</TR>
		<TR> 
			<TD>2
				<INPUT TYPE="radio" NAME="iItem" VALUE="radiobutton">
			</TD>
			<TD>m</TD>
			<TD>05/31</TD>
			<TD><A HREF="talk_query_user.php">taliao</A></TD>
			<TD><A HREF="mail_read_mail.php">Re: ����PHP�����s��z���D..</A></TD>
		</TR>
		<TR> 
			<TD>3
				<INPUT TYPE="radio" NAME="iItem" VALUE="radiobutton">
			</TD>
			<TD>&nbsp;</TD>
			<TD>06/09</TD>
			<TD><A HREF="talk_query_user.php">lachesis</A></TD>
			<TD><A HREF="mail_read_mail.php">Re: �U�Ԧ���檺���D</A></TD>
		</TR>
		-->
	</TABLE>
	<P>
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo2" onChange="document.fPageChanger.iDirectGo.selectedIndex = document.fPageChanger.iDirectGo2.selectedIndex;">
		<!-- �N�W�U�� <SELECT> �P�B -->
			<OPTION VALUE="1" SELECTED>1</OPTION>
			<OPTION VALUE="2">2</OPTION>
		</SELECT>
		��</P>
</FORM>