/*
 * 
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation 
 * bbs, the cross-media distributed communication platform. And it is 
 * developed by Cyberwork Solution in 2000.
 * 
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 * 
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or (at 
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or 
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

#include "system_lib.h"

#include <errno.h>
#include <pthread.h>


/*
 *  pthreads wrapper functions.
 */

int sys_pthread_create(pthread_t *tid, const pthread_attr_t *attr,
                       void * (*func)(void *), void *arg)
{
	int	n;

	if ((n = pthread_create(tid, attr, func, arg)) == 0) {
		return n;
	}
	errno = n;
	sys_error("sys_pthread_create error");

	return n;
}

int sys_pthread_join(pthread_t tid, void **status)
{
	int	n;

	if ((n = pthread_join(tid, status)) == 0) {
		return n;
	}

	errno = n;
	sys_error("sys_pthread_join error");

	return n;
}

int sys_pthread_detach(pthread_t tid)
{
	int	n;

	if ((n = pthread_detach(tid)) == 0) {
		return n;
	}
	errno = n;
	sys_error("sys_pthread_detach error");

	return n;
}

int sys_pthread_kill(pthread_t tid, int signo)
{
	int	n;

	if ((n = pthread_kill(tid, signo)) == 0) {
		return n;
	}

	errno = n;
	sys_error("sys_pthread_kill error");

	return n;
}

int sys_pthread_mutexattr_init(pthread_mutexattr_t *attr)
{
	int	n;

	if ((n = pthread_mutexattr_init(attr)) == 0) {
		return n;
	}
	errno = n;
	sys_error("sys_pthread_mutexattr_init error");

	return n;
}

#ifdef	_POSIX_THREAD_PROCESS_SHARED

int sys_pthread_mutexattr_setpshared(pthread_mutexattr_t *attr, int flag)
{
	int	n;

	if ((n = pthread_mutexattr_setpshared(attr, flag)) == 0) {
		return n;
	}
	errno = n;
	sys_error("sys_pthread_mutexattr_setpshared error");

	return n;
}

#endif	/* _POSIX_THREAD_PROCESS_SHARED */


int sys_pthread_mutex_init(pthread_mutex_t *mptr, pthread_mutexattr_t *attr)
{
	int	n;

	if ((n = pthread_mutex_init(mptr, attr)) == 0) {
		return n;
	}
	errno = n;
	sys_error("sys_pthread_mutex_init error");

	return n;
}

/* include sys_pthread_mutex_lock */

int sys_pthread_mutex_lock(pthread_mutex_t *mptr)
{
	int	n;

	if ((n = pthread_mutex_lock(mptr)) == 0) {
		return n;
	}
	errno = n;
	sys_error("sys_pthread_mutex_lock error");

	return n;
}

/* end sys_pthread_mutex_lock */

int sys_pthread_mutex_unlock(pthread_mutex_t *mptr)
{
	int	n;

	if ((n = pthread_mutex_unlock(mptr)) == 0) {
		return n;
	}
	errno = n;
	sys_error("sys_pthread_mutex_unlock error");

	return n;
}

int sys_pthread_cond_broadcast(pthread_cond_t *cptr)
{
	int	n;

	if ((n = pthread_cond_broadcast(cptr)) == 0) {
		return n;
	}
	errno = n;
	sys_error("sys_pthread_cond_broadcast error");

	return n;
}

int sys_pthread_cond_signal(pthread_cond_t *cptr)
{
	int n;

	if ((n = pthread_cond_signal(cptr)) == 0) {
	 	return n;
	}
	errno = n;
	sys_error("sys_pthread_cond_signal error");

	return n;
}

int sys_pthread_cond_wait(pthread_cond_t *cptr, pthread_mutex_t *mptr)
{
	int	n;

	if ((n = pthread_cond_wait(cptr, mptr)) == 0) {
		return n;
	}
	errno = n;
	sys_error("sys_pthread_cond_wait error");

	return n;
}

int sys_pthread_cond_timedwait(pthread_cond_t *cptr, pthread_mutex_t *mptr,
                               const struct timespec *tsptr)
{
	int	n;

	if ((n = pthread_cond_timedwait(cptr, mptr, tsptr)) == 0) {
		return n;
	}
	errno = n;
	sys_error("sys_pthread_cond_timedwait error");

	return n;
}

int sys_pthread_once(pthread_once_t *ptr, void (*func)(void))
{
	int	n;

	if ((n = pthread_once(ptr, func)) == 0) {
		return n;
	}
	errno = n;
	sys_error("sys_pthread_once error");

	return n;
}

int sys_pthread_key_create(pthread_key_t *key, void (*func)(void *))
{
	int	n;

	if ((n = pthread_key_create(key, func)) == 0) {
		return n;
	}
	errno = n;
	sys_error("sys_pthread_key_create error");

	return n;
}

int sys_pthread_setspecific(pthread_key_t key, const void *value)
{
	int	n;

	if ((n = pthread_setspecific(key, value)) == 0) {
		return n;
	}
	errno = n;
	sys_error("sys_pthread_setspecific error");

	return n;
}

void *sys_pthread_getspecific(pthread_key_t key)
{
	void	*ptr;

	ptr = pthread_getspecific(key);

	return ptr;
}

