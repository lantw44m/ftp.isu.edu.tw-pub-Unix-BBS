/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: bbs_logout.c,v 1.3 2000/09/30 16:18:13 jeffhung Exp $
 */

#undef DEBUG_BBS_LOGOUT

#include "bbs.h"
#include "w3if_session.h"
#include <time.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/param.h>
#include <fcntl.h>
#include <unistd.h>
#include "w3ifglobal.h"
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */

#ifdef AS_ARNI_MODULE

int mod_bbs_logout(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return bbs_logout(ofd, sid);
}

#endif /* AS_ARNI_MODULE */


#if 0 /* JeffHung.20000829: already defined in lib/cache_lib.c */

void utmp_free()
{
	UTMP *uentp;

	uentp = cutmp;
	if (!uentp || !uentp->pid) {
		return;
	}

#ifdef HAVE_SEM
	sem_lock(BSEM_ENTER);
#endif /* HAVE_SEM */

	uentp->pid = uentp->userno = 0;
	--(ushm->count);

#ifdef HAVE_SEM
	sem_lock(BSEM_LEAVE);
#endif /* HAVE_SEM */
}

#endif /* 0 */

int bbs_logout(int ofd, char* sid)
{
	W3IF_SESSENTRY *psess;
	int            fd;
	int            delta;
	ACCT           tuser;
	char           fpath[MAXPATHLEN];

	chdir(BBSHOME);

	write(ofd, "MRR-RESULT:bbs_logout\n", strlen("MRR-RESULT:bbs_logout\n"));

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	psess = w3ifsession_get(sid);

#ifdef DEBUG_BBS_LOGOUT
	if (psess) {
		fprintf(stderr, "DEBUG(%s,%d): php_sid: %s\n",
		        __FILE__, __LINE__, psess->php_sid);
	}
	else {
		fprintf(stderr, "DEBUG(%s,%d): cannot get session.\n",
		        __FILE__, __LINE__);
	}
#endif /* DEBUG_BBS_LOGOUT */

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;

	/* JeffHung.20000829: u_exit() */

	utmp_free(); /* ���� UTMP shm */
	blog("AXXED", 0);

	if (cuser.userlevel) {
		brh_save(); /* �x�s�\Ū�O���� */
	}

/* Thor.980405: �����ɥ��w�R�����T */
#ifndef LOG_BMW /* lkchu.981201: �i�b config.h �]�w */

	usr_fpath(fpath, cuser.userid, FN_BMW);
	unlink(fpath);

#endif /* LOG_BMW */

#ifdef MODE_STAT

	log_modes();

#endif /* MODE_STAT */

	usr_fpath(fpath, cuser.userid, fn_acct);
	fd = open(fpath, O_RDWR);
	if (fd >= 0) {
		if (read(fd, &tuser, sizeof(ACCT)) == sizeof(ACCT)) {
			delta = time(&cuser.lastlogin) - psess->ap_start;
			cuser.staytime += delta;
			/* Thor.980727:����, �b���W���W�L�T���������p�⦸��  */
			/* lkchu.981201: �� delta, �C���W�����n�W�L�T�����~�� */
			if (delta > 3 * 60) {
				++cuser.numlogins;
			}
			cuser.userlevel = tuser.userlevel;
			cuser.tvalid = tuser.tvalid;
			cuser.vtime = tuser.vtime;
			strcpy(cuser.justify, tuser.justify);
			strcpy(cuser.vmail, tuser.vmail);
			lseek(fd, (off_t)0, SEEK_SET);
			write(fd, &cuser, sizeof(ACCT));
		}
		close(fd);
	}

	write(ofd, "LOGOUT-RESULT:OK\nMRR-END:\n",
	      strlen("LOGOUT-RESULT:OK\nMRR-END:\n"));

	return 0;
}


