<FORM METHOD="post" ACTION="">
	<TABLE WIDTH="100%" BORDER="1">
		<TR> 
			<TH>�s��</TH>
			<TH>�ɶ�</TH>
			<TH>���O</TH>
			<TH>�N��</TH>
			<TH>���e</TH>
		</TR>
		<TR> 
			<TD>1
				<INPUT TYPE="radio" NAME="radiobutton" VALUE="radiobutton">
			</TD>
			<TD>19:19</TD>
			<TD>����</TD>
			<TD><A HREF="talk_query_user.php">SYSOP</A></TD>
			<TD>teswt</TD>
		</TR>
		<TR> 
			<TD>2
				<INPUT TYPE="radio" NAME="radiobutton" VALUE="radiobutton">
			</TD>
			<TD>19:19</TD>
			<TD>����</TD>
			<TD><A HREF="talk_query_user.php">SYSOP</A></TD>
			<TD>fjas;jf;ads</TD>
		</TR>
		<TR> 
			<TD>3
				<INPUT TYPE="radio" NAME="radiobutton" VALUE="radiobutton">
			</TD>
			<TD>19:19</TD>
			<TD>�e��</TD>
			<TD><A HREF="talk_query_user.php">Arlo</A></TD>
			<TD>test</TD>
		</TR>
	</TABLE>
</FORM>