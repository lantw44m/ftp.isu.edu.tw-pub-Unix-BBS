<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�ӤH���");

$SNOW_PAGE_TITLE = "�ӤH���";
$SNOW_PAGEAREA_MAIN = "user_info.m.php";
$SNOW_PAGEAREA_FUNC = "user_info.f.php";

include("bone.php");

?>