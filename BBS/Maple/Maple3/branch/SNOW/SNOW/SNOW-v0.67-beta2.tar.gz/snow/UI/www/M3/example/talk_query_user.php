<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�d�ߨϥΪ�");

$SNOW_PAGE_TITLE = "�d�ߨϥΪ�";
$SNOW_PAGEAREA_MAIN = "talk_query_user.m.php";
$SNOW_PAGEAREA_FUNC = "talk_query_user.f.php";

include("bone.php");

?>