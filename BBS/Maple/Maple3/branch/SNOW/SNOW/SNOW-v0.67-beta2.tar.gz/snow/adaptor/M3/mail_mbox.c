/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: mail_mbox.c,v 1.3 2000/09/30 16:18:13 jeffhung Exp $
 */

#include "bbs.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "w3if.h"
#include "dao.h"
#include <stdlib.h> /* for malloc */
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */


#ifdef AS_ARNI_MODULE

int mod_mail_mbox(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return mail_mbox(ofd, parg->args[0].s);
}

#endif /* AS_ARNI_MODULE */

#if 0 /* JeffHung.20000929: already defined in lib/mail_lib.c */

int mbox_attr(int type)
{
	if (type & MAIL_DELETE) {
		return 'D';
	}

	if (type & MAIL_REPLIED) {
		return (type & MAIL_MARKED) ? 'R' : 'r';
	}

	return "+ Mm"[type & 3];
}

#endif /* 0 */


int tag_char(int chrono)
{
	return TagNum && !Tagger(chrono, 0, TAG_NIN) ? '*' : ' ';
}


int mail_mbox(int ofd, char* userid)
{
	FILE		*mailfp;
	int			mailnum;
	char		fpath[MAXPATHLEN];
	char		lower_userid[IDLEN + 1];
	struct stat	st;
	HDR*		mailbuf;
	int			i;
	char		author[130 + 1];
	char*		pch;
	char		buf[GENERAL_BUFSIZE];

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

	if (strlen(userid) > IDLEN) {
		userid[IDLEN] = 0;
	}
	str_lower(lower_userid, userid);
	snprintf(fpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/.DIR",
	         lower_userid[0], lower_userid);

	if (lstat(fpath, &st) < 0) {
		return -999; /* mailbox index file not found */
	}
	mailnum = st.st_size / sizeof(HDR);

	if (!(mailbuf = (HDR*)malloc(sizeof(HDR) * mailnum))) {
		return -999; /* allocate memory error */
	}
	memset(mailbuf, 0, sizeof(HDR) * mailnum);

	if (!(mailfp = fopen(fpath, "r"))) {
		free(mailbuf);
		return -999; /* open mailbox index file error */
	}

	/* read all stuffs into buffer */
	if ((mailnum = fread(mailbuf, sizeof(HDR), mailnum, mailfp)) < 0) {
		fclose(mailfp);
		free(mailbuf);
		return -999; /* read mailbox index file error */
	}

	fclose(mailfp);

	for (i = 0; i < mailnum; ++i) {

		write(ofd, "MRR-RESULT:mail_mbox\n",
		      strlen("MRR-RESULT:mail_mbox\n"));

		strncpy(author, mailbuf[i].owner, sizeof(author));
		if ((pch = strchr(author, '@'))) {
			*pch = '.';
			++pch;
			*pch = 0;
		}

		snprintf(buf, GENERAL_BUFSIZE,
		         "INDEX:%d\n"
		         "MARK:%c\n"
		         "TAG:%c\n"
		         "DATE:%s\n"
		         "AUTHOR:%s\n"
		         "SUBJECT:%s\n"
		         "FILENAME:%s\n",
		         i + 1,
		         mbox_attr(mailbuf[i].xmode),
		         tag_char(mailbuf[i].chrono),
		         mailbuf[i].date,
		         author,
		         mailbuf[i].title,
		         mailbuf[i].xname);
		write(ofd, buf, strlen(buf));
	}

	if (mailbuf) {
		free(mailbuf);
	}

	write(ofd, "MRR-END:\n", strlen("MRR-END:\n"));

	return 0;
}


