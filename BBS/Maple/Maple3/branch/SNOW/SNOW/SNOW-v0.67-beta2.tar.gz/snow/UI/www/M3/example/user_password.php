<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�]�w�K�X");

$SNOW_PAGE_TITLE = "�]�w�K�X";
$SNOW_PAGEAREA_MAIN = "user_password.m.php";
$SNOW_PAGEAREA_FUNC = "user_password.f.php";

include("bone.php");

?>