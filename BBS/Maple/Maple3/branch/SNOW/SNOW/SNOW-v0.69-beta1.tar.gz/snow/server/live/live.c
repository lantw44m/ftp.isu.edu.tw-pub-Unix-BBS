/*
 * 
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation 
 * bbs, the cross-media distributed communication platform. And it is 
 * developed by Cyberwork Solution in 2000.
 * 
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 * 
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or (at 
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or 
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution.com , Isabel Ho
 *
 */

/*
 *  LIVE Lxxx.. Is Very Enchanting !!?? ~~
 *                                -- CSI SNOW mimic.
 */


#undef DEBUG_LIVE

#include "live.h"

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <pthread.h>
#include <unistd.h>
#include <syslog.h>
#include <sys/stat.h>
#include <netinet/in.h>

#include "live_server.h"
#include "mod_list.h"
#include "system_lib.h"
#include "tcp_lib.h"


struct THREAD_POOL {
	pthread_t	thread_tid; /* thread ID */
	long		thread_count; /* # of connections handled */
};

struct THREAD_POOL	*thread_ptr; /* array of thread structure */ 


/* Chat User info */
USER_INFO user_info_pool[MAX_CLIENT];
/* �Ϥ��O���Odaemon mode��flag */

extern int daemon_proc;

int					client_fd[MAX_CLIENT];
int					iget;
int					iput;
pthread_mutex_t		clifd_mutex;
pthread_cond_t		clifd_cond;

static int			nthreads;
pthread_mutex_t		clifd_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t		clifd_cond  = PTHREAD_COND_INITIALIZER;

void sig_int(int signo)
{
#ifdef	DEBUG_LIVE
	int	i;

	for (i = 0; i < nthreads; ++i) {
		DEBUG_PRINT1("thread %d, connections\n", i);
	}
#endif	/* DEBUG_LIVE */

	exit(0);
}

void sig_pipe(int signo)
{
	char	buf[128];

	sprintf(buf, "arni_server Pipe broken at %s\n", ctime((time_t *)time(0)));
	sys_log(ERR_NETWORK_LOG, buf);  
	exit(0);
}

void thread_make(int index)
{
	void	*thread_main(void*);

	pthread_create(&thread_ptr[index].thread_tid, NULL,
                   &thread_main, (void*)index);
	/*
	 *  JeffHung.20000815:
	 *
	 *  int to void*? what's a dangurous action! What if int and
     *  void* have different sizes? Why not use int* to void*?
	 */
	return; /* main thread returns */
}

void *thread_main(void *arg)
{
	int	connfd;

#ifdef	DEBUG_LIVE
	DEBUG_PRINT1("thread %d starting\n", (int) arg);
#endif	/* DEBUG_LIVE */

	for (;;) {

#ifdef	DEBUG_LIVE
		DEBUG_PRINT1("thread %d restart\n", (int) arg);
#endif	/* DEBUG_LIVE */

		pthread_mutex_lock(&clifd_mutex);
		/*
		 *  do nothing when iget == iput ,until not equal,
		 *  call sys_pthread_cond_signal to wake up
		 */
		while (iget == iput) {
			pthread_cond_wait(&clifd_cond, &clifd_mutex);
		}

		connfd = client_fd[iget]; /* connected socket to service */

		if (++iget == MAX_CLIENT) {
			iget = 0;
		}
		pthread_mutex_unlock(&clifd_mutex);
		thread_ptr[((int)arg)].thread_count++; /* arg is the index of thread */
		/*
		 *  JeffHung.20000815:
		 *
		 *  void* to int? what's a dangurous action! What if void* and
		 *  int have different sizes? Why not use void* to int*?
		 *
		 *  Is the THREAD_POOL.thread_count just for counting how many
		 *  request been served?
		 */
		live_server(connfd, user_info_pool); /* process the request */
		close(connfd);
	} /* for (;;) */
}
static void start_daemon( const char *ap_name , int facility)
{
  int i;
	pid_t pid;

  daemon_proc = 1;

	if( (pid = sys_fork()) != 0 ) /* parent process */
	{
	  sys_exit(0);
	}
  
	setsid(); /* ���� session leader */

/*
 * �]���� session leader (�Ĥ@��fork�X�Ӫ�child) terminate��, 
 * �Ҧ��b�o�@��session��process�|�e�X SIGHUP �o��signal 
 */
	sys_signal( SIGHUP , SIG_IGN ); 
  
	if( (pid = sys_fork()) != 0 ) /* 1st child */
	{
	  sys_exit(0);
	}

	umask(0); /* ��file creation mask�]���s�A�o�ˤ~���|�v�T�줧��ceate�X��file */

  for( i = 0 ; i < MAX_FD ; i++ )
	{
	  sys_close(i); /*��Ҧ�file descriptor�����F�A�ר�Ostandard input/output */
	}

/*
 * log�]�|�e��console 
 */
	openlog( ap_name , LOG_PID || LOG_CONS , facility );
}

int main(int argc, char *argv[])
{
	int 			i;
	int				listenfd;
	int				connfd;
  char			buf[6];
	socklen_t		addrlen;
	socklen_t		clilen;
	struct sockaddr	*cliaddr;

  listenfd = -1;
	sprintf(buf , "%d" , LIVE_SERVER_PORT);
	if( argc == 2 && !strcmp( argv[1] , "-d" ) ) /* daemon mode */
	{
	  start_daemon(argv[0] , 0);
		listenfd = tcp_listen(NULL, buf , &addrlen);
	}	
	else { /* ���O daemon mode�A�u�O�@�몺���� mode */
	  if (argc >= 2) {
	  	listenfd = tcp_listen(NULL, argv[1], &addrlen);
	  }
		else {
	  	DEBUG_PRINT("usage: live_server <port#>\n\n");
	  	sys_exit(0);
	  }
  }

	chdir(LIVE_SERVER_HOME); /* ���ެO���Odaemon mode , �̫�bchange dir ��server home directory */

  memset(user_info_pool , 0 , sizeof(struct w3if_USER_INFO)*MAX_CLIENT );

/* initial user info pool */
	for( i = 0 ; i < MAX_CLIENT ; i++ )
	{
	  user_info_pool[i].type = TYPE_OFFLINE;
    user_info_pool[i].index = 0;
	}
  
	live_add_modules();

	cliaddr = malloc(addrlen);

	nthreads = SERVER_THREAD;

	thread_ptr = calloc(nthreads, sizeof(struct THREAD_POOL));

	iget = iput = 0;

	for (i = 0; i < nthreads; ++i) {
		thread_make(i); /* only main thread returns */
	}

	signal(SIGINT, sig_int);
	signal(SIGPIPE, sig_pipe);

	for (;;) {
		clilen = addrlen;
		connfd = accept(listenfd, cliaddr, &clilen);

#ifdef	DEBUG_LIVE
		DEBUG_PRINT("DEBUG: socket accepted!\n");
#endif	/* DEBUG_LIVE */

		pthread_mutex_lock(&clifd_mutex);
		client_fd[iput] = connfd;
		if (++iput == MAX_CLIENT) {
			iput = 0;
		}
		if (iput == iget)  {
			sys_error("iput = iget = %d", iput);
			exit(0);
		}

#ifdef	DEBUG_LIVE
		DEBUG_PRINT("DEBUG: signal thread!\n");
#endif	/* DEBUG_LIVE */

		pthread_cond_signal(&clifd_cond);
		pthread_mutex_unlock(&clifd_mutex);
	} /* for (;;) */

	live_remove_modules();

	return 0;
}

