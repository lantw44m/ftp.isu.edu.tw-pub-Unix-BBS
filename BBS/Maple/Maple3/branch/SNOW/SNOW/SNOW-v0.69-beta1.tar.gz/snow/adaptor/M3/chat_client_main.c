/*
 * $Id: chat_client_main.c,v 1.3 2000/10/05 20:59:52 jeffhung Exp $
 */

#include "w3if.h"
#include <stdio.h>

int main(int argc, char **argv)
{
  int return_val;
  if( argc < 5 )
  {
    fprintf(stderr,
"/* ---------------------------------------------------------------- */\n"
"/* Argument: fd      -> �ǹL�Ӫ�socket fd                           */\n"
"/*           UserID  -> �ϥΪ�ID                                    */\n"
"/*           ChatID  -> chat�Ϊ�ID                                  */\n"
"/*           Action  -> �ϥΪ̰ʧ@                                  */\n"
"/*           Message -> �T��                                        */\n"
"/* ---------------------------------------------------------------- */\n"
    );
    return -1;
  }
	return_val = chat_client( atoi(argv[1]) ,stdout, argv[2],argv[3],argv[4],argv[5],NULL, NULL);
	return return_val;
}
