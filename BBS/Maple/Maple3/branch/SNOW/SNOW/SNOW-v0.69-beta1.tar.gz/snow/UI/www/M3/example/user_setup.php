<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�ӤH�]�w");

$SNOW_PAGE_TITLE = "�ӤH�]�w";
$SNOW_PAGEAREA_MAIN = "user_setup.m.php";
$SNOW_PAGEAREA_FUNC = "user_setup.f.php";

include("bone.php");

?>