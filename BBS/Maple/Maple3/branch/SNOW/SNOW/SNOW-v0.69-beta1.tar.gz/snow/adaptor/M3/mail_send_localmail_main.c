/*
 *  $Id: mail_send_localmail_main.c,v 1.4 2000/10/05 20:59:52 jeffhung Exp $
 */

#undef	DEBUG_MAIL_SEND_LOCALMAIL_MAIN

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 5) {
		printf("Usage: %s <from-user-id> <to-user-id> <subject> <mail-file-name>\n", argv[0]);
		return 0;
	}

#ifdef	DEBUG_MAIL_SEND_LOCALMAIL_MAIN
	{
	int	debug_i;
	for (debug_i = 1; debug_i <= argc; ++debug_i) {
		fprintf(stderr, "DEBUG(%s:%d): argv[%d]: %s`\n",
		        __FILE__, __LINE__, debug_i, argv[debug_i]);
	}
	}
#endif	/* DEBUG_MAIL_SEND_LOCALMAIL_MAIN */

	argv[3][strlen(argv[3]) - 1] = 0;
	if ((ret = mail_send_localmail(fileno(stdout), argv[1], argv[2], &(argv[3][1]), argv[4])) < 0) {
		fprintf(stderr, "mail_send_localmail error(%d).\n", ret);
	}

	return 0;
}

