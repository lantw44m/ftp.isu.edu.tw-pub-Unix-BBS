<SCRIPT LANGUAGE="JavaScript">
<!--

<?php

$max = $result["brd_class_list_max"][0]["MAX"][0];
debug_print($max);

?>

// ��Ĥ@��
function pg2first()
{
	document.fPageChanger.iPageTop.value = "1";
	document.fPageChanger.submit();
}

// ��W�@��
function pg2prev()
{
	<?php if ($iPageTop > $iPageSize) { ?>
	document.fPageChanger.iPageTop.value = <?php
	$prevPage = $iPageTop - $iPageSize;
	printf("\"%d\"", $iPageTop - $iPageSize);
	?>;
	<?php } ?>
	document.fPageChanger.submit();
}

// ��U�@��
function pg2next()
{
	<?php if (($max - $iPageTop) > $iPageSize) { ?>
	document.fPageChanger.iPageTop.value = <?php
	$nextPage = $iPageTop + $iPageSize;
	printf("\"%d\"", $iPageTop + $iPageSize);
	?>;
	<?php } ?>
	document.fPageChanger.submit();
}

// ��̥���
function pg2last()
{
	document.fPageChanger.iPageTop.value = <?php
	printf("\"%d\"", floor($max / $iPageSize) * $iPageSize + 1);
	?>;
	document.fPageChanger.submit();
}

function pg2go()
{
	document.fPageChanger.iPageTop.value = document.fPageChanger.iDirectGo.options[document.fPageChanger.iDirectGo.selectedIndex].value;
	document.fPageChanger.submit();
}

//-->
</SCRIPT>
<FORM METHOD="post" NAME="fPageChanger" ACTION="brd_class_list.php">
	<INPUT TYPE="hidden" NAME="iChannel" VALUE="<?php echo $iChannel; ?>">
	<INPUT TYPE="hidden" NAME="iPageTop" VALUE="<?php echo $iPageTop; ?>">
	<INPUT TYPE="hidden" NAME="iPageSize" VALUE="<?php echo $iPageSize; ?>">
	<INPUT TYPE="hidden" NAME="iMode" VALUE="<?php echo $iMode; ?>">
	<P> 
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo" onChange="document.fPageChanger.iDirectGo2.selectedIndex = document.fPageChanger.iDirectGo.selectedIndex;">
		<?php

		for ($i = 0; $i < ceil($max / $iPageSize); ++$i) {
			printf("<OPTION VALUE=\"%d\"%s>%d</OPTION>\n",
			       $iPageSize * $i + 1,
				   ((($iPageSize * $i + 1) == $iPageTop) ? " SELECTED" : ""),
				   $i + 1);
		}
		
		?>
		</SELECT>
		��
		<INPUT TYPE="button" VALUE="Go" onClick="pg2go();">
		</P>
	<TABLE WIDTH="100%" BORDER="1">
		<TR> 
			<TH>�s��</TH>
			<TH>�`��</TH>
			<TH>�Х�</TH>
			<TH>�ݪO</TH>
			<TH>����ԭz</TH>
			<TH>�벼</TH>
			<TH>���D</TH>
		</TR>
		<?php
		
		$cblist = $result["brd_class_list"];

		for ($i = 0; $i < count($cblist); ++$i) {
			if ($cblist[$i]["TYPE"][0] == "CLASS") {
				printf("<TR>\n");
				printf("<TD>%d <INPUT TYPE=\"radio\" NAME=\"iItem\" VALUE=\"%d\"></TD>\n",
					   $iPageTop + $i, $cblist[$i]["CHANNEL"][0]);
				printf("<TD>xx</TD>\n");
				printf("<TD>xx</TD>\n");
				printf("<TD><A HREF=\"brd_class_list.php?iChannel=%d&iPageTop=1&iPageSize=%d\">" .
					   "%s</A>/</TD>\n",
					   $cblist[$i]["CHANNEL"][0], $iPageSize, $cblist[$i]["CLASS-NAME"][0]);
				printf("<TD><A HREF=\"brd_class_list.php?iChannel=%d&iPageTop=1&iPageSize=%d\">" .
					   "%s</A></TD>\n",
					   $cblist[$i]["CHANNEL"][0], $iPageSize, $cblist[$i]["CLASS-TITLE"][0]);
				printf("<TD>&nbsp;</TD>\n");
				printf("<TD>&nbsp;</TD>\n");
				printf("</TR>\n");
			}
			else if ($cblist[$i]["TYPE"][0] == "BOARD") {
				printf("<TR>\n");
				printf("<TD>%d <INPUT TYPE=\"radio\" NAME=\"iItem\" VALUE=\"%s\"></TD>\n",
					   $iPageTop + $i, $cblist[$i]["BRD-NAME"][0]);
				printf("<TD>xx</TD>\n");
				printf("<TD>xx</TD>\n");
				printf("<TD><A HREF=\"brd_plist.php?iBoardID=%s&iPageTop=1&iPageSize=%d\">" .
					   "%s</A></TD>\n",
					   $cblist[$i]["BRD-NAME"][0], $iPageSize, $cblist[$i]["BRD-NAME"][0]);
				printf("<TD><A HREF=\"brd_plist.php?iBoardID=%s&iPageTop=1&iPageSize=%d\">" .
					   "%s</A></TD>\n",
					   $cblist[$i]["BRD-NAME"][0], $iPageSize, $cblist[$i]["BRD-TITLE"][0]);
				printf("<TD>%s</TD>\n", ($cblist[$i]["VOTE"][0] == "VOTE") ? "V" : "&nbsp;");
				printf("<TD>%s</TD>\n", $cblist[$i]["BRD-BM"][0]);
				printf("</TR>\n");
			}
		}

		?>
	</TABLE>
	<P>
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo2" onChange="document.fPageChanger.iDirectGo.selectedIndex = document.fPageChanger.iDirectGo2.selectedIndex;">
		<?php

		for ($i = 0; $i < ceil($max / $iPageSize); ++$i) {
			printf("<OPTION VALUE=\"%d\"%s>%d</OPTION>\n",
			       $iPageSize * $i + 1,
				   ((($iPageSize * $i + 1) == $iPageTop) ? " SELECTED" : ""),
				   $i + 1);
		}
		
		?>
		</SELECT>
		��
		<INPUT TYPE="button" VALUE="Go" onClick="pg2go();">
		</P>
</FORM>