/*
 *  $Id: bbs_logout_main.c,v 1.4 2000/10/05 20:59:52 jeffhung Exp $
 */

#undef DEBUG_BBS_LOGOUT_MAIN

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 2) {
		printf("Usage: %s <session-id>\n", argv[0]);
		return 0;
	}

	if ((ret = bbs_logout(fileno(stdout), argv[1])) != 0) {

#ifdef DEBUG_BBS_LOGOUT_MAIN
		fprintf(stderr, "bbs_logout() error(%d).\n", ret);
#endif /* DEBUG_BBS_LOGOUT_MAIN */
	}

	return 0;
}

