<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
SESSIONcache("SNOW_CHATCACHE");

$mrr = array(
	"chat_connect" => array(
		0 => array(
			// ...
			"MRR-SID" => array(0 => session_id()),
			"USERID" => array(0 => $sUserID),
			"CHATID" => array(0 => $iChatID),
			"ACTION" => array(0 => "message"),
			"MESSAGE" => array(0 => $iChatMessage),
			"TYPE" => array(0 => "chat")
		)
	)
);

$result = MRRquery($mrr);
$chatNewMsg = $result["chat_connect"];
$chatMessages = unserialize($SNOW_CHATCACHE);


if ((count($chatNewMsg) == 1) && isset($chatNewMsg[0]["NO-MSG"][0]) && ($chatNewMsg[0]["NO-MSG"][0] == "YES")) {
	$noMsg = TRUE;
}
else {
	$noMsg = FALSE;
	$chatMessages = array_merge(array(), $chatMessages);
	for ($i = 0; $i < count($chatNewMsg); ++$i) {
		array_push($chatMessages, $chatNewMsg[$i]["MESSAGE"][0]);
	}
}


?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE>��ѫ�</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=big5">
<META HTTP-EQUIV="Refresh" CONTENT="5;chatarea.php?iChatID=<?php echo $iChatID; ?>">
<META NAME="Generator" CONTENT="">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
<STYLE TYPE="text/css">
<!--

a:link		{	color: blue;	text-decoration: none;	}
a:visited	{	color: blue;	text-decoration: none;	}
a:hover		{	color: red;		text-decoration: none;	}
a:active	{	color: red;		text-decoration: none;	}

-->
</STYLE>
<SCRIPT LANGUAGE="JavaScript">
<!--

function sendChatMessage($newMsg)
{
	alert("!!!" + $newMsg);
	top.area.location = "chatarea.php?iChatID=<?php echo $iChatID; ?>&iChatMessage=" + $newMsg;
}

//-->
</SCRIPT></HEAD>

<BODY BGCOLOR="white">
Hi! <?php echo $iChatID; ?>�A<?php echo session_id(); ?>
<HR>
<?php

for ($i = count($chatMessages); $i >= 0; --$i) {
	printf("### %d ### %s ###<BR>\n", $i, $chatMessages[$i]);
}

$SNOW_CHATCACHE = serialize($chatMessages);

//phpinfo();

?>

</BODY>
</HTML>
