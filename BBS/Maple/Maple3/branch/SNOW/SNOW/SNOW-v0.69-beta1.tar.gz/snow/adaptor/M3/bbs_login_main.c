/*
 *  $Id: bbs_login_main.c,v 1.4 2000/10/05 20:59:52 jeffhung Exp $
 */

#undef DEBUG_BBS_LOGIN_MAIN

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 7) {
		printf("Usage: %s <session-id> <user-id> <password>"
		       " <rusername> <fromhost> <fromip>\n", argv[0]);
		return 0;
	}

	if ((ret = bbs_login(fileno(stdout), argv[1], argv[2], argv[3],
	                     argv[4], argv[5], argv[6])) != 0) {

#ifdef DEBUG_BBS_LOGIN_MAIN
		fprintf(stderr, "bbs_login() error(%d).\n", ret);
#endif /* DEBUG_BBS_LOGIN_MAIN */
	}

	return 0;
}

