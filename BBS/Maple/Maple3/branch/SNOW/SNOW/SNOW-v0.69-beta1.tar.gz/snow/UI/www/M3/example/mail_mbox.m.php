<SCRIPT LANGUAGE="JavaScript">
<!--

// ��Ĥ@��
function pg2first()
{
}

// ��W�@��
function pg2prev()
{
}

// ��U�@��
function pg2next()
{
}

// ��̥���
function pg2last()
{
}

//-->
</SCRIPT>
<FORM METHOD="POST" NAME="fPageChanger" ACTION="mail_mbox.php">
	<INPUT TYPE="hidden" NAME="iPageTop" VALUE="">
	<INPUT TYPE="hidden" NAME="iPageSize" VALUE="">
	<!--
	<P>
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo" onChange="document.fPageChanger.iDirectGo2.selectedIndex = document.fPageChanger.iDirectGo.selectedIndex;">
			<OPTION VALUE="1" SELECTED>1</OPTION>
			<OPTION VALUE="2">2</OPTION>
		</SELECT>
		��
	</P>
	-->
	<TABLE WIDTH="100%" BORDER="1">
		<THEAD>
		<TR> 
			<TH>�s��</TH>
			<TH>&nbsp;</TH>
			<TH>���</TH>
			<TH>�@��</TH>
			<TH>�H����D</TH>
		</TR>
		</THEAD>
		<TBODY>
		<?php

		debug_print(serialize($result));
		$mbox = $result["mail_mbox"];
		debug_print(serialize($mbox));

		for ($i = 0; $i < count($mbox); ++$i) {
			printf("<TR>\n");
			printf("<TD>%d <INPUT TYPE=\"radio\" NAME=\"iItem\" VALUE=\"%s\"></TD>\n",
			       $mbox[$i]["INDEX"][0], $mbox[$i]["FILENAME"][0]);
			printf("<TD>%s%s</TD>\n", $mbox[$i]["MARK"][0], $mbox[$i]["TAG"][0]);
			printf("<TD>%s</TD>\n", $mbox[$i]["DATE"][0]);
			printf("<TD><A HREF=\"talk_query_user.php?iQueryID=%s\">%s</A></TD>\n",
			       $mbox[$i]["AUTHOR"][0], $mbox[$i]["AUTHOR"][0]);
			printf("<TD><A HREF=\"mail_read_mail.php?iFilename=%s\">%s</A></TD>\n",
			       $mbox[$i]["FILENAME"][0], $mbox[$i]["SUBJECT"][0]);
			printf("</TR>\n");
		}

		?>
		</TBODY>
	</TABLE>
	<!--
	<P>
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo2" onChange="document.fPageChanger.iDirectGo.selectedIndex = document.fPageChanger.iDirectGo2.selectedIndex;">
			<OPTION VALUE="1" SELECTED>1</OPTION>
			<OPTION VALUE="2">2</OPTION>
		</SELECT>
		��
	</P>
	-->
</FORM>