<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�޲z����");

$SNOW_PAGE_TITLE = "�޲z����";
$SNOW_PAGEAREA_MAIN = "admin_center.m.php";
$SNOW_PAGEAREA_FUNC = "admin_center.f.php";

include("bone.php");

?>