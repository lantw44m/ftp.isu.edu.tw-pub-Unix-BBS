/*
 *  $Id: sys_load.c,v 1.4 2000/10/05 20:59:52 jeffhung Exp $
 */

#undef DEBUG_SYS_LOAD

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <stdio.h>



int sys_load(int ofd)
{
	double *load;
	char   buf[80];

	ushm_init();

	load = ushm->sysload;
	sprintf(buf, "MRR-RESULT:sys_load\nLOAD:%.2f %.2f %.2f\n",
	        load[0], load[1], load[2]);
	write(ofd, buf, strlen(buf));

	return 0;
}

