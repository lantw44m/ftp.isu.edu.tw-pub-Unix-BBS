/*
 *  $Id: acct_lib.c,v 1.2 2000/10/11 13:31:58 jeffhung Exp $
 */

#define _ADMIN_C_

#include "bbs.h"

extern BCACHE *bshm;

#define STR_PERM      "bctpjm#x--------PTCM--L*B#--ACBS"


/* ----------------------------------------------------- */
/* (.ACCT) �ϥΪ̱b�� (account) subroutines		 */
/* ----------------------------------------------------- */

void
blog(mode, msg)
  char *mode, *msg;
{
  char buf[512], data[256];
  time_t now;

  time(&now);
  if (!msg)
  {
    msg = data;
    sprintf(data, "Stay: %d (%d)", (now - ap_start) / 60, currpid);
  }

  sprintf(buf, "%s %s %-13s%s\n", Etime(&now), mode, cuser.userid, msg);
  f_cat(FN_USIES, buf);
}


int
acct_load(acct, userid)
  ACCT *acct;
  char *userid;
{
  int fd;

  usr_fpath((char *) acct, userid, fn_acct);
  fd = open((char *) acct, O_RDONLY);
  if (fd >= 0)
  {
    /* Thor.990416: �S�O�`�N, ���� .ACCT�����׷|�O0 */
    read(fd, acct, sizeof(ACCT));
    close(fd);
  }
  return fd;
}


void
acct_save(acct)
  ACCT *acct;
{
  int fd;
  char fpath[80];

  usr_fpath(fpath, acct->userid, fn_acct);
  fd = open(fpath, O_WRONLY, 0600);	/* fpath �����w�g�s�b */
  if (fd >= 0)
  {
    write(fd, acct, sizeof(ACCT));
    close(fd);
  }
}


int
acct_userno(userid)
  char *userid;
{
  int fd;
  int userno;
  char fpath[80];

  usr_fpath(fpath, userid, fn_acct);
  fd = open(fpath, O_RDONLY);
  if (fd >= 0)
  {
    read(fd, &userno, sizeof(userno));
    close(fd);
    return userno;
  }
  return 0;
}

/* ----------------------------------------------------- */
/* bit-wise display and setup				 */
/* ----------------------------------------------------- */

void
bitmsg(msg, str, level)
  char *msg, *str;
  int level;
{
  int cc;

  printf("%s",msg);
  while (cc = *str)
  {
    putchar((level & 1) ? cc : '-');
    level >>= 1;
    str++;
  }

  putchar('\n');
}

/* Arlo.20000706
 * delete bitset() setperm()
*/

/* ----------------------------------------------------- */
/* �b���޲z						 */
/* ----------------------------------------------------- */

void
bm_list(userid)                 /* ��� userid �O���ǪO���O�D */
  char *userid;
{
  int len, ch;
  BRD *bhdr, *tail;
  char *list;
  extern BCACHE *bshm;

  len = strlen(userid);
  printf("����O�D�G");

  bhdr = bshm->bcache;
  tail = bhdr + bshm->number;

  do
  {
    list = bhdr->BM;
    ch = *list;
    if ((ch > ' ') && (ch < 128))
    {
      do
      {
        if (!str_ncmp(list, userid, len))
        {
          ch = list[len];
          if ((ch == 0) || (ch == '/'))
          {
            printf(bhdr->brdname);
            printf(" ");
            break;
          }
        }
        while (ch = *list++)
        {
          if (ch == '/')
            break;
        }
      } while (ch);
    }
  } while (++bhdr < tail);

  printf("\n");
}

#ifdef LOG_ADMIN
/* Thor.990405: log permission modify */
void
perm_log(u, oldu)
  ACCT *u;
  ACCT *oldu;
{
  int i;
  usint level;
  char buf[128];

  for(i = 0, level = 1; i < NUMPERMS; i++, level <<= 1)
  {
    if ((u->userlevel & level) != (oldu->userlevel & level))
    {
      sprintf(buf, "%s %s %s (%s) by %s\n", u->userid,  
                       (u->userlevel & level) ? "��" : "��",
                       perm_tbl[i], Now(), cuser.userid);

      f_cat(FN_SECURITY, buf);
    }
  }
  if(str_ncmp(u->userid,oldu->userid,IDLEN))   
  {
      sprintf(buf, "%s ��W�� %s (%s) by %s\n", oldu->userid, u->userid,
                                                Now(), cuser.userid);
      f_cat(FN_SECURITY, buf);
  }                                                  
  
}
#endif

void
acct_show(u, adm)
  ACCT *u;
  int adm;			/* 1: admin 2: reg-form */
{
  int diff;
  usint ulevel;
  char *uid, buf[80];

  uid = u->userid;
  if (adm != 2)
    printf("\n�N    ���G%s", uid);

  printf(
    "\n��    �١G%s\n"
    "�u��m�W�G%s\n"
    "�~�����}�G%s\n"
    "�l��H�c�G%s\n",
    u->username,
    u->realname,
    u->address,
    u->email);

  printf("���U����G%s", ctime(&u->firstlogin));

  printf("���{����G%s", ctime(&u->lastlogin));

  diff = u->staytime / 60;
  printf("�W�����ơG%d �� (�@ %d �� %d ��)\n",
    u->numlogins, diff / 60, diff % 60);

  printf("�峹�ƥءG%d �g\n", u->numposts);

  usr_fpath(buf, uid, fn_dir);
  printf("�ӤH�H��G%d ��\n", rec_num(buf, sizeof(HDR)));

  ulevel = u->userlevel;

  printf("�����{�ҡG");
  if (ulevel & PERM_VALID)
  {
    printf(u->tvalid ? Ctime(&u->tvalid) : "���Ĵ����w�L�A�Э��s�{��");
  }
  else
  {
    printf("�аѦҥ������G��i��T�{�A�H���@�v��");
  }
#if 0
  printf("\033[m\n");
#endif

  if (adm)
  {
    printf("�{�Ҹ�ơG%s\n", u->justify);
    printf("�{�Ҧa�}�G%s\n", u->vmail);
    printf("RFC 931 �G%s\n", u->ident);
    printf("�W���a�I�G%s (%d)\n", u->lasthost, u->numemail);
    bitmsg(MSG_USERPERM, STR_PERM, ulevel);
    bitmsg("�X    �СG", "amnsEPQFAC", u->ufo);
  }
  else
  {
    diff = (time(0) - ap_start) / 60;
    printf("���d�����G%d �p�� %d ��\n", diff / 60, diff % 60);
  }

  if (adm == 2)
    return;

  /* Thor: �Q�ݬݳo�� user �O���Ǫ������D */

  if (ulevel & PERM_BM)
    bm_list(uid);

#ifdef	NEWUSER_LIMIT
  if (u->lastlogin - u->firstlogin < 3 * 86400)
    printf("\n�s��W���G�T�ѫ�}���v��");
#endif
}

/*Arlo.20000708 
 * delete acct_setup() u_info() m_user()
*/

/* ----------------------------------------------------- */
/* �]�w E-mail address					 */
/* ----------------------------------------------------- */


int
ban_addr(addr)
  char *addr;
{
  int i;
  char *host, *str;
  char foo[64]; /* SoC: ��m���ˬd�� email address */

  static char *invalid[] =
  {"@bbs", "bbs@", "root@", "gopher@",
    "guest@", "@ppp", "@slip", "@dial", "unknown@", "@anon.penet.fi",
    "193.64.202.3", NULL
  };

#if 1 /* Thor.991112: �����Ψӻ{�Ҫ�email */
  sprintf(foo, "%s # %s (%s)\n",addr, cuser.userid, Now());
  f_cat("run/emailreg.log", foo);
#endif  

  /* SoC: �O���� email ���j�p�g */
  str_lower(foo, addr);

  for (i = 0; str = invalid[i]; i++)
  {
    if (strstr(foo, str))
      return 1;
  }

#ifdef TRUST_ACLFILE
#ifdef UNTRUST_ACLFILE

  /* check for mail.acl (lower case filter) */

  host = (char *) strchr(foo, '@');
  *host = '\0';
  /* Thor.991103: �զW�� */
  i = acl_has(TRUST_ACLFILE, foo, host + 1);
  /* if(i < 0 ) TRACE("NOACL","TRUST_ACLFILE"); */
  if (i == 0) return 1; /* BAN */ 

  /* i = acl_has(MAIL_ACLFILE, foo, host + 1); */
  /* Thor.981223: �Nbbsreg�ڵ��������} */
 /* Thor.991103: �¦W�� */   
  i = acl_has(UNTRUST_ACLFILE, foo, host + 1);
  /* *host = '@'; */
  if(i < 0)
    TRACE("NOACL",host);

  return i > 0;

#else /* UNTRUST_ACLFILE */

  return 0;

#endif /* UNTRUST_ACLFILE */
#endif /* TRUST_ACLFILE */
}


/* Arlo.20000707
 * delete u_lock() u_xfile()
*/

/* ----------------------------------------------------- */
/* �ݪO�޲z						 */
/* ----------------------------------------------------- */


int
valid_brdname(brd)
  char *brd;
{
  int ch;

  if (!is_alnum(*brd))
    return 0;

  while (ch = *++brd)
  {
    if (!is_alnum(ch) && ch != '.' && ch != '-' && ch != '_')
      return 0;
  }
  return 1;
}

/* Arlo.20000707
 * delete m_setbrd() brd_edit()
*/

#ifdef	HAVE_REGISTER_FORM
/* ----------------------------------------------------- */
/* �ϥΪ̶�g���U����					 */
/* ----------------------------------------------------- */

/* Arlo.20000707
 * delete getfield()  u_register() 
 *        scan_register_form()  m_register()
*/


#endif


/* ----------------------------------------------------- */
/* ���Ͱl�ܰO���G��ĳ��� log_usies()�BTRACE()		 */
/* ----------------------------------------------------- */


#ifdef	HAVE_REPORT
void
report(s)
  char *s;
{
  static int disable = NA;
  int fd;

  if (disable)
    return;

  if ((fd = open("trace", O_WRONLY, 0600)) != -1)
  {
    char buf[256];
    char *thetime;
    time_t dtime;

    time(&dtime);
    thetime = Etime(&dtime);

    /* flock(fd, LOCK_EX); */
    /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
    f_exlock(fd);

    lseek(fd, 0, L_XTND);
    sprintf(buf, "%s %s %s\n", cuser.userid, thetime, s);
    write(fd, buf, strlen(buf));

    /* flock(fd, LOCK_UN); */
    /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
    f_unlock(fd);

    close(fd);
  }
  else
    disable = YEA;
}


#endif
