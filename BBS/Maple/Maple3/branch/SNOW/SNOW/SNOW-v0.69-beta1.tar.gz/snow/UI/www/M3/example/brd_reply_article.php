<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�^�Ф峹");

$SNOW_PAGE_TITLE = "�^�Ф峹";
$SNOW_PAGEAREA_MAIN = "brd_reply_article.m.php";
$SNOW_PAGEAREA_FUNC = "brd_reply_article.f.php";

include("bone.php");

?>