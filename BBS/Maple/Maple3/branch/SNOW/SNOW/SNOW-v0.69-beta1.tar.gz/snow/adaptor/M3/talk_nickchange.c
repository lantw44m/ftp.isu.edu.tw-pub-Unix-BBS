/*
 *  $Id: talk_nickchange.c,v 1.4 2000/10/05 20:59:53 jeffhung Exp $
 */

#undef DEBUG_TALK_NICKCHANGE

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"
#include <string.h>
#include "w3if_session.h"


int talk_nickchange(char *sid, char *newnick)
{
	W3IF_SESSENTRY *psess = 0;

	chdir(BBSHOME);

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	psess = w3ifsession_get(sid);

	if (!psess) {
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;
	acct_load(&cuser, cutmp->userid);

	strncpy(cutmp->username, newnick, 24 - 1);

	return 0;
}

