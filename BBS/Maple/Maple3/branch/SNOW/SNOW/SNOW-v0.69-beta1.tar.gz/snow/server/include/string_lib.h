/*
 * 
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation 
 * bbs, the cross-media distributed communication platform. And it is 
 * developed by Cyberwork Solution in 2000.
 * 
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 * 
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or (at 
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or 
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution.com , Isabel Ho
 *
 */


#ifndef	STR_H_INCLUDED
#define	STR_H_INCLUDED


/*
 *  Copy string ct to string s, including '\0'; return s.
 */
char* str_copy(char* s, const char* ct);

/*
 *  Copy at most n characters of string ct to s; return s.
 *  Pad s with '\0' if ct has fewer then n characters.
 */
char* str_ncopy(char* s, const char* ct, const int n);

/*
 *  Concatenate string ct to end of string s; return s.
 */
char* str_concat(char* s, const char* ct);

/*
 *  Concatenate at most n characters of string ct to string s, terminate
 *  s with '\0'; return s.
 */
char* str_nconcat(char* s, const char* ct, const int n);

/*
 *  Compare string cs to string ct; return <0 if cs < ct, 0 if cs == ct,
 *  or >0 if cs > ct.
 */
int str_compare(const char* cs, const char* ct);

/*
 *  Compare at most n characters of string cs to string ct; return <0 if
 *  cs < ct, 0 if cs == ct, or >0 if cs > ct.
 */
int str_ncompare(const char* cs, const char* ct, const int n);

/*
 *  Return pointer to first occurrence of c in cs or 0 if not present.
 */
char* str_findchar(const char* cs, const char c);

/*
 *  Return pointer to last occurrence of c in cs or 0 if not present.
 */
char* str_rfindchar(const char* cs, const char c);

/*
 *  Return pointer to first occurrence in string cs of any character of
 *  string ct, or 0 if none are present.
 */
char* str_findchars(const char* cs, const char* ct);

/*
 *  Return pointer to last occurrence in string cs of any character of
 *  string ct, or 0 if none are present.
 */
char* str_rfindchars(const char* cs, const char* ct);

/*
 *  Return pointer to first occurrence of string ct in cs, or 0 if not
 *  present.
 */
char* str_findstr(const char* cs, const char* ct);

/*
 *  Return pointer to last occurrence of string ct in cs, or 0 if not
 *  present.
 */
char* str_rfindstr(const char* cs, const char* ct);

/*
 *  Return length of s.
 */
int str_length(const char* s);

/*
 *  Same as sprintf().
 */
int str_format(char* s, const char* format, ...);

/*
 *
 */
int str_nformat(char* s, const int n, const char* format, ...);

/*
 *  Turn all letters in s to lower case and return s.
 */
char* str_tolower(char* s);

/*
 *  Turn all letters in s to upper case and return s.
 */
char* str_toupper(char* s);


#endif	/* STR_H_INCLUDED */

