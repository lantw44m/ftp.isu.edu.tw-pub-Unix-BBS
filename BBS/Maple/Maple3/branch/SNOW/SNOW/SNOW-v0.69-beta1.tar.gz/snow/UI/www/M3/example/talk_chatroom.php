<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("��ѫ�");

$SNOW_PAGE_TITLE = "��ѫ�";
$SNOW_PAGEAREA_MAIN = "talk_chatroom.m.php";
$SNOW_PAGEAREA_FUNC = "talk_chatroom.f.php";

include("bone.php");

?>