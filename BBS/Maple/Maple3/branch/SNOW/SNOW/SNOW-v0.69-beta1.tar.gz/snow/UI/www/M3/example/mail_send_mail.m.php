<FORM METHOD="POST" ACTION="_mail_send_mail.php">
	<P>�H�H�H�G<A HREF="talk_query_user.php"><?php echo $sUserID; ?></A> (<?php echo $sUserName; ?>)<BR>
		���H�H�G 
		<INPUT TYPE="text" NAME="iTo" VALUE="<?php
		
		if (isset($iTo) && (strlen($iTo) > 0)) {
			echo $iTo;
		}

		?>">
		<BR>
		�峹���D�G 
		<INPUT TYPE="text" NAME="iSubject" VALUE="<?php

		if (isset($iSubject) && (strlen($iSubject) > 0)) {
			echo $iSubject;
		}
		
		?>">
	</P>
	<P> 
		<TEXTAREA NAME="iBody" COLS="80" ROWS="24"></TEXTAREA>
	</P>
	<P> 
		<INPUT TYPE="submit" VALUE="�H�X�H��">
	</P>
</FORM>