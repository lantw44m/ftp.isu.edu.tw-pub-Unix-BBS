/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution.com , Isabel Ho
 *
 */

/*
 *  $Id: mod_talk.h,v 1.4 2000/10/05 20:59:53 jeffhung Exp $
 */

#ifndef MOD_TALK_H_INCLUDED
#define MOD_TALK_H_INCLUDED

#include "w3if.h"
#include "mod_header.h"

/* talk_ulist.c */

/* declare �nexport��server��table name */
extern BBS_Mod_Request_Table talk_ulist_table[];

/* declare �nexport��server �� function */
int talk_ulist_main(int fd, BBS_Mod_Request_Table *res_table);
int talk_ulist_register(BBS_Mod_Pool_Table *pool);


#endif /* MOD_TALK_H_INCLUDED */

