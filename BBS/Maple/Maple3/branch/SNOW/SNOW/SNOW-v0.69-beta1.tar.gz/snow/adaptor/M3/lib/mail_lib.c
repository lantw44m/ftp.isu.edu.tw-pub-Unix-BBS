/*
 *  $Id: mail_lib.c,v 1.1.1.1 2000/09/30 03:48:18 arlo Exp $
 */

#undef	DEBUG_MAIL_LIB

#include "w3iflib.h"
#include "w3ifglobal.h"


#include "bbs.h"



void ll_new()
{
	LinkList*	list, *next;

	list = ll_head;

	while (list) {
		next = list->next;
		free(list);
		list = next;
	}

	ll_head = ll_tail = 0;
}


void ll_add(char* name)
{
	LinkList*	node;
	int			len;

	len = strlen(name) + 1;

	/* JeffHung.2000710: oh~ oh~ �ݨ쨸�c���N�ϤF~ �u�O�������@�k�C*/
	node = (LinkList*)malloc(sizeof(LinkList) + len);
	node->next = 0;
	memcpy(node->data, name, len);

	if (ll_head) {
		ll_tail->next = node;
	}
	else {
		ll_head = node;
	}
	ll_tail = node;
}


int ll_del(char* name)
{
	LinkList*	list;
	LinkList*	prev;
	LinkList*	next;

	prev = 0;
	for (list = ll_head; list; list = next) {
		next = list->next;
		if (!strcmp(list->data, name)) {
			if (prev == 0) {
				ll_head = next;
			}
			else {
				prev->next = next;
			}

			if (list == ll_tail) {
				ll_tail = prev;
			}

			free(list);
			return 1;	/* JeffHung.2000710: found name and deleted it */
		}
		prev = list;
	}
	return 0;	/* JeffHung.20000710: node not found and deleted nothing */
}


int ll_has(char* name)
{
	LinkList*	list;

	for (list = ll_head; list; list = list->next) {
		if (!strcmp(list->data, name)) {
			return 1;	/* JeffHung.2000710: found */
		}
	}
	return 0;	/* JeffHung.2000710: not found */
}


/* JeffHung.2000710 delete ll_out(), m_internet() */



#ifdef	BATCH_SMTP	/* batch mode smtp */

int bsmtp(char* fpath, char* title, char* rcpt, int method)
{
	char		buf[80];
	time_t		chrono;
	MailQueue	mqueue;

	chrono = time(0);

	/* ���~�d�I */

	if (method != MQ_JUSTIFY) {

		/* stamp the queue file */

		strcpy(buf, "out/");

		for (;;) {
			archiv32(chrono, buf + 4);
			if (!f_ln(fpath, buf)) {
				break;
			}
			++chrono;
		}
		fpath = buf;

		strcpy(mqueue.filepath, fpath);
		strcpy(mqueue.subject, title);
	}

	/* setup mail queue */

	mqueue.mailtime = chrono;
	mqueue.method = method;
	strcpy(mqueue.sender, cuser.userid);
	strcpy(mqueue.username, cuser.username);
	strcpy(mqueue.rcpt, rcpt);
	if (rec_add(MAIL_QUEUE, &mqueue, sizeof(mqueue)) < 0) {
		return -1;
	}

	++(cuser.numemail);	/* �O���ϥΪ̦@�H�X�X�� Internet E-mail */
	return chrono;
}


#else	/* BATCH_SMTP */


int bsmtp(char* fpath, char* title, char* rcpt, int method)
{
	int		sock;
	time_t	chrono;
	time_t	stamp;
	FILE*	fp;
	FILE*	fr;
	FILE*	fw;
	char*	str;
	char	buf[512];
	char	from[80];
	char	subject[80];
	char	msgid[80];
#ifdef	HAVE_SIGNED_MAIL
	char	prikey[9];
	union {
		char	str[9];
		struct {
			unsigned int	hash;
			unsigned int	hash2;
		} val;
	} sign;

#ifdef	DEBUG_MAIL_LIB
	fprintf(stderr, "DEBUG(%s:%d): fpath: %s, title: %s\n"
	                "DEBUG(%s:%d): rcpt: %s, method: %d\n",
			__FILE__, __LINE__, fpath, title,
	        __FILE__, __LINE__, rcpt, method);
#endif	/* DEBUG_MAIL_LIB */

	*prikey = prikey[8] = sign.str[8] = 0;	/* '\0' */
#endif	/* HAVE_SIGNED_MAIL */

	++(cuser.numemail);	/* �O���ϥΪ̦@�H�X�X�� Internet E-mail */
	chrono = time(&stamp);

	/*
	 *  JeffHung.2000710: �쥻�O�� == ����A���O MQ_JUSTIFY==0x02
	 *  MQ_UUENCODE==0x01�A�ݨ� MQ_XXXX �O�Φ줸�覡�ӽs�X�A
	 *  �ҥH�o��令�Φ줸�B�⪺ & �ӬݬO���O�{�ҫH�C
	 */
	if (method & MQ_JUSTIFY) {
		fpath = "etc/valid";
		title = subject;
		/* Thor.990125: MYHOSTNAME�Τ@��J str_host */
		snprintf(from, 80, "bbsreg@%s", str_host);
		archiv32(str_hash(rcpt, chrono), buf);
		/* sprintf(title, "[MapleBBS]To %s(%s) [VALID]", cuser.userid, buf); */
		/* Thor.981012: �����b config.h �޲z */
		/*
		 *  JeffHung.20000710: copy �r���Ƕi�Ӫ� char* title�H
		 *  ������L�Y�ܡH
		 */
		sprintf(title, TAG_VALID"%s(%s) [VALID]", cuser.userid, buf);
	}
	else {
		/* Thor.990125: MYHOSTNAME�Τ@��J str_host */
		snprintf(from, 80, "%s.bbs@%s", cuser.userid, str_host);
	}

	str = strchr(rcpt, '@') + 1;

#ifdef	DEBUG_MAIL_LIB
	fprintf(stderr, "DEBUG(%s:%d): dns_smtp\n", __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_LIB */

	sock = dns_smtp(str);

	if (sock >= 0) {

#ifdef	DEBUG_MAIL_LIB
		fprintf(stderr, "DEBUG(%s:%d): sock >= 0\n", __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_LIB */

		archiv32(chrono, msgid);

		sleep(1);	/* wait for mail server response */
		/* JeffHung.20000710: why? ���O�| block ���ܡH�F���٭n���O�o 1sec�H*/

		fr = fdopen(sock, "r");
		fw = fdopen(sock, "w");

		fgets(buf, sizeof(buf), fr);
		if (memcmp(buf, "220", 3)) {
			goto smtp_error;
		}

		if (buf[3] == '-') {
			fgets(buf, sizeof(buf), fr);
		}

		/* Thor.990125: MYHOSTNAME�Τ@��J str_host */
		fprintf(fw, "HELO %s\r\n", str_host);
		fflush(fw);
		do {
			fgets(buf, sizeof(buf), fr);
			if (memcmp(buf, "250", 3)) {
				goto smtp_error;
			}
		} while (buf[3] == '-');

		fprintf(fw, "MAIL FROM:<%s>\r\n", from);
		fflush(fw);
		do {
			fgets(buf, sizeof(buf), fr);
			if (memcmp(buf, "250", 3)) {
				goto smtp_error;
			}
		} while (buf[3] == '-');

		fprintf(fw, "RCPT TO:<%s>\r\n", rcpt);
		fflush(fw);
		do {
			fgets(buf, sizeof(buf), fr);
			if (memcmp(buf, "250", 3)) {
				goto smtp_error;
			}
		} while (buf[3] == '-');

#if	0	/* JeffHung.20000710: fprintf() �Ѽƨϥο��~ */
		fprintf(fw, "DATA\r\n", rcpt);
#else	/* 0 */
		fprintf(fw, "DATA\r\n");
#endif	/* 0 */

		fflush(fw);
		do {
			fgets(buf, sizeof(buf), fr);
			if (memcmp(buf, "354", 3)) {
				goto smtp_error;
			}
		} while (buf[3] == '-');

		/*
		 *  begin of mail header
		 */

		/* Thor.990125: ���i�઺�� RFC822 & sendmail���@�k, �K�o�O�H����:p */
		fprintf(fw,
		        "From: %s\r\n"
		        "To: %s\r\n"
		        "Subject: %s\r\n"
		        "X-Sender: %s (%s)\r\n"
		        "Date: %s\r\n"
		        "Message-Id: <%s@%s>\r\n"
		        "X-Disclaimer: [%s] �糧�H���e�����t�d\r\n\r\n",
		        from,
		        rcpt,
		        title,
		        cuser.userid, cuser.username,
		        Atime(&stamp),
		        msgid, str_host,
		        str_site);

		if (method & MQ_JUSTIFY) {
			fprintf(fw, " ID: %s (%s)  E-mail: %s\r\n\r\n",
			        cuser.userid, cuser.username, rcpt);
		}

		/*
		 *  begin of mail body
		 */

		if (fp = fopen(fpath, "r")) {
			char*	ptr;

			str = buf;
			*str++ = '.';
			while (fgets(str, sizeof(buf) - 3, fp)) {
				/* JeffHung.2000710: replace "\n" to "\r\n" */
				if (ptr = strchr(str, '\n')) {
					*ptr++ = '\r';
					*ptr++ = '\n';
					*ptr = 0;
				}
				/* JeffHung.20000710: �Y���Y�@�欰 ".\r\n"�A�K��� "..\r\n" */
				fputs((*str == '.' ? buf : str), fw);
			}
			fclose(fp);
		}
#ifdef	HAVE_SIGNED_MAIL
		/* Thor.990413: ���F�{�Ҩ�~, ��L�H�󳣭n�[sign */
		if (!(method & MQ_JUSTIFY) && !rec_get(PRIVATE_KEY, prikey, 8, 0)) {
			/* Thor.990413: buf�Τ���F, �ɨӥΥ� :P */
			/* JeffHung.20000710: �Q���o�ؤ@���h�Ϊ��{���g�k :-) */
			snprintf(buf, 512, "%s -> %s", cuser.userid, rcpt);
			sign.val.hash = str_hash(buf, stamp);
			sign.val.hash2 = str_hash2(buf, sign.val.hash);
			str_xor(sign.str, prikey);
			/* Thor.990413: ���[()����, �ɶ����ťշ|�Q�Y��(���Ү�) */
			fprintf(fw, "�� X-Info: %s\r\n�� X-Sign: %s%s (%s)\r\n",
			       buf, msgid, genpasswd(sign.str), Btime(&stamp));
		}
#endif	/* HAVE_SIGNED_MAIL */
		fputs("\r\n.\r\n", fw);
		fflush(fw);

		fgets(buf, sizeof(buf), fr);
		if (memcmp(buf, "250", 3)) {
			goto smtp_error;
		}

		fputs("QUIT\r\n", fw);
		fflush(fw);
		fclose(fw);
		fclose(fr);
		goto smtp_log;

smtp_error:

		fclose(fw);
		fclose(fr);
		snprintf(msgid + 7, 80 - 7, "\n\t%.70s", buf);
		chrono = -1;
	} /* if (sock >= 0) */
	else {
		/* chrono = -1; */
		chrono = -3;	/* Thor.991203: �ϥ��N�O������ */
		strcpy(msgid, "CONN FAIL");
	}

smtp_log:

	/* �O���H�H */

	snprintf(buf, 512, "%s%-13s%c> %s %s %s\n\t%s\n\t%s\n",
	         Btime(&stamp), cuser.userid,
	         ((method & MQ_JUSTIFY) ? '=' : '-'), rcpt, msgid,
#ifdef	HAVE_SIGNED_MAIL
	         *prikey ? genpasswd(sign.str) : "NoPriKey",
#else	/* HAVE_SIGNED_MAIL */
			"",
#endif	/* HAVE_SIGNED_MAIL */
			title, fpath);

	f_cat("run/mail.log", buf);

	return chrono;
}

#endif	/* BATCH_SMTP */



#ifdef	HAVE_SIGNED_MAIL

/* JeffHung.20000710: delete m_verify() */

#endif	/* HAVE_SIGNED_MAIL */


usint m_quota()
{
	usint		ufo;
	int			fd;
	int			count;
	int			fsize;
	int			limit;
	int			xmode;
	time_t		mail_due;
	time_t		mark_due;
	struct stat	st;
	HDR*		head;
	HDR*		tail;
	char*		base;
	char*		folder;
	char		date[9];

	if ((fd = open(folder = cmbox.dir, O_RDWR)) < 0) {
		return 0;
	}

	ufo = 0;
	fsize = 0;

	if (!fstat(fd, &st) &&
	    ((fsize = st.st_size) >= sizeof(HDR)) &&
	    (base = (char*)malloc(fsize))) {
		/* flock(fd, LOCK_EX); */
		/* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
		f_exlock(fd);

		if ((fsize = read(fd, base, fsize)) >= sizeof(HDR)) {
			int	prune;	/* number of pruned mail */

			limit = time(0);
			mail_due = limit - MAIL_DUE * 86400;
			mark_due = limit - MARK_DUE * 86400;
			st.st_mtime = limit + CHECK_PERIOD;
			str_stamp(date, &st.st_mtime);

			limit = cuser.userlevel;
			/* JeffHung.20000710: �H�W�S�O�@��@���h�Ϊ��ϨҤF.. :< */
			if (limit & (PERM_SYSOP | PERM_MBOX)) {
				limit = MAX_BBSMAIL;
			}
			else {
				limit = (limit & PERM_VALID) ? MAX_VALIDMAIL : MAX_NOVALIDMAIL;
			}

			count = fsize / sizeof(HDR);

			head = (HDR*)base;
			tail = (HDR*)(base + fsize);

			prune = 0;

			do {
				xmode = head->xmode;
				if (xmode & MAIL_DELETE) {
					char	fpath[64];

					hdr_fpath(fpath, folder, head);
					unlink(fpath);
					--prune;
					continue;
				}

				if (!(xmode & MAIL_READ)) {
					ufo |= UFO_BIFF;
				}

				if ((count > limit) ||
				    (head->chrono <= ((xmode & MAIL_MARKED) ?
				                      mark_due : mail_due))) {
					--count;
					head->xmode = xmode | MAIL_DELETE;
					strcpy(head->date, date);
					ufo |= UFO_MQUOTA;
				}

				if (prune) {
					head[prune] = head[0];
				}
			} while (++head < tail);

			fsize += (prune * sizeof(HDR));
			if ((fsize > 0) && (prune || (ufo & UFO_MQUOTA))) {
				lseek(fd, 0, SEEK_SET);
				write(fd, base, fsize);
				ftruncate(fd, fsize);
			}
		}

		/* flock(fd, LOCK_UN); */
		/* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
		f_unlock(fd);

		free(base);
	}

	close(fd);
	if (fsize < sizeof(HDR)) {
		unlink(folder);
	}

	return ufo;
}


int m_query(char* userid)
{
	int			fd;
	int			ans;
	int			fsize;
	HDR*		head;
	HDR*		tail;
	char		folder[64];	/* JeffHung.20000710: why not use MAXPATHLEN? */
	struct stat	st;

	ans = 0;
	usr_fpath(folder, userid, fn_dir);
	if ((fd = open(folder, O_RDONLY)) >= 0) {
		fsize = 0;

		if (!fstat(fd, &st) &&
		    (fsize = st.st_size) >= sizeof(HDR) &&
		    (head = (HDR*)malloc(fsize))) {
			if ((fsize = read(fd, head, fsize)) >= sizeof(HDR)) {
				tail = (HDR*)((char*)head + fsize);

				while (--tail >= head) {
					if (!(tail->xmode & MAIL_READ)) {
						ans = UFO_BIFF;
						break;	/* while */
					}
				}
			}
			free(head);
		}

		close(fd);
		if (fsize < sizeof(HDR)) {
			unlink(folder);
		}
	}

	return ans;
}


void m_biff(int userno)
{
	UTMP*	utmp;
	UTMP*	uceil;

	utmp = ushm->uslot;
	uceil = (void*)utmp + ushm->offset;
	do {
		if (utmp->userno == userno) {
			utmp->ufo |= UFO_BIFF;

#ifdef	BELL_ONCE_ONLY

			return;
#endif	/* BELL_ONCE_ONLY */

		}
	} while (++utmp <= uceil);
}


/* JeffHung.20000710: delete m_count(), mail_hold(), hdr_reply() */


int mail_external(char* addr)
{
	char*	str;

	str = strchr(addr, '@');
	if (!str) {
		return 0;
	}

	/* Thor.990125: MYHOSTNAME�Τ@��J str_host */
	if (str_cmp(str_host, str + 1)) {
		return 1;
	}

	/* �d�I xyz@domain �� xyz.bbs@domain */
	*str = 0;
	if (str = strchr(addr, '.')) {
		*str = 0;
	}

	return 0;
}


/*
 *  JeffHung.20000710: delete mail_send(), mail_reply(), my_send(), m_send(),
 *  mail_sysop()
 */

#ifndef	MULTI_MAIL

#define	multi_reply(x)	mail_reply(x)

#else	/* MULTI_MAIL */
		/* Thor.981009: ����R�����B�H */

/* JeffHung.20000710: delete multi_send(), multi-reply(), mail_list() */

#endif	/* MULTI_MAIL */


int mbox_attr(int type)
{
	if (type & MAIL_DELETE) {
		return 'D';
	}

	if (type & MAIL_REPLIED) {
		return (type & MAIL_MARKED) ? 'R' : 'r';
	}

	return "+ Mm"[type & 3];
}


/*
 *  JeffHung.20000710: delete tag_char(), hdr_outs(), mbox_item(),
 *  mbox_body(), mbox_head(), mbox_load(), mbox_init(), mbox_delete(),
 *  mbox_forward(), mbox_browse(), mbox_reply()
 */

/* JeffHung.20000710: �h�� output �������C*/
int mbox_mark(XO* xo)
{
	HDR*	mhdr;
	int		cur;
	int		pos;

	pos = xo->pos;
	cur = pos - xo->top;
	mhdr = (HDR*)xo_pool + cur;
	mhdr->xmode ^= MAIL_MARKED;
	rec_put(xo->dir, mhdr, sizeof(HDR), pos);
	return XO_NONE;
}



/*
 *  JeffHung.20000710: delete mbox_tag(), mbox_send(), mbox_sysop(),
 *  mbox_help(), mbox_main()
 */





