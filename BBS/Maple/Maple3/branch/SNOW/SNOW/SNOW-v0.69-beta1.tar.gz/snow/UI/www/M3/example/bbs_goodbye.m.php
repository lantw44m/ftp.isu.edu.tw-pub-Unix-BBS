<SCRIPT LANGUAGE="JavaScript">
<!--

function byebyeOption()
{
	if (document.fBye.iByeOption.value == "LEAVE") {
		window.location = "_logout.php";
	}
	else if (document.fBye.iByeOption.value == "YESSIR") {
		window.location = "mail_yessir.php";
	}
	else if (document.fBye.iByeOption.value == "NOTEPAD") {
		window.location = "";
	}
	else if (document.fBye.iByeOption.value == "ABORT") {
		window.location = "<?php echo HISTORYget(1); ?>"; // �^�W�@��
	}
}

//-->
</SCRIPT>
<FORM METHOD="post" NAME="fBye">
	<P>
		<INPUT TYPE="radio" NAME="iByeOption" VALUE="LEAVE" CHECKED>
		�ڭn���]�F<BR>
		<INPUT TYPE="radio" NAME="iByeOption" VALUE="YESSIR">
		���i����<BR>
		<INPUT TYPE="radio" NAME="iByeOption" VALUE="NOTEPAD">
		�d���� <BR>
		<INPUT TYPE="radio" NAME="iByeOption" VALUE="ABORT">
		��������</P>
	<P>
		<INPUT TYPE="button" VALUE="�T�T..." onClick="">
	</P>
</FORM>