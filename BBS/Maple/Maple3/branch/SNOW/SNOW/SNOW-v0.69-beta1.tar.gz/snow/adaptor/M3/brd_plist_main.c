/*
 *  $Id: brd_plist_main.c,v 1.2 2000/09/30 08:05:11 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"
#include <stdlib.h> /* for atoi */


int main(int argc, char* argv[])
{
	int	fd;
	int	ret;

	if (argc != 4) {
		printf("Usage: %s <board-id> <top-index> <page-size>\n",
		       argv[0]);
		return 0;
	}

	fd = fileno(stdout);

	if ((ret = brd_plist(fd, argv[1], atoi(argv[2]), atoi(argv[3]))) < 0) {
		fprintf(stderr, "brd_plist error(%d).\n", ret);
	}

	return 0;
}

