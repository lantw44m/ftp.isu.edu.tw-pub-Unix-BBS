/*
 *  $Id: talk_query_user.c,v 1.5 2000/10/05 20:59:53 jeffhung Exp $
 */

#define DEBUG_TALK_QUERY_USER

#define	_MODES_C_	/* for ModeTypeTable */

#include "bbs.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */

#ifdef AS_ARNI_MODULE

int mod_talk_query_user(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return talk_query_user(ofd, parg->args[0].s);
}

#endif /* AS_ARNI_MODULE */


#if 0 /* JeffHung.20001004: already defined in lib/talk_lib.c */

char* bmode(UTMP* up, int simple)
{
	static char	modestr[32];
	int			mode;
	char*		word;

	word = ModeTypeTable[mode = up->mode];
	if (simple) {
		return word;
	}

	if (mode < M_TALK || mode > M_QUERY) {
		return word;
	}

	/* Thor.980805: ����: �������H���|�Q���D���talk */
	if ((mode != M_QUERY) &&
	    !HAS_PERM(PERM_SEECLOAK) &&
	    (up->ufo & UFO_CLOAK)) {
		return word;
	}

	snprintf(modestr, 32, "%s [%s]", word, up->mateid);
	return modestr;
}

#endif /* 0 */


void showplans(char* userid)
{
	int		i;
	FILE*	fp;
	char	buf[256];

	usr_fpath(buf, userid, fn_plans);
	if (fp = fopen(buf, "r")) {
		i = MAXQUERYLINES;
		while (i-- && fgets(buf, sizeof(buf), fp)) {
			printf("%s", buf);
		}
		fclose(fp);
	}
}


int talk_query_user(int ofd, char *userid_toquery)
{
	ACCT  acctoq;
	UTMP* up;
	char  buf[1024];
	int   i;
	FILE* fp;
	char  rbuf[512];

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

#ifdef DEBUG_TALK_QUERY_USER
	fprintf(stderr, "DEBUG(%s,%d):begin talk_query_user\n",
	        __FILE__, __LINE__);
#endif /* DEBUG_TALK_QUERY_USER */

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	acct_load(&acctoq, userid_toquery);

#ifdef DEBUG_TALK_QUERY_USER
	fprintf(stderr, "DEBUG(%s,%d):load acct:userno: %d\n",
	        __FILE__, __LINE__, acctoq.userno);
#endif /* DEBUG_TALK_QUERY_USER */

	up = (acctoq.lastlogin < time(0) - 6 * 3600) ? 0 :
	                                               utmp_find(acctoq.userno);

#ifdef DEBUG_TALK_QUERY_USER
	fprintf(stderr, "DEBUG(%s,%d):get up:%p\n", __FILE__, __LINE__, up);
#endif /* DEBUG_TALK_QUERY_USER */

	sprintf(buf, "MRR-RESULT:talk_query_user\n"
	             "USERID:%s\n"
	             "USERNAME:%s\n"
	             "NUM-LOGINS:%d\n"
	             "NUM-POSTS:%d\n"
	             "ACCOUNT-VALID:%s\n"
	             "LAST-LOGIN:%s\n"
	             "LAST-FORM:%s\n"
	             "MODE:%s\n"
	             "NEW-MAIL:%s\n",
	             acctoq.userid,
	             acctoq.username,
	             acctoq.numlogins,
	             acctoq.numposts,
	             ((acctoq.userlevel & PERM_VALID) ? "YES" : "NA"),
	             Ctime(&(acctoq.lastlogin)),
	             acctoq.lasthost,
	             (up && (HAS_PERM(PERM_SEECLOAK) || !(up->ufo & UFO_CLOAK))) ?
	                 bmode(up, 1) : "���b���W",
	             (m_query(acctoq.userid) ? "YES" : "NA"));
	write(ofd, buf, strlen(buf));


#if	defined(REALINFO) && defined(QUERY_REALNAMES)

	if (HAS_PERM(PERM_BASIC)) {
		sprintf(buf, "REAL-NAME:%s\n", acctoq.realname);
		write(ofd, buf, strlen(buf));
	}

#endif	/* REALINFO && QUERY_REALNAMES */

    usr_fpath(rbuf, acctoq.userid, fn_plans);
    if (fp = fopen(rbuf, "r")) {
        i = MAXQUERYLINES;
        while (i-- && fgets(rbuf, sizeof(rbuf), fp)) {
			if (i < (MAXQUERYLINES - 1)) {
				write(ofd, "CONTINUE:", strlen("CONTINUE:"));
			}
			else {
				write(ofd, "NOTE:", strlen("NOTE:"));
			}
            sprintf(buf, "%s", rbuf);
			write(ofd, buf, strlen(buf));
        }
        fclose(fp);
    }

	write(ofd, "MRR-END:\n", strlen("MRR-END:\n"));

	return 0;
}


