/*
 *  $Id: brd_note_main.c,v 1.2 2000/09/30 08:05:11 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 2) {
		printf("Usage: %s <brd-id>\n", argv[0]);
		return 0;
	}

	if ((ret = brd_note(fileno(stdout), argv[1])) < 0) {
		fprintf(stderr, "brd_note error(%d).\n", ret);
	}

	return 0;
}

