<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�B�ͦW��");

$SNOW_PAGE_TITLE = "�B�ͦW��";
$SNOW_PAGEAREA_MAIN = "talk_pal_list.m.php";
$SNOW_PAGEAREA_FUNC = "talk_pal_list.f.php";

include("bone.php");

?>