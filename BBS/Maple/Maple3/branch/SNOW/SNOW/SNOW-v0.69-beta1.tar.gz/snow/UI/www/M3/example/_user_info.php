<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();

SESSIONcache("sUserID");
SESSIONcache("sUserName");

$mrr = array(
	"user_info_setup" => array(
		0 => array(
			"MRR-SID" => array(0 => session_id()),
			"PASSWD" => array(0 => $iPassword),
			"NEW-USERNAME" => array(0 => $iUserName),
			"NEW-REALNAME" => array(0 => $iRealName),
			"NEW-ADDRESS" => array(0 => $iAddress)
		)
	)
);
$result = MRRquery($mrr);

$goPage = HISTORYget(0);
$redirect = sprintf("Location: %s", $goPage["URI"]);
header($redirect);
exit();

?>