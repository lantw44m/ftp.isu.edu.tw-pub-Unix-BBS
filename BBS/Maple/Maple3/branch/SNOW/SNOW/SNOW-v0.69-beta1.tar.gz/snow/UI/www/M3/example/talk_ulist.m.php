<SCRIPT LANGUAGE="JavaScript">
<!--

<?php

$max = $result["talk_ulist_max"][0]["MAX"][0];
debug_print($max);

?>

// ��Ĥ@��
function pg2first()
{
	document.fPageChanger.iPageTop.value = "1";
	document.fPageChanger.submit();
}

// ��W�@��
function pg2prev()
{
	<?php if ($iPageTop > $iPageSize) { ?>
	document.fPageChanger.iPageTop.value = <?php
	$prevPage = $iPageTop - $iPageSize;
	printf("\"%d\"", $iPageTop - $iPageSize);
	?>;
	<?php } ?>
	document.fPageChanger.submit();
}

// ��U�@��
function pg2next()
{
	<?php if (($max - $iPageTop) > $iPageSize) { ?>
	document.fPageChanger.iPageTop.value = <?php
	$nextPage = $iPageTop + $iPageSize;
	printf("\"%d\"", $iPageTop + $iPageSize);
	?>;
	<?php } ?>
	document.fPageChanger.submit();
}

// ��̥���
function pg2last()
{
	document.fPageChanger.iPageTop.value = <?php
	printf("\"%d\"", floor($max / $iPageSize) * $iPageSize + 1);
	?>;
	document.fPageChanger.submit();
}

function pg2go()
{
	document.fPageChanger.iPageTop.value = document.fPageChanger.iDirectGo.options[document.fPageChanger.iDirectGo.selectedIndex].value;
	document.fPageChanger.submit();
}

//-->
</SCRIPT>
<FORM METHOD="POST" NAME="fPageChanger" ACTION="talk_ulist.php">
	<INPUT TYPE="hidden" NAME="iPageTop" VALUE="<?php echo $iPageTop; ?>">
	<INPUT TYPE="hidden" NAME="iPageSize" VALUE="<?php echo $iPageSize; ?>">
	<P>�ƧǼҦ��G
		<SELECT NAME="iSortMethod" onChange="document.fPageChanger.iSortMethod2.selectedIndex = document.fPageChanger.iSortMethod.selectedIndex;">
			<OPTION VALUE="RANDOM" SELECTED>���N</OPTION>
			<OPTION VALUE="ID">�N��</OPTION>
			<OPTION VALUE="FROM">�ӷ�</OPTION>
			<OPTION VALUE="MODE">�ʺA</OPTION>
			<OPTION VALUE="FRIEND">�n��</OPTION>
		</SELECT>
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo" onChange="document.fPageChanger.iDirectGo2.selectedIndex = document.fPageChanger.iDirectGo.selectedIndex;">
		<?php

		for ($i = 0; $i < ceil($max / $iPageSize); ++$i) {
			printf("<OPTION VALUE=\"%d\"%s>%d</OPTION>\n",
			       $iPageSize * $i + 1,
				   ((($iPageSize * $i + 1) == $iPageTop) ? " SELECTED" : ""),
				   $i + 1);
		}
		
		?>
		</SELECT>
		��
		<INPUT TYPE="button" VALUE="Go" onClick="pg2go();">
	</P>
	<TABLE WIDTH="100%" BORDER="1">
		<TR> 
			<TH>�s��</TH>
			<TH>C</TH>
			<TH>P</TH>
			<TH>�N��</TH>
			<TH>�ʺ�</TH>
			<TH>�G�m</TH>
			<TH>�ʺA</TH>
			<TH>���m</TH>
		</TR>
		<?php

		$ulist = $result["talk_ulist"];
		printf("<!-- %s -->\n", serialize($ulist));

		for ($i = 0; $i < count($ulist); ++$i) {
			printf("<TR>\n");
			printf("<TD>%d <INPUT TYPE=\"radio\" NAME=\"iItem\" VALUE=\"%s\"></TD>\n",
			       $iPageTop + $i, $ulist[$i]["PID"][0]);
			printf("<TD>*</TD>\n");
			printf("<TD>&nbsp;</TD>\n");
			printf("<TD>%s</TD>\n",
			       query_user_link($ulist[$i]["USERID"][0], $ulist[$i]["USERID"][0]));
			printf("<TD>%s</TD>\n", $ulist[$i]["USERNAME"][0]);
			printf("<TD>%s</TD>\n", $ulist[$i]["FROM"][0]);
			printf("<TD>%s</TD>\n", $ulist[$i]["MODE"][0]);
			printf("<TD>%s</TD>\n", $ulist[$i]["IDLE-TIME"][0]);
			printf("</TR>\n");
		}

		?>
	</TABLE>
	<P>�ƧǼҦ��G 
		<SELECT NAME="iSortMethod2" onChange="document.fPageChanger.iSortMethod.selectedIndex = document.fPageChanger.iSortMethod2.selectedIndex;">
			<OPTION VALUE="RANDOM" SELECTED>���N</OPTION>
			<OPTION VALUE="ID">�N��</OPTION>
			<OPTION VALUE="FROM">�ӷ�</OPTION>
			<OPTION VALUE="MODE">�ʺA</OPTION>
			<OPTION VALUE="FRIEND">�n��</OPTION>
		</SELECT>
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo2" onChange="document.fPageChanger.iDirectGo.selectedIndex = document.fPageChanger.iDirectGo2.selectedIndex;">
		<?php

		for ($i = 0; $i < ceil($max / $iPageSize); ++$i) {
			printf("<OPTION VALUE=\"%d\"%s>%d</OPTION>\n",
			       $iPageSize * $i + 1,
				   ((($iPageSize * $i + 1) == $iPageTop) ? " SELECTED" : ""),
				   $i + 1);
		}
		
		?>
		</SELECT>
		��
		<INPUT TYPE="button" VALUE="Go" onClick="pg2go();">
	</P>
</FORM>
<SCRIPT LANGUAGE="JavaScript">
<!--

function selectedRadio()
{
	var i;
	var o;

	for (i = 0; i < document.fPageChanger.iItem.length; ++i) {
		if (document.fPageChanger.iItem[i].checked) {
			return document.fPageChanger.iItem[i];
		}
	}
	return false;
}

function sendMessage()
{
	var o = selectedRadio();

	if (o != false) {
		alert(o.value);
		document.fMessagePack.iToPID.value = o.value;
		return true;
	}
	return false;
}

//-->
</SCRIPT>
<FORM METHOD="POST" NAME="fMessagePack" ACTION="_talk_sendmsg.php" onSubmit="return sendMessage();">
	<INPUT TYPE="hidden" NAME="iToPID" VALUE="">
	�T�����e�G<INPUT TYPE="text" NAME="iMessage" VALUE="">
	<INPUT TYPE="submit" VALUE="�e�X">
</FORM>