<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("��ذ�");

$SNOW_PAGE_TITLE = "��ذ�";
$SNOW_PAGEAREA_MAIN = "gem.m.php";
$SNOW_PAGEAREA_FUNC = "gem.f.php";

include("bone.php");

?>