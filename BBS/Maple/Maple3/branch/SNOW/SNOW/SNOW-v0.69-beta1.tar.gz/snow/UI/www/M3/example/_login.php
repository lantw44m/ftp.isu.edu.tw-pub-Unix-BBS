<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();

SESSIONcache("sUserID");
SESSIONcache("sUserName");

/* logout first */
$mrr = array(
	"bbs_logout" => array(
		0 => array(
			"MRR-SID" => array(0 => session_id())
		)
	)
);
$result = MRRquery($mrr);

// now let's login.
$mrr = array(
	"bbs_login" => array(
		0 => array(
			"MRR-SID" => array(0 => session_id()),
			"USERID" => array(0 => $iUserID),
			"PASSWORD" => array(0 => $iPassword),
			"REMOTE-USERNAME" => array(0 => "N/A"),
			"FROM-HOST" => array(0 => $GLOBALS["REMOTE_ADDR"]),
			"FROM-IP" => array(0 => $GLOBALS["REMOTE_ADDR"])
		)
	)
);
$result = MRRquery($mrr);
$GLOBALS["sUserID"] = $result["bbs_login"][0]["USERID"][0];
$GLOBALS["sUserName"] = $result["bbs_login"][0]["USERNAME"][0];

$goPage = HISTORYget(0);
$redirect = sprintf("Location: %s", $goPage["URI"]);
header($redirect);
exit();

?>