/*
 * $Id: mail_first_unread_mail_main.c,v 1.3 2000/10/05 20:59:52 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	fd;
	int	ret;

	if (argc != 2) {
		printf("Usage: %s <user-id>\n", argv[0]);
		return 0;
	}

	fd = fileno(stdout);

	if ((ret = mail_first_unread_mail(fd, argv[1])) != 0) {
		fprintf(stderr, "mail_first_unread_mail error(%d).\n", ret);
	}

	return 0;
}

