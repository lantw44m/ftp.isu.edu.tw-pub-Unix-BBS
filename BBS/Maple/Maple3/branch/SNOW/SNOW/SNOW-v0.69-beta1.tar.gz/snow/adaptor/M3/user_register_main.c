/*
 *  $Id: user_register_main.c,v 1.1 2000/10/06 10:28:59 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 7) {
		printf("Usage: %s <session-id> <new-id> <new-password> "
		       "<new-nick> <new-realname> <new-address>\n", argv[0]);
		return 0;
	}

	if ((ret = user_register(fileno(stdout), argv[1], argv[2], argv[3],
	                         argv[4], argv[5], argv[6])) < 0) {
		fprintf(stderr, "user_register error(%d).\n", ret);
	}

	return 0;
}

