/*
 *  $Id: user_setup_email_main.c,v 1.4 2000/10/05 20:59:53 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 3) {
		printf("Usage: %s <session-id> <new-email>\n", argv[0]);
		return 0;
	}

	if ((ret = user_setup_email(fileno(stdout), argv[1], argv[2])) < 0) {
		fprintf(stderr, "user_setup_email error(%d).\n", ret);
	}

	return 0;
}

