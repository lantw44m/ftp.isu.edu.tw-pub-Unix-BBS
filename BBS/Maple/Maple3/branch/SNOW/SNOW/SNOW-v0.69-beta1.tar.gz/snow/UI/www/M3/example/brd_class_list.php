<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�����C��");

/*
 * Required Inputs: iChannel
 */

/*
 * Optional Inputs: iPageTop, iPageSize, iSortMethod
 */

if (!isset($iMode) || (strlen($iMode) <= 0) || ($iMode < 0) || ($iMode > 2)) {
	$iMode = 0;
}

$mrr = array(
	"brd_class_list" => array(
		0 => array(
			"USERID" => array(0 => "JeffHung"),
			"CHANNEL" => array(0 => $iChannel),
			"PAGETOP" => array(0 => $iPageTop),
			"PAGESIZE" => array(0 => $iPageSize),
			"MODE" => array(0 => $iSortMethod)
		)
	)
);

$result = MRRquery($mrr);
//printf("<!-- %s -->\n", serialize($result["brd_post_num"]));

$SNOW_PAGE_TITLE = "�����C��";
$SNOW_PAGEAREA_MAIN = "brd_class_list.m.php";
$SNOW_PAGEAREA_FUNC = "brd_class_list.f.php";

include("bone.php");

?>