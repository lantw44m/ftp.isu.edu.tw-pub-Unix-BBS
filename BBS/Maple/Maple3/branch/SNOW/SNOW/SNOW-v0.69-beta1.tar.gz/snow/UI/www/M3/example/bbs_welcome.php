<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�w����{");

$SNOW_PAGE_TITLE = "�w����{";
$SNOW_PAGEAREA_MAIN = "bbs_welcome.m.php";
$SNOW_PAGEAREA_FUNC = "bbs_welcome.f.php";

include("bone.php");

?>