/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: talk_paldel.c,v 1.3 2000/09/30 16:18:13 jeffhung Exp $
 */

#undef DEBUG_TALK_PALDEL

#include "bbs.h"
#include "dao.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "w3if_session.h"
#include <string.h>
#include <sys/param.h>
#include <unistd.h>
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */

#ifdef AS_ARNI_MODULE

int mod_talk_paldel(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return talk_paldel(ofd, sid, parg->args[0].s);
}

#endif /* AS_ARNI_MODULE */

#if 0 /* JeffHung.20000930: already defined in w3ifglobal.c */

int is_samepal(int userno, PAL *pal)
{
	return (userno == pal->userno);
}

#endif /* 0 */

#ifdef HAVE_ALOHA

int cmpbmw(BMW *benz)
{
	return benz->recver == cuser.userno;
}

#endif /* HAVE_ALOHA */

int talk_paldel(int ofd, char *sid, char *palid)
{
	W3IF_SESSENTRY *psess;
	ACCT           palacct;
	int            userno;
	PAL            pal;
	char           fpath[MAXPATHLEN];
	int            palno;

	chdir(BBSHOME);

	write(ofd, "MRR-RESULT:talk_paldel\n", strlen("MRR-RESULT:talk_paldel\n"));

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	if (!(psess = w3ifsession_get(sid))) {
		write(ofd, "RESULT:no such user\nMRR-END:\n",
		      strlen("RESULT:no such user\nMRR-END:\n"));
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;

	acct_load(&cuser, cutmp->userid);

	if (!cuser.userlevel) {
		write(ofd, "RESULT:no permission\nMRR-END:\n",
		      strlen("RESULT:no permission\nMRR-END:\n"));
		return 999; /* no permission */
	}

	acct_load(&palacct, palid);
	pal_cache(); /* JeffHung.20000904: load pal cache first */

#ifdef DEBUG_TALK_PALDEL

	fprintf(stderr, "DEBUG(%s,%d): 1st pal_cache()\n", __FILE__, __LINE__);

#endif /* DEBUG_TALK_PALDEL */

	/* pal_del() */

	userno = palacct.userno;
	if (userno <= 0) {
		write(ofd, "RESULT:userno error\nMRR-END:\n",
		      strlen("RESULT:userno error\nMRR-END:\n"));
		return -999; /* userno error */
	}

	usr_fpath(fpath, cuser.userid, FN_PAL);
	if (!(palno = rec_search(fpath, &pal, sizeof(PAL), is_samepal, userno))) {
		write(ofd, "RESULT:no such pal\nMRR-END:\n",
		      strlen("RESULT:no such pal\nMRR-END:\n"));
		return -999; /* no such pal */
	}
#if 0 /* JeffHung.20000904: rec_search() �N��Ū�����\�� */
	rec_get(fpath, &pal, sizeof(PAL), palno);
#endif /* 0 */

#ifdef DEBUG_TALK_PALDEL

	fprintf(stderr, "DEBUG(%s,%d): get pal record\n", __FILE__, __LINE__);

#endif /* DEBUG_TALK_PALDEL */

#ifdef HAVE_ALOHA

	if (!(pal.ftype & PAL_BAD)) {
		/* we are good friend */
		usr_fpath(fpath, palacct.userid, FN_FRIEND_BENZ);
		rec_del(fpath, sizeof(BMW), 0, cmpbmw, NULL);
	}

#endif /* HAVE_ALOHA */

	usr_fpath(fpath, cuser.userid, FN_PAL);

#ifdef DEBUG_TALK_PALDEL

	fprintf(stderr, "DEBUG(%s,%d): before 2nd pal_cache()\n",
	        __FILE__, __LINE__);

#endif /* DEBUG_TALK_PALDEL */

	if (!rec_del(fpath, sizeof(PAL), palno - 1, NULL, NULL)) {
		pal_cache();
	}

	write(ofd, "RESULT:OK\nMRR-END:\n",
	      strlen("RESULT:OK\nMRR-END:\n"));

	return 0;
}

