<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�\Ū��ؤ��e");

$SNOW_PAGE_TITLE = "�\Ū��ؤ��e";
$SNOW_PAGEAREA_MAIN = "gem_read_article.m.php";
$SNOW_PAGEAREA_FUNC = "gem_read_article.f.php";

include("bone.php");

?>