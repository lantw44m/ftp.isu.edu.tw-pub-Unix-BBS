<?php

$rmail = $result["mail_readmail"][0];

?>
<FORM METHOD="post" ACTION="">
	<P>�H�H�H�G<A HREF="talk_query_user.php"><?php echo $sUserID ?></A> (<?php echo $sUserName; ?>)<BR>
		���H�H�G 
		<INPUT TYPE="text" NAME="iTo" VALUE="<?php echo $rmail["AUTHOR-ID"][0] ?>">
		<BR>
		�峹���D�G 
		<INPUT TYPE="text" NAME="iSubject" VALUE="<?php
		
		if (substr($rmail["SUBJECT"][0], 0, 4) != "Re: ") {
			echo "Re: ";
		}
		echo $rmail["SUBJECT"][0];

		?>">
	</P>
	<P> 
		<TEXTAREA NAME="iBody" COLS="80" ROWS="24"><?php

		printf("�� �ޭz�m%s (%s)�n���ʨ��G\n", $rmail["AUTHOR-ID"][0], $rmail["AUTHOR-NAME"][0]);
		for ($i = 0; $i < count($rmail["BODY"]); ++$i) {
			if (chop($rmail["BODY"][$i]) == "") {
				continue; // skip empty line
			}
			printf("&gt; %s\n", htmlspecialchars($rmail["BODY"][$i]));
		}
		
		?>
		</TEXTAREA>
	</P>
	<P> 
		<INPUT TYPE="BUTTON" NAME="Submit4" VALUE="�H�X�H��">
	</P>
</FORM>