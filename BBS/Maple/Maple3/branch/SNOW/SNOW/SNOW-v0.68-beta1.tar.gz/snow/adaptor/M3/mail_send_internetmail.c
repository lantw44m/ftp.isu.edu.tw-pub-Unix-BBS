/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: mail_send_internetmail.c,v 1.3 2000/09/30 16:18:13 jeffhung Exp $
 */

#undef	DEBUG_MAIL_SEND_INTERNETMAIL

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */

#ifdef AS_ARNI_MODULE

int mod_mail_send_internetmail(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return mail_send_internetmail(ofd, parg->args[0].s, parg->args[1].s,
	                              parg->args[2].s, parg->args[3].s);
}

#endif /* AS_ARNI_MODULE */


int mail_send_internetmail(int ofd, char *fromid, char *toaddr, char *subject,
#ifdef AS_ARNI_MODULE
                           char *body)
#else /* AS_ARNI_MODULE */
                           char *fname)
#endif /* AS_ARNI_MODULE */
{
	time_t	now;
	char	tmpfpath[MAXPATHLEN];
	FILE	*tmpfp;
	FILE	*bodyfp;
	char	buf[GENERAL_BUFSIZE];

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

	/* JeffHung.20000731: prevent buffer overflow */
	if (strlen(fromid) > IDLEN) {
		fromid[IDLEN] = 0;
	}

	if (!(fromid = w3if_getCorrectUserID(fromid))) {
		return -999; /* no such user */
	}

#ifdef	DEBUG_MAIL_SEND_INTERNETMAIL
	fprintf(stderr, "DEBUG(%s:%d): acct_load\n", __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_SEND_INTERNETMAIL */
	acct_load(&cuser, fromid);
#ifdef	DEBUG_MAIL_SEND_INTERNETMAIL
	fprintf(stderr, "DEBUG(%s:%d): acct_load done.\n", __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_SEND_INTERNETMAIL */

	tmpnam(tmpfpath);

#ifdef	DEBUG_MAIL_SEND_INTERNETMAIL
	fprintf(stderr, "DEBUG(%s:%d): tmpfpath: %s\n", __FILE__, __LINE__, tmpfpath);
#endif	/* DEBUG_MAIL_SEND_INTERNETMAIL */

	if (!(tmpfp = fopen(tmpfpath, "w"))) {
		return -999; /* can not create temp file */
	}
	time(&now);
	fprintf(tmpfp, "�@��: %s (%s)\n"
	               "���D: %s\n"
	               "�ɶ�: %s\n",
	        cuser.userid, cuser.username, subject, ctime(&now));
#ifdef AS_ARNI_MODULE
	fprintf(tmpfp, "%s", body);
#else /* AS_ARNI_MODULE */
	if (!(bodyfp = fopen(fname, "r"))) {
		fclose(tmpfp);
		return -999; /* can not open mail body file */
	}
	while (fgets(buf, GENERAL_BUFSIZE, bodyfp)) {
		fprintf(tmpfp, "%s", buf);
	}
	fclose(bodyfp);
#endif /* AS_ARNI_MODULE */
	fclose(tmpfp);

#ifdef	DEBUG_MAIL_SEND_INTERNETMAIL
	fprintf(stderr, "DEBUG(%s:%d): bsmtp\n", __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_SEND_INTERNETMAIL */
	if (bsmtp(tmpfpath, subject, toaddr, 0) < 0) {
		return -999; /* can not send mail */
	}
#ifdef	DEBUG_MAIL_SEND_INTERNETMAIL
	fprintf(stderr, "DEBUG(%s:%d): bsmtp done.\n", __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_SEND_INTERNETMAIL */

	unlink(tmpfpath);

	return 0; /* success */
}

