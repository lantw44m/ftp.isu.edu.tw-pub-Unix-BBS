<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�d����");

$SNOW_PAGE_TITLE = "�d����";
$SNOW_PAGEAREA_MAIN = "user_note.m.php";
$SNOW_PAGEAREA_FUNC = "user_note.f.php";

include("bone.php");

?>