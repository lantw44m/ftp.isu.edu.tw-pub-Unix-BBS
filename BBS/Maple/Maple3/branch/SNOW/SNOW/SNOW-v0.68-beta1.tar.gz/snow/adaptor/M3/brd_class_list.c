/*
 *  $Id: brd_class_list.c,v 1.2 2000/09/30 08:05:11 jeffhung Exp $
 */

/* -------------------------------------------------------------- */
/*    Class/Board �����C��                                        */
/* -------------------------------------------------------------- */

#undef DEBUG_BRD_CLASS_LIST

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */


#ifdef AS_ARNI_MODULE

int mod_brd_class_list(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return brd_class_list(ofd, parg->args[0].s, parg->args[1].i,
	                      parg->args[2].i, parg->args[3].i, parg->args[4].i);
}

#endif /* AS_ARNI_MODULE */


char          brd_bits[MAXBOARD];
static time_t brd_visit[MAXBOARD]; /* �̪��s���ɶ� */
static char   *class_img;
static XO     board_xo;

static int  class_flag;
static char *str_sysop = "sysop";

typedef struct BoardReadingHistory {
	time_t bstamp; /* �إ߬ݪO���ɶ�, unique */
                   /* Thor.brh_tail*/
	time_t bvisit; /* �W���\Ū�ɶ� */
                   /* Thor.980902:�S�Ψ�? */
                   /* Thor.980904:��Ū�ɩ�W��Ū���ɶ�, ��Ū�ɩ� bhno */
	int    bcount; /* Thor.980902:�S�Ψ�? */
                   /* Thor.980902:���ۤv�ݪ� */
	/*
	 * time_t {final, begin} / {final | BRH_SIGN}
	 */
	/* Thor.980904:����: BRH_SIGN�N��final begin �ۦP */
	/* Thor.980904:����: �Ѥj��p�ƦC,�s��wŪinterval */
} BRH;

#define BRH_EXPIRE (180) /* Thor.980902:����:�O�d�h�֤� */
#define BRH_MAX    (200) /* Thor.980902:����:�C���̦h���X�Ӽ��� */
#define BRH_PAGE   (2048) /* Thor.980902:����:�C���h�t�q, �Τ���F */
#define BRH_MASK   (0x7fffffff) /* Thor.980902:����:�̤j�q��2038�~1�뤤 */
#define BRH_SIGN   (0x80000000) /* Thor.980902:����:zap����final�M�� */
#define BRH_WINDOW (sizeof(BRH) + sizeof(time_t) * BRH_MAX * 2)

static int    *brh_base; /* allocated memory */
static int    *brh_tail; /* allocated memory */
static int    brh_size; /* allocated memory size */
static time_t brh_expire;


#if 0 /* JeffHung.20000929: already defined in cache/board_lib.c */

int bstamp2bno(time_t stamp)
{
  BRD *brd;
  int bno, max;

  bno = 0;
  brd = bshm->bcache;
  max = bshm->number;
  for (;;)
  {
    if (stamp == brd->bstamp)
      return bno;
    if (++bno >= max)
      return -1;
    brd++;
  }
}

#endif /* 0 */
static inline int
is_bm(list)
  char *list;                   /* �O�D�GBM list */
{
  int cc, len;
  char *userid;

  len = strlen(userid = cuser.userid);
  do
  {
    cc = list[len];
    if ((!cc || cc == '/') && !str_ncmp(list, userid, len))
    {
      return 1;
    }
    while (cc = *list++)
    {
      if (cc == '/')
        break;
    }
  } while (cc);

  return 0;
}

static inline int
Ben_Perm(bhdr, ulevel)
  BRD *bhdr;
  usint ulevel;
{
  usint readlevel, postlevel, bits;
  char *blist, *bname;

  bname = bhdr->brdname;
  if (!*bname)
    return 0;

  if (!str_cmp(bname, DEFAULT_BOARD))
    return (BRD_R_BIT | BRD_W_BIT);

  bits = 0;

  readlevel = bhdr->readlevel;
  if (!readlevel || (readlevel & ulevel))
  {
    bits = BRD_R_BIT;

    if (ulevel & PERM_POST)
    {
      postlevel = bhdr->postlevel;
      if (!postlevel || (postlevel & ulevel))
        bits |= BRD_W_BIT;
    }
  }

  /* (moderated) ���K�ݪO�G�ֹ�ݪO���n�ͦW�� */

#ifdef HAVE_MODERATED_BOARD
  if (readlevel == PERM_SYSOP)
  {
    extern int bm_belong();
#if 0
    return (bm_belong(bname));
#endif
    bits = bm_belong(bname);  /* Thor.980813: �ﯵ�K�ݪ��Ө�, �O���s�P�_�� */
  }
#endif

  /* Thor.980813: ����: �S�O�� BM �Ҷq, bm ���Ӫ����Ҧ��v�� */

  blist = bhdr->BM;
#if 0
  if (blist[0] <= ' ')
    return bits;
#endif

#if 0
  if ((ulevel & PERM_BM) && is_bm(blist))
#endif
  if ((ulevel & PERM_BM) && blist[0] > ' ' && is_bm(blist))
    return (BRD_R_BIT | BRD_W_BIT | BRD_X_BIT);

  return bits;
}

static inline void brh_load(void)
{
  BRD *brdp, *bend;
  usint ulevel;
  int n, cbno;
  char *bits;

  int size, *base;
  time_t expire, *bstp;
  char fpath[64];

  ulevel = cuser.userlevel;
  n = (ulevel & PERM_ALLBOARD) ? (BRD_R_BIT | BRD_W_BIT | BRD_X_BIT) : 0;
  memset(bits = brd_bits, n, sizeof(brd_bits));
  memset(bstp = brd_visit, 0, sizeof(brd_visit));

  if (n == 0)
  {
    brdp = bshm->bcache;
    bend = brdp + bshm->number;

    do
    {
      *bits++ = Ben_Perm(brdp, ulevel);
    } while (++brdp < bend);
  }

  /* --------------------------------------------------- */
  /* �N .BRH ���J memory				 */
  /* --------------------------------------------------- */

  size = 0;
  cbno = -1;
  brh_expire = expire = time(0) - BRH_EXPIRE * 86400;

  if (ulevel)
  {
    struct stat st;

    usr_fpath(fpath, cuser.userid, FN_BRH);
    if (!stat(fpath, &st))
      size = st.st_size;
  }

  /* --------------------------------------------------- */
  /* �h�O�d BRH_WINDOW ���B�@�Ŷ�			 */
  /* --------------------------------------------------- */

  /* brh_size = n = ((size + BRH_WINDOW) & -BRH_PAGE) + BRH_PAGE; */
  brh_size = n = size + BRH_WINDOW;
  brh_base = base = (int *) malloc(n);

  if (size && ((n = open(fpath, O_RDONLY)) >= 0))
  {
    int *head, *tail, *list, bstamp, bhno;

    size = read(n, base, size);
    close(n);


    /* compact reading history : remove dummy/expired record */

    head = base;
    tail = (int *) ((char *) base + size);
    bits = brd_bits;
    while (head < tail)
    {
      bstamp = *head;

      if (bstamp & BRH_SIGN)	/* zap */
      {
	bstamp ^= BRH_SIGN;
	bhno = bstamp2bno(bstamp);
	if (bhno >= 0)
	{
#if 1     /* Thor.991121: NOZAP��, ���|�X�{ */
          brdp = bshm->bcache + bhno;
          if (!(brdp->battr & BRD_NOZAP))
#endif       	
	  bits[bhno] |= BRD_Z_BIT;
	}
	head++;
	continue;
      }

      bhno = bstamp2bno(bstamp);
      list = head + 2;
      n = *list;
      size = n + 3;

      /* �o�ӬݪO�s�b�B�S���Q zap ���B�i�H read */

      if (bhno >= 0 && (bits[bhno] & BRD_R_BIT))
      {
	bits[bhno] |= BRD_H_BIT;/* �w���\Ū�O�� */
	bstp[bhno] = head[1];	/* �W���\Ū�ɶ� */
	cbno = bhno;

	if (n > 0)
	{

	  list += n;   /* Thor.980904: ����: �̫�@��tag */

	  do
	  {
	    bhno = *list;
	    if ((bhno & BRH_MASK) > expire)
	      break;

	    if (!(bhno & BRH_SIGN))
	    {
	      if (*--list > expire)
		break;
	      n--;
	    }

	    list--;
	    n--;
	  } while (n > 0);

	  head[2] = n;
	}

	n = n * sizeof(time_t) + sizeof(BRH);
	if (base != head)
	  memcpy(base, head, n);
	base = (int *) ((char *) base + n);
      }
      head += size;
    }
  }

  *base = 0;
  brh_tail = base;

}

static int
class_load(xo)
  XO *xo;
{
  short *cbase, *chead, *ctail;
  int chn;			/* ClassHeader number */
  int pos, max, val, zap;
  BRD *brd;
  char *bits;

  if (!class_img)
    return 0;          

  chn = CH_END - xo->key;

  cbase = (short *) class_img;
  chead = cbase + chn;

  pos = chead[0] + CH_TTLEN;
  max = chead[1];

  chead = (short *) ((char *) cbase + pos);
  ctail = (short *) ((char *) cbase + max);

  max -= pos;

  if (cbase = (short *) xo->xyz)
    cbase = (short *) realloc(cbase, max);
  else
    cbase = (short *) malloc(max);
  xo->xyz = (char *) cbase;

  max = 0;
  brd = bshm->bcache;
  bits = brd_bits;
  zap = (class_flag & BFO_YANK) ? 0 : BRD_Z_BIT;

  do
  {
    chn = *chead++;
    if (chn >= 0)
    {
      val = bits[chn];
/* ----------------------------------------------- */
/* Arlo.20000716: �ڪ��̷RMode(BFO_ENJOY)          */
/* ----------------------------------------------- */      
#ifdef MY_FAVORITE

      if( class_flag & BFO_ENJOY ) {
        if(!(val & BRD_R_BIT) || !(val & BRD_F_BIT) || !(brd[chn].brdname[0]) )
          continue;
      }
      else 

#endif      
      {
      if (!(val & BRD_R_BIT) || (val & zap) || !(brd[chn].brdname[0]))
	continue;
      }	
    } /* end of if(chn >= 0) */

    max++;
    *cbase++ = chn;
  } while (chead < ctail);

  xo->max = max;
  if (xo->pos >= max)
    xo->pos = xo->top = 0;

  return max;
}


void init_class(void)
{
  int fsize;
  
  brh_load();

  class_img = f_img(CLASS_IMGFILE, &fsize);

  if (class_img == NULL)
  {
    blog("CACHE", "class.img");
  }

  if (!cuser.userlevel)		/* guest yank all boards */
  {
    class_flag = BFO_YANK;
  }
  else
  {
    class_flag = cuser.ufo & UFO_BRDNEW;
  }

  board_xo.key = CH_END;
  class_load(&board_xo);

}

static int class_body(int ofd, XO *xo, int top, int range)
{
#ifdef MY_FAVORITE
	char  ch_flag;
#endif /* MY_FAVORITE */
	char  buf[GENERAL_BUFSIZE];
	char  *img;
	char  *bits;
	short *chp;
	BRD   *bcache;
	int   n;
	int   cnt;
	int   max;
	int   brdnew;

	img = class_img;

	bcache = bshm->bcache;
	brdnew = class_flag & UFO_BRDNEW;
	bits = brd_bits;

	max = xo->max;
	cnt = top - 1;
	chp = (short*) xo->xyz + cnt;
	n = 0;
	do {
		if (cnt < max) {
			int  chn;
			char *str;

			++cnt;
			chn = *chp++;

			write(ofd, "MRR-RESULT:brd_class_list\n",
			      strlen("MRR-RESULT:brd_class_list\n"));

			if (chn >= 0) {
				/* JeffHung.20000929: is board */
				BRD *brd;
				int num;

				brd = bcache + chn;

				if (brdnew) {
					int         fd;
					int         fsize;
					char        folder[64];
					struct stat st;

					brd_fpath(folder, brd->brdname, fn_dir);
					if ((fd = open(folder, O_RDONLY)) >= 0) {
						fstat(fd, &st);

						if (st.st_mtime > brd->btime) {
							/* 45 �������������ˬd */
							brd->btime = time(0) + 5;
							if ((fsize = st.st_size) >= sizeof(HDR)) {
								brd->bpost = fsize / sizeof(HDR);
								lseek(fd, fsize - sizeof(HDR), SEEK_SET);
								read(fd, &brd->blast, sizeof(time_t));
							}
							else {
								brd->blast = brd->bpost = 0;
							}
						}

						close(fd);
					}
					num = brd->bpost;
					str = brd->blast > brd_visit[chn] ?
					                   "\033[1;33m��\033[m" : "��";
					/* lkchu.981201: �W����M�� :p */                                              
				}
				else {
					num = cnt;
					str = "  ";
				}
#ifdef MY_FAVORITE
				if (bits[chn] & BRD_F_BIT) {
					ch_flag = '=';
				}
				else if(bits[chn] & BRD_Z_BIT) {
					ch_flag = '-';
				}
				else {
					ch_flag = ' ';
				}
#if 0
				printf("%6d%s%c%-13s%-42s%c %.13s\n",
				       num, str, ch_flag, brd->brdname, brd->title,
				       brd->bvote ? 'V' : ' ', brd->BM);
#endif /* 0 */

#else /* MY_FAVORITE */

#if 0
				printf("%6d%s%c%-13s%-42s%c %.13s\n",
				       num, str, bits[chn] & BRD_Z_BIT ? '-' : ' ',
				       brd->brdname, brd->title, brd->bvote ? 'V' : ' ',
				       brd->BM);
#endif /* 0 */

#endif /* MY_FAVORITE */

				/*
				 * Arlo.20000731: MRR output
				 */
				snprintf(buf, GENERAL_BUFSIZE,
				         "CHANNEL:%d\n"
				         "TYPE:%s\n"
				         "BRD-NAME:%s\n"
				         "BRD-TITLE:%s\n"
				         "BRD-BM:%s\n"
				         "BRD-VOTE:%s\n"
				         "BRD-BITS:%d\n",
				         chn,
				         "BOARD",
				         brd->brdname,
				         brd->title,
				         brd->BM,
				         brd->bvote ? "VOTE" : "NONE",
				         bits[chn]);
				write(ofd, buf, strlen(buf));                                
			}
			else {
				short *chx;
				char  *class_buf;
				char  *class_name;
				char  *class_title;
				char  ch;
				int   index;
        
				chx = (short*) img + (CH_END - chn);

				class_buf = (char*)malloc(GENERAL_BUFSIZE);
				class_name = (char*)malloc(128 * sizeof(char));
				class_title = (char*)malloc(128 * sizeof(char));

				memset(class_name, 0 , 128);
				memset(class_title, 0, 128);
#if 0
				printf("%6d   %s\n", cnt, img + *chx);
#endif /* 0 */
				snprintf(class_buf, 256, "%s", img + *chx);
        
				for (index = 0, ch = *class_buf; 
				     ch != '/' ; 
				     ch = *(++class_buf), index++) {
					class_name[index] = ch; 
				}

				for (ch = *(++class_buf); ch == ' '; ch = *(++class_buf))
					;
        
				for (index = 0, ch = *class_buf; 
				     ch != 0;
				     ch = *(++class_buf), index++) {
					class_title[index] = ch;
				}

				snprintf(buf, GENERAL_BUFSIZE,
				         "CHANNEL:%d\n"
				         "TYPE:%s\n"
				         "CLASS-NAME:%s\n"
				         "CLASS-TITLE: %s\n",
				         chn,
				         "CLASS",
				         class_name,
				         class_title);
				write(ofd, buf, strlen(buf));                                
			}
		}
	} while (++n < range);

	snprintf(buf, GENERAL_BUFSIZE, "MRR-END:\n");
	write(ofd, buf, strlen(buf));

	return 0;
}

static int Read_Class(int ofd, int chn , int top , int range)
{
  XO xo, *xt;

  xo.pos = xo.top = 0;

  xo.key = chn;
  xo.xyz = NULL;
  if (!class_load(&xo))
  {
    free(xo.xyz);
    return -115;
  }

  return class_body(ofd, &xo , top , range);
}


/*
 * Argument: ofd     : output file descriptor
 *           username: �ϥΪ�ID
 *           channel : ���@�Ӥ����W�D (-2���D�W�D)
 *           top     : �}�l����m
 *           range   : ��top�_��᪺�d��
 *           mode    : ���@��Mode(BFO_NONE/BFO_YANK/BFO_ENJOY)
 *                               ( 0 / 1 / 2 )
 */

int brd_class_list(int ofd, char *username, int channel,
                   int top, int range, int mode)
{
	char userid[IDLEN + 1];

	chdir(BBSHOME);
  
	bshm_init();

	str_lower(userid, username);
	if(acct_load(&cuser, userid ) < 0 ) {
#ifdef DEBUG_BRD_CLASS_LIST
		fprintf(stderr, "acct load failed!\n");
#endif /* DEBUG_BRD_CLASS_LIST */
		return -100;
	}

	init_class();

	if (!class_img) {
#ifdef DEBUG_BRD_CLASS_LIST
		fprintf(stderr, "���w�q���հQ�װ�\n");
#endif /* DEBUG_BRD_CLASS_LIST */
		return -105;
	} /* ���� ���� account �y�X class.img �ΨS�� class�����p */
  
	if ( channel >= 0 ) {
#ifdef DEBUG_BRD_CLASS_LIST
		fprintf(stderr, "������ϰ�w�W��\n");
#endif /* DEBUG_BRD_CLASS_LIST */
		return -110;
	}

	Read_Class(ofd, channel, top, range);

	return 0;
}

