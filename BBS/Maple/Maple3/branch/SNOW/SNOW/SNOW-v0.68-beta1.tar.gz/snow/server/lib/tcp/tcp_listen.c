/*
 * 
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation 
 * bbs, the cross-media distributed communication platform. And it is 
 * developed by Cyberwork Solution in 2000.
 * 
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 * 
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or (at 
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or 
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

#undef DEBUG_TCP_LISTEN

#include "tcp_lib.h"

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

#include "socket_lib.h"
#include "system_lib.h"


int tcp_listen(const char *host, const char *service, socklen_t *addrlenp)
{
	/*
	 *  declare variable;
	 */
	int				listenfd;
	int				n;
	const int		on = 1; /* turn socket option on */
	struct addrinfo	hints;
	struct addrinfo	*res;
	struct addrinfo	*ressave;

	memset(&hints, 0, sizeof(struct addrinfo));

	hints.ai_flags = AI_PASSIVE;
	hints.ai_family = AF_UNSPEC; /* or AF_INET ?? */
	hints.ai_socktype = SOCK_STREAM;

	if ((n = getaddrinfo(host, service, &hints, &res))) {
		sys_err_quit("tcp_listen error for %s, %s: %s",
		             host, service, gai_strerror(n));
	}

	ressave = res; /* save a record */

#ifdef	DEBUG_TCP_LISTEN
	fprintf(stderr, "DEBUG(%s,%d): start listen\n", __FILE__, __LINE__);
#endif	/* DEBUG_TCP_LISTEN */

	do {
		listenfd = sock_socket(res->ai_family, res->ai_socktype,
		                       res->ai_protocol);
		if (listenfd < 0) {
			/* error, must try again */
			continue;
		}

		sock_setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));

		if (sock_bind(listenfd, res->ai_addr, res->ai_addrlen) == 0) {
			break;
		}
		sys_close(listenfd); /* bind error, close & try next one */    
	} while ((res = res->ai_next) != NULL);

	if (res == NULL) {
		sys_error("tcp_listen error for %s, %s", host, service);
	}

	sock_listen(listenfd, LISTENQ);

	if (addrlenp) {
		*addrlenp = res->ai_addrlen; /* return size of protocol address */
	}

	freeaddrinfo(ressave);

	return listenfd;

} 



