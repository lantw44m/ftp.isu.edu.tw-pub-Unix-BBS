/*
 *  $Id: mod_interface.c,v 1.2 2000/09/30 08:05:11 jeffhung Exp $
 */

#include "w3if.h"
#ifdef	HAVE_MODULE

#include "mod_header.h"

int mod_register_module(struct mod_request_table *res_table,
                        struct mod_pool_table *pool)
{
	int	index;

	fprintf(stderr, "start mod_register_module\n");

	for (index = 0; res_table[index].command; ++index)
		;

	pool->table.list = (BBS_Mod_Request_Table *)
	                   calloc(index+1, sizeof(BBS_Mod_Request_Table));
	memcpy(pool->table.list, res_table,
	       index * sizeof(BBS_Mod_Request_Table));

	/* JeffHung.20000814: no return value?? */
}

int mod_unregister_module(BBS_Mod_Pool_Table *pool)
{
	pool->flag = 0;
	return 0;
}

#endif /* HAVE_MODULE */

