/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: w3ifglobal.h,v 1.5 2000/10/04 12:32:27 jeffhung Exp $
 */

#ifndef	W3IFGLOBAL_H_INCLUDED
#define	W3IFGLOBAL_H_INCLUDED

#include "bbs.h"


/*
 *  Global variables for w3if
 */
extern time_t	ap_start;

/* 
 * ���ª�OS�S��INET_ADDRSTRLEN�o��definition 
 */
#ifndef INET_ADDRSTRLEN
#define INET_ADDRSTRLEN 16
#endif /* #ifndef INET_ADDRSTRLEN */

/*
 *  Global variables declared in bbsd.c
 */
extern char	*str_host;
extern char	*str_site;
extern char *str_sysop;
extern char	*fn_dir;
extern char	*fn_acct;
extern char	*fn_plans;
extern char	*fn_note;

extern pid_t currpid;		/* current process ID */
extern char  currboard[IDLEN + 2]; /* name of currently selected board */

#ifdef  HAVE_REGISTER_FORM
extern char	*fn_rform; /* ���U���� */
#endif  /* HAVE_REGISTER_FORM */

/*
 *  Global variables declared in global.h
 */
#if	0	/* JeffHung.2000707: �o�Ǧb src/include/global.h �̳����F */

extern ACCT		cuser;	/* current user structure */
extern time_t	ap_start; /* start time form user login */
extern UTMP*	cutmp; /* current utmp */

#endif	/* 0 */


/*
 *  Global variables declared in cache.c
 */

extern int		ap_semid; /* application's semaphore id */
extern UCACHE*	ushm; /* .UTMP cache */
extern BCACHE*	bshm; /* .BRD cache */
#ifdef	MODE_STAT
extern UMODELOG	modelog;
#endif	/* MODE_STAT */


/*
 *  Global variables declared in mail.c
 */

extern LinkList*	ll_head;	/* head of link list */
extern LinkList*	ll_tail;	/* tail of link list */

struct tagCMBOX {
	XO		mail_xo;
	char	dir[32];
};

extern struct tagCMBOX	cmbox;
extern int	TagNum;

/*
 *  Global variables decalred in xover.c
 */

extern int		TagNum; /* tag's number */
extern TagItem	TagList[TAG_MAX]; /* ascending list */
extern char		xo_pool[]; /* XO's data I/O pool */

#if	0	/* JeffHung.20000714: try to discard this to decouple sources */
extern XZ	xz[];
#endif	/* 0 */

extern char *user_flags[];
extern int  user_flags_num;


extern char *trim_r_newline(char *s);
extern int is_samepal(int userno, PAL *pal);

#endif	/* W3IFGLOBAL_H_INCLUDED */

