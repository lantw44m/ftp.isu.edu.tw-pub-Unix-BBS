<SCRIPT LANGUAGE="JavaScript">
<!--

// ��Ĥ@��
function pg2first()
{
}

// ��W�@��
function pg2prev()
{
}

// ��U�@��
function pg2next()
{
}

// ��̥���
function pg2last()
{
}

//-->
</SCRIPT>
<FORM METHOD="POST" NAME="fPageChanger" ACTION="talk_ulist.php">
	<P>�ƧǼҦ��G
		<SELECT NAME="select2">
			<OPTION VALUE="RANDOM" SELECTED>���N</OPTION>
			<OPTION VALUE="ID">�N��</OPTION>
			<OPTION VALUE="FROM">�ӷ�</OPTION>
			<OPTION VALUE="MODE">�ʺA</OPTION>
			<OPTION VALUE="FRIEND">�n��</OPTION>
		</SELECT>
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo" onChange="document.fPageChanger.iDirectGo2.selectedIndex = document.fPageChanger.iDirectGo.selectedIndex;">
		<!-- �N�W�U�� <SELECT> �P�B -->
			<OPTION VALUE="1" SELECTED>1</OPTION>
			<OPTION VALUE="2">2</OPTION>
		</SELECT>
		��
	</P>
	<TABLE WIDTH="100%" BORDER="1">
		<TR> 
			<TH>�s��</TH>
			<TH>C</TH>
			<TH>P</TH>
			<TH>�N��</TH>
			<TH>�ʺ�</TH>
			<TH>�G�m</TH>
			<TH>�ʺA</TH>
			<TH>���m</TH>
		</TR>
		<?php

		$ulist = $result["talk_ulist"];
		printf("<!-- %s -->\n", serialize($ulist));

		for ($i = 0; $i < count($ulist); ++$i) {
			printf("<TR>\n");
			printf("<TD>%d <INPUT TYPE=\"radio\" NAME=\"iItem\" VALUE=\"%s\"></TD>\n",
			       $i + 1, $ulist[$i]["PID"][0]);
			printf("<TD>*</TD>\n");
			printf("<TD>&nbsp;</TD>\n");
			printf("<TD><A HREF=\"talk_query_user.php\">%s</A></TD>\n",
			       $ulist[$i]["USERID"][0]);
			printf("<TD>%s</TD>\n", $ulist[$i]["USERNAME"][0]);
			printf("<TD>%s</TD>\n", $ulist[$i]["FROM"][0]);
			printf("<TD>%s</TD>\n", $ulist[$i]["MODE"][0]);
			printf("<TD>%s</TD>\n", $ulist[$i]["IDLE-TIME"][0]);
			printf("</TR>\n");
		}

		?>
	</TABLE>
	<P>�ƧǼҦ��G 
		<SELECT NAME="select3">
			<OPTION VALUE="RANDOM" SELECTED>���N</OPTION>
			<OPTION VALUE="ID">�N��</OPTION>
			<OPTION VALUE="FROM">�ӷ�</OPTION>
			<OPTION VALUE="MODE">�ʺA</OPTION>
			<OPTION VALUE="FRIEND">�n��</OPTION>
		</SELECT>
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo2" onChange="document.fPageChanger.iDirectGo.selectedIndex = document.fPageChanger.iDirectGo2.selectedIndex;">
		<!-- �N�W�U�� <SELECT> �P�B -->
			<OPTION VALUE="1" SELECTED>1</OPTION>
			<OPTION VALUE="2">2</OPTION>
		</SELECT>
		��
	</P>
</FORM>
<SCRIPT LANGUAGE="JavaScript">
<!--

function selectedRadio()
{
	var i;
	var o;

	for (i = 0; i < document.fPageChanger.iItem.length; ++i) {
		if (document.fPageChanger.iItem[i].checked) {
			return document.fPageChanger.iItem[i];
		}
	}
	return false;
}

function sendMessage()
{
	var o = selectedRadio();

	if (o != false) {
		alert(o.value);
		document.fMessagePack.iToPID.value = o.value;
		return true;
	}
	return false;
}

//-->
</SCRIPT>
<FORM METHOD="POST" NAME="fMessagePack" ACTION="_talk_sendmsg.php" onSubmit="return sendMessage();">
	<INPUT TYPE="hidden" NAME="iToPID" VALUE="">
	�T�����e�G<INPUT TYPE="text" NAME="iMessage" VALUE="">
	<INPUT TYPE="submit" VALUE="�e�X">
</FORM>