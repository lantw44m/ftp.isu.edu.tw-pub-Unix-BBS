<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�o���峹");

$SNOW_PAGE_TITLE = "�o���峹";
$SNOW_PAGEAREA_MAIN = "brd_post_article.m.php";
$SNOW_PAGEAREA_FUNC = "brd_post_article.f.php";

include("bone.php");

?>