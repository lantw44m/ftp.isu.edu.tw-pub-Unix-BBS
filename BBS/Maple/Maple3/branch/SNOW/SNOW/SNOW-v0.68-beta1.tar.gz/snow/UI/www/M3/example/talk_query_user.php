<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�d�ߨϥΪ�");

// required: iQueryID

$mrr = array(
	"talk_query_user" => array(
		0 => array(
			"MRR-SID" => array(0 => session_id()),
			"QUERY-ID" => array(0 => $iQueryID)
		)
	)
);

$result = MRRquery($mrr);


$SNOW_PAGE_TITLE = "�d�ߨϥΪ�";
$SNOW_PAGEAREA_MAIN = "talk_query_user.m.php";
$SNOW_PAGEAREA_FUNC = "talk_query_user.f.php";

include("bone.php");

?>