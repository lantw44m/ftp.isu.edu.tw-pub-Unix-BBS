<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�\Ū�峹");

$mrr = array(
	"brd_readpost" => array(
		0 => array(
			"BRDID" => array(0 => $iBoardID),
			"FILENAME" => array(0 => $iFilename)
		)
	)
);
$result = MRRquery($mrr);

$SNOW_PAGE_TITLE = "�\Ū�峹";
$SNOW_PAGEAREA_MAIN = "brd_read_post.m.php";
$SNOW_PAGEAREA_FUNC = "brd_read_post.f.php";

include("bone.php");

?>