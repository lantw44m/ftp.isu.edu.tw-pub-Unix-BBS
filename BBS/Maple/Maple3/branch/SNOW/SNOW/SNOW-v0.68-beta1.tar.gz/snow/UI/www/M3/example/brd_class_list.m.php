<SCRIPT LANGUAGE="JavaScript">
<!--

// ��Ĥ@��
function pg2first()
{
}

// ��W�@��
function pg2prev()
{
}

// ��U�@��
function pg2next()
{
}

// ��̥���
function pg2last()
{
}

//-->
</SCRIPT>
<FORM METHOD="post" NAME="fPageChanger" ACTION="brd_class_list.php">
	<INPUT TYPE="hidden" NAME="iChannel" VALUE="">
	<INPUT TYPE="hidden" NAME="iPageTop" VALUE="">
	<INPUT TYPE="hidden" NAME="iPageSize" VALUE="">
	<INPUT TYPE="hidden" NAME="iSortMethod" VALUE="">
	<P> 
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo" onChange="document.fPageChanger.iDirectGo2.selectedIndex = document.fPageChanger.iDirectGo.selectedIndex;">
		<!-- �N�W�U�� <SELECT> �P�B -->
			<OPTION VALUE="1" SELECTED>1</OPTION>
			<OPTION VALUE="2">2</OPTION>
		</SELECT>
		��
		<INPUT TYPE="button" VALUE="Go">
		</P>
	<TABLE WIDTH="100%" BORDER="1">
		<TR> 
			<TH>�s��</TH>
			<TH>�`��</TH>
			<TH>�Х�</TH>
			<TH>�ݪO</TH>
			<TH>����ԭz</TH>
			<TH>�벼</TH>
			<TH>���D</TH>
		</TR>
		<?php
		
		$cblist = $result["brd_class_list"];

		for ($i = 0; $i < count($cblist); ++$i) {
			if ($cblist[$i]["TYPE"][0] == "CLASS") {
				printf("<TR>\n");
				printf("<TD>%d <INPUT TYPE=\"radio\" NAME=\"iItem\" VALUE=\"%d\"></TD>\n",
					   $iPageTop + $i, $cblist[$i]["CHANNEL"][0]);
				printf("<TD>xx</TD>\n");
				printf("<TD>xx</TD>\n");
				printf("<TD><A HREF=\"brd_class_list.php?iChannel=%d&iPageTop=1&iPageSize=%d\">" .
					   "%s</A>/</TD>\n",
					   $cblist[$i]["CHANNEL"][0], $iPageSize, $cblist[$i]["CLASS-NAME"][0]);
				printf("<TD><A HREF=\"brd_class_list.php?iChannel=%d&iPageTop=1&iPageSize=%d\">" .
					   "%s</A></TD>\n",
					   $cblist[$i]["CHANNEL"][0], $iPageSize, $cblist[$i]["CLASS-TITLE"][0]);
				printf("<TD>&nbsp;</TD>\n");
				printf("<TD>&nbsp;</TD>\n");
				printf("</TR>\n");
			}
			else if ($cblist[$i]["TYPE"][0] == "BOARD") {
				printf("<TR>\n");
				printf("<TD>%d <INPUT TYPE=\"radio\" NAME=\"iItem\" VALUE=\"%d\"></TD>\n",
					   $iPageTop + $i, $cblist[$i]["CHANNEL"][0]);
				printf("<TD>xx</TD>\n");
				printf("<TD>xx</TD>\n");
				printf("<TD><A HREF=\"brd_plist.php?iBoardID=%s&iPageTop=1&iPageSize=%d\">" .
					   "%s</A></TD>\n",
					   $cblist[$i]["BRD-NAME"][0], $iPageSize, $cblist[$i]["BRD-NAME"][0]);
				printf("<TD><A HREF=\"brd_plist.php?iBoardID=%s&iPageTop=1&iPageSize=%d\">" .
					   "%s</A></TD>\n",
					   $cblist[$i]["BRD-NAME"][0], $iPageSize, $cblist[$i]["BRD-TITLE"][0]);
				printf("<TD>%s</TD>\n", ($cblist[$i]["VOTE"][0] == "VOTE") ? "V" : "&nbsp;");
				printf("<TD>%s</TD>\n", $cblist[$i]["BRD-BM"][0]);
				printf("</TR>\n");
			}
		}

		?>
		<!--
		<TR> 
			<TD>1
				<INPUT TYPE="radio" NAME="iItem" VALUE="channel1">
			</TD>
			<TD>94</TD>
			<TD>�C</TD>
			<TD><A HREF="brd_class_list.php">System</A>/</TD>
			<TD><A HREF="brd_class_list.php">�@�~�t�� �P �M��</A></TD>
			<TD>&nbsp;</TD>
			<TD>&nbsp;</TD>
		</TR>
		<TR> 
			<TD>2
				<INPUT TYPE="radio" NAME="iItem" VALUE="channel2">
			</TD>
			<TD>35</TD>
			<TD>�E</TD>
			<TD><A HREF="brd_plist.php">PHP</A></TD>
			<TD><A HREF="brd_plist.php">http://www.php.net</A></TD>
			<TD>V</TD>
			<TD><A HREF="talk_query_user.php">skyter</A></TD>
		</TR>
		<TR> 
			<TD>3
				<INPUT TYPE="radio" NAME="iItem" VALUE="channel3">
			</TD>
			<TD>13</TD>
			<TD>�E</TD>
			<TD><A HREF="brd_plist.php">Python</A></TD>
			<TD><A HREF="brd_plist.php">Python�{���]�p</A></TD>
			<TD>&nbsp;</TD>
			<TD><A HREF="talk_query_user.php">JeffHung</A>/<A HREF="talk_query_user.php">Arlo</A></TD>
		</TR>
		-->
	</TABLE>
	<P>
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo2" onChange="document.fPageChanger.iDirectGo.selectedIndex = document.fPageChanger.iDirectGo2.selectedIndex;">
		<!-- �N�W�U�� <SELECT> �P�B -->
			<OPTION VALUE="1" SELECTED>1</OPTION>
			<OPTION VALUE="2">2</OPTION>
		</SELECT>
		��
		<INPUT TYPE="button" VALUE="Go">
		</P>
</FORM>