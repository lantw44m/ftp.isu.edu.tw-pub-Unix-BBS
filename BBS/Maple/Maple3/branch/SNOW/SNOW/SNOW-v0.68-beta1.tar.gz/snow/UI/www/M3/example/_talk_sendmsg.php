<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();

SESSIONcache("sUserID");
SESSIONcache("sUserName");

/*
$mrr = array(
	"talk_sendmsg" => array(
		0 => array(
			"MRR-SID" => array(0 => session_id()),
			"TO-PID" => array(0 => $iToPID),
			"MESSAGE" => array(0 => $iMessage)
		}
	)
);
$result = MRRquery($mrr);
*/
$cmd = sprintf("/serv/bbs/www/bin/talk_sendmsg %s %s \"%s\"", session_id(), $iToPID, $iMessage);
//echo $cmd;
exec($cmd);

$goPage = HISTORYget(0);
$redirect = sprintf("Location: %s", $goPage["URI"]);
//header($redirect);
exit();

?>