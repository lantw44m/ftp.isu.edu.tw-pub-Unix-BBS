<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("���Q�װϳ]�w");

$SNOW_PAGE_TITLE = "���Q�װϳ]�w";
$SNOW_PAGEAREA_MAIN = "admin_edit_board.m.php";
$SNOW_PAGEAREA_FUNC = "admin_edit_board.f.php";

include("bone.php");

?>