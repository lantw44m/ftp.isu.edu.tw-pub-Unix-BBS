/*
 *  $Id: mail_first_unread_mail.c,v 1.7 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_MAIL_FIRST_UNREAD_MAIL

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_mail.h"
#include "bbs.h"
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include "w3if_general.h"
#include <unistd.h>
#include <sys/uio.h>
#include <string.h>
#include "dao.h"
#include <stdlib.h>

#ifdef AS_ARNI_MODULE

/* ARGSUSED 1 */

int mod_mail_first_unread_mail(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return mail_first_unread_mail(ofd, parg->args[0].s);
}

#endif /* AS_ARNI_MODULE */

int mail_first_unread_mail(int ofd, char *userid)
{
	char		lower_userid[IDLEN + 1];
	char		fpath[MAXPATHLEN];
	struct stat	st;
	int			mailnum;
	HDR			*mailbuf;
	FILE		*mailfp;
	int			i; /* generic i */
	char		buf[GENERAL_BUFSIZE]; /* general buffer */

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

	write(ofd, "MRR-RESULT:mail_first_unread_mail\n",
	      strlen("MRR-RESULT:mail_first_unread_mail\n"));

	str_lower(lower_userid, (char*)userid);
	snprintf(fpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/.DIR",
	         lower_userid[0], lower_userid);

	if (lstat(fpath, &st) < 0) {
		write(ofd, "RESULT:mailbox index file not found\nMRR-END:\n",
		      strlen("RESULT:mailbox index file not found\nMRR-END:\n"));
		return -999; /* mailbox index file not found */
	}
	mailnum = st.st_size / sizeof(HDR);

	if (!(mailbuf = (HDR*)malloc(sizeof(HDR) * mailnum))) {
		write(ofd, "RESULT:allocate memory error\nMRR-END:\n",
		      strlen("RESULT:allocate memory error\nMRR-END:\n"));
		return -999; /* allocate memory error */
	}
	memset(mailbuf, 0, sizeof(HDR) * mailnum);

	if (!(mailfp = fopen(fpath, "r"))) {
		free(mailbuf);
		write(ofd, "RESULT:open mailbox index file error\nMRR-END:\n",
		      strlen("RESULT:open mailbox index file error\nMRR-END:\n"));
		return -999; /* open mailbox index file error */
	}

	/* read all stuff into buffer */
	if ((mailnum = fread(mailbuf, sizeof(HDR), mailnum,mailfp)) < 0) {
		fclose(mailfp);
		free(mailbuf);
		write(ofd, "RESULT:read mailbox index file error\nMRR-END:\n",
		      strlen("RESULT:read mailbox index file error\nMRR-END:\n"));
		return -999; /* read mailbox index file error */
	}

	fclose(mailfp);

	for (i = 0; i < mailnum; ++i) {
		if (!(mailbuf[i].xmode & POST_READ)) {
			/* unread */
			snprintf(buf, GENERAL_BUFSIZE, "INDEX:%d\nFILENAME:%s\nMRR-END:\n",
			         i + 1, mailbuf[i].xname);
			write(ofd, buf, strlen(buf));
			free(mailbuf);
			return 0; /* success */
		}
	}

	free(mailbuf);
	write(ofd, "RESULT:unread mail not found\nMRR-END:\n",
	      strlen("RESULT:unread mail not found\nMRR-END:\n"));
	return 999; /* unread mail not found */
}

