/*
 *  $Id: post_lib.c,v 1.1 2000/09/30 03:48:18 arlo Exp $
 */

#include "w3iflib.h"
#include "w3ifglobal.h"
#include "bbs.h"


int post_attr(HDR *fhdr)
{
	int		mode;
	int		attr;

	mode = fhdr->xmode;

	if (mode & POST_CANCEL) {
		return (int)('c');
	}

	if (mode & POST_DELETE) {
		return (int)('d');
	}

	attr = brh_unread(fhdr->chrono) ? 0 : 0x20; /* JeffHung.20000724: 0x20? */

#if	0	/* JeffHung.20000725: why not? skip a global variable :-p */
	/* Thor:�@��user�ݤ���G */
	mode &= (bbstate & STAT_BOARD) ? (~0) : (~POST_GEM);
#endif	/* 0 */

	if (mode &= (POST_MARKED | POST_GEM)) {
		attr |= (int)((mode = POST_MARKED)
		        ? 'M' : (mode = POST_GEM ? 'G' : 'B'));
	}
	else if (!attr) {
		attr = (int)('+');
	}

	return attr;
}



