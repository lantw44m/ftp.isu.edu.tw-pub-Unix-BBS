/*
 *  $Id: brd_readpost.c,v 1.6 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_BRD_READPOST

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_brd.h"
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "bbs.h"
#include <stdio.h>
#include <sys/param.h>
#include "w3if_general.h"
#include "w3ifglobal.h"
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/uio.h>


#ifdef AS_ARNI_MODULE

/* ARGSUSED 1 */

int mod_brd_readpost(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return brd_readpost(ofd, parg->args[0].s, parg->args[1].s);
}

#endif /* AS_ARNI_MODULE */


#if 0 /* JeffHung.20000929: defined at w3ifglobal.c */

char *trim_r_newline(char *s)
{
	register char *p = s;

	while (*p) {
		if ((*p == '\n') || (*p == '\r')) {
			*p = 0;
			break;
		}
		++p;
	}

	return s;
}

#endif /* 0 */


int subject_cmp(char *s1, char *s2)
{
	if (!strncmp(s1, "Re: ", 4)) {
		s1 += 4;
	}
	if (!strncmp(s2, "Re: ", 4)) {
		s2 += 4;
	}
	return strcmp(s1, s2);
}

/* PIF stands for Post Index Filename */
struct tagPIF {
	int  idx;
	char fname[33];
};
typedef struct tagPIF PIF;

#define PIF_ME  (0) /* this post */
#define PIF_PT  (1) /* Previous post by Time */
#define PIF_NT  (2) /* Next post by Time */
#define PIF_PS  (3) /* Previous post by Subject */
#define PIF_NS  (4) /* Next post by Subject */
#define PIF_PA  (5) /* Previoius post by Author */
#define PIF_NA  (6) /* Next post by Author */
#define PIF_NUM (7)


/*
 *  return value:
 *  -1: open file error
 *  -2: write to ofd error
 */
int brd_readpost(int ofd, char* brdname, char* fname)
{
	struct stat	st;
	int			brdnum;
	BRD			*brdbuf;
	FILE		*brdfp;
	int			i; /* generic i */
	char		fpath[MAXPATHLEN];
	FILE		*postfp;
	char        *p1;
	char        *p2;
	char        *p3;
	char        obuf[GENERAL_BUFSIZE];
	char		buf[GENERAL_BUFSIZE];
	int			len;
	int         idx_brd; /* board index */
	PIF         pif[PIF_NUM];
	HDR         *postbuf;
	int         postnum;
	FILE        *idxfp;

#ifdef DEBUG_BRD_READPOST
	fprintf(stderr, "DEBUG(%s,%d): enter brd_readpost(): "
	                "brdname: %s, fname: %s\n",
	        __FILE__, __LINE__, brdname, fname);
#endif /* DEBUG_BRD_READPOST */

	chdir(BBSHOME);

	/* JeffHung.20000718: get board index size */
	if (lstat(".BRD", &st) < 0) {

#ifdef DEBUG_BRD_READPOST
		fprintf(stderr, "DEBUG(%s,%d): board index file not found\n",
		        __FILE__, __LINE__);
#endif /* DEBUG_BRD_READPOST */

		return -999; /* board index file not found */
	}
	brdnum = st.st_size / sizeof(BRD);

	if (!(brdbuf = (BRD*)malloc(sizeof(BRD) * brdnum))) {

#ifdef DEBUG_BRD_READPOST
		fprintf(stderr, "DEBUG(%s,%d): allocate memory error\n",
		        __FILE__, __LINE__);
#endif /* DEBUG_BRD_READPOST */

		return -999; /* allocate memory error */
	}
	memset(brdbuf, 0, sizeof(BRD) * brdnum);

	if (!(brdfp = fopen(".BRD", "r"))) {

#ifdef DEBUG_BRD_READPOST
		fprintf(stderr, "DEBUG(%s,%d): open board index file error\n",
		        __FILE__, __LINE__);
#endif /* DEBUG_BRD_READPOST */

		free(brdbuf);
		return -999; /* open board index file error */
	}

	/* read all stuff into buffer */
	if ((brdnum = fread(brdbuf, sizeof(BRD), brdnum, brdfp)) < 0) {

#ifdef DEBUG_BRD_READPOST
		fprintf(stderr, "DEBUG(%s,%d): read board index file error\n",
		        __FILE__, __LINE__);
#endif /* DEBUG_BRD_READPOST */

		fclose(brdfp);
		free(brdbuf);
		return -999; /* read board index file error */
	}

	fclose(brdfp);

	for (i = 0; i < brdnum; ++i) {
		if (!strncasecmp(brdbuf[i].brdname, brdname, IDLEN)) {
			idx_brd = i;
			break;
		}
	}
	if (i >= brdnum) {

#ifdef DEBUG_BRD_READPOST
		fprintf(stderr, "DEBUG(%s,%d): board not found\n", __FILE__, __LINE__);
#endif /* DEBUG_BRD_READPOST */

		return -999; /* board not found */
	}

	/* found that board. */

	memset(pif, 0, sizeof(PIF) * PIF_NUM);
	snprintf(fpath, MAXPATHLEN, "brd/%s/" FN_DIR, brdbuf[idx_brd].brdname);
	if (lstat(fpath, &st) < 0) {

#ifdef DEBUG_BRD_READPOST
		fprintf(stderr, "DEBUG(%s,%d): post index file not found\n",
		        __FILE__, __LINE__);
#endif /* DEBUG_BRD_READPOST */

		return -999; /* post index file not found */
	}
	postnum = st.st_size / sizeof(HDR);

	if (!(postbuf = (HDR*)malloc(sizeof(HDR) * postnum))) {

#ifdef DEBUG_BRD_READPOST
		fprintf(stderr, "DEBUG(%s,%d): allocate memory error\n",
		        __FILE__, __LINE__);
#endif /* DEBUG_BRD_READPOST */

		return -999; /* allocate memory error */
	}
	memset(postbuf, 0, sizeof(HDR) * postnum);

	if (!(idxfp = fopen(fpath, "r"))) {

#ifdef DEBUG_BRD_READPOST
		fprintf(stderr, "DEBUG(%s,%d): open post index file error\n",
		        __FILE__, __LINE__);
#endif /* DEBUG_BRD_READPOST */

		free(postbuf);
		return -999; /* open post index file error */
	}

	/* read all stuff into buffer */
	if ((postnum = fread(postbuf, sizeof(HDR), postnum, idxfp)) < 0) {

#ifdef DEBUG_BRD_READPOST
		fprintf(stderr, "DEBUG(%s,%d): read post index file error\n",
		        __FILE__, __LINE__);
#endif /* DEBUG_BRD_READPOST */

		fclose(idxfp);
		free(postbuf);
		return -999; /* read post index file error */
	}

	memset(pif, 0, sizeof(PIF) * PIF_NUM);

	for (i = 0; i < postnum; ++i) {
		if (!strcmp(postbuf[i].xname, fname)) {
			pif[PIF_ME].idx = i;
			strcpy(pif[PIF_ME].fname, postbuf[i].xname);
			break;
		}
	}
	if (i >= postnum) {

#ifdef DEBUG_BRD_READPOST
		fprintf(stderr, "DEBUG(%s,%d): post not found\n", __FILE__, __LINE__);
#endif /* DEBUG_BRD_READPOST */

		/* error */
		return -999; /* post not found */
	}
	if (i < postnum - 1) {
		/* got PIF_NT */
		pif[PIF_NT].idx = i + 2;
		strcpy(pif[PIF_NT].fname, postbuf[i + 1].xname);
	}
	if (i > 0) {
		/* got PIF_PT */
		pif[PIF_PT].idx = i;
		strcpy(pif[PIF_PT].fname, postbuf[i - 1].xname);
	}
	/* find forward */
	for (++i; i < postnum; ++i) {
		if (postbuf[i].xmode & POST_DELETE) {
			continue; /* this post has been deleted */
		}
		if (!(pif[PIF_NS].idx) &&
		    !subject_cmp(postbuf[i].title,
		                 postbuf[pif[PIF_ME].idx].title)) {
			/* got PIF_NS */
			pif[PIF_NS].idx = i + 1;
			strcpy(pif[PIF_NS].fname, postbuf[i].xname);
		}
		if (!(pif[PIF_NA].idx) &&
		    !strcmp(postbuf[i].owner, postbuf[pif[PIF_ME].idx].owner)) {
			/* got PIF_NA */
			pif[PIF_NA].idx = i + 1;
			strcpy(pif[PIF_NA].fname, postbuf[i].xname);
		}
		if (pif[PIF_NS].idx && pif[PIF_NA].idx) {
			break;
		}
	}
	/* find backward */
	for (i = pif[PIF_ME].idx - 1; i >= 0; --i) {
		if (postbuf[i].xmode & POST_DELETE) {
			continue; /* this post has been deleted */
		}
		if (!(pif[PIF_PS].idx) &&
		    !subject_cmp(postbuf[i].title,
		                 postbuf[pif[PIF_ME].idx].title)) {
			/* got PIF_PS */
			pif[PIF_PS].idx = i + 1;
			strcpy(pif[PIF_PS].fname, postbuf[i].xname);
		}
		if (!(pif[PIF_PA].idx) &&
		    !strcmp(postbuf[i].owner, postbuf[pif[PIF_ME].idx].owner)) {
			/* got PIF_PA */
			pif[PIF_PA].idx = i + 1;
			strcpy(pif[PIF_PA].fname, postbuf[i].xname);
		}
		if (pif[PIF_PS].idx && pif[PIF_PA].idx) {
			break;
		}
	}
	free(postbuf);

	/* read that post */
	snprintf(fpath, MAXPATHLEN, "brd/%s/%c/%s",
	         brdbuf[idx_brd].brdname, fname[7], fname);

	if (!(postfp = fopen(fpath, "r"))) {

#ifdef DEBUG_BRD_READPOST
		fprintf(stderr, "DEBUG(%s,%d): unable to open file: fpath: %s\n",
		        __FILE__, __LINE__, fpath);
#endif /* DEBUG_BRD_READPOST */

		return -999; /* unable to open file */
	}

	free(brdbuf);

	write(ofd, "MRR-RESULT:brd_readpost\n",
	      strlen("MRR-RESULT:brd_readpost\n"));

	sprintf(obuf, "PIF-ME:%s\n", pif[PIF_ME].fname);
	write(ofd, obuf, strlen(obuf));
	if (pif[PIF_PT].idx) {
		sprintf(obuf, "PIF-PT:%s\n", pif[PIF_PT].fname);
		write(ofd, obuf, strlen(obuf));
	}
	if (pif[PIF_NT].idx) {
		sprintf(obuf, "PIF-NT:%s\n", pif[PIF_NT].fname);
		write(ofd, obuf, strlen(obuf));
	}
	if (pif[PIF_PS].idx) {
		sprintf(obuf, "PIF-PS:%s\n", pif[PIF_PS].fname);
		write(ofd, obuf, strlen(obuf));
	}
	if (pif[PIF_NS].idx) {
		sprintf(obuf, "PIF-NS:%s\n", pif[PIF_NS].fname);
		write(ofd, obuf, strlen(obuf));
	}
	if (pif[PIF_PA].idx) {
		sprintf(obuf, "PIF-PA:%s\n", pif[PIF_PA].fname);
		write(ofd, obuf, strlen(obuf));
	}
	if (pif[PIF_NA].idx) {
		sprintf(obuf, "PIF-NA:%s\n", pif[PIF_NA].fname);
		write(ofd, obuf, strlen(obuf));
	}

	/* read header */

	for (i = 0; fgets(buf, GENERAL_BUFSIZE, postfp); ++i) {
		if (!strncmp(buf, "�@��: ", 6) ||
		    !strncmp(buf, "�o�H�H: ", 8)) {
			if (!*(p1 = strchr(buf, ':') + 2) ||
			    !(p2 = strchr(buf, '(')) ||
			    (*(--p2) != ' ') ||
			    !(p3 = strrchr(buf, ')'))) {
				continue; /* this is not a valid header line */
			}
			*p2++ = 0;
			sprintf(obuf, "AUTHOR-ID:%s\n", p1);
			write(ofd, obuf, strlen(obuf));
			*p3++ = 0;
			sprintf(obuf, "AUTHOR-NAME:%s\n", ++p2);
			write(ofd, obuf, strlen(obuf));
			if ((p1 = strstr(p3, "�ݪO: ")) && *(p1 += 6)) {
				trim_r_newline(p1);
				sprintf(obuf, "BOARD-ID:%s\n", p1);
				write(ofd, obuf, strlen(obuf));
			}
			continue;
		} /* �@�� */
		if (!strncmp(buf, "���D: ", 6) ||
		    !strncmp(buf, "��  �D: ", 8)) {
			if (!*(p1 = strchr(buf, ':') + 2)) {
				continue; /* this is not a valid header line */
			}
			trim_r_newline(p1);
			sprintf(obuf, "SUBJECT:%s\n", p1);
			write(ofd, obuf, strlen(obuf));
			continue;
		} /* ���D */
		if (!strncmp(buf, "�ɶ�: ", 6) ||
		    !strncmp(buf, "�o�H��: ", 8)) {
			if (!*(p1 = p2 = strchr(buf, ':') + 2)) {
				continue; /* this is not a valid header line */
			}
			if ((p2 = strchr(p1, '(')) &&
			    (p3 = strrchr(p1, ')'))) {
				/* have site name */
				*p2++ = 0;
				sprintf(obuf, "SITENAME:%s\n", p1);
				write(ofd, obuf, strlen(obuf));
				*p3 = 0;
				p1 = p2;
			}
			trim_r_newline(p1);
			sprintf(obuf, "DATE:%s\n", p1);
			write(ofd, obuf, strlen(obuf));
			continue;
		} /* �ɶ� */
		if (!strncmp(buf, "��H��: ", 8)) {
			if (!*(p1 = strchr(buf, ':') + 2)) {
				continue; /* this is not a valid header line */
			}
			trim_r_newline(p1);
			sprintf(obuf, "PATH:%s\n", p1);
			write(ofd, obuf, strlen(obuf));
			continue;
		} /* ��H�� */
		if (!strncmp(buf, "Origin: ", 8)) {
			if (!*(p1 = strchr(buf, ':') + 2)) {
				continue; /* this is not a valid header line */
			}
			trim_r_newline(p1);
			sprintf(obuf, "ORIGIN:%s\n", p1);
			write(ofd, obuf, strlen(obuf));
			continue;
		} /* Origin */
		if ((*buf == '\n') || (*buf == '\r')) {
			break; /* for (i) */
		}
	}

	for (i = 0; fgets(buf, GENERAL_BUFSIZE, postfp); ++i) {
		if (i == 0) {
			write(ofd, "BODY:", strlen("BODY:"));
		}
		else {
			write(ofd, "CONTINUE:", strlen("CONTINUE:"));
		}
		len = strlen(buf);
		if (write(ofd, buf, len) < 0) {

#ifdef DEBUG_BRD_READPOST
			fprintf(stderr, "DEBUG(%s,%d): unable to write file\n",
			        __FILE__, __LINE__);
#endif /* DEBUG_BRD_READPOST */

			fclose(postfp);
			return -999; /* unable to write file */
		}
	}
	write(ofd, "MRR-END:\n", strlen("MRR-END:\n"));

	fclose(postfp);
	return 0; /* success */
}

