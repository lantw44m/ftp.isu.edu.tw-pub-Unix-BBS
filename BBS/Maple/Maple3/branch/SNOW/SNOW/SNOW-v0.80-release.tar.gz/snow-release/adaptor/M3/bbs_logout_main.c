/*
 *  $Id: bbs_logout_main.c,v 1.6 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_BBS_LOGOUT_MAIN

#include <stdio.h>
#include "w3if_bbs.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 2) {
		printf("Usage: %s <session-id>\n", argv[0]);
		return 0;
	}

	ret = bbs_logout(fileno(stdout), argv[1]);

	if (ret != 0) {
#ifdef DEBUG_BBS_LOGOUT_MAIN
		fprintf(stderr, "bbs_logout() error(%d).\n", ret);
#endif /* DEBUG_BBS_LOGOUT_MAIN */
	}

	return 0;
}

