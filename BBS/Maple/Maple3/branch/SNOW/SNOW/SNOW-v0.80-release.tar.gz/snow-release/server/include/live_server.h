/*
 * 
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation 
 * bbs, the cross-media distributed communication platform. And it is 
 * developed by Cyberwork Solution in 2000.
 * 
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 * 
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or (at 
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or 
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution.com , Isabel Ho
 *
 */

#ifndef LIVE_SERVER_H_INCLUDED
#define LIVE_SERVER_H_INCLUDED
#include "live.h"
#define	BUF_SIZE	(512)
#define	BREAK_LINE	'\n'
#define	MAX_SIZE	(1024 * 1024)

struct LIVE_ARG_SPEC {
	char	*name;
	int		type;
};

#define	MRR_CMD_REQUEST		"MRR-REQUEST"
#define	MRR_CMD_CONTINUE	"CONTINUE"
#define MRR_CMD_SID       "MRR-SID"
#define	MRR_CMD_END			  "MRR-END"


#define	MRR_SINGLE_TEXTLINE	(100)
#define	MRR_MULTI_TEXTLINE	(200)
#define	MRR_DATETIME		(300)
#define	MRR_INTEGER			(400)
#define	MRR_FILENAME		(500)

#define	LIVE_MAX_ARGS		(16)



extern int daemon_proc;

#define DEBUG_LOG		"log/debug.message"
#define DEBUG_PRINT(MESSAGE)                     { if(daemon_proc) sys_log(DEBUG_LOG,MESSAGE); else {fflush(stdout);fputs(MESSAGE,stderr);fflush(stderr);} }
#define DEBUG_PRINT1(FORMAT,ARGS)                { char buf[256]; sprintf(buf , FORMAT , ARGS);if(daemon_proc) sys_log(DEBUG_LOG,buf); else {fflush(stdout);fputs(buf,stderr);fflush(stderr);} }
#define DEBUG_PRINT2(FORMAT,ARG1,ARG2)           { char buf[256]; sprintf(buf , FORMAT , ARG1,ARG2);if(daemon_proc) sys_log(DEBUG_LOG,buf); else {fflush(stdout);fputs(buf,stderr);fflush(stderr);} }
#define DEBUG_PRINT3(FORMAT,ARG1,ARG2,ARG3)      { char buf[256]; sprintf(buf , FORMAT , ARG1,ARG2,ARG3);if(daemon_proc) sys_log(DEBUG_LOG,buf); else {fflush(stdout);fputs(buf,stderr);fflush(stderr);} }
#define DEBUG_PRINT4(FORMAT,ARG1,ARG2,ARG3,ARG4) { char buf[256]; sprintf(buf , FORMAT , ARG1,ARG2,ARG3,ARG4);if(daemon_proc) sys_log(DEBUG_LOG,buf); else {fflush(stdout);fputs(buf,stderr);fflush(stderr);} }

struct LIVE_ARGS {
	int narg;
	union {
		int      i;
		char    *s;
	} args[LIVE_MAX_ARGS];
};


struct LIVE_MODULE_ENTRY {
	char						*name;
	int							(*fptr)(int, char * , USER_INFO*, struct LIVE_ARGS* );
	int							narg;
	struct LIVE_ARG_SPEC		args[LIVE_MAX_ARGS];
	struct LIVE_MODULE_ENTRY	*next;
};


struct LIVE_MODULE {
	struct LIVE_MODULE_ENTRY	*mods;
};

extern struct LIVE_MODULE	live_modules;


int live_module_register(char *mod_name, void *mod_fptr);
int live_module_addarg(char *mod_name, char *arg_name, int arg_type);
int live_module_unregister(char *mod_name);
int live_server(int fd, USER_INFO *user_info_pool);

#endif /* LIVE_SERVER_H_INCLUDED */

