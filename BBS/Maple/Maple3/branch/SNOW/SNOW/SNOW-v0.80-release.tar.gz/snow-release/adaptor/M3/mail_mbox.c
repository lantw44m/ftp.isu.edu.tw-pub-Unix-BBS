/*
 *  $Id: mail_mbox.c,v 1.8 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_MAIL_MBOX

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_mail.h"
#include "bbs.h"
#include "w3ifglobal.h"
#include <stdio.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "w3if_general.h"
#include <unistd.h>
#include <string.h>
#include "dao.h"
#include <sys/stat.h>
#include <stdlib.h>
#include <sys/uio.h>
#include "w3ifglobal.h"
#include "w3iflib.h"


#ifdef AS_ARNI_MODULE

/* ARGSUSED 1 */

int mod_mail_mbox(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return mail_mbox(ofd, parg->args[0].s);
}

#endif /* AS_ARNI_MODULE */

#if 0 /* JeffHung.20000929: already defined in lib/mail_lib.c */

int mbox_attr(int type)
{
	if (type & MAIL_DELETE) {
		return 'D';
	}

	if (type & MAIL_REPLIED) {
		return (type & MAIL_MARKED) ? 'R' : 'r';
	}

	return "+ Mm"[type & 3];
}

#endif /* 0 */


int tag_char(int chrono)
{
	return TagNum && !Tagger(chrono, 0, TAG_NIN) ? '*' : ' ';
}


int mail_mbox(int ofd, char* userid)
{
	FILE		*mailfp;
	int			mailnum;
	char		fpath[MAXPATHLEN];
	char		lower_userid[IDLEN + 1];
	struct stat	st;
	HDR*		mailbuf;
	int			i;
	char		author[130 + 1];
	char*		pch;
	char		buf[GENERAL_BUFSIZE];

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

	if (strlen(userid) > IDLEN) {
		userid[IDLEN] = 0;
	}
	str_lower(lower_userid, userid);
	snprintf(fpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/.DIR",
	         lower_userid[0], lower_userid);

	if (lstat(fpath, &st) < 0) {
		return -999; /* mailbox index file not found */
	}
	mailnum = st.st_size / sizeof(HDR);

	if (!(mailbuf = (HDR*)malloc(sizeof(HDR) * mailnum))) {
		return -999; /* allocate memory error */
	}
	memset(mailbuf, 0, sizeof(HDR) * mailnum);

	if (!(mailfp = fopen(fpath, "r"))) {
		free(mailbuf);
		return -999; /* open mailbox index file error */
	}

	/* read all stuffs into buffer */
	if ((mailnum = fread(mailbuf, sizeof(HDR), mailnum, mailfp)) < 0) {
		fclose(mailfp);
		free(mailbuf);
		return -999; /* read mailbox index file error */
	}

	fclose(mailfp);

	for (i = 0; i < mailnum; ++i) {

		write(ofd, "MRR-RESULT:mail_mbox\n",
		      strlen("MRR-RESULT:mail_mbox\n"));

		strncpy(author, mailbuf[i].owner, sizeof(author));
		if ((pch = strchr(author, '@'))) {
			*pch = '.';
			++pch;
			*pch = 0;
		}

		snprintf(buf, GENERAL_BUFSIZE,
		         "INDEX:%d\n"
		         "MARK:%c\n"
		         "TAG:%c\n"
		         "DATE:%s\n"
		         "AUTHOR:%s\n"
		         "SUBJECT:%s\n"
		         "FILENAME:%s\n",
		         i + 1,
		         mbox_attr(mailbuf[i].xmode),
		         tag_char(mailbuf[i].chrono),
		         mailbuf[i].date,
		         author,
		         mailbuf[i].title,
		         mailbuf[i].xname);
		write(ofd, buf, strlen(buf));
	}

	if (mailbuf) {
		free(mailbuf);
	}

	write(ofd, "MRR-END:\n", strlen("MRR-END:\n"));

	return 0;
}


