/*
 *  $Id: mail_readmail_main.c,v 1.6 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_MAIL_READMAIL_MAIN

#include <stdio.h>
#include "w3if_mail.h"

int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 3) {
		printf("Usage: %s <user-id> <mail-file-name>\n", argv[0]);
		return 0;
	}

	ret = mail_readmail(fileno(stdout), argv[1], argv[2]);

	if (ret < 0) {
#ifdef DEBUG_MAIL_READMAIL_MAIN
		fprintf(stderr, "mail_readmail error(%d).\n", ret);
#endif /* DEBUG_MAIL_READMAIL_MAIN */
	}

	return 0;
}

