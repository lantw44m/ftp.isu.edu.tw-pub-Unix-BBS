/*
 *  $Id: mail_send_internetmail.c,v 1.9 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_MAIL_SEND_INTERNETMAIL

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_mail.h"
#include <time.h>
#include <sys/param.h>
#include <stdio.h>
#include "w3if_general.h"
#include <unistd.h>
#include <string.h>
#include "w3iflib.h" /* for w3if_getCorrectUserID() */
#include "bbs.h"
#include "w3ifglobal.h"

#ifdef AS_ARNI_MODULE

/* ARGSUSED 1 */

int mod_mail_send_internetmail(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return mail_send_internetmail(ofd, parg->args[0].s, parg->args[1].s,
	                              parg->args[2].s, parg->args[3].s);
}

#endif /* AS_ARNI_MODULE */

/* ARGSUSED 0 */

int mail_send_internetmail(int ofd, char *fromid, char *toaddr, char *subject,
#ifdef AS_ARNI_MODULE
                           char *body)
#else /* AS_ARNI_MODULE */
                           char *fname)
#endif /* AS_ARNI_MODULE */
{
	time_t	now;
	char	tmpfpath[MAXPATHLEN];
	FILE	*tmpfp;
#ifndef AS_ARNI_MODULE
	FILE	*bodyfp;
	char	buf[GENERAL_BUFSIZE];
#endif /* AS_ARNI_MODULE */

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

	/* JeffHung.20000731: prevent buffer overflow */
	if (strlen(fromid) > IDLEN) {
		fromid[IDLEN] = 0;
	}

	if (!(fromid = w3if_getCorrectUserID(fromid))) {
		return -999; /* no such user */
	}

#ifdef	DEBUG_MAIL_SEND_INTERNETMAIL
	fprintf(stderr, "DEBUG(%s:%d): acct_load\n", __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_SEND_INTERNETMAIL */
	acct_load(&cuser, fromid);
#ifdef	DEBUG_MAIL_SEND_INTERNETMAIL
	fprintf(stderr, "DEBUG(%s:%d): acct_load done.\n", __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_SEND_INTERNETMAIL */

#ifdef USE_TMPNAM
	/*
	 * JeffHung.20001103:
	 * tmpnam() has problem about race condition
	 */
	tmpnam(tmpfpath);

#ifdef	DEBUG_MAIL_SEND_INTERNETMAIL
	fprintf(stderr, "DEBUG(%s:%d): tmpfpath: %s\n", __FILE__, __LINE__, tmpfpath);
#endif	/* DEBUG_MAIL_SEND_INTERNETMAIL */

	if (!(tmpfp = fopen(tmpfpath, "w"))) {
		return -999; /* can not create temp file */
	}
#else /* USE_TMPNAM */
	/* JeffHung.20001103: use mkstemp() instead */
	{
		int tmpfd;
		tmpfd = mkstemp("/tmp/snow.temp.XXXXXX");
		tmpfp = fdopen(tmpfd, "rw");
	}
#endif /* USE_TMPNAM */

	time(&now);
	fprintf(tmpfp, "�@��: %s (%s)\n"
	               "���D: %s\n"
	               "�ɶ�: %s\n",
	        cuser.userid, cuser.username, subject, ctime(&now));
#ifdef AS_ARNI_MODULE
	fprintf(tmpfp, "%s", body);
#else /* AS_ARNI_MODULE */
	if (!(bodyfp = fopen(fname, "r"))) {
		fclose(tmpfp);
		return -999; /* can not open mail body file */
	}
	while (fgets(buf, GENERAL_BUFSIZE, bodyfp)) {
		fprintf(tmpfp, "%s", buf);
	}
	fclose(bodyfp);
#endif /* AS_ARNI_MODULE */
	fclose(tmpfp);

#ifdef	DEBUG_MAIL_SEND_INTERNETMAIL
	fprintf(stderr, "DEBUG(%s:%d): bsmtp\n", __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_SEND_INTERNETMAIL */
	if (bsmtp(tmpfpath, subject, toaddr, 0) < 0) {
		return -999; /* can not send mail */
	}
#ifdef	DEBUG_MAIL_SEND_INTERNETMAIL
	fprintf(stderr, "DEBUG(%s:%d): bsmtp done.\n", __FILE__, __LINE__);
#endif	/* DEBUG_MAIL_SEND_INTERNETMAIL */

	unlink(tmpfpath);

	return 0; /* success */
}

