/*
 *  $Id: talk_nickchange_main.c,v 1.6 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_TALK_NICKCHANGE_MAIN

#include <stdio.h>
#include "w3if_talk.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 3) {
		printf("Usage: %s <session-id> <new-nick>\n",
		       argv[0]);
		return 0;
	}

	ret = talk_nickchange(argv[1], argv[2]);

	if (ret != 0) {
#ifdef DEBUG_TALK_NICKCHANGE_MAIN
		fprintf(stderr, "talk_nickchange() error(%d).\n", ret);
#endif /* DEBUG_TALK_NICKCHANGE_MAIN */
	}

	return 0;
}

