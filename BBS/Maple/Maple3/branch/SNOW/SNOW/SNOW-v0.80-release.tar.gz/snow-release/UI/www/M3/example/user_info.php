<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�ӤH���");

$mrr = array(
	"user_info_show" => array(
		0 => array(
			"MRR-SID" => array(0 => session_id())
		)
	)
);

$result = MRRquery($mrr);

$SNOW_PAGE_TITLE = "�ӤH���";
$SNOW_PAGEAREA_MAIN = "user_info.m.php";
$SNOW_PAGEAREA_FUNC = "user_info.f.php";

include("bone.php");

?>