/*
 *  $Id: talk_kickusr.c,v 1.6 2000/10/25 12:31:55 jeffhung Exp $
 */

#undef DEBUG_TALK_KICKUSR

#include "w3if_talk.h"
#include "w3if_session.h"
#include "bbs.h"
#include <stdio.h>
#include <unistd.h>
#include "w3ifglobal.h"
#include "w3if_general.h"
#include <sys/types.h>
#include <signal.h>
#include <errno.h>


int talk_kickusr(char *sid, pid_t kickpid)
{
	W3IF_SESSENTRY *psess = 0;
	W3IF_SESSENTRY *pkick = 0;
	int            i;
	UTMP           *up = NULL;
	char           buf[80];

#ifdef DEBUG_TALK_KICKUSR

	fprintf(stderr, "DEBUG(%s,%d): enter talk_kickusr()\n",
	        __FILE__, __LINE__);

#endif /* DEBUG_TALK_KICKUSR */

	chdir(BBSHOME);

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	psess = w3ifsession_get(sid);

	if (!psess) {
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;
	acct_load(&cuser, cutmp->userid);

	if (!HAS_PERM(PERM_SYSOP)) {
		return 999; /* no permission */
	}

#ifdef DEBUG_TALK_KICKUSR

	fprintf(stderr, "DEUBG(%s,%d): begin to find pkick by pid: %d\n",
	        __FILE__, __LINE__, (pid_t)kickpid);

#endif /* DEBUG_TALK_KICKUSR */

	for (i = 0; i < MAXACTIVE; ++i) {
		if (ushm->uslot[i].pid == kickpid) {
			up = &(ushm->uslot[i]);
			break;
		}
	}
	if (!up) {
		return 999; /* no such user */
	}

	sprintf(buf, "%s (%s)", up->userid, up->username);

	if (up->from[0] == W3IF_FROM_TAG) {
		/* this one come from web interface */

		if (!(pkick = w3ifsession_get_by_pid(kickpid))) {
			return 999; /* no such user */
		}

		up->pid = up->userno = 0;
		--(ushm->count);
		w3ifsession_delete(pkick->php_sid);
	}
	else {
		/* this one come from telnet interface */

		if ((kill(up->pid, SIGTERM) == -1) && (errno == ESRCH)) {
			up->pid = up->userno = 0;
		}
	}

	blog("KICK", buf);

	return 0;
}

