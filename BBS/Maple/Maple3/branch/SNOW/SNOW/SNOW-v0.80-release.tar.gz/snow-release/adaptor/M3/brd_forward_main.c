/*
 *  $Id: brd_forward_main.c,v 1.5 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_BRD_FORWARD_MAIN

#include <stdio.h>
#include "w3if_brd.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 5) {
		printf("Usage: %s <user-id> <to-address> <brd-id> <post-filename>\n",
		       argv[0]);
		return 0;
	}

	ret = brd_forward(fileno(stdout), argv[1], argv[2], argv[3], argv[4]);

	if (ret < 0) {
#ifdef DEBUG_BRD_FORWARD_MAIN
		fprintf(stderr, "brd_forward error(%d).\n", ret);
#endif /* DEBUG_BRD_FORWARD_MAIN */
	}

	return 0;
}

