/*
 *  $Id: mail_delete_main.c,v 1.7 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_MAIL_DELETE_MAIN

#include <stdio.h>
#include "w3if_mail.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 3) {
		printf("Usage: %s <user-id> <mail-file-name>\n", argv[0]);
		return 0;
	}

	ret = mail_delete(fileno(stdout), argv[1], argv[2]);

	if (ret < 0) {
#ifdef DEBUG_MAIL_DELETE_MAIN
		fprintf(stderr, "mail_delete error(%d).\n", ret);
#endif /* DEBUG_MAIL_DELETE_MAIN */
	}

	return 0;
}

