/*
 *  $Id: brd_toggle_mark.c,v 1.5 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_BRD_TOGGLE_MARK

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_brd.h"
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "bbs.h"
#include <unistd.h>
#include <sys/uio.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>


#ifdef AS_ARNI_MODULE

/* ARGSUSED 1 */

int mod_brd_toggle_mark(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return brd_toggle_mark(ofd, parg->args[0].s, parg->args[1].s);
}

#endif /* AS_ARNI_MODULE */


int brd_toggle_mark(int ofd, char *brdid, char *fname)
{
	char		fpath[MAXPATHLEN];
	struct stat	st;
	int			brdnum;
	HDR			*brdbuf;
	FILE		*brdfp;
	int			i; /* generic i */

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

	write(ofd, "MRR-RESULT:brd_toggle_mark\n",
	      strlen("MRR-RESULT:brd_toggle_mark\n"));

	/* prevent buffer overflow */
	if (strlen(brdid) > IDLEN) {
		brdid[IDLEN] = 0;
	}

	snprintf(fpath, MAXPATHLEN, "brd/%s/" FN_DIR, brdid);

#ifdef DEBUG_BRD_TOGGLE_MARK

	fprintf(stderr, "DEBUG(%s,%d): index filename: %s\n",
	        __FILE__, __LINE__, fpath);

#endif /* DEBUG_BRD_TOGGLE_MARK */

	if (lstat(fpath, &st) < 0) {
#ifdef	DEBUG_BRD_TOGGLE_MARK
		fprintf(stderr, "DEBUG(%d): post list index file not found.\n",
		        __LINE__);
#endif	/* DEBUG_BRD_TOGGLE_MARK */
		write(ofd, "RESULT:post list index file not found\nMRR-END:\n",
		      strlen("RESULT:post list index file not found\nMRR-END:\n"));
		return -999; /* post list index file not found */
	}
	brdnum = st.st_size / sizeof(HDR);

	if (!(brdbuf = (HDR*)malloc(sizeof(HDR) * brdnum))) {
#ifdef	DEBUG_BRD_TOGGLE_MARK
		fprintf(stderr, "DEBUG(%d): allocate memory error.\n", __LINE__);
#endif	/* DEBUG_BRD_TOGGLE_MARK */
		write(ofd, "RESULT:allocate memory error\nMRR-END:\n",
		      strlen("RESULT:allocate memory error\nMRR-END:\n"));
		return -999; /* allocate memory error */
	}
	memset(brdbuf, 0, sizeof(HDR) * brdnum);

	if (!(brdfp = fopen(fpath, "r+"))) {
#ifdef	DEBUG_BRD_TOGGLE_MARK
		fprintf(stderr, "DEBUG(%d): can not open mail index file.\n",
		        __LINE__);
#endif	/* DEBUG_BRD_TOGGLE_MARK */
		free(brdbuf);
		write(ofd, "RESULT:can not open mail index file\nMRR-END:\n",
		      strlen("RESULT:can not open mail index file\nMRR-END:\n"));
		return -999; /* can not open mail index file */
	}

	/* read all stuffs into buffer */
	fseek(brdfp, 0, SEEK_SET);
	if ((brdnum = fread(brdbuf, sizeof(HDR), brdnum, brdfp)) < 0) {
#ifdef	DEBUG_BRD_TOGGLE_MARK
		fprintf(stderr, "DEBUG(%d): read post list index file error.\n",
		        __LINE__);
#endif	/* DEBUG_BRD_TOGGLE_MARK */
		fclose(brdfp);
		free(brdbuf);
		write(ofd, "RESULT:read post list index file error\nMRR-END:\n",
		      strlen("RESULT:read post list index file error\nMRR-END:\n"));
		return -999; /* read post list index file error */
	}

	for (i = 0; i < brdnum; ++i) {
		if (!strcmp(brdbuf[i].xname, fname)) {
			brdbuf[i].xmode ^= POST_MARKED;
			fseek(brdfp, sizeof(HDR) * i, SEEK_SET);
			if (fwrite(&(brdbuf[i]), sizeof(HDR), 1, brdfp) != 1) {
#ifdef	DEBUG_BRD_TOGGLE_MARK
				fprintf(stderr, "DEBUG(%d): write to board index file error.\n",
				        __LINE__);
#endif	/* DEBUG_BRD_TOGGLE_MARK */
				fclose(brdfp);
				free(brdbuf);
				write(ofd, "RESULT:write to mail index file error\nMRR-END:\n",
				      strlen("RESULT:write to mail index file error\nMRR-END:\n"));
				return -999; /* write to mail index file error */
			}

			fclose(brdfp);
			free(brdbuf);
			write(ofd, "RESULT:OK\nMRR-END:\n",
			      strlen("RESULT:OK\nMRR-END:\n"));
			return 0; /* success */
		}
	}

#ifdef	DEBUG_BRD_TOGGLE_MARK
	fprintf(stderr, "DEBUG(%d): post not found.\n", __LINE__);
#endif	/* DEBUG_BRD_TOGGLE_MARK */
	write(ofd, "RESULT:mail not found\nMRR-END:\n",
	strlen("RESULT:mail not found\nMRR-END:\n"));
	return 999; /* mail not found */
}

