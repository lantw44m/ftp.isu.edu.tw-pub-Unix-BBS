/*
 *  $Id: brd_plist_main.c,v 1.4 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_BRD_PLIST_MAIN

#include <stdio.h>
#include <stdlib.h>
#include "w3if_brd.h"


int main(int argc, char* argv[])
{
	int	fd;
	int	ret;

	if (argc != 4) {
		printf("Usage: %s <board-id> <top-index> <page-size>\n",
		       argv[0]);
		return 0;
	}

	fd = fileno(stdout);
	ret = brd_plist(fd, argv[1], atoi(argv[2]), atoi(argv[3]));

	if (ret < 0) {
#ifdef DEBUG_BRD_PLIST_MAIN
		fprintf(stderr, "brd_plist error(%d).\n", ret);
#endif /* DEBUG_BRD_PLIST_MAIN */
	}

	return 0;
}

