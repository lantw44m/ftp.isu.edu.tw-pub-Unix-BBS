/*
 * 
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation 
 * bbs, the cross-media distributed communication platform. And it is 
 * developed by Cyberwork Solution in 2000.
 * 
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 * 
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or (at 
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or 
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution.com , Isabel Ho
 *
 */


/*
 *  �V�|�I�����S�Q�����F~~
 *                                -- South Park Chinese Ver.
 */



#define DEBUG_ARNI

#include "arni.h"

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <pthread.h>
#include <unistd.h>
#include <syslog.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <errno.h>

#include "arni_server.h"
#include "mod_list.h"
#include "system_lib.h"
#include "tcp_lib.h"


struct THREAD_POOL {
  pthread_t thread_tid; /* thread ID */
  long    thread_count; /* # of connections handled */
};

struct THREAD_POOL  *thread_ptr; /* array of thread structure */ 

/* �Ϥ��O���Odaemon mode��flag */

extern int daemon_proc;

int         client_fd[MAX_CLIENT];
int         iget;
int         iput;

#ifdef DYNAMIC_THREAD
int thread_count;
int client_count;
#endif

static int      nthreads;
pthread_mutex_t   clifd_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t    clifd_cond  = PTHREAD_COND_INITIALIZER;

char  server_port[6];

#ifdef DYNAMIC_THREAD
pthread_mutex_t   count_mutex = PTHREAD_MUTEX_INITIALIZER;
#endif

static int main_server(int argc , char **argv , int flag);

/* ARGSUSED 0 */

void sig_int(int signo)
{
#ifdef  DEBUG_ARNI

    DEBUG_PRINT("thread closed\n");
#endif  /* DEBUG_ARNI */
  exit(0);
}

static void sig_chld(int signo)
{
  pid_t pid;
  pid_t child_pid;
  int stat;

  while( (pid = sys_waitpid(-1, &stat , WNOHANG) ) > 0 )
  {
    fprintf(stderr, "child %d terminated.\n", pid);
    if((child_pid = sys_fork()) ==0 )
    {
      pthread_mutex_unlock(&count_mutex);
      thread_count = 0;
      main_server(NULL , NULL , 1);
    }
  }
}

/* ARGSUSED 0 */

void sig_pipe(int signo)
{
  char  buf[128];

  sprintf(buf, "arni_server Pipe broken at %s\n", ctime((time_t *)time(0)));
  sys_log(ERR_NETWORK_LOG, buf);  
  exit(0);
}

void thread_make(int index)
{
  void  *thread_main(void*);

#ifdef DYNAMIC_THREAD
  pthread_mutex_lock(&count_mutex);
    thread_count++;
  pthread_mutex_unlock(&count_mutex);
#endif

  pthread_create(&thread_ptr[index].thread_tid, NULL,
                   &thread_main, (void*)index);
  /*
   *  JeffHung.20000815:
   *
   *  int to void*? what's a dangurous action! What if int and
     *  void* have different sizes? Why not use int* to void*?
   */
  return; /* main thread returns */
}

void *thread_main(void *arg)
{
  int connfd;

#ifdef  DEBUG_ARNI
  DEBUG_PRINT1("thread %d starting\n", (int) arg);
#endif  /* DEBUG_ARNI */

  for (;;) {

#ifdef  DEBUG_ARNI
    DEBUG_PRINT1("thread %d restart\n", (int) arg);
#endif  /* DEBUG_ARNI */

    pthread_mutex_lock(&clifd_mutex);
    /*
     *  do nothing when iget == iput ,until not equal,
     *  call sys_pthread_cond_signal to wake up
     */
    while (iget == iput) {
      
#ifdef  DEBUG_ARNI
    DEBUG_PRINT3("DEBUG: pthread_wait:%d,iget=%d iput=%d\n", client_count ,iget,iput);
#endif  /* DEBUG_ARNI */

      pthread_cond_wait(&clifd_cond, &clifd_mutex);

#ifdef DYNAMIC_THREAD
       client_count++;  /* for dynamic thread , count client number */
#endif
    }

    connfd = client_fd[iget]; /* connected socket to service */

    if (++iget == MAX_CLIENT) {
      iget = 0;
    }
    pthread_mutex_unlock(&clifd_mutex);

    thread_ptr[((int)arg)].thread_count++; /* arg is the index of thread */

    /*
     *  JeffHung.20000815:
     *
     *  void* to int? what's a dangurous action! What if void* and
     *  int have different sizes? Why not use void* to int*?
     *
     *  Is the THREAD_POOL.thread_count just for counting how many
     *  request been served?
     */
#ifdef DEBUG_ARNI
    fprintf(stderr,"arni start\n");
#endif
    arni_server(connfd); /* process the request */

/*for dynamic thread , if exec arni_server() done , decrease client+count */
#ifdef DYNAMIC_THREAD
    pthread_mutex_lock(&count_mutex);
      client_count--; 
    pthread_mutex_unlock(&count_mutex);
#endif

#ifdef  DEBUG_ARNI
    DEBUG_PRINT1("DEBUG: close_process , thread_count:%d\n", thread_count );
#endif  /* DEBUG_ARNI */
    
    close(connfd);

#ifdef DYNAMIC_THREAD
    if( thread_count > SERVER_THREAD + 1 )
    {
      pthread_mutex_lock(&count_mutex);
        thread_count--;
      pthread_mutex_unlock(&count_mutex);
#ifdef  DEBUG_ARNI
    DEBUG_PRINT1("DEBUG: pthread closed:%d\n", thread_count );
#endif  /* DEBUG_ARNI */    
      /* JeffHung.20001107: there should return something typed as void* */
      return NULL; /* close thread */
    }
#endif

  } /* for (;;) */
}
static void start_daemon( const char *ap_name , int facility)
{
  int i;
  pid_t pid;

  daemon_proc = 1;

  if( (pid = sys_fork()) != 0 ) /* parent process */
  {
    sys_exit(0);
  }
  
  setsid(); /* ���� session leader */

/*
 * �]���� session leader (�Ĥ@��fork�X�Ӫ�child) terminate��, 
 * �Ҧ��b�o�@��session��process�|�e�X SIGHUP �o��signal 
 */
  sys_signal( SIGHUP , SIG_IGN ); 
  
  if( (pid = sys_fork()) != 0 ) /* 1st child */
  {
    sys_exit(0);
  }

  umask(0); /* ��file creation mask�]���s�A�o�ˤ~���|�v�T�줧��ceate�X��file */

  for( i = 0 ; i < MAX_FD ; i++ )
  {
    sys_close(i); /*��Ҧ�file descriptor�����F�A�ר�Ostandard input/output */
  }

/*
 * log�]�|�e��console 
 */
  openlog( ap_name , LOG_PID || LOG_CONS , facility );
}
static int dynamic_detect(void)
{
/*���d�@�Usignal�A�d��child process*/
  sys_signal(SIGINT, sig_int);
  sys_signal(SIGCHLD, sig_chld); 
  sys_signal(SIGPIPE, sig_pipe);
  sys_signal(SIGUSR1, SIG_IGN);
  sys_signal(SIGUSR2, SIG_IGN);
  
  for(;;)
  {
    printf("dynamic detect...\n");
    sleep(1);
  }

}

static int main_server(int argc , char **argv , int flag)
{
  int       index;
  int       listenfd;
  int       connfd;
  socklen_t   addrlen;
  socklen_t   clilen;
  struct sockaddr *cliaddr;

/* initial thread_count & client_count */
#ifdef DYNAMIC_THREAD
  thread_count = client_count = 0 ;
#endif
  listenfd = -1;

  sprintf(server_port , "%d" , ARNI_SERVER_PORT);
  
  if( flag != 1)
  {
    if(argc == 2 && !strcmp(argv[1], "-d") )
    {
      listenfd = tcp_listen(NULL, server_port , &addrlen);
    }
    else { 
      if (argc >= 2) {
        sprintf(server_port , "%s" , argv[1]);
        listenfd = tcp_listen(NULL, server_port, &addrlen);
      }
      else {
        DEBUG_PRINT("usage: arni_server <port#>\n\n");
        sys_exit(0);
      }
    }
  }
  else {
    listenfd = tcp_listen(NULL, server_port, &addrlen);
  }

  arni_add_modules();

  cliaddr = sys_malloc(addrlen);

  nthreads = SERVER_THREAD;
  
  if(flag == 1)
  {
    free(thread_ptr);
    thread_ptr = sys_calloc(nthreads, sizeof(struct THREAD_POOL));
    sleep(5);
  }
  thread_ptr = sys_calloc(nthreads, sizeof(struct THREAD_POOL));

  iget = iput = 0;

  for (index = 0; index < nthreads; ++index) {
    thread_make(index); /* only main thread returns */
  }
  sleep(10);
  for (;;) {
    clilen = addrlen;
    connfd = accept(listenfd, cliaddr, &clilen);

    pthread_mutex_lock(&clifd_mutex);
    client_fd[iput] = connfd;
    if (++iput == MAX_CLIENT) {
      iput = 0;
    }
    if (iput == iget)  {
      sys_error("iput = iget = %d", iput);
      exit(0);
    }


#ifdef DYNAMIC_THREAD
    if (client_count >= thread_count-1)
    {
      if( index+1 >= MAX_CLIENT )
        index = 0;
      thread_make(index++);
    }
#endif
    pthread_cond_signal(&clifd_cond);
    pthread_mutex_unlock(&clifd_mutex);
  } /* for (;;) */

/* remove registed module */
  arni_remove_modules();
  return 0;

}

int main(int argc, char *argv[])
{
  pid_t     child_pid;
  pid_t     cur_pid;
  FILE      *fp;


  if( argc == 2 && !strcmp( argv[1] , "-d" ) ) /* daemon mode */
  {
    start_daemon(argv[0] , 0);
  } 

  chdir(ARNI_SERVER_HOME); /* ���ެO���Odaemon mode , �̫�bchange dir ��server home directory */

  cur_pid = getpid();
  if( !(fp = fopen(ARNI_PID_FILE , "w")) )
  {
    sys_log(ERR_SYSTEM_LOG , "log pid error\n");
  }
  else {
    fprintf(fp , "%d\t%d" , cur_pid , ARNI_SERVER_PORT);
    fclose(fp);
  }
  
  if( (child_pid = sys_fork()) ) /*parent process*/
  {
    return dynamic_detect();
  }
  else {                       /*child process*/
    return main_server(argc, argv, 0);
  } /* end of child process */
  return 0;
}

