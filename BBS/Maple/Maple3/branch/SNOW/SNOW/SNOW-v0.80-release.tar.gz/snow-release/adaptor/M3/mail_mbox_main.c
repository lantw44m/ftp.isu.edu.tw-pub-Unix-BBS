/*
 *  $Id: mail_mbox_main.c,v 1.6 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_MAIL_MBOX_MAIN

#include <stdio.h>
#include "w3if_mail.h"

int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 2) {
		printf("Usage: %s <user-id>\n", argv[0]);
		return 0;
	}

	ret = mail_mbox(fileno(stdout), argv[1]);

	if (ret < 0) {
#ifdef DEBUG_MAIL_MBOX_MAIN
		fprintf(stderr, "mail_mbox error(%d).\n", ret);
#endif /* DEBUG_MAIL_MBOX_MAIN */
	}

	return 0;
}


