<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("��ܭӤH�ɮ�");

$SNOW_PAGE_TITLE = "��ܭӤH�ɮ�";
$SNOW_PAGEAREA_MAIN = "user_personal_files.m.php";
$SNOW_PAGEAREA_FUNC = "user_personal_files.f.php";

include("bone.php");

?>