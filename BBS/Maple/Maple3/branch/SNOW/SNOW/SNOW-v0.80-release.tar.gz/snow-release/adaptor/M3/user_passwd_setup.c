/*
 * $Id: user_passwd_setup.c,v 1.4 2000/10/25 12:31:55 jeffhung Exp $
 */

#undef DEBUG_USER_PASSWD_SETUP

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_user.h"
#include "w3if_session.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <string.h>
#include "w3ifglobal.h"
#include "dao.h"
#include "w3iflib.h"


#ifdef AS_ARNI_MODULE

int mod_user_passwd_setup(int ofd, char *sid, struct ARNI_ARGS *parg)
{
    return user_passwd_setup(ofd, sid, parg->args[0].s, parg->args[1].s);
}

#endif /* AS_ARNI_MODULE */



int user_passwd_setup(int ofd, char *sid, char *passwd, char *newpasswd)
{
	W3IF_SESSENTRY *psess;

	chdir(BBSHOME);

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	psess = w3ifsession_get(sid);

	write(ofd, "MRR-RESULT:user_passwd_setup\n",
	      strlen("MRR-RESULT:user_passwd_setup\n"));

	if (!psess) {
		write(ofd, "RESULT:no such user\n",
		      strlen("RESULT:no such user\n"));
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;
	acct_load(&cuser, cutmp->userid);

	if (chkpasswd(cuser.passwd, passwd)) {
		write(ofd, "RESULT:wrong password\nMRR-END:\n",
		      strlen("RESULT:wrong password\nMRR-END:\n"));
		return -999; /* wrong passwd */
	}

	strncpy(cuser.passwd, genpasswd(newpasswd), PASSLEN);

	acct_save(&cuser);

	write(ofd, "RESULT:OK\nMRR-END:\n", strlen("RESULT:OK\nMRR-END:\n"));

	return 0;
}



