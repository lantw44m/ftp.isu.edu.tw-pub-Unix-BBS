/*
 *  $Id: w3iflib.h,v 1.5 2000/10/25 12:31:55 jeffhung Exp $
 */

#ifndef	W3IFLIB_H_INCLUDED
#define	W3IFLIB_H_INCLUDED

#define	FN_W3IF_LOG	".W3IFLOG"
#include "bbs.h"

/*
 *  acct_lib
 */
void acct_save(ACCT *acct);
int ban_addr(char *addr);

/*
 *  talk_lib
 */
char *bmode(UTMP *utmp , int simple);
int can_override(UTMP *up);


/*
 *  board_lib
 */

int brh_unread(time_t chrono);
void brh_visit(int mode);
int brh_add(time_t prev, time_t chrono, time_t next);


/*
 *  cache_lib
 */
void* shm_attach(int shmkey, int shmsize);
void attach_err(int shmkey, char* name);


/*
 *  mail_lib
 */
int m_query(char* userid);
int mbox_attr(int type);


/*
 *  w3if_lib
 */
void w3if_log(char* mode, char* msg);
char *w3if_getCorrectUserID(char *userid);


/*
 *  post_lib
 */
int post_attr(HDR *fhdr);


#endif	/* W3IFLIB_H_INCLUDED */

