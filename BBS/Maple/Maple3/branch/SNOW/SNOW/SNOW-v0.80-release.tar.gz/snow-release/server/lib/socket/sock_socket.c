/*
 * 
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation 
 * bbs, the cross-media distributed communication platform. And it is 
 * developed by Cyberwork Solution in 2000.
 * 
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 * 
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or (at 
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or 
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution.com , Isabel Ho
 *
 */
                               
#include "socket_lib.h"
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
#include <poll.h>
#include <sys/ioctl.h>
#include <sys/uio.h>
/*
 *  JeffHung.20000821:
 *
 *  for struct msghdr.msg_iov, <sys/socket.h> didn't include <sys/uio.h>
 */
#include "system_lib.h"


int sock_accept(int fd, struct sockaddr *sa, socklen_t *salenptr)
{
	int	n;

	do {
		if ((n = accept(fd, sa, salenptr)) >= 0) {
			return(n); 
		}
	}

#ifdef EPROTO
	while (errno == EPROTO || errno == ECONNABORTED)
		;
#else	/* EPROTO */
	while (errno == ECONNABORTED)
		;
#endif	/* EPROTO */

	sys_error("accept error");
	return n;
}

int sock_bind(int fd, const struct sockaddr *sa, socklen_t salen)
{
	int result;

	if ((result = bind(fd, sa, salen)) < 0) {
		sys_error("bind error");
	}
	return result;
}

int sock_connect(int fd, const struct sockaddr *sa, socklen_t salen)
{
	int	result;

	if ((result = connect(fd, sa, salen)) < 0) {
		sys_error("connect error");
	}
	return result;
}

int sock_getpeername(int fd, struct sockaddr *sa, socklen_t *salenptr)
{
	int	result;

	if ((result = getpeername(fd, sa, salenptr)) < 0) {
		sys_error("getpeername error");
	}
	return result;
}

int sock_getsockname(int fd, struct sockaddr *sa, socklen_t *salenptr)
{
	int	result;

	if ((result = getsockname(fd, sa, salenptr)) < 0) {
		sys_error("getsockname error");
	}
	return result;
}

int sock_getsockopt(int fd, int level, int optname, void *optval,
                    socklen_t *optlenptr)
{
	int	result;

	if ((result = getsockopt(fd, level, optname, optval, optlenptr)) < 0) {
		sys_error("getsockopt error");
	}
	return result;
}

/* include Listen */

int sock_listen(int fd, int backlog)
{
	char	*ptr;
	int		result;

	/* 4can override 2nd argument with environment variable */
	if ((ptr = getenv("LISTENQ")) != NULL) {
		backlog = atoi(ptr);
	}

	if ((result = listen(fd, backlog)) < 0) {
		sys_error("listen error");
	}
	return result;
}

/* end Listen */

#ifdef	HAVE_POLL

int sock_poll(struct pollfd *fdarray, unsigned long nfds, int timeout)
{
	int	n;

	if ((n = poll(fdarray, nfds, timeout)) < 0) {
		sys_error("poll error");
	}

	return(n);
}

#endif	/* HAVE_POLL */

ssize_t sock_recv(int fd, void *ptr, size_t nbytes, int flags)
{
	ssize_t	n;

	if ((n = recv(fd, ptr, nbytes, flags)) < 0) {
		sys_error("recv error");
	}
	return(n);
}

ssize_t sock_recvfrom(int fd, void *ptr, size_t nbytes, int flags,
                      struct sockaddr *sa, socklen_t *salenptr)
{
	ssize_t	n;

	if ((n = recvfrom(fd, ptr, nbytes, flags, sa, salenptr)) < 0) {
		sys_error("recvfrom error");
	}
	return(n);
}

ssize_t sock_recvmsg(int fd, struct msghdr *msg, int flags)
{
	ssize_t	n;

	if ((n = recvmsg(fd, msg, flags)) < 0) {
		sys_error("recvmsg error");
	}
	return(n);
}

int sock_select(int nfds, fd_set *readfds, fd_set *writefds, fd_set *exceptfds,
                struct timeval *timeout)
{
	int	n;

	if ((n = select(nfds, readfds, writefds, exceptfds, timeout)) < 0) {
		sys_error("select error");
	}
	return(n); /* can return 0 on timeout */
}

int sock_send(int fd, const void *ptr, size_t nbytes, int flags)
{
	int	result;

	if ((result = send(fd, ptr, nbytes, flags)) != nbytes) {
		sys_error("send error");
	}
	return result;
			
}

int sock_sendto(int fd, const void *ptr, size_t nbytes, int flags,
                const struct sockaddr *sa, socklen_t salen)
{
	int result;

	if ((result = sendto(fd, ptr, nbytes, flags, sa, salen)) != nbytes) {
		sys_error("sendto error");
	}
	return result;	
}

int sys_sendmsg(int fd, const struct msghdr *msg, int flags)
{
	int		i;
	ssize_t	nbytes;
	int		result;

	nbytes = 0;	/* must first figure out what return value should be */
	for (i = 0; i < msg->msg_iovlen; i++) {
		nbytes += msg->msg_iov[i].iov_len;
	}

	if ((result = sendmsg(fd, msg, flags)) != nbytes) {
		sys_error("sendmsg error");
	}
	return result;		
}

int sock_setsockopt(int fd, int level, int optname, const void *optval,
                    socklen_t optlen)
{
	int result;

	if ((result = setsockopt(fd, level, optname, optval, optlen)) < 0) {
		sys_error("setsockopt error");
	}
	return result;
}

int sock_shutdown(int fd, int how)
{
	int result;

	if ((result = shutdown(fd, how)) < 0) {
		sys_error("shutdown error");
	}
		
	return result;
}


/* include Socket */

int sock_socket(int family, int type, int protocol)
{
	int	n;

	if ((n = socket(family, type, protocol)) < 0) {
		sys_error("socket error");
	}
	return(n);
}

/* end Socket */

int sock_socketpair(int family, int type, int protocol, int *fd)
{
	int	n;

	if ((n = socketpair(family, type, protocol, fd)) < 0) {
		sys_error("socketpair error");
	}

	return n;
}

int sock_sockatmark(int fd)
{
	int	flag;

	if (ioctl(fd, SIOCATMARK, &flag) < 0) {
		sys_error("sockatmark error");
		return(-1);
	}
	return (flag != 0 ? 1 : 0);
}



