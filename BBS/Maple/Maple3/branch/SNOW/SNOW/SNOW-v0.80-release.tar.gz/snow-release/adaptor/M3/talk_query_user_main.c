/*
 *  $Id: talk_query_user_main.c,v 1.7 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_TALK_QUERY_USER_MAIN

#include <stdio.h>
#include "w3if_talk.h"


int main(int argc, char* argv[])
{

	if (argc != 2) {
		printf("Usage: %s <user-id>\n", argv[0]);
		return 0;
	}

	talk_query_user(fileno(stdout), argv[1]);

	return 0;
}

