/*
 *  $Id: w3if_lib.c,v 1.2 2000/11/07 07:47:12 jeffhung Exp $
 */

#undef	DEBUG_W3IF_LIB

#include "w3iflib.h"
#include "bbs.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include "dao.h"


char *w3if_getCorrectUserID(char *userid)
{
	static char	correct_userid[IDLEN + 1];
	struct stat	st;
	int			schemanum;
	FILE		*fp;
	SCHEMA		*schemabuf;
	int			i; /* generic i */

#ifdef	DEBUG_W3IF_LIB
	fprintf(stderr, "DEBUG(%s:%d): w3if_getCorrectUserID()\n", __FILE__, __LINE__);
#endif	/* DEBUG_W3IF_LIB */
	memset(correct_userid, 0, IDLEN + 1);

	if (lstat(BBSHOME "/.USR", &st) < 0) {
		return 0;	/* schema file doesn't exist */
	}
	schemanum = st.st_size / sizeof(SCHEMA);

	if (!(schemabuf = (SCHEMA*)malloc(sizeof(SCHEMA) * schemanum))) {
		return 0; /* allocate memory failed */
	}

	if (!(fp = fopen(BBSHOME "/.USR", "r"))) {
		return 0; /* unable to open schema file */
	}

#ifdef	DEBUG_W3IF_LIB
	fprintf(stderr, "DEBUG(%s:%d): sizeof(SCHEMA): %d, schemanum: %d.\n",
	        __FILE__, __LINE__, sizeof(SCHEMA), schemanum);
#endif	/* DEBUG_W3IF_LIB */

	/* read in all stuffs */
	if ((schemanum = fread(schemabuf, sizeof(SCHEMA), schemanum, fp)) < 0) {
		fclose(fp);
		return 0; /* unable to read from schema file */
	}

	fclose(fp);

#ifdef	DEBUG_W3IF_LIB
	fprintf(stderr, "DEBUG(%s:%d): find schema.\n", __FILE__, __LINE__);
#endif	/* DEBUG_W3IF_LIB */

	for (i = 0; i < schemanum; ++i) {
		if (!strncasecmp(schemabuf[i].userid, userid, IDLEN)) {
			/* found it */
			strncpy(correct_userid, schemabuf[i].userid, IDLEN);
			free(schemabuf);
			return correct_userid;
		}
	}

	free(schemabuf);
	return 0; /* not found */
}


void w3if_log(char* mode, char* msg)
{
	char	buf[512];
	char	data[256];
	time_t	now;

	time(&now);
	if (!msg) {
		msg = data;
		sprintf(data, "Stay: %ld (%d)", (now - ap_start) / 60, getpid());
	}

	sprintf(buf, "%s %s %-13s%s\n", Etime(&now), mode,
	        "[W3IF User]" /* cuser.userid*/, msg);
#if 0	/* use FN_W3IF_LOG instead */
	f_cat(FN_USIES, buf);
#else
	f_cat(FN_W3IF_LOG, buf);
#endif
}

