/*
 *  $Id: user_setup_email.c,v 1.7 2000/11/07 14:21:13 jeffhung Exp $
 */

#undef DEBUG_USER_SETUP_EMAIL

#include "w3if_user.h"
#include "w3if_session.h"
#include <unistd.h>
#include "bbs.h"
#include "w3ifglobal.h"
#include <string.h>
#include "w3iflib.h"

/* ARGSUSED 0 */

int user_setup_email(int ofd, char *sid, char *newemail)
{
	W3IF_SESSENTRY *psess;
	int            vtime;

	chdir(BBSHOME);

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	psess = w3ifsession_get(sid);

	if (!psess) {
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;
	acct_load(&cuser, cutmp->userid);

	if (not_addr(newemail)) {
		return -999; /* ���X�檺 E-mail address */
	}
	else if (ban_addr(newemail)) {
		return -999; /* �Q ban ���� E-mail address */
	}

#ifdef EMAIL_JUSTIFY

	vtime = bsmtp(NULL, NULL, newemail, MQ_JUSTIFY);

	if (vtime == -3) {
		return -999; /* �e�H�s�u�إߥ��� */
	}
	else if (vtime == -1) {
		return -999; /* ���H�ݩڨ��{�ҫH��A�άO�ϥΪ̤��s�b */
	}

	if (vtime < 0) {
		/* Thor.991203: ���ӬO���|�]�o�q�F */
		return -999; /* �����{�ҫH��L�k�H�X�A�Х��T��g E-mail address */
	}

	cuser.userlevel &= ~(PERM_VALID /* | PERM_POST | PERM_PAGE */ );
	cuser.vtime = vtime;
	strcpy(cuser.email, newemail);
	acct_save(&cuser);

#endif /* EMAIL_JUSTIFY */

	return 0;
}

