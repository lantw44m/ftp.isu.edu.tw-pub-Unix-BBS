/*
 *  $Id: bbs_login_main.c,v 1.6 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_BBS_LOGIN_MAIN

#include <stdio.h>
#include "w3if_bbs.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 7) {
		printf("Usage: %s <session-id> <user-id> <password>"
		       " <rusername> <fromhost> <fromip>\n", argv[0]);
		return 0;
	}

	ret = bbs_login(fileno(stdout), argv[1], argv[2], argv[3], argv[4],
	                argv[5], argv[6]);

	if (ret != 0) {
#ifdef DEBUG_BBS_LOGIN_MAIN
		fprintf(stderr, "bbs_login() error(%d).\n", ret);
#endif /* DEBUG_BBS_LOGIN_MAIN */
	}

	return 0;
}

