/*
 *  $Id: user_toggle_flag.c,v 1.6 2000/10/25 12:31:55 jeffhung Exp $
 */

#undef DEBUG_USER_TOGGLE_FLAG

#include "w3if_user.h"
#include "w3if_session.h"
#include "bbs.h"
#include <unistd.h>
#include <stdio.h>
#include "w3ifglobal.h"
#include <string.h>
#include <sys/types.h>
#include <sys/uio.h>
#include "w3iflib.h"

int user_toggle_flag(int ofd, char *sid, char *flagname)
{
	W3IF_SESSENTRY *psess;
	int            ufo;
	int            nflag;
	int            len;
	int            ufo_old;
	int            toggle_bit;

	chdir(BBSHOME);

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	psess = w3ifsession_get(sid);

	if (!psess) {
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;
	acct_load(&cuser, cutmp->userid);

	nflag = cuser.userlevel;
	if (!nflag) {
		len = 5;
	}
	else if (nflag & PERM_ADMIN) {
		/*
		 *  Thor.980910:
		 *
		 *  �ݪ`�N��PERM_ADMIN���F�i��acl, �ٶ��K�]�i�H�������N�F:P
		 */
		len = 21;
	}
	else if (nflag & PERM_CLOAK) {
		len = 20;
	}
	else {
		len = 13;
	}

#ifdef DEBUG_USER_TOGGLE_FLAG
	fprintf(stderr, "DEBUG(%s,%d):len:%d\n", __FILE__, __LINE__, len);
#endif /* DEBUG_USER_TOGGLE_FLAG */

	ufo_old = ufo = cuser.ufo;

#ifdef DEBUG_USER_TOGGLE_FLAG
	fprintf(stderr, "DEBUG(%s,%d):ufo_old:%x\n", __FILE__, __LINE__, ufo_old);
#endif /* DEBUG_USER_TOGGLE_FLAG */

	/* update ufo according to len */
	for (toggle_bit = 0; toggle_bit < user_flags_num; ++toggle_bit) {
		if (!strcasecmp(flagname, user_flags[toggle_bit])) {

#ifdef DEBUG_USER_TOGGLE_FLAG
			fprintf(stderr, "DEBUG(%s,%d):got flag named: %s\n",
			        __FILE__, __LINE__, flagname);
#endif /* DEBUG_USER_TOGGLE_FLAG */

			break;
		}
	}
	if (toggle_bit >= user_flags_num) {
		return -999; /* no such flag to toggle */
	}

	ufo ^= (1 << toggle_bit);

#ifdef DEBUG_USER_TOGGLE_FLAG
	fprintf(stderr, "DEBUG(%s,%d):ufo changed to %x\n",
	        __FILE__, __LINE__, ufo);
#endif /* DEBUG_USER_TOGGLE_FLAG */

	if (ufo == ufo_old) {
		return 0; /* no thing changed */
	}

	/* Thor.980805: �ѨM ufo BIFF���P�B���D */
	ufo = ((ufo & ~UFO_UTMP_MASK) | (cutmp->ufo & UFO_UTMP_MASK));

	/*
	 *  Thor.980805:
	 *
	 *  �n�S�O�`�N cuser.ufo�Mcutmp->ufo��UFO_BIFF���P�B���D,�A��
	 */
	cutmp->ufo = cuser.ufo = ufo;

#ifdef DEBUG_USER_TOGGLE_FLAG
	fprintf(stderr, "DEBUG(%s,%d):cuser.ufo:%x\n",
	        __FILE__, __LINE__, cuser.ufo);
#endif /* DEBUG_USER_TOGGLE_FLAG */

	/* save cuser back */
	acct_save(&cuser);

	write(ofd, "MRR-RESULT:user_toggle_flag\nRESULT:OK\n",
	      strlen("MRR-RESULT:user_toggle_flag\nRESULT:OK\n"));

	return 0;
}


