<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("����");

$SNOW_PAGE_TITLE = "����";
$SNOW_PAGEAREA_MAIN = "main.m.php";
$SNOW_PAGEAREA_FUNC = "main.f.php";

include("bone.php");

?>