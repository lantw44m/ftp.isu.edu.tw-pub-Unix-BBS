/*
 *  $Id: talk_query_user.c,v 1.8 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_TALK_QUERY_USER

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_talk.h"
#include "bbs.h"
#include <stdio.h>
#include "dao.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/uio.h>


#ifdef AS_ARNI_MODULE

/* ARGSUSED 1 */

int mod_talk_query_user(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return talk_query_user(ofd, parg->args[0].s);
}

#endif /* AS_ARNI_MODULE */


void showplans(char* userid)
{
	int		i;
	FILE*	fp;
	char	buf[256];

	usr_fpath(buf, userid, fn_plans);
	if ((fp = fopen(buf, "r")) != NULL) {
		i = MAXQUERYLINES;
		while (i-- && fgets(buf, sizeof(buf), fp)) {
			printf("%s", buf);
		}
		fclose(fp);
	}
}


int talk_query_user(int ofd, char *userid_toquery)
{
	ACCT  acctoq;
	UTMP* up;
	char  buf[1024];
	int   i;
	FILE* fp;
	char  rbuf[512];

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

#ifdef DEBUG_TALK_QUERY_USER
	fprintf(stderr, "DEBUG(%s,%d):begin talk_query_user\n",
	        __FILE__, __LINE__);
#endif /* DEBUG_TALK_QUERY_USER */

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	acct_load(&acctoq, userid_toquery);

#ifdef DEBUG_TALK_QUERY_USER
	fprintf(stderr, "DEBUG(%s,%d):load acct:userno: %d\n",
	        __FILE__, __LINE__, acctoq.userno);
#endif /* DEBUG_TALK_QUERY_USER */

	up = (acctoq.lastlogin < time(0) - 6 * 3600) ? 0 :
	                                               utmp_find(acctoq.userno);

#ifdef DEBUG_TALK_QUERY_USER
	fprintf(stderr, "DEBUG(%s,%d):get up:%p\n", __FILE__, __LINE__, up);
#endif /* DEBUG_TALK_QUERY_USER */

	sprintf(buf, "MRR-RESULT:talk_query_user\n"
	             "USERID:%s\n"
	             "USERNAME:%s\n"
	             "NUM-LOGINS:%d\n"
	             "NUM-POSTS:%d\n"
	             "ACCOUNT-VALID:%s\n"
	             "LAST-LOGIN:%s\n"
	             "LAST-FORM:%s\n"
	             "MODE:%s\n"
	             "NEW-MAIL:%s\n",
	             acctoq.userid,
	             acctoq.username,
	             acctoq.numlogins,
	             acctoq.numposts,
	             ((acctoq.userlevel & PERM_VALID) ? "YES" : "NA"),
	             Ctime(&(acctoq.lastlogin)),
	             acctoq.lasthost,
	             (up && (HAS_PERM(PERM_SEECLOAK) || !(up->ufo & UFO_CLOAK))) ?
	                 bmode(up, 1) : "���b���W",
	             (m_query(acctoq.userid) ? "YES" : "NA"));
	write(ofd, buf, strlen(buf));


#if	defined(REALINFO) && defined(QUERY_REALNAMES)

	if (HAS_PERM(PERM_BASIC)) {
		sprintf(buf, "REAL-NAME:%s\n", acctoq.realname);
		write(ofd, buf, strlen(buf));
	}

#endif	/* REALINFO && QUERY_REALNAMES */

    usr_fpath(rbuf, acctoq.userid, fn_plans);
    if ((fp = fopen(rbuf, "r")) != NULL) {
        i = MAXQUERYLINES;
        while (i-- && fgets(rbuf, sizeof(rbuf), fp)) {
			if (i < (MAXQUERYLINES - 1)) {
				write(ofd, "CONTINUE:", strlen("CONTINUE:"));
			}
			else {
				write(ofd, "NOTE:", strlen("NOTE:"));
			}
            sprintf(buf, "%s", rbuf);
			write(ofd, buf, strlen(buf));
        }
        fclose(fp);
    }

	write(ofd, "MRR-END:\n", strlen("MRR-END:\n"));

	return 0;
}


