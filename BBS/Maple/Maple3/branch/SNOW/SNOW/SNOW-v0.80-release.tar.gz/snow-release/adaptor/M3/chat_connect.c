/*
 * $Id: chat_connect.c,v 1.14 2000/11/14 16:51:48 arlo Exp $
 */

#undef DEBUG_CHAT_CONNECT

#include "w3if_chat.h"
#include "live_server.h"
#include <string.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <sys/socket.h>
#include "w3if_general.h"
#include <stdio.h>
#include "bbs.h"

int mod_chat_connect(int ofd, char *sid, struct LIVE_ARGS *args)
{
	char *userid;
	char *chatid;
	char *action;
	char *message;
	char *type;

	userid  = args->args[0].s;
	chatid  = args->args[1].s;
	action  = args->args[2].s;
	message = args->args[3].s;
	type    = args->args[4].s;

	return chat_connect(ofd, sid, userid, chatid, action, message, type);
	
}

static int printchatline(int ofd, char *msg)
{
	return write(ofd, msg, strlen(msg));      
}

static int recv_data(int fd, int ofd)
{
	char buf[512];
	int  len;
	int  buf_size;

	buf_size = sizeof(buf);
	memset(buf, 0, buf_size);

	if ((len = recv(fd, buf, buf_size, 0)) <= 0) {
		return -1;
	}

	printchatline(ofd, buf);
	return 0;
}


/*
 * Argument: ofd     -> �ǹL�Ӫ� socket fd
 *           sid     -> Session ID
 *           UserID  -> �ϥΪ�ID
 *           ChatID  -> chat �Ϊ�ID
 *           Action  -> �ϥΪ̰ʧ@
 *           Message -> �T��
 *           Type    -> �T������
 */

int chat_connect(int ofd, char *sid, char *UserID, char *ChatID,
                 char *Action, char *Message, char *Type)
{
	char               buf[GENERAL_BUFSIZE];
#if 0 /* JeffHung.20001025: recv_buf is unused */
	char               recv_buf[128];
#endif /* 0 */
	char               out_buf[512];
	struct sockaddr_in sin;
	int                fd;

	chdir(BBSHOME);

	sin.sin_family = AF_INET;
	sin.sin_port = htons(LIVE_SERVER_PORT);
	/* ���� address any , �H��A�令�� flixable */
	sin.sin_addr.s_addr = INADDR_ANY; 
	memset(sin.sin_zero, 0, sizeof(sin.sin_zero));
	fd = socket(AF_INET, SOCK_STREAM, 0);
 

	if (fd < 0) {
		return -1;
	}

	if (connect(fd, (struct sockaddr*)&sin, sizeof(sin))) {
		close(fd);

#ifdef DEBUG_CHAT_CONNECT
		fprintf(stderr, "connect fail\n");
#endif /* DEBUG_CHAT_CONNECT */

		return -1;
	}
#ifdef DEBUG_CHAT_CONNECT
	fprintf(stderr, "chat_connect:connect ok\n");
#endif /* DEBUG_CHAT_CONNECT */
 
	snprintf(buf, GENERAL_BUFSIZE,
	         "MRR-REQUEST:chat_client\n"
	         "MRR-SID:%s\n"
	         "USERID:%s\n"
	         "CHATID:%s\n"
	         "ACTION:%s\n"
	         "MESSAGE:%s\n"
	         "TYPE:%s\n"
	         "MRR-END:\n",
	         sid,
	         UserID,
	         ChatID,
	         Action,
	         Message,
	         Type);

#ifdef DEBUG_CHAT_CONNECT
	fprintf(stderr, "writing to xchatd\n");
#endif /* DEBUG_CHAT_CONNECT */

	write(fd, buf, strlen(buf));

	if (!strcasecmp(Action, "enter")) {
		snprintf(out_buf, 128,
		         "MRR-RESULT:chat_connect\n"
		         "NO-MSG:YES\n"
		         "MRR-END:\n");
		write(ofd, out_buf, strlen(out_buf)); 
		close(fd);
	}

/* �@����Data�����_�u */
	for (  ; recv_data(fd,ofd) >= 0; )
		;

  
#if 0
	close(fd);
#endif /* 0 */
  return 0;
}

