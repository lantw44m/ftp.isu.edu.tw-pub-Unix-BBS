/*
 *  $Id: mail_delete_range.c,v 1.7 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_MAIL_DELETE_RANGE

#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */
#include "w3if_mail.h"
#include "bbs.h"
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/uio.h>
#include <string.h>
#include "dao.h"
#include <stdlib.h>

#ifdef AS_ARNI_MODULE

/* ARGSUSED 1 */

int mod_mail_delete_range(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return mail_delete_range(ofd, parg->args[0].s, parg->args[1].s,
	                         parg->args[2].s);
}

#endif /* AS_ARNI_MODULE */


int mail_delete_range(int ofd, char *userid, char *startfname, char *endfname)
{
	char		lower_userid[IDLEN + 1];
	char		fpath[MAXPATHLEN];
	struct stat	st;
	int			mailnum;
	HDR			*mailbuf;
	FILE		*mailfp;
	int			i; /* generic i */
	int			startpos; /* start position of delete range */
	int			endpos; /* end position of delete range */
	char		fnewpath[MAXPATHLEN];
	FILE		*nmailfp; /* new mail index file */
	int			nmailnum;
	char		fdelpath[MAXPATHLEN];

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

	write(ofd, "MRR-RESULT:mail_delete_range\n",
	      strlen("MRR-RESULT:mail_delete_range\n"));

	/* prevent buffer overflow */
	if (strlen(userid) > IDLEN) {
		userid[IDLEN] = 0;
	}

	str_lower(lower_userid, userid);
	snprintf(fpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/" FN_DIR,
	         lower_userid[0], lower_userid);

	if (lstat(fpath, &st) < 0) {
		write(ofd, "RESULT:mailbox index file not found\nMRR-END:\n",
		      strlen("RESULT:mailbox index file not found\nMRR-END:\n"));
		return -999; /* mailbox index file not found */
	}
	mailnum = st.st_size / sizeof(HDR);

	if (!(mailbuf = (HDR*)malloc(sizeof(HDR) * mailnum))) {
		write(ofd, "RESULT:allocate memory error\nMRR-END:\n",
		      strlen("RESULT:allocate memory error\nMRR-END:\n"));
		return -999; /* allocate memory error */
	}
	memset(mailbuf, 0, sizeof(HDR) * mailnum);

	if (!(mailfp = fopen(fpath, "r"))) {
		free(mailbuf);
		write(ofd, "RESULT:open mailbox index file error\nMRR-END:\n",
		      strlen("RESULT:open mailbox index file error\nMRR-END:\n"));
		return -999; /* open mailbox index file error */
	}

	/* read all stuffs into buffer */
	if ((mailnum = fread(mailbuf, sizeof(HDR), mailnum, mailfp)) < 0) {
		fclose(mailfp);
		free(mailbuf);
		write(ofd, "RESULT:read mailbox index file error\nMRR-END:\n",
		      strlen("RESULT:\nMRR-END:\n"));
		return -999; /* read mailbox index file error */
	}

	fclose(mailfp);

	/* JeffHung.20000721: -1 means not found yet */
	startpos = -1;
	endpos = -1;
	for (i = 0; i < mailnum; ++i) {
		if (!strcmp(mailbuf[i].xname, startfname)) {
			startpos = i;
		}
		if (!strcmp(mailbuf[i].xname, endfname)) {
			endpos = i;
		}
		if ((startpos != -1) && (endpos != -1)) {
			/* JeffHung.20000721: both found */
			break;
		}
	}

	if ((startpos == -1) || (endpos == -1) || (endpos < startpos)) {
		write(ofd, "RESULT:range error\nMRR-END:\n",
		      strlen("RESULT:range error\nMRR-END:\n"));
		return -999; /* range error */
	}

	/*
	 *  write to new index file
	 *
	 *  JeffHung.20000724: f_new and hdr_prune are too dirty, so I'll do
	 *  it by my self.
	 */
	snprintf(fnewpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/" FN_DIR ".n",
	         lower_userid[0], lower_userid);

	if (!(nmailfp = fopen(fnewpath, "w"))) {
		free(mailbuf);
		write(ofd, "RESULT:can not open new mail index file\nMRR-END:\n",
		      strlen("RESULT:can not open new mail index file\nMRR-END:\n"));
		return -999; /* can not open new mail index file */
	}

	for (i = 0, nmailnum = 0; i < mailnum; ++i) {
		if ((mailbuf[i].xmode & MAIL_MARKED) || /* mark */
		    ((i < startpos) || (i > endpos)) || /* range */
		    (!startpos && Tagger(mailbuf[i].chrono, i - 1, TAG_NIN))) { /* TagList */
			/* keep mail */
			if (fwrite(&(mailbuf[i]), sizeof(HDR), 1, nmailfp) != 1) {
				free(mailbuf);
				fclose(nmailfp);
				unlink(fnewpath);
				write(ofd, "RESULT:unable to write to new mail index file\n"
				           "MRR-END:\n",
				      strlen("RESULT:unable to write to new mail index file\n"
				           "MRR-END:\n"));
				return -999; /* unable to write to new mail index file */
			}
			++nmailnum;
		}
		else {
			/* delete mail */
			snprintf(fdelpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/@/%s",
			         lower_userid[0], lower_userid, mailbuf[i].xname);
			unlink(fdelpath);
		}
	}

	/* JeffHung:20000724: reuse fdelpath */
	snprintf(fdelpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/" FN_DIR ".o",
	         lower_userid[0], lower_userid);
	rename(fpath, fdelpath);
	if (nmailnum > 0) {
		rename(fnewpath, fpath);
	}
	else {
		unlink(fnewpath);
	}

	write(ofd, "RESULT:OK\nMRR-END:\n",
	      strlen("RESULT:\nMRR-END:\n"));

	return 0;
}


