/*
 *  $Id: talk_paladd_main.c,v 1.7 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_TALK_PALADD_MAIN

#include <stdio.h>
#include <stdlib.h>
#include "w3if_talk.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 5) {
		printf("Usage: %s <session-id> <pal-id> <friendship> <is-bad>\n",
		       argv[0]);
		return 0;
	}

	ret = talk_paladd(fileno(stdout), argv[1], argv[2], argv[3],
	                  atoi(argv[4]));

	if (ret != 0) {
#ifdef DEBUG_TALK_PALADD_MAIN
		fprintf(stderr, "talk_paladd() error(%d).\n", ret);
#endif /* DEBUG_TALK_PALADD_MAIN */
	}

	return 0;
}

