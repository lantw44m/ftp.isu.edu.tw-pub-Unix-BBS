/*
 *  $Id: user_note_main.c,v 1.6 2000/11/07 14:21:12 jeffhung Exp $
 */

#undef DEBUG_USER_NOTE_MAIN

#include <stdio.h>
#include "w3if_user.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 1) {
		printf("Usage: %s\n", argv[0]);
		return 0;
	}

	ret = user_note(fileno(stdout));

	if (ret < 0) {
#ifdef DEBUG_USER_NOTE_MAIN
		fprintf(stderr, "user_note error(%d).\n", ret);
#endif /* DEBUG_USER_NOTE_MAIN */
	}

	return 0;
}

