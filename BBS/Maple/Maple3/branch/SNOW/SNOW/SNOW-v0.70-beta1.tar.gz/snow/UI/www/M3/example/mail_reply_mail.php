<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�^�Я����H��");

$mrr = array(
	"mail_readmail" => array(
		0 => array(
			"MRR-SID" => array(0 => session_id()),
			"USERID" => array(0 => $sUserID),
			"FILENAME" => array(0 => $iFilename)
		)
	)
);

$result = MRRquery($mrr);

$SNOW_PAGE_TITLE = "�^�Я����H��";
$SNOW_PAGEAREA_MAIN = "mail_reply_mail.m.php";
$SNOW_PAGEAREA_FUNC = "mail_reply_mail.f.php";

include("bone.php");

?>