/*
 *  $Id: talk_recvmsg_main.c,v 1.4 2000/10/05 20:59:53 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"
#include <stdio.h>


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 2) {
		printf("Usage: %s <session-id>\n", argv[0]);
		return 0;
	}

	if ((ret = talk_recvmsg(fileno(stdout), argv[1])) != 0) {
		fprintf(stderr, "talk_recvmsg() error(%d).\n", ret);
	}

	return 0;
}

