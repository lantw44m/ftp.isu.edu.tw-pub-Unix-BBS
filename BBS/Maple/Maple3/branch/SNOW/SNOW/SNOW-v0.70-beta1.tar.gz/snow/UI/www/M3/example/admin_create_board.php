<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�إ߷s�Q�װ�");

/*
 * Required Inputs: (none)
 */

$SNOW_PAGE_TITLE = "�إ߷s�Q�װ�";
$SNOW_PAGEAREA_MAIN = "admin_create_board.m.php";
$SNOW_PAGEAREA_FUNC = "admin_create_board.f.php";

include("bone.php");

?>