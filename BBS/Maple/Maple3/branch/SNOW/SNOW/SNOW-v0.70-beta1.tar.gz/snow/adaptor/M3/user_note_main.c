/*
 *  $Id: user_note_main.c,v 1.4 2000/10/05 20:59:53 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 1) {
		printf("Usage: %s\n", argv[0]);
		return 0;
	}

	if ((ret = user_note(fileno(stdout))) < 0) {
		fprintf(stderr, "user_note error(%d).\n", ret);
	}

	return 0;
}

