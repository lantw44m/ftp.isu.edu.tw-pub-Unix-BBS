/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution.com , Isabel Ho
 *
 */

/*
 *  $Id: mod_header.h,v 1.4 2000/10/05 20:59:53 jeffhung Exp $
 */

#ifndef	MOD_HEADER_H_INCLUDED
#define	MOD_HEADER_H_INCLUDED

#ifndef	ARNI_MOD_H_INCLUDED

#define	MOD_LEN			(32)

#ifndef	COMMAND_LEN
#define	COMMAND_LEN		(32)
#endif	/* COMMAND_LEN */

#define	SINGLE_TEXTLINE	(100)
#define	MULTI_TEXTLINE	(200)
#define	DATETIME		(300)
#define	INTEGER			(400)
#define	MIME			(500)


struct mod_pool_table;
struct mod_index_table;
struct mod_list_table;
struct mod_request_table;

typedef int (*mod_main_func)(int fd, struct mod_request_table *res_table);
typedef int (*mod_reg_func)(struct mod_pool_table *pool);
typedef int (*mod_unreg_func)(struct mod_pool_table *pool);

struct mod_request_table {
	char	*command;
	int		type;
	char	*content;
};
typedef struct mod_request_table	BBS_Mod_Request_Table;


struct mod_index_table {
	mod_main_func			main_func;
	char					name[MOD_LEN+1];  
	BBS_Mod_Request_Table	*list; 
};
typedef struct mod_index_table	BBS_Mod_Index_Table;

struct mod_list_table {
	char			name[MOD_LEN+1];
	mod_main_func	main_func;
	mod_reg_func	reg_func;
};
typedef struct mod_list_table	BBS_Mod_List_Table;


/* -------------------------------- */
/*   Module Pool                    */
/* -------------------------------- */

#define	UNSET	(0)
#define	SET		(1)

struct mod_pool_table {
	BBS_Mod_Index_Table	table;
	int					flag;
};
typedef struct mod_pool_table	BBS_Mod_Pool_Table;

/* export to module */

int mod_register_module(struct mod_request_table res_table[],
                        struct mod_pool_table *pool);
int mod_unregister_module(struct mod_pool_table *pool);


#endif	/* ARNI_MOD_H_INCLUDED */

#endif	/* MOD_HEADER_H_INCLUDED */

