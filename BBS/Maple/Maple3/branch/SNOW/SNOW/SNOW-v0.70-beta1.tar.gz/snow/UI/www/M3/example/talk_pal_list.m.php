<FORM METHOD="post" ACTION="">
	<P> 
		<INPUT TYPE="BUTTON" NAME="Submit4" VALUE="�Ĥ@��">
		<INPUT TYPE="BUTTON" NAME="Submit5" VALUE="�W�@��">
		<INPUT TYPE="BUTTON" NAME="Submit6" VALUE="�U�@��">
		<INPUT TYPE="BUTTON" NAME="Submit7" VALUE="�̥���">
		������� 
		<SELECT NAME="select2">
			<OPTION VALUE="1" SELECTED>1</OPTION>
			<OPTION VALUE="2">2</OPTION>
		</SELECT>
		��</P>
	<TABLE WIDTH="100%" BORDER="1">
		<TR> 
			<TH>�s��</TH>
			<TH>�N��</TH>
			<TH>�n��/�l��</TH>
			<TH>�ͽ�</TH>
		</TR>
		<TR> 
			<TD>1
				<INPUT TYPE="radio" NAME="radiobutton" VALUE="radiobutton">
			</TD>
			<TD><A HREF="talk_query_user.php">Arlo</A></TD>
			<TD>�n</TD>
			<TD>�D�D</TD>
		</TR>
		<TR> 
			<TD>2
				<INPUT TYPE="radio" NAME="radiobutton" VALUE="radiobutton">
			</TD>
			<TD><A HREF="talk_query_user.php">JeffHung</A></TD>
			<TD>�a</TD>
			<TD>�²�</TD>
		</TR>
		<TR> 
			<TD>3
				<INPUT TYPE="radio" NAME="radiobutton" VALUE="radiobutton">
			</TD>
			<TD><A HREF="talk_query_user.php">Kevin</A></TD>
			<TD>�n</TD>
			<TD>�Ĩ�</TD>
		</TR>
	</TABLE>
    <P>
		<INPUT TYPE="BUTTON" NAME="Submit42" VALUE="�Ĥ@��">
		<INPUT TYPE="BUTTON" NAME="Submit52" VALUE="�W�@��">
		<INPUT TYPE="BUTTON" NAME="Submit62" VALUE="�U�@��">
		<INPUT TYPE="BUTTON" NAME="Submit72" VALUE="�̥���">
		������� 
		<SELECT NAME="select3">
			<OPTION VALUE="1" SELECTED>1</OPTION>
			<OPTION VALUE="2">2</OPTION>
		</SELECT>
		��</P>
</FORM>