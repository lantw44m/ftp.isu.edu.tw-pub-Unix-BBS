/*
 *  $Id: talk_paldel_main.c,v 1.5 2000/10/05 20:59:53 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 3) {
		printf("Usage: %s <session-id> <pal-id>\n",
		       argv[0]);
		return 0;
	}

	if ((ret = talk_paldel(fileno(stdout), argv[1], argv[2])) != 0) {
		fprintf(stderr, "talk_paldel() error(%d).\n", ret);
	}

	return 0;
}

