<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�\Ū�H��");

$mrr = array(
	"mail_readmail" => array(
		0 => array(
			"USERID" => array(0 => $sUserID),
			"FILENAME" => array(0 => $iFilename)
		)
	)
);
printf("<!-- %s -->\n", serialize($mrr));
$result = MRRquery($mrr);
printf("<!-- %s -->\n", serialize($result));

$SNOW_PAGE_TITLE = "�\Ū�H��";
$SNOW_PAGEAREA_MAIN = "mail_read_mail.m.php";
$SNOW_PAGEAREA_FUNC = "mail_read_mail.f.php";

include("bone.php");

?>