/*
 *  $Id: talk_recvmsg.c,v 1.6 2000/10/05 20:59:53 jeffhung Exp $
 */

#undef DEBUG_TALK_RECVMSG

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"
#include "w3if_session.h"
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */

#ifdef AS_ARNI_MODULE

int mod_talk_recvmsg(int ofd, char *sid, struct ARNI_ARGS *parg)
{
    return talk_recvmsg(ofd, sid);
}

#endif /* AS_ARNI_MODULE */



int talk_recvmsg(int ofd, char *sid)
{
	W3IF_SESSENTRY *psess;
	char           buf[128];
	int            i;
	int            j;
	int            userno;
	int            locus;
	BMW            bmw[BMW_PER_USER];
	BMW            *mptr;
	BMW            **mslot;

	chdir(BBSHOME);

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	psess = w3ifsession_get(sid);

	if (!psess) {
		write(ofd, "MRR-RESULT:talk_recvmsg\n"
		           "RESULT:no such user\nMRR-END:\n",
		      strlen("MRR-RESULT:talk_recvmsg\n"
		             "RESULT:no such user\nMRR-END:\n"));
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;
	acct_load(&cuser, cutmp->userid);

	/* bmw_rqst() */

	/* download BMW slot first */

	i = j = 0;
	userno = cuser.userno;
	mslot = cutmp->mslot;

	while (mptr = mslot[i]) {
		mslot[i] = NULL;
		if (mptr->recver == userno) {
			bmw[j++] = *mptr;
		}
		mptr->btime = 0;

		if (++i >= BMW_PER_USER) {
			break;
		}
	}
	psess->has_msg = 0;

	/* process the request */

	/* write(...): j == msg count */

	if (j) {

#if 0
		sprintf(buf, "MSG-COUNT:%d\n", j);
		write(ofd, buf, strlen(buf));
#endif /* 0 */

#if 0 /* JeffHung.20000901: ���ݭn�A���� front-end ���C*/
		locus = bmw_locus;
		i = locus + j - BMW_LOCAL_MAX;
		if (i >= 0) {
			locus -= i;
			memcpy(bmw_lslot, bmw_lslot + i, locus * sizeof(BMW));
		}
#endif /* 0 */

		i = 0;
		do {
			mptr = &bmw[i];
			usr_fpath(buf, cuser.userid, FN_BMW);
			rec_add(buf, &bmw[i], sizeof(BMW));

			sprintf(buf, "MRR-RESULT:talk_recvmsg\n"
			             "SEND-TIME:%d\n"
			             "FROM-USERID:%s\n"
			             "FROM-PID:%d\n"
			             "MESSAGE:%s\n",
			        mptr->btime, mptr->userid, mptr->caller->pid, mptr->msg);
			write(ofd, buf, strlen(buf));

#if 0 /* JeffHung.20000901: ���ݭn�A���� front-end ���C*/
			bmw_lslot[locus++] = *mptr;
#endif /* 0 */
		} while (++i < j);

#if 0 /* JeffHung.20000901: ���ݭn�A���� front-end ���C*/
		bmw_locus = locus;
#endif /* 0 */
	}
	else {
		write(ofd, "MRR-RESULT:talk_recvmsg\nNO-MSG:YES\n",
		      strlen("MRR-RESULT:talk_recvmsg\nNO-MSG:YES\n"));
	}

	write(ofd, "MRR-END:\n", strlen("MRR-END:\n"));

	return 0;
}

