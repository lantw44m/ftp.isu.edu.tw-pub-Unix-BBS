/*
 * $Id: user_passwd_setup_main.c,v 1.2 2000/10/05 20:59:53 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 4) {
		printf("Usage: %s <session-id> <old-password> <new-password>\n",
		       argv[0]);
		return 0;
	}

	if ((ret = user_passwd_setup(fileno(stdout), argv[1], argv[2], argv[3])) < 0) {
		fprintf(stderr, "user_passwd_setup error(%d).\n", ret);
	}

	return 0;
}

