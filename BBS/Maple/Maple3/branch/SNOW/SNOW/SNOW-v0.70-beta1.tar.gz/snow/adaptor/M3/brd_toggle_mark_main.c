/*
 *  $Id: brd_toggle_mark_main.c,v 1.3 2000/09/30 11:40:11 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 3) {
		printf("Usage: %s <board-id> <post-file-name>\n", argv[0]);
		return 0;
	}

	if ((ret = brd_toggle_mark(fileno(stdout), argv[1], argv[2])) < 0) {
		fprintf(stderr, "brd_toggle_mark error(%d).\n", ret);
	}

	return 0;
}

