<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();

$mrr = array(
	"talk_recvmsg" => array(
		0 => array(
			"MRR-SID" => array(0 => session_id())
		)
	)
);

$result = MRRquery($mrr);
$msgs = $result["talk_recvmsg"];
if ((count($msgs) == 1) && isset($msgs[0]["NO-MSG"][0]) && ($msgs[0]["NO-MSG"][0] == "YES")) {
	$noMsg = TRUE;
}
else {
	$noMsg = FALSE;
}

?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE>message</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=big5">
<META NAME="Generator" CONTENT="">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
<STYLE TYPE="text/css">
<!--

a:link		{	color: blue;	text-decoration: none;	}
a:visited	{	color: blue;	text-decoration: none;	}
a:hover		{	color: red;		text-decoration: none;	}
a:active	{	color: red;		text-decoration: none;	}

-->
</STYLE>
<SCRIPT LANGUAGE="JavaScript">
<!--

function Is()
{
	var agent = navigator.userAgent.toLowerCase();
	this.major = parseInt(navigator.appVersion);
	this.minor = parseFloat(navigator.appVersion);
	this.ns = ((agent.indexOf("mozilla") != -1) &&
	          ((agent.indexOf("spoofer") == -1) &&
			   (agent.indexOf("compatible") == -1)));
	this.ns2 = (this.ns && (this.major == 2));
	this.ns3 = (this.ns && (this.major == 3));
	this.ns4 = (this.ns && (this.major >= 4));
	this.ie = (agent.indexOf("msie") != -1);
	this.ie3 = (this.ie && (this.major == 2));
	this.ie4 = (this.ie && (this.major >= 4));
	this.op3 = (agent.indexOf("opera") != -1);
}

var is = new Is();

//-->
</SCRIPT>
<SCRIPT LANGUAGE="JavaScript">
<!--

function reloadMessage()
{
	if (is.ie4) {
		location = "msg.php";
	}
	else if (is.ns4) {
		document.layers.lyrMessageCarrier.load("msg.php", 200);
	}
}

<?php if ($noMsg) { ?>

// if has no message
setTimeout("reloadMessage();", 60000); // this number indicate how often to reload.

<?php } else { ?>

// if has messages

function replyMessage()
{
	var rmsg = document.fMessageBar.iMessage.value;
	var rto = document.fMessageBar.iReplyTo[document.fMessageBar.iReplyTo.selectedIndex].value
	var url = "msg.php?iReplyTo=" + rto + "&iMessage=" + rmsg;

	alert(url);

	if (is.ie4) {
		location = url;
	}
	else if (is.ns4) {
		//alert(document.layers.lyrMessageCarrier.name);
		document.layers["lyrMessageCarrier"].load(url, 400);
	}
}

<?php } ?>


//-->
</SCRIPT></HEAD>

<BODY BGCOLOR="white">

<!-- if has messages -->

<?php if ($noMsg) { ?>

<!-- if has no message -->
�S���s�T���C

<?php } else { ?>

<FORM NAME="fMessageBar" METHOD="POST" ACTION="">
	�ήɶǰT�G
	<SELECT NAME="iReplyTo">
		<?php

		for ($i = count($msgs) - 1; $i >= 0; --$i) {
			printf("<OPTION VALUE=\"%s\">%s(%d): %s</OPTION>\n",
				   $msgs[$i]["FROM-PID"][0], $msgs[$i]["FROM-USERID"][0],
				   $msgs[$i]["SEND-TIME"][0], $msgs[$i]["MESSAGE"][0]);
		}

		?>
	</SELECT>
	�^�аT���G<INPUT TYPE="text" NAME="iMessage" VALUE="">
	<INPUT TYPE="button" VALUE="�e�X�T��" onClick="replyMessage(); return false;">
	<INPUT TYPE="button" VALUE="�����T��" onClick="reloadMessage(); return false;">
</FORM>

<?php } ?>

</BODY>
</HTML>
