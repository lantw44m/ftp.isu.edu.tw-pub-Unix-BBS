/*
 *  $Id: talk_sendmsg.c,v 1.5 2000/10/05 20:59:53 jeffhung Exp $
 */

#undef DEBUG_TALK_SENDMSG

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"
#include <stdlib.h> /* for malloc/free */
#include <time.h>
#include <string.h>
#include <sys/param.h>
#include "w3if_session.h"
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */

#ifdef AS_ARNI_MODULE

int mod_talk_sendmsg(int ofd, char *sid, struct ARNI_ARGS *parg)
{
    return talk_sendmsg(ofd, sid, parg->args[0].i, parg->args[1].s);
}

#endif /* AS_ARNI_MODULE */


static int bmw_send(UTMP *callee, BMW *bmw)
{
	BMW    *mpool;
	BMW    *mhead;
	BMW    *mtail;
	BMW    **mslot;
	int    i;
	pid_t  pid;
	time_t texpire;

#ifdef DEBUG_TALK_SENDMSG

	fprintf(stderr, "DEBUG(%s,%d): enter bmw_send(): "
	                "callee->userno: %d, bmw->recver: %d\n",
	        __FILE__, __LINE__, callee->userno, bmw->recver);

#endif /* DEBUG_TALK_SENDMSG */

	if ((callee->userno != bmw->recver) || ((pid = callee->pid) <= 0)) {

#ifdef DEBUG_TALK_SENDMSG

		fprintf(stderr, "DEBUG(%s,%d): bwm_send(): wrong parameter\n",
		        __FILE__, __LINE__);

#endif /* DEBUG_TALK_SENDMSG */

		return 1;
	}

	/* sem_lock(BSEM_ENTER); */

	/* find callee's available slot */

	mslot = callee->mslot;
	i = 0;

	for (;;) {
		if (mslot[i] == NULL) {
			break;
		}

		if (++i >= BMW_PER_USER) {
			/* sem_lock(BSEM_LEAVE); */

#ifdef DEBUG_TALK_SENDMSG

			fprintf(stderr, "DEBUG(%s,%d): bmw_send(): callee: "
			                "no available slot\n",
			        __FILE__, __LINE__);

#endif /* DEBUG_TALK_SENDMSG */

			return 1;
		}
	}

	/* find available BMW slot in pool */

	texpire = time(&bmw->btime) - BMW_EXPIRE;

	mpool = ushm->mpool;
	mhead = ushm->mbase;

	if (mhead < mpool) {
		mhead = mpool;
	}
	mtail = mpool + BMW_MAX;

	do {
		if (++mhead >= mtail) {
			mhead = mpool;
		}
	} while (mhead->btime > texpire);

	memcpy(mhead, bmw, sizeof(BMW));
	ushm->mbase = mslot[i] = mhead;
	/*
	 *  Thor.981206:
	 *
	 *  �ݪ`�N, �Yushm mapping���P, �h���P�� bbsd ��call�|core dump, ��
	 *  �D�o�]��offset, ���L���F -i, ���ӬO�D���n
	 */

	/* sem_lock(BSEM_LEAVE); */

#ifdef DEBUG_TALK_SENDMSG
	fprintf(stderr, "DEBUG(%s,%d):bmw_send():before kill\n",
	        __FILE__, __LINE__);
#endif /* DEBUG_TALK_SENDMSG */

	return kill(pid, SIGUSR2);
}


int talk_sendmsg(int ofd, char *sid, pid_t to_pid, char *msg)
{
	W3IF_SESSENTRY *psess;
	UTMP           *up;
	int            i;
	char           fpath[MAXPATHLEN];

#ifdef DEBUG_TALK_SENDMSG

	fprintf(stderr, "DEBUG(%s,%d): enter talk_sendmsg():topid:%d,msg:%s\n",
	        __FILE__, __LINE__, to_pid, msg);

#endif /* DEBUG_TALK_SENDMSG */

	chdir(BBSHOME);

	write(ofd, "MRR-RESULT:talk_sendmsg\n",
	      strlen("MRR-RESULT:talk_sendmsg\n"));

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

#ifdef DEBUG_TALK_SENDMSG
	fprintf(stderr, "DEBUG(%s,%d):sid:%s\n", __FILE__, __LINE__, sid);
#endif /* DEBUG_TALK_SENDMSG */

	if (!(psess = w3ifsession_get(sid))) {
		write(ofd, "RESULT:no such session\nMRR-END:\n",
		      strlen("RESULT:no such session\nMRR-END:\n"));
		return -999; /* no such user */
	}

#ifdef DEBUG_TALK_SENDMSG

	fprintf(stderr, "DEBUG(%s,%d): sess pid: %d, sess sid: %s\n",
	        __FILE__, __LINE__, psess->utmp_entry->pid, psess->php_sid);

#endif /* DEBUG_TALK_SENDMSG */

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;

	acct_load(&cuser, cutmp->userid);

	for (i = 0; i < MAXACTIVE; ++i) {
		if (ushm->uslot[i].pid == to_pid) {
			up = &(ushm->uslot[i]);
			break;
		}
	}
	if (i >= MAXACTIVE) {

#ifdef DEBUG_TALK_SENDMSG

		fprintf(stderr, "DEBUG(%s,%d): no such receiver", __FILE__, __LINE__);

#endif /* DEBUG_TALK_SENDMSG */

		write(ofd, "RESULT:no such user\nMRR-END:\n",
		      strlen("RESULT:no such user\nMRR-END:\n"));

		return 999; /* no such user */
	}

	/*
	 *  ulist_write()
	 */

	if (HAS_PERM(PERM_PAGE)) {
		if (can_override(up)) {
			BMW  bmw;
			char buf[20];

#ifdef DEBUG_TALK_SENDMSG

			fprintf(stderr, "DEBUG(%s,%d): %s: sending a msg to %s(%d)\n",
			        __FILE__, __LINE__, cuser.userid, up->userid, up->pid);

#endif /* DEBUG_TALK_SENDMSG */

			memset(&bmw, 0, sizeof(BMW));

			bmw.recver = up->userno;
			strncpy(bmw.msg, msg, 49);
			bmw.caller = cutmp;
			bmw.sender = cuser.userno;
#ifdef DEBUG_TALK_SENDMSG
			fprintf(stderr, "DEBUG(%s,%d):bmw.recver:%d,bmw.caller:%p,bmw.sender:%d\n",
			        __FILE__, __LINE__, bmw.recver, bmw.caller, bmw.sender);
#endif /* DEBUG_TALK_SENDMSG */
			strcpy(bmw.userid, cuser.userid);

#ifdef DEBUG_TALK_SENDMSG
			fprintf(stderr, "DEBUG(%s,%d):bwm_send():kill():%d\n",
			        __FILE__, __LINE__, bmw_send(up, &bmw));
#else /* DEBUG_TALK_SENDMSG */
			bmw_send(up, &bmw);
#endif /* DEBUG_TALK_SENDMSG */

			/* lkchu.990103: �Y�O�ۤv�e�X�� bmw, �s��誺 userid */
			strcpy(bmw.userid, up->userid);
			time(&(bmw.btime));
			usr_fpath(fpath, cuser.userid, FN_BMW);
			rec_add(fpath, &bmw, sizeof(BMW));

			write(ofd, "RESULT:OK\nMRR-END:\n",
			      strlen("RESULT:OK\nMRR-END:\n"));

			return 0;
		}
	} /* if (has perm page) */

	write(ofd, "RESULT:no permission\nMRR-END:\n",
	      strlen("RESULT:no permission\nMRR-END:\n"));

	return 999;
}

