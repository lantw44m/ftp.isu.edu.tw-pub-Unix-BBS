/*
 *  $Id: talk_kickusr_main.c,v 1.4 2000/10/05 20:59:53 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"
#include <stdio.h>


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 3) {
		printf("Usage: %s <session-id> <kick-pid>\n", argv[0]);
		return 0;
	}

	if ((ret = talk_kickusr(argv[1], atoi(argv[2]))) != 0) {
		fprintf(stderr, "talk_kickusr() error(%d).\n", ret);
	}

	return 0;
}

