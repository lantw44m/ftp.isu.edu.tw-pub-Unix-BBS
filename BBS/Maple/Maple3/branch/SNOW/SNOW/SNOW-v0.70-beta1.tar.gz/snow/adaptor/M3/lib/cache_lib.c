/*
 *  $Id: cache_lib.c,v 1.2 2000/10/02 09:55:46 arlo Exp $
 */

#include "w3iflib.h"
#include "w3ifglobal.h"

#include <stdio.h>
#include <string.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>


#include "bbs.h"


void* shm_attach(int shmkey, int shmsize)
{
	void*	shmptr;
	int		shmid;

	shmid = shmget(shmkey, shmsize, 0);
	if (shmid < 0) {
		shmid = shmget(shmkey, shmsize, IPC_CREAT | 0600);
		if (shmid < 0) {
			attach_err(shmkey, "shmget");
		}
	}
	else {
		shmsize = 0;
	}

	shmptr = (void *) shmat(shmid, NULL, 0);
	if (shmptr == (void *) -1) {
		attach_err(shmkey, "shmat");
	}

	if (shmsize) {
		memset(shmptr, 0, shmsize);
	}

	return shmptr;
}


void attach_err(int shmkey, char* name)
{
	char buf[80];

	sprintf(buf, "key = %x", shmkey);
	w3if_log(name, buf);
	exit(1);
}



#ifdef  HAVE_SEM

/*
 *  semaphore : for critical section
 */

#if 0	/* JeffHung.2000707: move to w3ifglobal.c */
static int ap_semid;
#endif	/* 0 */


void sem_init()
{
	int	semid;

	union	semun {
		int					val;
		struct semid_ds*	buf;
		ushort*				array;
	} arg = {
		1
	};

	semid = semget(BSEM_KEY, 1, 0);
	if (semid == -1) {
		semid = semget(BSEM_KEY, 1, IPC_CREAT | BSEM_FLG);
		if (semid == -1) {
			attach_err(BSEM_KEY, "semget");
		}
		semctl(semid, 0, SETVAL, arg);
	}
	ap_semid = semid;
}



/*
 *  op is BSEM_ENTER or BSEM_LEAVE
 */
void sem_lock(int op)
{
	struct sembuf	sops;

	sops.sem_num = 0;
	sops.sem_flg = SEM_UNDO;
	sops.sem_op = op;
	semop(ap_semid, &sops, 1);
}


#endif	/* HAVE_SEM */


/*
 *  .UTMP cache
 */

#if	0	/* JeffHung.2000707: move to w3ifglobal.c */

UCACHE*	ushm;

#endif	/* 0 */


void ushm_init()
{
	UCACHE *xshm;

	ushm = xshm = shm_attach(UTMPSHM_KEY, sizeof(UCACHE));

#if 0
	if (xshm->mbase < xshm->mpool) {
		xshm->mbase = xshm->mpool;
	}
#endif
}


#ifndef _BBTP_



void utmp_mode(int mode)
{
	if (bbsmode != mode) {

#ifdef MODE_STAT
		/*
		 * XMODE �Q���Ӱ��䥦����, ���C�J�έp
		 */
		if (mode != M_XMODE && bbsmode != M_XMODE) {
			time_t now;

			time(&now);
			modelog.used_time[bbsmode] += (now - mode_lastchange);
			mode_lastchange = now;
		}
#endif	/* MODE_STAT */

		cutmp->mode = bbsmode = mode;
	}
}





int utmp_new(UTMP* up)
{
	UCACHE*	xshm;
	UTMP*	uentp;
	UTMP*	utail;

  /*
   *  semaphore : critical section
   */
#ifdef	HAVE_SEM
	sem_lock(BSEM_ENTER);
#endif	/* HAVE_SEM */

	xshm = ushm;
	uentp = xshm->uslot;
	utail = uentp + MAXACTIVE;

#if 0	/* JeffHung.2000706 �쥻�O�_�����ѡA��� #if 0 mark �_�� */
	/* uentp += (up->pid % xshm->count);  /* hashing */
#endif

	do {
		if (!uentp->pid) {
			usint offset;

			offset = (void *) uentp - (void *) xshm->uslot;
			memcpy(uentp, up, sizeof(UTMP));
			xshm->count++;
			if (xshm->offset < offset) {
				xshm->offset = offset;
			}
			cutmp = uentp;

#ifdef	HAVE_SEM
			sem_lock(BSEM_LEAVE);
#endif	/* HAVE_SEM */

			return 1;
		}
	} while (++uentp < utail);

	/* Thor:�i�Duser���H�n���@�B�F */

#ifdef	HAVE_SEM
	sem_lock(BSEM_LEAVE);
#endif	/* HAVE_SEM */

	return 0;
}






void utmp_free()
{
	UTMP*	uentp;

	uentp = cutmp;
	if (!uentp || !uentp->pid) {
		return;
	}
#ifdef	HAVE_SEM
	sem_lock(BSEM_ENTER);
#endif	/* HAVE_SEM */

	uentp->pid = uentp->userno = 0;
	ushm->count--;

#ifdef	HAVE_SEM
	sem_lock(BSEM_LEAVE);
#endif	/* HAVE_SEM */
}




UTMP* utmp_find(int userno)
{
	UTMP*	uentp;
	UTMP*	uceil;

	uentp = ushm->uslot;
	uceil = (void *) uentp + ushm->offset;
	do {
		if (uentp->userno == userno) {
			return uentp;
		}
	} while (++uentp <= uceil);

	return NULL;
}



#if 0


int apply_ulist(int (*fptr)())
{
	UTMP*	uentp;
	int		i;
	int		state;

	uentp = ushm->uslot;
	for (i = 0; i < USHM_SIZE; i++, uentp++) {
		if (uentp->pid) {
			if (state = (*fptr) (uentp)) {
				return state;
			}
		}
	}
	return 0;
}





/*
 *  order: �ĴX��
 */
UTMP* utmp_search(int userno, int order)
{
	UTMP*	uentp;
	UTMP*	uceil;

	uentp = ushm->uslot;
	uceil = (void *) uentp + ushm->offset;
	do {
		if (uentp->userno == userno) {
			if (--order <= 0) {
				return uentp;
			}
		}
	} while (++uentp <= uceil);
	return NULL;
}



#endif	/* 0 */



int utmp_count(int userno, int show)
{
	UTMP*	uentp;
	UTMP*	uceil;
	int		count;

	count = 0;
	uentp = ushm->uslot;
	uceil = (void *) uentp + ushm->offset;
	do {
		if (uentp->userno == userno) {
			count++;
			if (show) {
				printf("(%d) �ثe���A��: %-17.16s(�Ӧ� %s)\n",
				       count, bmode(uentp, 0), uentp->from);
			}
		}
	} while (++uentp <= uceil);
	return count;
}



/*
 *  .BRD cache
 */

#if	0	/* JeffHung.2000707: move to w3ifglobal.c */

BCACHE*	bshm;

#endif	/* 0 */


#if	0




void bsync()
{
	rec_put(FN_BRD, bshm->bcache, sizeof(BRD) * bshm->number, 0);
}



#endif	/* 0 */



void bshm_init()
{
	BCACHE*	xshm;
	time_t*	uptime;
	int		n;
	int		turn;

	turn = 0;
	xshm = bshm;
	if (xshm == NULL) {
		bshm = xshm = shm_attach(BRDSHM_KEY, sizeof(BCACHE));
	}

	uptime = &(xshm->uptime);

	for (;;) {
		n = *uptime;
		if (n > 0) {
			return;
		}

		if (n < 0) {
			if (++turn < 30) {
				sleep(2);
				continue;
			}
		}

		*uptime = -1;

		if ((n = open(FN_BRD, O_RDONLY)) >= 0) {
			xshm->number =
			    read(n, xshm->bcache,
			         MAXBOARD * sizeof(BRD)) / sizeof(BRD);
			close(n);
		}

		/* ���Ҧ� boards ��Ƨ�s��A�]�w uptime */

		time(uptime);
#if	0	/* JeffHung.2000707: replace blog() as w3if_log() */
		blog("CACHE", "reload bcache");
#else	/* 0 */
		w3if_log("CACHE", "reload bcache");
#endif	/* 0 */

		return;
	}
}




#if	0




int apply_boards(int (*func)())
{
	extern char	brd_bits[];
	BRD*		bhdr;
	int			i;

	for (i = 0, bhdr = bshm->bcache; i < bshm->number; i++, bhdr++) {
		if (brd_bits[i]) {
			if ((*func) (bhdr) == -1) {
				return -1;
			}
		}
	}
	return 0;
}



#endif	/* 0 */



int brd_bno(char* bname)
{
	BRD*	brdp;
	BRD*	bend;
	int		bno;

	brdp = bshm->bcache;
	bend = brdp + bshm->number;
	bno = 0;

	do {
		if (!str_cmp(bname, brdp->brdname)) {
			return bno;
		}

		bno++;
	} while (++brdp < bend);

	return -1;
}




#if	0




BRD* getbrd(char* bname)
{
	BRD*	bhdr;
	BRD*	tail;

	bhdr = bshm->bcache;
	tail = bhdr + bshm->number;
	do {
		if (!str_cmp(bname, bhdr->brdname)) {
			return bhdr;
		}
	} while (++bhdr < tail);
	return NULL;
}



#endif	/* 0 */



/*
 *  etc/movie cache
 */


#if	0	/* JeffHung.2000707: movie is useless on web interface */

FCACHE *fshm;

#endif	/* 0 */



/*
 *  JeffHung.2000707: Delete etc/movie cache related functions.
 *
 *  fshm_init(), film_out()
 */



void out_rle(uschar* str)
{
#ifdef	SHOW_USER_IN_TEXT
	uschar*	t_name = cuser.userid;
	uschar*	t_nick = cuser.username;
#endif	/* SHOW_USER_IN_TEXT */

	int cc, rl;

	while (cc = *str) {
		str++;
		switch (cc) {
		case 8:  /* Thor.980804: ���Ѥ@�U, opus���Y�L�F */
			rl = *str++;
			cc = *str++;

			while (--rl >= 0) {
				printf("%c", cc);
			}
			continue;

#ifdef	SHOW_USER_IN_TEXT
		case 1:
			if (cc = *t_name) {
				t_name++;
			}
			else {
				cc = ' ';
			}
			break;

		case 2:
			if (cc = *t_nick) {
				t_nick++;
			}
			else {
				cc = ' ';
			}
#endif	/* SHOW_USER_IN_TEXT */
		}
		printf("%c", cc);
	}
}



#endif	/* _BBTP_ */






