/*
 *  $Id: talk_paladd_main.c,v 1.5 2000/10/05 20:59:53 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 5) {
		printf("Usage: %s <session-id> <pal-id> <friendship> <is-bad>\n",
		       argv[0]);
		return 0;
	}

	if ((ret = talk_paladd(fileno(stdout), argv[1], argv[2], argv[3], atoi(argv[4]))) != 0) {
		fprintf(stderr, "talk_paladd() error(%d).\n", ret);
	}

	return 0;
}

