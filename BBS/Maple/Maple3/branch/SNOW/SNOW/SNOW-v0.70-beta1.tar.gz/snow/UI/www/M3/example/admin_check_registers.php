<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�f�ֵ��U��");

/*
 * Required Inputs: (none)
 */

$SNOW_PAGE_TITLE = "�f�ֵ��U��";
$SNOW_PAGEAREA_MAIN = "admin_check_registers.m.php";
$SNOW_PAGEAREA_FUNC = "admin_check_registers.f.php";

include("bone.php");

?>