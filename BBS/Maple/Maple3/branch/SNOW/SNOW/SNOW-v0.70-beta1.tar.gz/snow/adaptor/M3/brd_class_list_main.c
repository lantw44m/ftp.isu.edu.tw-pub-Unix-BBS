/*
 *  $Id: brd_class_list_main.c,v 1.2 2000/09/30 08:05:11 jeffhung Exp $
 */

#include "w3if.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc , char **argv)
{
  int return_val;
  if( argc != 6 )
  {
    fprintf(stderr, 
"usage: UserID Channel Top Range Mode\n"
"/* ------------------------------------------------------------ */\n"
"/* Argument: ofd     : output file descriptor                   */\n"
"/*           username: �ϥΪ�ID                                 */\n"
"/*           channel : ���@�Ӥ����W�D( -2���D�W�D )             */\n"
"/*           top     : �}�l����m                               */\n"
"/*           range   : ��top�_��᪺�d��                        */\n"
"/*           mode    : ���@��Mode(BFO_NONE/BFO_YANK/BFO_ENJOY)  */\n"
"/*                               ( 0 / 1 / 2 )                  */\n"
"/* ------------------------------------------------------------ */\n"
    );
    return -1;
  }
  return_val = brd_class_list( fileno(stdout),argv[1] , atoi(argv[2]) , atoi(argv[3]), atoi(argv[4]), atoi(argv[5]));
  
  return return_val;
  
}

