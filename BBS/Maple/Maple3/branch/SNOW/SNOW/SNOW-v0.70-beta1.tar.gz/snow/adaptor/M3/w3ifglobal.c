/*
 *  $Id: w3ifglobal.c,v 1.5 2000/10/05 20:59:53 jeffhung Exp $
 */

#include "bbs.h"
#include "w3ifglobal.h"
#include <sys/types.h>
#include <sys/uio.h>
#include <fcntl.h>
#include <unistd.h>



/*
 *  Global variables for w3if
 */
time_t	ap_start;


/*
 *  Global variables declared in bbsd.c
 */
char	*str_host = MYHOSTNAME;
char	*str_site = BOARDNAME;
char    *str_sysop = "sysop";
char	*fn_dir = FN_DIR;
char	*fn_acct = FN_ACCT;
char	*fn_plans = "plans";
char	*fn_note = "note";
pid_t   currpid;
char    currboard[IDLEN + 2]; /* name of currently selected board */

#ifdef	HAVE_REGISTER_FORM
char	*fn_rform = FN_RFORM; /* ���U���� */
#endif	/* HAVE_REGISTER_FORM */


/*
 *  Global variables declared in global.h
 */
UTMP	*cutmp;    
ACCT	cuser;	/* current user structure */
time_t	ap_start; /* start time form user login */
usint	bbsmode; /* bbs operating mode, see modes.h */

/*
 *  Global variables declared in cache.c
 */
int			ap_semid; /* application's semaphore id */
UCACHE 		*ushm; /* .UTMP cache */
BCACHE		*bshm; /* .BRD cache */

#ifdef MODE_STAT
UMODELOG	modelog;
time_t		mode_lastchange;
#endif

/*
 *  Global variables declared in mail.c
 */
LinkList*	ll_head;	/* head of link list */
LinkList*	ll_tail;	/* tail of link list */

struct tagCMBOX	cmbox;
int	TagNum;

/*
 *  Global variables declared in xover.c
 */

int		TagNum; /* tag's number */
TagItem	TagList[TAG_MAX];	/* ascending list */
char	xo_pool[XO_TALL * XO_RSIZ];

#if	0	/* JeffHung.20000714: try to discard this to decouple sources */
XZ	xz[] = {
	{ NULL,	NULL,		M_BOARD		}, /* XZ_CLASS */
	{ NULL,	NULL,		M_LUSERS	}, /* XZ_ULIST */
	{ NULL,	NULL,		M_PAL		}, /* XZ_PAL */
#ifdef MY_FAVORITE
	{ NULL,	NULL,		M_FAB		}, /* XZ_FAB */
#else
	{ NULL,	NULL,		M_FAB		}, /* XZ_FAB */
#endif
	{ NULL,	NULL,		M_VOTE		}, /* XZ_VOTE */
	/* lkchu.981230: BMW �s���� */
	{ NULL,	NULL,		M_BMW		}, /* XZ_BMW */
#ifdef XZ_XPOST /* Thor.990303: �p�G�� XZ_XPOST���� */
	{ NULL,	xpost_cb,	M_READA		}, /* XZ_XPOST */
#else
	{ NULL, NULL,		M_READA		}, /* skip XZ_XPOST */
#endif
	{ NULL, NULL,		M_RMAIL		}, /* XZ_MBOX */
	{ NULL, post_cb,	M_READA		}, /* XZ_POST */
	{ NULL, NULL,		M_GEM		}  /* XZ_GEM */
}; 

#endif	/* 0 */


char *user_flags[] = {
	"COLOR",   /* �m��Ҧ� */
	"MOVIE",   /* �ʵe��� */
	"BRDNEW",  /* �s�峹 */
	"BNOTE",   /* ��ܶi�O�e�� */
	"VEDIT",   /* ²�ƽs�边 */

	"PAGER",   /* �����I�s�� */
	"QUITE",   /* �������� */
	"PAL",     /* �u��ܦn�� */
	"ALOHA",   /* �n�ͤW���q�� */

	"MOTD",    /* ²�ƶi���e�� */

	"MPAGER",  /* �q�l�l��ǩI */
	"NWLOG",   /* ���x�s���T���� */
	"NTLOG",   /* ���x�s��Ѭ��� */
	"UNUSED1", /* �O�d */
	"UNUSED2", /* �O�d */
	"UNUSED3", /* �O�d */
	"UNUSED4", /* �O�d */
	"UNUSED5", /* �O�d */
	"UNUSED6", /* �O�d */

	"CLOAK",   /* �����N */
	"ACL"      /* ACL */
};

int user_flags_num = sizeof(user_flags) / sizeof(char*);


char *trim_r_newline(char *s)
{
	register char *p = s;

	while (*p) {
		if ((*p == '\n') || (*p == '\r')) {
			*p = 0;
			break;
		}
		++p;
	}

	return s;
}

int is_samepal(int userno, PAL *pal)
{
	return (userno == pal->userno);
}


int rec_search(char *fpath, char *rptr, int size,
               int (*fptr)(), int farg)
{
	int fd;
	int id = 1;

	if ((fd = open(fpath, O_RDONLY)) == -1) {
		return 0;
	}
	while (read(fd, rptr, size) == size) {
		if ((*fptr)(farg, rptr)) {
			close(fd);
			return id;
		}
		++id;
	}
	close(fd);
	return 0;
}


