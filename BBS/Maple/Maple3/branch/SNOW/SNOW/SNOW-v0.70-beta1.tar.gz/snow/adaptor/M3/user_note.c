/*
 *  $Id: user_note.c,v 1.4 2000/10/05 20:59:53 jeffhung Exp $
 */

#undef DEBUG_USER_NOTE

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <sys/param.h>
#include <unistd.h>
#include <stdio.h>


#define FN_NOTE_PAD "run/note.pad"
#define FN_NOTE_TMP "run/note.tmp"
#define NOTE_MAX    (100)
#define NOTE_DUE    (48)

typedef struct {
	time_t tpad;
	char   msg[356];
} Pad;


int user_note(int ofd)
{
	FILE        *fp;
	struct stat st;
	int         padnum;
	Pad         *ppad;
	char        obuf[GENERAL_BUFSIZE];
	int         i;
	char        *p;
	char        *ep;
	int         n;

	chdir(BBSHOME);

	if (lstat(FN_NOTE_PAD, &st) < 0) {

#ifdef DEBUG_USER_NOTE
		fprintf(stderr, "DEBUG(%s,%d):current directory:%s\n",
		        __FILE__, __LINE__, getcwd(obuf, GENERAL_BUFSIZE));
		fprintf(stderr, "DEBUG(%s,%d):no such file:%s\n",
		        __FILE__, __LINE__, FN_NOTE_PAD);
#endif /* DEBUG_USER_NOTE */

		return -999; /* no such file */
	}
	padnum = st.st_size / sizeof(Pad);

	if (!(fp = fopen(FN_NOTE_PAD, "r"))) {

#ifdef DEBUG_USER_NOTE
		fprintf(stderr, "DEBUG(%s,%d):can not open %s\n",
		        __FILE__, __LINE__, FN_NOTE_PAD);
#endif /* DEBUG_USER_NOTE */

		return -999; /* can not open FN_NOTE_PAD */
	}

	if (!(ppad = (Pad*)malloc(sizeof(Pad) * padnum))) {
		fclose(fp); /* can not allocate memory */
	}

	if (fread(ppad, sizeof(Pad), padnum, fp) != padnum) {
		free(ppad);
		fclose(fp);

#ifdef DEBUG_USER_NOTE
		fprintf(stderr, "DEBUG(%s,%d):read failed\n", __FILE__, __LINE__);
#endif /* DEBUG_USER_NOTE */

		return -999; /* read failed */
	}

	fclose(fp);

	sprintf(obuf, "MRR-RESULT:user_note\n");
	write(ofd, obuf, strlen(obuf));

	for (i = 0; i < padnum; ++i) {
		/* �H�U�ݾA���d�������ܦ�榡 */
		p = ppad[i].msg + 9;
		ep = strchr(p, '(') - 1;
		*ep = 0;
		sprintf(obuf, "USERID:%s\n", p);
		write(ofd, obuf, strlen(obuf));
		p = ++ep;
		ep = strchr(++p, ')');
		*ep = 0;
		sprintf(obuf, "USERNAME:%s\n", p);
		write(ofd, obuf, strlen(obuf));
		p = strchr(++ep, '\n');
		strcpy(obuf, "NOTE:");
		ep = obuf + 5;
		n = 0;
		while (*++p) {
			*ep = *p;
			++ep;
			if (*p == '\n') {
				if (n >= 2) {
					break; /* while */
				}
				strcpy(ep, "CONTINUE:");
				ep += 9;
				++n;
			}
		}
		*ep = 0;
		write(ofd, obuf, strlen(obuf));
	} /* for (i) */

	free(ppad);
}



