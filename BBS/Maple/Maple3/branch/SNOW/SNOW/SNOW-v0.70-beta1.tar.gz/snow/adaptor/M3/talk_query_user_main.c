/*
 *  $Id: talk_query_user_main.c,v 1.5 2000/10/05 20:59:53 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{

	if (argc != 2) {
		printf("Usage: %s <user-id>\n", argv[0]);
		return 0;
	}

	talk_query_user(fileno(stdout), argv[1]);

	return 0;
}

