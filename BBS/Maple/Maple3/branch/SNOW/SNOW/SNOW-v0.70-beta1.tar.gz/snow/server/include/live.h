/*
 * 
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation 
 * bbs, the cross-media distributed communication platform. And it is 
 * developed by Cyberwork Solution in 2000.
 * 
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 * 
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or (at 
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or 
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution.com , Isabel Ho
 *
 */


#ifndef	LIVE_H_INCLUDED
#define	LIVE_H_INCLUDED

#include "bbs.h"
/* live server �Ҥ����쪺�ؿ�  */
#define	LIVE_SERVER_HOME	"/serv/bbs"
/* live server �ҨϥΪ�Port    */
#define LIVE_SERVER_PORT	(7777)
/* �@���w���}��threads         */
#define SERVER_THREAD	(16)
/* �̦h���P�ɤW�u�H��          */
#define	MAX_CLIENT	(1024)

/*Dynamic creating thread �[�c */
#define DYNAMIC_THREAD 

#define LIVE_PID_FILE   "run/live.pid"
#define LIVE_SERVER_LOG "log/live_server.log"
#define	ERR_NETWORK_LOG	"log/err_network.log"
#define ERR_SYSTEM_LOG  "log/err_system.log"

#define MAX_RECORD           (40)         /*�̦h�i�H�Ȧs�h�ֵ��T��*/
#define MAX_FD		     (1024)

/*--------------- �T���O�� ----------------*/ 
struct w3if_CHAT_MSG
{
  char chatroom[IDLEN];
  char msg[80];
};
typedef struct w3if_CHAT_MSG CHAT_MSG;

/*------------- �ϥΪ̸�T ----------------*/ 
#define TYPE_CHAT     (100)
#define TYPE_TALK     (200)
#define TYPE_OFFLINE  (-1)
struct w3if_USER_INFO
{
  int          fd;
	int          type;
  int          index;
	char         sid[32+1];
  char         userid[IDLEN+1];
	CHAT_MSG     msg_pool[MAX_RECORD];
};
typedef struct w3if_USER_INFO USER_INFO;


#endif	/* LIVE_H_INCLUDED */

