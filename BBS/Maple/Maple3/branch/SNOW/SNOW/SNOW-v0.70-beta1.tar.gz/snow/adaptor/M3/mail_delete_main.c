/*
 *  $Id: mail_delete_main.c,v 1.5 2000/10/05 20:59:52 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 3) {
		printf("Usage: %s <user-id> <mail-file-name>\n", argv[0]);
		return 0;
	}

	if ((ret = mail_delete(fileno(stdout), argv[1], argv[2])) < 0) {
		fprintf(stderr, "mail_delete error(%d).\n", ret);
	}

	return 0;
}

