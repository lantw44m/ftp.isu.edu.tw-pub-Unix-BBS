/*
 *  $Id: user_register.c,v 1.6 2000/10/11 13:13:30 jeffhung Exp $
 */

#define DEBUG_USER_REGISTER

#include "bbs.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "w3if.h"
#include "w3if_session.h"
#include "dao.h"
#include <sys/types.h>
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <unistd.h>
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */


#ifdef AS_ARNI_MODULE

int mod_user_register(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return user_register(ofd, sid, parg->args[0].s, parg->args[1].s,
	                     parg->args[2].s, parg->args[3].s, parg->args[4].s);
}

#endif /* AS_ARNI_MODULE */

static int uniq_userno(int fd)
{
	char   buf[4096];
	int    userno;
	int    size;
	SCHEMA *sp; /* record length 16 �i�㰣 4096 */

	userno = 1;

	while ((size = read(fd, buf, sizeof(buf))) > 0) {
		sp = (SCHEMA*)buf;
		do {
			if (sp->userid[0] == '\0') {
				lseek(fd, -size, SEEK_CUR);
				return userno;
			}
			++userno;
			size -= sizeof(SCHEMA);
			++sp;
		} while (size);
	}

	return userno;
}


static int belong(char *flist, char *key)
{
	int fd;
	int rc;

	rc = 0;
	fd = open(flist, O_RDONLY);
	if (fd >= 0) {
		mgets(-1);

		while (flist = mgets(fd)) {
			str_lower(flist, flist);
			if (str_str(key, flist)) {
				rc = 1;
				break;
			}
		}

		close(fd);
	}
	return rc;
}

static int is_badid(char *userid)
{
	int  ch;
	char *str;

	if (strlen(userid) < 2) {
		return 1;
	}

	if (!is_alpha(*userid)) {
		return 1;
	}

	if (!str_cmp(userid, "new")) {
		return 1;
	}

	str = userid;
	while (ch = *(++str)) {
		if (!is_alnum(ch)) {
			return 1;
		}
	}
	return (belong("etc/badid", userid));
}

int user_register(int ofd, char *sid, char *newid, char *newpasswd,
                  char *newnick, char *newrealname, char *newaddress)
{
#ifdef LOGINASNEW

	W3IF_SESSENTRY *psess;
	SCHEMA         slot;
	char           buf[MAXPATHLEN];
	int            fd;
	int            userno;
	char           obuf[GENERAL_BUFSIZE];

	chdir(BBSHOME);

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	psess = w3ifsession_get(sid);

	snprintf(obuf, GENERAL_BUFSIZE, "MRR-RESULT:user_register\n");
	write(ofd, obuf, strlen(obuf));

	if (!psess) {
		snprintf(obuf, GENERAL_BUFSIZE, "RESULT:no such session\nMRR-END:\n");
		write(ofd, obuf, strlen(obuf));
		return -999; /* no such session */
	}

	/* JeffHung: ���Ӥw�g�H guest login �L�F�C */
	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;

	if (strlen(newid) > IDLEN) {
		newid[IDLEN] = 0;
	}

	if (is_badid(newid)) {
		snprintf(obuf, GENERAL_BUFSIZE, "RESULT:bad id\nMRR-END:\n");
		write(ofd, obuf, strlen(obuf));
		return -999; /* �L�k�����o�ӥN���A�Шϥέ^��r���A�åB���n�]�t�Ů� */
	}

	usr_fpath(buf, newid, NULL);
	if (dashd(buf)) {
		snprintf(obuf, GENERAL_BUFSIZE,
		         "RESULT:someone else has already own this id\nMRR-END:\n");
		write(ofd, obuf, strlen(obuf));
		return -999; /* ���N���w�g���H�ϥ� */
	}

	memset(&cuser, 0, sizeof(cuser));

	strncpy(cuser.userid, newid, sizeof(cuser.userid));

	if (strlen(newpasswd) > PASSLEN) {
		newpasswd[PASSLEN] = 0;
	}

	if ((strlen(newpasswd) < 3) || !strcmp(newpasswd, newid)) {
		snprintf(obuf, GENERAL_BUFSIZE, "RESULT:bas password\nMRR-END:\n");
		write(ofd, obuf, strlen(obuf));
		return -999; /* �K�X��²��A���D�J�I�A�ܤ֭n 4 �Ӧr�A�Э��s��J */
	}

	strncpy(cuser.passwd, genpasswd(newpasswd), PASSLEN);

	if (strlen(newnick) < 2) {
		snprintf(obuf, GENERAL_BUFSIZE, "RESULT:bad nick\nMRR-END:\n");
		write(ofd, obuf, strlen(obuf));
		return -999; /* �ʺ٤ӵu */
	}
	strncpy(cuser.username, newnick, sizeof(cuser.username));

	if (strlen(newrealname) < 4) {
		snprintf(obuf, GENERAL_BUFSIZE, "RESULT:bad real name\nMRR-END:\n");
		write(ofd, obuf, strlen(obuf));
		return -999; /* �u��m�W�ӵu */
	}
	strncpy(cuser.realname, newrealname, sizeof(cuser.realname));

	if (strlen(newaddress) < 12) {
		snprintf(obuf, GENERAL_BUFSIZE, "RESULT:bad address\nMRR-END:\n");
		write(ofd, obuf, strlen(obuf));
		return -999; /* �a�}�ӵu */
	}
	strncpy(cuser.address, newaddress, sizeof(cuser.address));

	cuser.userlevel = PERM_DEFAULT;
	/* Thor.980805: ����, �w�]�X��ufo *
	cuser.ufo = UFO_COLOR | UFO_MOVIE | UFO_BNOTE;
	cuser.numlogins = 1;

	/* dispatch unique userno */

	cuser.firstlogin = cuser.lastlogin = cuser.tcheck = slot.uptime = ap_start;
	memcpy(slot.userid, newid, IDLEN);

#ifdef DEBUG_USER_REGISTER
	fprintf(stderr, "DEBUG(%s,%d):slot.userid:%s, slot.uptime:%d\n",
	        __FILE__, __LINE__, slot.userid, slot.uptime);
#endif /* DEBUG_USER_REGISTER */

	fd = open(FN_SCHEMA, O_RDWR | O_CREAT, 0600);
	{
		/* flock(fd, LOCK_EX); */
		/* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
		f_exlock(fd);

		cuser.userno = userno = uniq_userno(fd);
#ifdef DEBUG_USER_REGISTER
		fprintf(stderr, "DEBUG(%s,%d):userno:%d\n", __FILE__, __LINE__, userno);
#endif /* DEBUG_USER_REGISTER */
		write(fd, &slot, sizeof(slot));

		/* flock(fd, LOCK_UN); */
		/* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
		f_unlock(fd);
	}
	close(fd);

	usr_fpath(buf, newid, NULL);
	mkdir(buf, 0755);
	strcat(buf, "/@");
	mkdir(buf, 0755);

	usr_fpath(buf, newid, fn_acct);
	fd = open(buf, O_WRONLY | O_CREAT, 0600);
	write(fd, &cuser, sizeof(cuser));
	close(fd);
	/* Thor.990416: �`�N: ���|�� .ACCT���׬O0��, �ӥB�u��@�ؿ�, �����[� */

	sprintf(buf, "%d", userno);
	blog("APPLY", buf);

	/* �ܨ������s�ϥΪ� */
	/* ... */

	snprintf(obuf, GENERAL_BUFSIZE, "RESULT:OK\nMRR-END:\n");
	write(ofd, obuf, strlen(obuf));

	return 0;

#else /* LOGINASNEW */

	snprintf(obuf, GENERAL_BUFSIZE,
	         "MRR-RESULT:user_register\nRESULT:no register\nMRR-END:\n");
	write(ofd, obuf, strlen(obuf));

	return -999; /* ���t�Υثe�Ȱ��u�W���U, �Х� guest �i�J */

#endif /* LOGINASNEW */
}

