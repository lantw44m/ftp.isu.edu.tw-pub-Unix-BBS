/*
 *  $Id: mail_readmail.c,v 1.5 2000/10/11 13:13:30 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"
#include <sys/param.h>
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */

#ifdef AS_ARNI_MODULE

int mod_mail_readmail(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return mail_readmail(ofd, parg->args[0].s, parg->args[1].s);
}

#endif /* AS_ARNI_MODULE */

#if 0 /* JeffHung.20000929: defined at w3ifglobal.c */

char *trim_r_newline(char *s)
{
	register char *p = s;

	while (*p) {
		if ((*p == '\n') || (*p == '\r')) {
			*p = 0;
			break;
		}
		++p;
	}

	return s;
}

#endif /* 0 */


/*
 *  return value:
 *  -1: open file error
 *  -2: write to ofd error
 */
int mail_readmail(int ofd, char* userid, char* fname)
{
	char fpath[MAXPATHLEN];
	char lower_userid[IDLEN + 1];
	FILE *fp;
	char buf[GENERAL_BUFSIZE];
	int  len;
	int  i; /* generic i */
	char *p1;
	char *p2;
	char *p3;
	char obuf[GENERAL_BUFSIZE]; /* output buffer */

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

	str_lower(lower_userid, userid);
	snprintf(fpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/@/%s",
	         lower_userid[0], lower_userid, fname);

	if (!(fp = fopen(fpath, "r"))) {
		fprintf(stderr, "Unable to open %s.\n", fpath);
		return -1;
	}

	write(ofd, "MRR-RESULT:mail_readmail\n",
	      strlen("MRR-RESULT:mail_readmail\n")); 

	/* read header */

	for (i = 0; fgets(buf, GENERAL_BUFSIZE, fp); ++i) {
		if (!strncmp(buf, "�@��: ", 6) || !strncmp(buf, "�o�H�H: ", 8)) {
			if (!*(p1 = strchr(buf, ':') + 2) ||
			    !(p2 = strchr(buf, '(')) ||
			    (*(--p2) != ' ') ||
			    !(p3 = strrchr(buf, ')'))) {
				continue; /* this is not a valid header line */
			}
			*p2++ = 0;
			sprintf(obuf, "AUTHOR-ID:%s\n", p1);
			write(ofd, obuf, strlen(obuf));
			*p3++ = 0;
			sprintf(obuf, "AUTHOR-NAME:%s\n", ++p2);
			write(ofd, obuf, strlen(obuf));
			if ((p1 = strstr(p3, "�ݪO: ")) && *(p1 += 6)) {
				trim_r_newline(p1);
				sprintf(obuf, "BOARD-ID:%s\n", p1);
				write(ofd, obuf, strlen(obuf));
			}
			continue;
		} /* �@�� */
		if (!strncmp(buf, "���D: ", 6) || !strncmp(buf, "��  �D: ", 8)) {
			if (!*(p1 = strchr(buf, ':') + 2)) {
				continue; /* this is not a valid header line */
			}
			trim_r_newline(p1);
			sprintf(obuf, "SUBJECT:%s\n", p1);
			write(ofd, obuf, strlen(obuf));
			continue;
		} /* ���D */
		if (!strncmp(buf, "�ɶ�: ", 6) || !strncmp(buf, "�o�H��: ", 8)) {
			if (!*(p1 = p2 = strchr(buf, ':') + 2)) {
				continue; /* this is not a valid header line */
			}
			if ((p2 = strchr(p1, '(')) &&
			    (p3 = strrchr(p1, ')'))) {
				/* have site name */
				*p2++ = 0;
				sprintf(obuf, "SITENAME:%s\n", p1);
				write(ofd, obuf, strlen(obuf));
				*p3 = 0;
				p1 = p2;
			}
			trim_r_newline(p1);
			sprintf(obuf, "DATE:%s\n", p1);
			write(ofd, obuf, strlen(obuf));
			continue;
		} /* �ɶ� */
		if (!strncmp(buf, "��H��: ", 8)) {
			if (!*(p1 = strchr(buf, ':') + 2)) {
				continue; /* this is not a valid header line */
			}
			trim_r_newline(p1);
			sprintf(obuf, "PATH:%s\n", p1);
			write(ofd, obuf, strlen(obuf));
			continue;
		} /* ��H�� */
		if (!strncmp(buf, "Origin: ", 8)) {
			if (!*(p1 = strchr(buf, ':') + 2)) {
				continue; /* this is not a valid header line */
			}
			trim_r_newline(p1);
			sprintf(obuf, "ORIGIN:%s\n", p1);
			write(ofd, obuf, strlen(obuf));
			continue;
		} /* Origin */
		if ((*buf == '\n') || (*buf == '\r')) {
			break; /* for (i) */
		}
	}

	for (i = 0; fgets(buf, GENERAL_BUFSIZE, fp); ++i) {
		if (i == 0) {
			write(ofd, "BODY:", strlen("BODY:"));
		}
		else {
			write(ofd, "CONTINUE:", strlen("CONTINUE:"));
		}
		len = strlen(buf);
		if (write(ofd, buf, len) < 0) {
			fclose(fp);
			return -2;
		}
	}

	fclose(fp);
	return 0;
}

