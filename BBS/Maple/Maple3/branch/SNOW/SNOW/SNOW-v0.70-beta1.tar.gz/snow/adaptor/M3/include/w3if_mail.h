/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution.com , Isabel Ho
 *
 */

/*
 *  $Id: w3if_mail.h,v 1.4 2000/10/05 20:59:53 jeffhung Exp $
 */

#ifndef	W3IF_MAIL_H_INCLUDED
#define	W3IF_MAIL_H_INCLUDED

#ifdef AS_ARNI_MODULE
#include "arni_server.h"

extern int mod_mail_mbox(int ofd, char *sid, struct ARNI_ARGS *args);
extern int mod_mail_readmail(int ofd, char *sid, struct ARNI_ARGS *parg);
extern int mod_mail_toggle_mark(int ofd, char *sid, struct ARNI_ARGS *parg);
extern int mod_mail_send_localmail(int ofd, char *sid, struct ARNI_ARGS *parg);
extern int mod_mail_delete(int ofd, char *sid, struct ARNI_ARGS *parg);
extern int mod_mail_delete_range(int ofd, char *sid, struct ARNI_ARGS *parg);
extern int mod_mail_first_unread_mail(int ofd, char *sid, struct ARNI_ARGS *parg);
extern int mod_mail_send_internetmail(int ofd, char *sid, struct ARNI_ARGS *parg);

#endif /* AS_ARNI_MODULE */

int mail_mbox(int ofd, char* userid);

/*
 *  return value:
 *  -1: open file error
 *  -2: write to ofd error
 */
int mail_readmail(int ofd, char* userid, char* fname);

int mail_first_unread_mail(int ofd, char *userid);

int mail_send_localmail(int ofd, char *fromid, char *toid, char *subject,
#ifdef AS_ARNI_MODULE
                        char *body);
#else /* AS_ARNI_MODULE */
                        char *fname);
#endif /* AS_ARNI_MODULE */

int mail_send_internetmail(int ofd, char *fromid, char *toaddr, char *subject,
#ifdef AS_ARNI_MODULE
                           char *body);
#else /* AS_ARNI_MODULE */
                           char *fname);
#endif /* AS_ARNI_MODULE */

int mail_delete(int ofd, char *userid, char *fname);

int mail_delete_range(int ofd, char *userid, char *startfname, char *endfname);

int mail_toggle_mark(int ofd, char *userid, char *fname);

#endif	/* W3IF_MAIL_H_INCLUDED */

