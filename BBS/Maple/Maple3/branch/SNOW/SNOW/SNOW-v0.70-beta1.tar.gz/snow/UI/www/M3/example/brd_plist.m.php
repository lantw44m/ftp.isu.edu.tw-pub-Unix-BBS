<SCRIPT LANGUAGE="JavaScript">
<!--

<?php

$max = $result["brd_post_num"][0]["POSTNUM"][0];
debug_print($max);

?>

// ��Ĥ@��
function pg2first()
{
	document.fPageChanger.iPageTop.value = "1";
	document.fPageChanger.submit();
}

// ��W�@��
function pg2prev()
{
	<?php if ($iPageTop > $iPageSize) { ?>
	document.fPageChanger.iPageTop.value = <?php
	$prevPage = $iPageTop - $iPageSize;
	printf("\"%d\"", $iPageTop - $iPageSize);
	?>;
	<?php } ?>
	document.fPageChanger.submit();
}

// ��U�@��
function pg2next()
{
	<?php if (($max - $iPageTop) > $iPageSize) { ?>
	document.fPageChanger.iPageTop.value = <?php
	$nextPage = $iPageTop + $iPageSize;
	printf("\"%d\"", $iPageTop + $iPageSize);
	?>;
	<?php } ?>
	document.fPageChanger.submit();
}

// ��̥���
function pg2last()
{
	document.fPageChanger.iPageTop.value = <?php
	printf("\"%d\"", floor($max / $iPageSize) * $iPageSize + 1);
	?>;
	document.fPageChanger.submit();
}

function pg2go()
{
	document.fPageChanger.iPageTop.value = document.fPageChanger.iDirectGo.options[document.fPageChanger.iDirectGo.selectedIndex].value;
	document.fPageChanger.submit();
}

//-->
</SCRIPT>
<FORM METHOD="post" NAME="fPageChanger" ACTION="brd_plist.php">
	<INPUT TYPE="hidden" NAME="iBoardID" VALUE="<?php echo $iBoardID; ?>">
	<INPUT TYPE="hidden" NAME="iPageTop" VALUE="<?php echo $iPageTop; ?>">
	<INPUT TYPE="hidden" NAME="iPageSize" VALUE="<?php echo $iPageSize; ?>">
	<P> 
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo" onChange="document.fPageChanger.iDirectGo2.selectedIndex = document.fPageChanger.iDirectGo.selectedIndex;">
		<!-- �N�W�U�� <SELECT> �P�B -->
		<?php

		for ($i = 0; $i < ceil($max / $iPageSize); ++$i) {
			printf("<OPTION VALUE=\"%d\"%s>%d</OPTION>\n",
			       $iPageSize * $i + 1,
				   ((($iPageSize * $i + 1) == $iPageTop) ? " SELECTED" : ""),
				   $i + 1);
		}
		
		?>
		</SELECT>
		��
		<INPUT TYPE="button" VALUE="Go" onClick="pg2go();">
	</P>
	<TABLE WIDTH="100%" BORDER="1">
		<TR> 
			<TH>�s��</TH>
			<TH>�Х�</TH>
			<TH>���</TH>
			<TH>�@��</TH>
			<TH>�峹���D</TH>
		</TR>
		<?php
		
		$plist = $result["brd_plist"];

		for ($i = 0; $i < count($plist); ++$i) {
			printf("<TR>\n");
			printf("<TD>%d <INPUT TYPE=\"radio\" NAME=\"iItem\" VALUE=\"%s\"></TD>\n",
			       $plist[$i]["INDEX"][0], $plist[$i]["FILENAME"][0]);
			printf("<TD>+</TD>\n");
			printf("<TD>%s</TD>\n", strftime("%Y-%m-%d %H:%M:%S", $plist[$i]["TIMESTAMP"][0]));
			printf("<TD>%s</TD>\n",
            query_user_link($plist[$i]["AUTHOR-ID"][0], $plist[$i]["AUTHOR-ID"][0]));
			printf("<TD><A HREF=\"brd_read_post.php?iBoardID=%s&iFilename=%s\">%s</A></TD>\n",
			       $iBoardID, $plist[$i]["FILENAME"][0], $plist[$i]["SUBJECT"][0]);
			printf("</TR>\n");
		}

		?>
	</TABLE>
	<P>
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo2" onChange="document.fPageChanger.iDirectGo.selectedIndex = document.fPageChanger.iDirectGo2.selectedIndex;">
		<?php

		for ($i = 0; $i < ceil($max / $iPageSize); ++$i) {
			printf("<OPTION VALUE=\"%d\"%s>%d</OPTION>\n",
			       $iPageSize * $i + 1,
				   ((($iPageSize * $i + 1) == $iPageTop) ? " SELECTED" : ""),
				   $i + 1);
		}
		
		?>
		</SELECT>
		��
		<INPUT TYPE="button" VALUE="Go" onClick="pg2go();">
	</P>
</FORM>