/*
 * 
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation 
 * bbs, the cross-media distributed communication platform. And it is 
 * developed by Cyberwork Solution in 2000.
 * 
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 * 
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or (at 
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or 
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

#ifndef SYSTEM_LIB_H_INCLUDED
#define SYSTEM_LIB_H_INCLUDED

#include <pthread.h>


#define	MAXLINE	(4096) /* max text line length */


/*
 *  sys_signal.c 
 */
   
typedef void Sigfunc(int); /* for signal handlers */
Sigfunc *sys_signal(int signo, Sigfunc *func);

/*
 *  sys_error.c 
 */

void sys_log(char *fpath , char *message);
void sys_error(const char *fmt, ...);
void sys_err_quit(const char *fmt, ...);

/*
 *  sys_pthread.c
 */

int sys_pthread_create(pthread_t *tid, const pthread_attr_t *attr,
                       void *(*func)(void *), void *arg);
int sys_pthread_join(pthread_t tid, void **status);
int sys_pthread_detach(pthread_t tid);
int sys_pthread_kill(pthread_t tid, int signo);
int sys_pthread_mutexattr_init(pthread_mutexattr_t *attr);
int sys_pthread_mutex_init(pthread_mutex_t *mptr, pthread_mutexattr_t *attr);
int sys_pthread_mutex_lock(pthread_mutex_t *mptr);
int sys_pthread_mutex_unlock(pthread_mutex_t *mptr);
int sys_pthread_cond_broadcast(pthread_cond_t *cptr);
int sys_pthread_cond_signal(pthread_cond_t *cptr);
int sys_pthread_cond_wait(pthread_cond_t *cptr, pthread_mutex_t *mptr);
int sys_pthread_cond_timedwait(pthread_cond_t *cptr, pthread_mutex_t *mptr,
                               const struct timespec *tsptr);
int sys_pthread_once(pthread_once_t *ptr, void (*func)(void));
int sys_pthread_key_create(pthread_key_t *key, void (*func)(void *));
int sys_pthread_setspecific(pthread_key_t key, const void *value);
void *sys_pthread_getspecific(pthread_key_t key);

/*
 *  sys_unix.c
 */

void *sys_alloca(size_t);
void *sys_calloc(size_t n, size_t size);
int sys_close(int fd);
int sys_dup2(int fd1, int fd2);
int sys_fcntl(int fd, int cmd, int arg);
int sys_gettimeofday(struct timeval *tv, void *ptr);
int sys_ioctl(int fd, int request, void *arg);
pid_t sys_fork(void);
void *sys_malloc(size_t size);
void sys_free(void *ptr);
char *sys_mktemp(char *template);
void *sys_mmap(void *addr, size_t len, int prot, int flags, int fd,
               off_t offset);
int sys_open(const char *pathname, int oflag, mode_t mode);
int sys_pipe(int *fds);
ssize_t sys_read(int fd, void *ptr, size_t nbytes);
int sys_sigaddset(sigset_t *set, int signo);
int sys_sigdelset(sigset_t *set, int signo);
int sys_sigemptyset(sigset_t *set);
int sys_sigfillset(sigset_t *set);
int sys_sigismember(const sigset_t *set, int signo);
int sys_sigpending(sigset_t *set);
int sys_sigprocmask(int how, const sigset_t *set, sigset_t *oset);
char *sys_trdup(const char *str);
long sys_sysconf(int name);
int sys_sysctl(int *name, u_int namelen, void *oldp, size_t *oldlenp,
               void *newp, size_t newlen);
int sys_unlink(const char *pathname);
pid_t sys_wait(int *iptr);
pid_t sys_waitpid(pid_t pid, int *iptr, int options);
int sys_write(int fd, void *ptr, size_t nbytes);
void sys_exit(int value);
int sys_chdir(const char *path);
int sys_isfdtype(int fd, int fdtype);
ssize_t readline(int fd, void *vptr, size_t maxlen, char symbol);
ssize_t sys_readline(int fd, void *ptr, size_t maxlen , char symbol);

#endif /* SYSTEM_LIB_H_INCLUDED */

