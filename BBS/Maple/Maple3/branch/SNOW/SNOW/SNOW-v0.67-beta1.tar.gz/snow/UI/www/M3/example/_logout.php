<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();

$mrr = array(
	"bbs_logout" => array(
		0 => array(
			"MRR-SID" => array(0 => session_id())
		)
	)
);
$result = MRRquery($mrr);

$GLOBALS["sUserID"] = "";
$GLOBALS["sUserName"] = "";

HISTORYclean();
$goPage = array("URI" => "main.php", "TITLE", "����");
$redirect = sprintf("Location: %s", $goPage["URI"]);
header($redirect);
exit();

?>