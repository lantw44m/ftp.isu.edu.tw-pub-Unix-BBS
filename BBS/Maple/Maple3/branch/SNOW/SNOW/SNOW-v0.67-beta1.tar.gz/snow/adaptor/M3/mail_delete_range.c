/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: mail_delete_range.c,v 1.3 2000/09/30 16:18:13 jeffhung Exp $
 */

#undef DEBUG_MAIL_DELETE_RANGE

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"
#include <stdlib.h> /* for malloc */
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */

#ifdef AS_ARNI_MODULE

int mod_mail_delete_range(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return mail_delete_range(ofd, parg->args[0].s, parg->args[1].s,
	                         parg->args[2].s);
}

#endif /* AS_ARNI_MODULE */


int mail_delete_range(int ofd, char *userid, char *startfname, char *endfname)
{
	char		lower_userid[IDLEN + 1];
	char		fpath[MAXPATHLEN];
	struct stat	st;
	int			mailnum;
	HDR			*mailbuf;
	FILE		*mailfp;
	int			i; /* generic i */
	int			startpos; /* start position of delete range */
	int			endpos; /* end position of delete range */
	char		fnewpath[MAXPATHLEN];
	FILE		*nmailfp; /* new mail index file */
	int			nmailnum;
	char		fdelpath[MAXPATHLEN];

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

	write(ofd, "MRR-RESULT:mail_delete_range\n",
	      strlen("MRR-RESULT:mail_delete_range\n"));

	/* prevent buffer overflow */
	if (strlen(userid) > IDLEN) {
		userid[IDLEN] = 0;
	}

	str_lower(lower_userid, userid);
	snprintf(fpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/" FN_DIR,
	         lower_userid[0], lower_userid);

	if (lstat(fpath, &st) < 0) {
		write(ofd, "RESULT:mailbox index file not found\nMRR-END:\n",
		      strlen("RESULT:mailbox index file not found\nMRR-END:\n"));
		return -999; /* mailbox index file not found */
	}
	mailnum = st.st_size / sizeof(HDR);

	if (!(mailbuf = (HDR*)malloc(sizeof(HDR) * mailnum))) {
		write(ofd, "RESULT:allocate memory error\nMRR-END:\n",
		      strlen("RESULT:allocate memory error\nMRR-END:\n"));
		return -999; /* allocate memory error */
	}
	memset(mailbuf, 0, sizeof(HDR) * mailnum);

	if (!(mailfp = fopen(fpath, "r"))) {
		free(mailbuf);
		write(ofd, "RESULT:open mailbox index file error\nMRR-END:\n",
		      strlen("RESULT:open mailbox index file error\nMRR-END:\n"));
		return -999; /* open mailbox index file error */
	}

	/* read all stuffs into buffer */
	if ((mailnum = fread(mailbuf, sizeof(HDR), mailnum, mailfp)) < 0) {
		fclose(mailfp);
		free(mailbuf);
		write(ofd, "RESULT:read mailbox index file error\nMRR-END:\n",
		      strlen("RESULT:\nMRR-END:\n"));
		return -999; /* read mailbox index file error */
	}

	fclose(mailfp);

	/* JeffHung.20000721: -1 means not found yet */
	startpos = -1;
	endpos = -1;
	for (i = 0; i < mailnum; ++i) {
		if (!strcmp(mailbuf[i].xname, startfname)) {
			startpos = i;
		}
		if (!strcmp(mailbuf[i].xname, endfname)) {
			endpos = i;
		}
		if ((startpos != -1) && (endpos != -1)) {
			/* JeffHung.20000721: both found */
			break;
		}
	}

	if ((startpos == -1) || (endpos == -1) || (endpos < startpos)) {
		write(ofd, "RESULT:range error\nMRR-END:\n",
		      strlen("RESULT:range error\nMRR-END:\n"));
		return -999; /* range error */
	}

	/*
	 *  write to new index file
	 *
	 *  JeffHung.20000724: f_new and hdr_prune are too dirty, so I'll do
	 *  it by my self.
	 */
	snprintf(fnewpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/" FN_DIR ".n",
	         lower_userid[0], lower_userid);

	if (!(nmailfp = fopen(fnewpath, "w"))) {
		free(mailbuf);
		write(ofd, "RESULT:can not open new mail index file\nMRR-END:\n",
		      strlen("RESULT:can not open new mail index file\nMRR-END:\n"));
		return -999; /* can not open new mail index file */
	}

	for (i = 0, nmailnum = 0; i < mailnum; ++i) {
		if ((mailbuf[i].xmode & MAIL_MARKED) || /* mark */
		    ((i < startpos) || (i > endpos)) || /* range */
		    (!startpos && Tagger(mailbuf[i].chrono, i - 1, TAG_NIN))) { /* TagList */
			/* keep mail */
			if (fwrite(&(mailbuf[i]), sizeof(HDR), 1, nmailfp) != 1) {
				free(mailbuf);
				fclose(nmailfp);
				unlink(fnewpath);
				write(ofd, "RESULT:unable to write to new mail index file\n"
				           "MRR-END:\n",
				      strlen("RESULT:unable to write to new mail index file\n"
				           "MRR-END:\n"));
				return -999; /* unable to write to new mail index file */
			}
			++nmailnum;
		}
		else {
			/* delete mail */
			snprintf(fdelpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/@/%s",
			         lower_userid[0], lower_userid, mailbuf[i].xname);
			unlink(fdelpath);
		}
	}

	/* JeffHung:20000724: reuse fdelpath */
	snprintf(fdelpath, MAXPATHLEN, BBSHOME "/usr/%c/%s/" FN_DIR ".o",
	         lower_userid[0], lower_userid);
	rename(fpath, fdelpath);
	if (nmailnum > 0) {
		rename(fnewpath, fpath);
	}
	else {
		unlink(fnewpath);
	}

	write(ofd, "RESULT:OK\nMRR-END:\n",
	      strlen("RESULT:\nMRR-END:\n"));

	return 0;
}


