/*
 * 
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation 
 * bbs, the cross-media distributed communication platform. And it is 
 * developed by Cyberwork Solution in 2000.
 * 
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 * 
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or (at 
 * your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or 
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

#include "system_lib.h"

#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/uio.h>
#include <sys/sysctl.h>
#include <sys/wait.h>


void *sys_alloca(size_t size)
{
	void *ptr;
	if ((ptr = alloca(size)) == NULL) {
		sys_error("alloca error");
	}
	return ptr;  
}

void *sys_calloc(size_t n, size_t size)
{
	void  *ptr;

	if ((ptr = calloc(n, size)) == NULL) {
		sys_error("calloc error");
	}
	return(ptr);
}

int sys_close(int fd)
{
	int	result;

	if ((result = close(fd)) < 0) {
		sys_error("close error");
	}
	return result;
}

int sys_dup2(int fd1, int fd2)
{
	int	result;

	if ((result = dup2(fd1, fd2)) == -1) {
		sys_error("dup2 error");
	}

	return result;
}

int sys_fcntl(int fd, int cmd, int arg)
{
	int	n;

	if ((n = fcntl(fd, cmd, arg)) == -1) {
		sys_error("fcntl error");
	}
	return (n);
}

int sys_gettimeofday(struct timeval *tv, void *ptr)
{
	int result;

	if ((result = gettimeofday(tv, ptr)) == -1) {
		sys_error("gettimeofday error");
	}
	return result;
}

int sys_ioctl(int fd, int request, void *arg)
{
	int	n;

	if ((n = ioctl(fd, request, arg)) == -1) {
		sys_error("ioctl error");
	}
	return(n);  
}

pid_t sys_fork(void)
{
	pid_t pid;

	if ((pid = fork()) == -1) {
		/* fork error */
		sys_error("fork error");
	}
	return(pid);
}

void *sys_malloc(size_t size)
{
	void	*ptr;

	if ((ptr = malloc(size)) == NULL) {
		sys_error("malloc error");
	}
	return(ptr);
}

void sys_free(void *ptr)
{
	free(ptr);
	return;
}


void *sys_mmap(void *addr, size_t len, int prot, int flags, int fd,
               off_t offset)
{
	void	*ptr;

	if ((ptr = mmap(addr, len, prot, flags, fd, offset)) == ((void*)(-1))) {
		sys_error("mmap error");
	}
	return(ptr);
}

int sys_open(const char *pathname, int oflag, mode_t mode)
{
	int	fd;

	if ((fd = open(pathname, oflag, mode)) == -1) {
		sys_error("file:%s open error", pathname);
	}
	return(fd);
}

int sys_pipe(int *fds)
{
	int result;
	
	if ((result = pipe(fds)) < 0) {
		sys_error("pipe error");
	}
 
	return result;
}

ssize_t sys_read(int fd, void *ptr, size_t nbytes)
{
	ssize_t	n;

	if ((n = read(fd, ptr, nbytes)) == -1) {
		sys_error("read error");
	}
	return(n);
}

int sys_sigaddset(sigset_t *set, int signo)
{
	int result;

	if ((result = sigaddset(set, signo)) == -1) {
		sys_error("sigaddset error");
	}
	return result;
}

int sys_sigdelset(sigset_t *set, int signo)
{
	int	result;

	if ((result = sigdelset(set, signo)) == -1) {
		sys_error("sigdelset error");
	}
	return result;
}

int sys_sigemptyset(sigset_t *set)
{
	int	result;

	if ((result = sigemptyset(set)) == -1) {
		sys_error("sigemptyset error");
	}
	return result;
}

int sys_sigfillset(sigset_t *set)
{
	int result;

	if ((result = sigfillset(set)) == -1) {
		sys_error("sigfillset error");
	}
	return result;
}

int sys_sigismember(const sigset_t *set, int signo)
{
	int n;

	if ((n = sigismember(set, signo)) == -1) {
		sys_error("sigismember error");
	}
	return(n);
}

int sys_sigpending(sigset_t *set)
{
	int result;

	if ((result = sigpending(set)) == -1) {
		sys_error("sigpending error");
	}
	return result;
}

int sys_sigprocmask(int how, const sigset_t *set, sigset_t *oset)
{
	int result;

	if ((result = sigprocmask(how, set, oset)) == -1) {
		sys_error("sigprocmask error");
	}
	return result;
}

char *sys_strdup(const char *str)
{
	char	*ptr;

	if ((ptr = strdup(str)) == NULL) {
		sys_error("strdup error");
	}
	return(ptr);
}

long sys_sysconf(int name)
{
	long	val;

	errno = 0; /* in case sysconf() does not change this */
	if ((val = sysconf(name)) == -1) {
		sys_error("sysconf error");
	}
	return(val);
}

int sys_sysctl(int *name, u_int namelen, void *oldp, size_t *oldlenp,
               void *newp, size_t newlen)
{
	int	result;

	if ((result = sysctl(name, namelen, oldp, oldlenp, newp, newlen)) == -1) {
		sys_error("sysctl error");
	}

	return result;
}

int sys_unlink(const char *pathname)
{
	int	result;

	if ((result = unlink(pathname)) == -1) {
		sys_error("unlink error for %s", pathname);
	}

	return result;
}

pid_t sys_wait(int *iptr)
{
	pid_t	pid;

	if ((pid = wait(iptr)) == -1) {
		sys_error("wait error");
	}
	return(pid);
}

pid_t sys_waitpid(pid_t pid, int *iptr, int options)
{
	pid_t	retpid;

	if ((retpid = waitpid(pid, iptr, options)) == -1) {
		sys_error("waitpid error");
	}
	return(retpid);
}

int sys_write(int fd, void *ptr, size_t nbytes)
{
	int result;

	if ((result = write(fd, ptr, nbytes)) != nbytes) {
		sys_error("write error");
	}
	return result;
}

void sys_exit(int value)
{
	exit(value);
}

int sys_chdir(const char *path)
{
	int result;

	if ((result=chdir(path)) == -1 ) {
		sys_error("chdir error");
	}
  
	return result;
}

