/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 * $Id: chat_client.c,v 1.12 2000/09/30 16:18:13 jeffhung Exp $
 */

/* ----------------------------------------------- */
/* chat client adaptor for live_server             */
/* ----------------------------------------------- */

#undef DEBUG_CHAT_CLIENT
#include "live.h"
#include "live_server.h"
#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
static char chatroom[IDLEN];	/* Chat-Room Name */
static char chatopic[48];


#ifdef AS_ARNI_MODULE

int mod_chat_client(int ofd, char *sid , USER_INFO *user_info_pool , struct LIVE_ARGS *args)
{
  char *userid , *chatid, *action , *message , *type;
  int i , index;
	userid  = args->args[0].s;
	chatid  = args->args[1].s;
	action  = args->args[2].s;
	message = args->args[3].s;
	type    = args->args[4].s;

#ifdef DEBUG_CHAT_CLIENT
  fprintf(stderr, "chat_client starting..\n");
#endif
  if( !strcasecmp(type , "chat") )
	{
		if( !strcasecmp(action , ACTION_ENTER) )
  	{
	     for( index = 0 ; index < MAX_CLIENT ; index++ )
			   if( user_info_pool[index].type == TYPE_OFFLINE )
				   break;

#ifdef DEBUG_CHAT_CLIENT
  fprintf(stderr, "call chat_client..\n");
#endif
       
			 return chat_client( 0 , ofd, userid , chatid, action , message , &user_info_pool[index] , sid );       
		}
		if( !strcasecmp(action , ACTION_MSG) )
  	{
		  for( index = 0 ; index < MAX_CLIENT ; index++ )
			{
			  if( user_info_pool[index].type != TYPE_OFFLINE)
				{
				  if( !strcasecmp( user_info_pool[index].userid , userid ) )
					  break;
				}
			}

			if( index < MAX_CLIENT )
			{
  	    return chat_client( user_info_pool[index].fd , ofd, userid , chatid, action , message , &user_info_pool[index] , sid );       
			}
			else return -1;
    }		
  }
}

#endif /* AS_ARNI_MODULE */


static void sys_log(char *fpath, char *message)
{
  int fd;

  if ((fd = open(fpath, O_WRONLY | O_CREAT | O_APPEND, 0600)) >= 0) {
    write(fd, message, strlen(message));
    close(fd);
  }
}

static inline int
chat_send(fd, buf)
  int fd;
  char *buf;
{
  int len;

  len = strlen(buf);
  return (send(fd, buf, len, 0) == len);
}

static int printchatline( char *msg , USER_INFO *user_info)
{
  int index;

	index = user_info->index;
  strncpy( user_info->msg_pool[index].msg , msg , 80);
  strcpy(  user_info->msg_pool[index].chatroom , chatroom);
  user_info->msg_pool[index].msg[79] = '\0';
  user_info->msg_pool[index].chatroom[IDLEN-1] = '\0';
  user_info->index++;
      
}
static inline int
chat_recv(fd, chatid , user_info)
  int fd;
  char *chatid;
	USER_INFO *user_info;
{
  static char buf[512];
  static int bufstart = 0;
	int cc, len;
  char *bptr, *str , option;

  bptr = buf;
  cc = bufstart;
  len = sizeof(buf) - cc - 1;
  if ((len = recv(fd, bptr + cc, len, 0)) <= 0)
    return -1;
  cc += len;

  for (;;)
  {
    len = strlen(bptr);

    if (len >= cc)
    {				/* wait for trailing data */
      memcpy(buf, bptr, len);
      bufstart = len;
      break;
    }
    if (*bptr == '/')
    {
      str = bptr + 1;
      option = *str++;

      if (option == 'n')
      {
	      strncpy(chatid, str, 9);
	      strncpy(cutmp->mateid, str, sizeof(cutmp->mateid));
        printchatline(chatid , user_info);
      }
			else if (fd == 'r')
      {
       	strncpy(chatroom, str, sizeof(chatroom));
      }
			else if (fd == 't')
      {
  	    str_ncpy(chatopic, str, sizeof(chatopic));
      }
		} /* if(*bptr == '/') */
    else
    {
			printchatline(bptr , user_info); 
		}

    cc -= ++len;
    if (cc <= 0)
    {
      bufstart = 0;
      break;
    }
    bptr += len;
  }

  return 0;
}

/* ---------------------------------------------------------------- */
/* Argument: fd      -> �ǹL�Ӫ�socket fd                           */
/*           UserID  -> �ϥΪ�ID                                    */
/*           ChatID  -> chat�Ϊ�ID                                  */
/*           Action  -> �ϥΪ̰ʧ@                                  */
/*           Message -> �T��                                        */
/* ---------------------------------------------------------------- */


int chat_client(int fd, int ofd, char *UserID, char *ChatID ,char *Action, char *Message, USER_INFO *User_Info, char *sid)
{
	int i;
  int index;
	char buf[80], userid[IDLEN+1],chatid[8+1];
  struct sockaddr_in sin;
  char out_buf[GENERAL_BUFSIZE];

#ifdef CHAT_SECURE
  char passbuf[9];  /*arlo: from bbsd */
  if( !strcasecmp(Action , ACTION_ENTER) )
	  strncpy( passbuf , Message , 9);
#endif
  
  chdir(BBSHOME);
  if( !strcasecmp( Action , ACTION_ENTER ) )
  {
    sin.sin_family = AF_INET;
    sin.sin_port = htons(CHAT_PORT);
    sin.sin_addr.s_addr = INADDR_ANY; 
    memset(sin.sin_zero, 0, sizeof(sin.sin_zero));
    fd = socket(AF_INET, SOCK_STREAM, 0);
  }

	if (fd < 0)
   return -1;
#ifdef DEBUG_CHAT_CLIENT
	else fprintf(stderr , "action:%s fd:%d\n" , Action,fd);
  fprintf(stderr , "pre compare action string\n");
#endif
	if( !strcasecmp( Action , ACTION_ENTER) )
	{ /* begin enter command  */
#ifdef DEBUG_CHAT_CLIENT
    fprintf(stderr , "pre connect\n");
#endif
		if (connect(fd, (struct sockaddr *) & sin, sizeof sin))
    {
      close(fd);
      fprintf(stderr , "connect fail\n");
			return -1;
    }
#ifdef DEBUG_CHAT_CLIENT
    fprintf(stderr , "connect ok\n");
#endif
		/* load ACCT data to cuser struct */
	  str_lower(userid, UserID);
	  if (acct_load(&cuser, userid) < 0) 
		{
#ifdef DEBUG_CHAT_CLIENT
			fprintf(stderr, "user:%s acct_load failed\n", userid);
#endif
			return -1;
	  }
/*
    if(!( up = utmp_find(cuser.userno)) )
	    return -1;
    else cutmp = up;
*/
/* ����L���Ϊť�id */
    strncpy(userid, UserID , IDLEN);
  	strncpy(chatid, ChatID , 8 );
    userid[IDLEN] = '\0';  
	  chatid[8] = '\0';

  	for(i = 0 ; i < 8 ; i++ )
  	  if( chatid[i] == ' ');
	  	  chatid[i] = '\0';
#ifdef CHAT_SECURE
		sprintf(buf, "/! %s %s %s\n",
            cuser.userid, chatid, passbuf);
#else
		sprintf(buf, "/! %d %d %s %s\n",
            cuser.userno, cuser.userlevel, cuser.userid, chatid);
#endif
    chat_send(fd, buf);
    if (recv(fd, buf, 3, 0) != 3)
    {
#ifdef DEBUG_CHAT_CLIENT
			fprintf(stderr , "can't login la\n");
#endif
			return 1;
    }
		if (!strcmp(buf, CHAT_LOGIN_EXISTS))
    {
#ifdef DEBUG_CHAT_CLIENT
		  fprintf(stderr , "login exists\n");
#endif
			return -20;
	  }
		else if (!strcmp(buf, CHAT_LOGIN_INVALID))
    {
#ifdef DEBUG_CHAT_CLIENT
		  fprintf(stderr , "login invalid\n");
#endif
      return -30;
	  }
		else if (!strcmp(buf, CHAT_LOGIN_BOGUS))
    {				/* �T��ۦP�G�H�i�J */
#ifdef DEBUG_CHAT_CLIENT
		  fprintf(stderr , "login bogus\n");
#endif
			return -40;
    }

		User_Info->fd   = fd;
    User_Info->type = TYPE_CHAT;
	  strcpy(User_Info->sid , sid);
		strcpy(User_Info->userid , cuser.userid);

    for(;;)
		{
			chat_recv(fd , buf , User_Info);
		}


	} /* end of enter command */
  else if( !strcasecmp( Action , ACTION_MSG) )
	{
#ifdef DEBUG_CHAT_CLIENT
		fprintf(stderr , "action=%s\n" , Action);
	  fprintf(stderr , "DEBUG:message:%s\n" , Message);
#endif
		write(fd, Message , strlen(Message) );
    write(fd,"\n",1);
    
		/*�B�z���}�����O..�H�K�y��leak */
		if( Message[0] == '/' && Message[1] == 'b' )
		{
		  close(fd);
		}

		/* ��Ȧs��message �Ǧ^ , ����²�檺��k*/
		for( index = 0 ; index < User_Info->index ; index++ )
		{
      snprintf(out_buf, GENERAL_BUFSIZE,
              "MRR-RESULT:chat_connect\n"
              "MESSAGE:%s\n\0",
							User_Info->msg_pool[index].msg
			);

			write(ofd,out_buf,strlen(out_buf));
		} /* for( index = 0 ...*/

		if (!User_Info->index)
    {
      snprintf(out_buf, GENERAL_BUFSIZE,
              "MRR-RESULT:chat_connect\n"
              "NO-MSG:YES\n\0" );
			write(ofd,out_buf,strlen(out_buf));
    }

		snprintf(out_buf , GENERAL_BUFSIZE , "MRR-END:\n\0");
    write(ofd , out_buf, strlen(out_buf) );
		User_Info->index = 0;
	}
	return 0;

} /* end of chat_client() */
