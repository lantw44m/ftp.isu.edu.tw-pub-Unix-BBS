<FORM METHOD="post" ACTION="">
	<P> 
		<SELECT NAME="select2">
			<OPTION VALUE="NORMAL" SELECTED>�@��Ҧ�</OPTION>
			<OPTION VALUE="SUBJECT">�P�D�D�Ҧ�</OPTION>
			<OPTION VALUE="AUTHOR">�P�@�̼Ҧ�</OPTION>
		</SELECT>
		<INPUT TYPE="BUTTON" NAME="Submit4" VALUE="�W�@�g">
		<INPUT TYPE="BUTTON" NAME="Submit5" VALUE="�U�@�g">
	</P>
	<P>�ݪO�G<?php echo $iBoardID ?><BR>
		�@�̡G<A HREF="talk_query_user.php"><?php
			echo $result["brd_readpost"][0]["AUTHOR-ID"][0];
		?></A> (<?php
			echo $result["brd_readpost"][0]["AUTHOR-NAME"][0];
		?>)<BR>
		���D�G<?php
			echo $result["brd_readpost"][0]["SUBJECT"][0];
		?><BR>
		�ɶ��G<?php
			echo $result["brd_readpost"][0]["DATE"][0];
		?><BR>
		<!--
		���W�GNCTU CSIE FreeBSD Server<BR>
		���|�GOBW3IFBBS!netnews.hinet.net!ctu-gate!ctu-peer!news.nctu!News.Math.NCTU!<BR>
		�ӷ��Gfreebsd.csie.nctu.edu.tw </P>
		-->
	<P>
	<?php

		$body = $result["brd_readpost"][0]["BODY"];
//		printf("<!-- %s -->\n", serialize($body));
		for ($i = 0; $i < count($body); ++$i) {
			$leadingString = substr($body[$i], 0, 2);
			if (chop($leadingString) == "��") {
				$span_class = "MoreQuoteFrom";
			}
			else if (chop($leadingString) == ":") {
				$span_class = "MoreQuote";
			}
			else if (chop($leadingString) == ">") {
				$span_class = "MoreQuote";
			}
			else {
				$span_class = "MoreText";
			}
			printf("<SPAN CLASS=\"%s\">%s</SPAN><BR>\n", $span_class, $body[$i]);
		}

	?>
	<P>
		<SELECT NAME="select3">
			<OPTION VALUE="NORMAL" SELECTED>�@��Ҧ�</OPTION>
			<OPTION VALUE="SUBJECT">�P�D�D�Ҧ�</OPTION>
			<OPTION VALUE="AUTHOR">�P�@�̼Ҧ�</OPTION>
		</SELECT>
		<INPUT TYPE="BUTTON" NAME="Submit42" VALUE="�W�@�g">
		<INPUT TYPE="BUTTON" NAME="Submit52" VALUE="�U�@�g">
	</P>
</FORM>