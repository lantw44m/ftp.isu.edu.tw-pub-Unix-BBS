/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: talk_recvmsg_main.c,v 1.3 2000/09/30 16:18:14 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"
#include <stdio.h>


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 2) {
		printf("Usage: %s <session-id>\n", argv[0]);
		return 0;
	}

	if ((ret = talk_recvmsg(fileno(stdout), argv[1])) != 0) {
		fprintf(stderr, "talk_recvmsg() error(%d).\n", ret);
	}

	return 0;
}

