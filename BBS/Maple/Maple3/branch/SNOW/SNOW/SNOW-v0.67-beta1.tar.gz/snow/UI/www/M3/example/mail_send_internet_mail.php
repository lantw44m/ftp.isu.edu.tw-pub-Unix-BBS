<?php

include("snow.phps");
include("snow_util.phps");

SESSIONinit();
HISTORYset("�H�e Internet �H��");

$SNOW_PAGE_TITLE = "�H�e Internet �H��";
$SNOW_PAGEAREA_MAIN = "mail_send_internet_mail.m.php";
$SNOW_PAGEAREA_FUNC = "mail_send_internet_mail.f.php";

include("bone.php");

?>