/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: user_toggle_flag.c,v 1.3 2000/09/30 16:18:14 jeffhung Exp $
 */

#undef DEBUG_USER_TOGGLE_FLAG

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>


int user_toggle_flag(int ofd, char *sid, char *flagname)
{
	W3IF_SESSENTRY *psess;
	int            ufo;
	int            nflag;
	int            len;
	int            ufo_old;
	int            toggle_bit;

	chdir(BBSHOME);

#ifdef HAVE_SEM
	sem_init();
#endif /* HAVE_SEM */
	ushm_init();

	psess = w3ifsession_get(sid);

	if (!psess) {
		return -999; /* no such user */
	}

	ap_start = psess->ap_start;
	cutmp = psess->utmp_entry;
	acct_load(&cuser, cutmp->userid);

	nflag = cuser.userlevel;
	if (!nflag) {
		len = 5;
	}
	else if (nflag & PERM_ADMIN) {
		/*
		 *  Thor.980910:
		 *
		 *  �ݪ`�N��PERM_ADMIN���F�i��acl, �ٶ��K�]�i�H�������N�F:P
		 */
		len = 21;
	}
	else if (nflag & PERM_CLOAK) {
		len = 20;
	}
	else {
		len = 13;
	}

#ifdef DEBUG_USER_TOGGLE_FLAG
	fprintf(stderr, "DEBUG(%s,%d):len:%d\n", __FILE__, __LINE__, len);
#endif /* DEBUG_USER_TOGGLE_FLAG */

	ufo_old = ufo = cuser.ufo;

#ifdef DEBUG_USER_TOGGLE_FLAG
	fprintf(stderr, "DEBUG(%s,%d):ufo_old:%x\n", __FILE__, __LINE__, ufo_old);
#endif /* DEBUG_USER_TOGGLE_FLAG */

	/* update ufo according to len */
	for (toggle_bit = 0; toggle_bit < user_flags_num; ++toggle_bit) {
		if (!strcasecmp(flagname, user_flags[toggle_bit])) {

#ifdef DEBUG_USER_TOGGLE_FLAG
			fprintf(stderr, "DEBUG(%s,%d):got flag named: %s\n",
			        __FILE__, __LINE__, flagname);
#endif /* DEBUG_USER_TOGGLE_FLAG */

			break;
		}
	}
	if (toggle_bit >= user_flags_num) {
		return -999; /* no such flag to toggle */
	}

	ufo ^= (1 << toggle_bit);

#ifdef DEBUG_USER_TOGGLE_FLAG
	fprintf(stderr, "DEBUG(%s,%d):ufo changed to %x\n",
	        __FILE__, __LINE__, ufo);
#endif /* DEBUG_USER_TOGGLE_FLAG */

	if (ufo == ufo_old) {
		return 0; /* no thing changed */
	}

	/* Thor.980805: �ѨM ufo BIFF���P�B���D */
	ufo = ((ufo & ~UFO_UTMP_MASK) | (cutmp->ufo & UFO_UTMP_MASK));

	/*
	 *  Thor.980805:
	 *
	 *  �n�S�O�`�N cuser.ufo�Mcutmp->ufo��UFO_BIFF���P�B���D,�A��
	 */
	cutmp->ufo = cuser.ufo = ufo;

#ifdef DEBUG_USER_TOGGLE_FLAG
	fprintf(stderr, "DEBUG(%s,%d):cuser.ufo:%x\n",
	        __FILE__, __LINE__, cuser.ufo);
#endif /* DEBUG_USER_TOGGLE_FLAG */

	/* save cuser back */
	acct_save(&cuser);

	write(ofd, "MRR-RESULT:user_toggle_flag\nRESULT:OK\n",
	      strlen("MRR-RESULT:user_toggle_flag\nRESULT:OK\n"));

	return 0;
}


