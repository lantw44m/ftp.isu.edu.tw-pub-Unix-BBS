<SCRIPT LANGUAGE="JavaScript">
<!--

// ��Ĥ@��
function pg2first()
{
	document.fPageChanger.iPageTop = 1;
}

// ��W�@��
function pg2prev()
{
	document.fPageChanger.iPageTop = document.fPageChanger.iPageTop - document.fPageChanger.iPageSize;
	if (document.fPageChanger.iPageTop < 1) {
		document.fPageChanger.iPageTop = 1;
	}
}

// ��U�@��
function pg2next()
{
	document.fPageChanger.iPageTop = document.fPageChanger.iPageTop + document.fPageChanger.iPageSize;
}

// ��̥���
function pg2last()
{
	document.fPageChanger.iPageTop = 2;
}

function pg2no()
{
}

//-->
</SCRIPT>
<FORM METHOD="post" NAME="fPageChanger" ACTION="brd_plist.php">
	<INPUT TYPE="hidden" NAME="iBoardID" VALUE="">
	<INPUT TYPE="hidden" NAME="iPageTop" VALUE="">
	<INPUT TYPE="hidden" NAME="iPageSize" VALUE="">
	<P> 
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo" onChange="document.fPageChanger.iDirectGo2.selectedIndex = document.fPageChanger.iDirectGo.selectedIndex;">
		<!-- �N�W�U�� <SELECT> �P�B -->
			<?php
			
			$post_num = $result["brd_post_num"][0]["POSTNUM"][0];
			$page_num = ceil($post_num / $iPageSize);
			$curr_page = ceil($iPageTop / $iPageSize);

			printf("<!-- iPageTop: %d, iPageSize: %d, post_num: %d, page_num: %d, curr_page: %d -->\n",
			       $iPageTop, $iPageSize, $post_num, $page_num, $curr_page);

			for ($i = 0; $i < $page_num; ++$i) {
				printf("<OPTION VALUE=\"%d\"%s>%d</OPTION>\n",
				       $i + 1, (($i + 1 == $curr_page) ? " SELECTED" : ""), $i + 1);
			}

			?>
			<!--
			<OPTION VALUE="1" SELECTED>1</OPTION>
			<OPTION VALUE="2">2</OPTION>
			-->
		</SELECT>
		��
		<INPUT TYPE="button" VALUE="Go" onClick="pg2no();">
		</P>
	<TABLE WIDTH="100%" BORDER="1">
		<TR> 
			<TH>�s��</TH>
			<TH>�Х�</TH>
			<TH>���</TH>
			<TH>�@��</TH>
			<TH>�峹���D</TH>
		</TR>
		<?php
		
		$plist = $result["brd_plist"];

		for ($i = 0; $i < count($plist); ++$i) {
			printf("<TR>\n");
			printf("<TD>%d <INPUT TYPE=\"radio\" NAME=\"iItem\" VALUE=\"%s\"></TD>\n",
			       $plist[$i]["INDEX"][0], $plist[$i]["FILENAME"][0]);
			printf("<TD>+</TD>\n");
			printf("<TD>%s</TD>\n", $plist[$i]["TIMESTAMP"][0]);
			printf("<TD><A HREF=\"talk_query_user.php\">%s</A></TD>\n", $plist[$i]["AUTHOR-ID"][0]);
			printf("<TD><A HREF=\"brd_read_post.php?iBoardID=%s&iFilename=%s\">%s</A></TD>\n",
			       $iBoardID, $plist[$i]["FILENAME"][0], $plist[$i]["SUBJECT"][0]);
			printf("</TR>\n");
		}

		?>
		<!--
		<TR> 
			<TD>1
				<INPUT TYPE="radio" NAME="iItem" VALUE="filename1">
			</TD>
			<TD>+</TD>
			<TD>07/21</TD>
			<TD><A HREF="talk_query_user.php">Pahud</A></TD>
			<TD><A HREF="brd_read_post.php">�� �аݦp�G�Q�J�I�|�X�{���g�T��</A></TD>
		</TR>
		<TR> 
			<TD HEIGHT="19">2
				<INPUT TYPE="radio" NAME="iItem" VALUE="filename2">
			</TD>
			<TD HEIGHT="19">m</TD>
			<TD HEIGHT="19">07/21</TD>
			<TD HEIGHT="19"><A HREF="talk_query_user.php">jslu</A></TD>
			<TD HEIGHT="19"><A HREF="brd_read_post.php">Re: �ǩǪ����~? ����: �ϥΪ̤j�q�ϥ� 
				cpu �귽</A></TD>
		</TR>
		<TR> 
			<TD>3
				<INPUT TYPE="radio" NAME="iItem" VALUE="filename3">
			</TD>
			<TD>&nbsp;</TD>
			<TD>07/21</TD>
			<TD><A HREF="talk_query_user.php">JeffHung.</A></TD>
			<TD><A HREF="brd_read_post.php">�� [���]The Java SSH/Telnet Application/Applet 
				2</A></TD>
		</TR>
		-->
	</TABLE>
	<P>
		<INPUT TYPE="button" VALUE="�Ĥ@��" onClick="pg2first();">
		<INPUT TYPE="button" VALUE="�W�@��" onClick="pg2prev();">
		<INPUT TYPE="button" VALUE="�U�@��" onClick="pg2next();">
		<INPUT TYPE="button" VALUE="�̥���" onClick="pg2last();">
		������� 
		<SELECT NAME="iDirectGo2" onChange="document.fPageChanger.iDirectGo.selectedIndex = document.fPageChanger.iDirectGo2.selectedIndex;">
		<!-- �N�W�U�� <SELECT> �P�B -->
			<?php
			
			for ($i = 0; $i < $page_num; ++$i) {
				printf("<OPTION VALUE=\"%d\"%s>%d</OPTION>\n",
				       $i + 1, (($i + 1 == $curr_page) ? " SELECTED" : ""), $i + 1);
			}

			?>
			<!--
			<OPTION VALUE="1" SELECTED>1</OPTION>
			<OPTION VALUE="2">2</OPTION>
			-->
		</SELECT>
		��
		<INPUT TYPE="button" VALUE="Go" onClick="pg2no();">
	</P>
</FORM>