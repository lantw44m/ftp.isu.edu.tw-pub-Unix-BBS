/*
 *  $Id: brd_plist.c,v 1.2 2000/09/30 08:05:11 jeffhung Exp $
 */

#include "bbs.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "w3if.h"
#include "dao.h"
#include <stdlib.h> /* for malloc */
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */


#ifdef AS_ARNI_MODULE

int mod_brd_plist(int ofd, char *sid, struct ARNI_ARGS *parg)
{
	return brd_plist(ofd, parg->args[0].s, parg->args[1].i, parg->args[2].i);
}

#endif /* AS_ARNI_MODULE */

static int outputHDR(int ofd, int index, HDR *hdr)
{
	static char	buf[GENERAL_BUFSIZE];

	snprintf(buf, GENERAL_BUFSIZE, "MRR-RESULT:brd_plist\n");
	write(ofd, buf, strlen(buf));

	snprintf(buf, GENERAL_BUFSIZE, "INDEX:%d\n", index);
	write(ofd, buf, strlen(buf));

	snprintf(buf, GENERAL_BUFSIZE, "TIMESTAMP:%d\n", (int)(hdr->chrono));
	write(ofd, buf, strlen(buf));

	snprintf(buf, GENERAL_BUFSIZE, "FILENAME:%s\n", hdr->xname);
	write(ofd, buf, strlen(buf));

	snprintf(buf, GENERAL_BUFSIZE, "AUTHOR-ID:%s\n", hdr->owner);
	write(ofd, buf, strlen(buf));

	snprintf(buf, GENERAL_BUFSIZE, "AUTHOR-NAME:%s\n", hdr->nick);
	write(ofd, buf, strlen(buf));

	snprintf(buf, GENERAL_BUFSIZE, "SUBJECT:%s\n", hdr->title);
	write(ofd, buf, strlen(buf));

	return 0;
}

/*
 *  return value:
 */
int brd_plist(int ofd, char *brdname, int pagetop, int pagesize)
{
	struct stat	st;
	BRD			*brdbuf;
	int			brdnum;
	FILE		*brdfp;
	int			i; /* generic i */
	HDR			*hdrbuf;
	char		fpath[MAXPATHLEN];
	FILE		*hdrfp;
	int			j; /* generic j */
	int			hdrnum;
	char        buf[GENERAL_BUFSIZE];

	/* JeffHung.20000718: get board index size */
	if (lstat(BBSHOME "/.BRD", &st) < 0) {
		return -999; /* board index file not found */
	}
	brdnum = st.st_size / sizeof(BRD);

	if (!(brdbuf = (BRD*)malloc(sizeof(BRD) * brdnum))) {
		return -999; /* allocate memory error */
	}
	memset(brdbuf, 0, sizeof(BRD) * brdnum);

	if (!(brdfp = fopen(BBSHOME "/.BRD", "r"))) {
		free(brdbuf);
		return -999; /* open board index file error */
	}

	/* read all stuff into buffer */
	if ((brdnum = fread(brdbuf, sizeof(BRD), brdnum, brdfp)) < 0) {
		fclose(brdfp);
		free(brdbuf);
		return -999; /* read board index file error */
	}

	fclose(brdfp);

	for (i = 0; i < brdnum; ++i) {
		if (!strncasecmp(brdbuf[i].brdname, brdname, IDLEN)) {

			if (!(hdrbuf = (HDR*)malloc(sizeof(HDR) * pagesize))) {
				return -999; /* allocate memory error */
			}

			snprintf(fpath, MAXPATHLEN, BBSHOME "/brd/%s/.DIR",
			         brdbuf[i].brdname);
			lstat(fpath, &st); /* JeffHung.20000718: reuse st */
			hdrnum = st.st_size / sizeof(HDR);

			/* JeffHung.20000718: �ץ� pagetop */
			if (pagetop < 0) {
				pagetop = 1;
			}
			if (pagetop >= hdrnum) {
				pagetop = hdrnum - pagesize;
			}

			if (!(hdrfp = fopen(fpath, "r"))) {
				return -999; /* read post index file error */
			}
			if (fseek(hdrfp, sizeof(HDR) * (pagetop - 1), SEEK_SET) < 0) {
				return -999; /* seek file post error */
			}
			fread(hdrbuf, sizeof(HDR), pagesize, hdrfp);
			fclose(hdrfp);
			for (j = 0; j < pagesize; ++j) {
				outputHDR(ofd, pagetop + j, &(hdrbuf[j]));
			}
			free(hdrbuf);
			snprintf(buf, GENERAL_BUFSIZE,
			         "MRR-RESULT:brd_post_num\n"
			         "POSTNUM:%d\n", hdrnum);
			write(ofd, buf, strlen(buf));
			write(ofd, "MRR-END:", strlen("MRR-END:"));
			return 0; /* success */
		}
	}

	free(brdbuf);
	return -999; /* board not found */
}

