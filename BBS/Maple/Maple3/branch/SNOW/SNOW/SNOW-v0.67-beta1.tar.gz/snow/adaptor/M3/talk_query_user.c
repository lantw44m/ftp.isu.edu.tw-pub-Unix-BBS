/*
 * SNOW (Snow's Not Only WebBBS ) is a model toward to next generation
 * bbs, the cross-media distributed communication platform. And it is
 * developed by Cyberwork Solution in 2000.
 *
 * Copyright (C) 2000 CYBERWORK SOLUTION,Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. Or
 * write e-mail to:
 *
 *    jeffhung@cyberworksolution.com , Hung, Chen-Chou
 *    cpf@cyberworksolution.com , Cheung, Pei-Fang
 *    arlo@cyberworksolution.com , Liu, Yen-You
 *
 * Legal Counsel
 *
 *    isabelho@cyberworksolution , Isabel Ho
 *
 */

/*
 *  $Id: talk_query_user.c,v 1.3 2000/09/30 16:18:14 jeffhung Exp $
 */

#define	_MODES_C_	/* for ModeTypeTable */

#include "bbs.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#ifdef AS_ARNI_MODULE
#include "arni_server.h"
#endif /* AS_ARNI_MODULE */

#ifdef AS_ARNI_MODULE

int mod_talk_query_user(int ofd, struct ARNI_ARGS *parg)
{
	return talk_query_user(ofd, parg->args[0].s);
}

#endif /* AS_ARNI_MODULE */


char* bmode(UTMP* up, int simple)
{
	static char	modestr[32];
	int			mode;
	char*		word;

	word = ModeTypeTable[mode = up->mode];
	if (simple) {
		return word;
	}

	if (mode < M_TALK || mode > M_QUERY) {
		return word;
	}

	/* Thor.980805: ����: �������H���|�Q���D���talk */
	if ((mode != M_QUERY) &&
	    !HAS_PERM(PERM_SEECLOAK) &&
	    (up->ufo & UFO_CLOAK)) {
		return word;
	}

	snprintf(modestr, 32, "%s [%s]", word, up->mateid);
	return modestr;
}


void showplans(char* userid)
{
	int		i;
	FILE*	fp;
	char	buf[256];

	usr_fpath(buf, userid, fn_plans);
	if (fp = fopen(buf, "r")) {
		i = MAXQUERYLINES;
		while (i-- && fgets(buf, sizeof(buf), fp)) {
			printf("%s", buf);
		}
		fclose(fp);
	}
}


void talk_query_user(int ofd, char* userid_toquery)
{
	ACCT  acctoq;
	UTMP* up;
	char  buf[1024];
	int   i;
	FILE* fp;
	char  rbuf[512];

	/*
	 *  JeffHung.20000731: Arlo said, before using acct_XXX, we should
	 *  chdir to BBSHOME
	 */
	chdir(BBSHOME);

	acct_load(&acctoq, userid_toquery);

	up = (acctoq.lastlogin < time(0) - 6 * 3600) ? 0 : utmp_find(acctoq.userno);

	sprintf(buf, "\n"
	             "�ϥΪ̱b��: %s\n"
	             "�ϥΪ̼ʺ�: %s\n"
	             "�W������: %s\n"
	             "�峹�g��: %s\n"
	             "�O�_�q�L�����{��: %s\n"
	             "�W���W���ɶ�: %s\n"
	             "�W���W���Ӧ�: %s\n"
	             "�ʺA: %s\n"
	             "�O�_���s�H��: %s\n",
	             acctoq.userid,
	             acctoq.username,
	             acctoq.numlogins,
	             acctoq.numposts,
	             ((acctoq.userlevel & PERM_VALID) ? "�O" : "�_"),
	             Ctime(&(acctoq.lastlogin)),
	             acctoq.lasthost,
	             (up && (HAS_PERM(PERM_SEECLOAK) || !(up->ufo & UFO_CLOAK))) ?
	                 bmode(up, 1) : "���b���W",
	             (m_query(acctoq.userid) ? "�O" : "�_"));
	write(ofd, buf, strlen(buf));


#if	defined(REALINFO) && defined(QUERY_REALNAMES)

	if (HAS_PERM(PERM_BASIC)) {
		sprintf(buf, "�u��m�W: %s\n", acctoq.realname);
		write(ofd, buf, strlen(buf));
	}

#endif	/* REALINFO && QUERY_REALNAMES */

	sprintf(buf, "������: (�ۤU��_���O������)\n");
	write(ofd, buf, strlen(buf));

    usr_fpath(rbuf, acctoq.userid, fn_plans);
    if (fp = fopen(rbuf, "r")) {
        i = MAXQUERYLINES;
        while (i-- && fgets(rbuf, sizeof(rbuf), fp)) {
            sprintf(buf, "%s", rbuf);
			write(ofd, buf, strlen(buf));
        }
        fclose(fp);
    }
}


