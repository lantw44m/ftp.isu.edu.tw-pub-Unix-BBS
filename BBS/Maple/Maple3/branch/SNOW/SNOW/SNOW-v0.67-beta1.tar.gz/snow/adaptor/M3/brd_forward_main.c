/*
 *  $Id: brd_forward_main.c,v 1.3 2000/09/30 11:40:11 jeffhung Exp $
 */

#include "bbs.h"
#include "w3if.h"
#include "w3iflib.h"
#include "w3ifglobal.h"
#include "dao.h"


int main(int argc, char* argv[])
{
	int	ret;

	if (argc != 5) {
		printf("Usage: %s <user-id> <to-address> <brd-id> <post-filename>\n",
		       argv[0]);
		return 0;
	}

	if ((ret = brd_forward(fileno(stdout), argv[1], argv[2], argv[3], argv[4])) < 0) {
		fprintf(stderr, "brd_forward error(%d).\n", ret);
	}

	return 0;
}

