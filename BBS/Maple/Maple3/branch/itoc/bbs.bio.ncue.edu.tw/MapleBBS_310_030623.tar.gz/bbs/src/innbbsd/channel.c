/*-------------------------------------------------------*/
/* channel.c	( NTHU CS MapleBBS Ver 3.10 )		 */
/*-------------------------------------------------------*/
/* target : innbbsd main program			 */
/* create : 95/04/27					 */
/* update :   /  /  					 */
/* author : skhuang@csie.nctu.edu.tw			 */
/*-------------------------------------------------------*/


#include "innbbsconf.h"
#include "daemon.h"
#include <dirent.h>
#include "bbslib.h"
#include "inntobbs.h"
#include "nntp.h"

#ifdef _NoCeM_
#include "nocem.h"
#endif
#ifdef GETRUSAGE
#include <sys/resource.h>
#endif


/* ----------------------------------------------------- */
/* connect sock						 */
/* ----------------------------------------------------- */

static fd_set rfd, orfd;
static ClientType INNBBSD_STAT;


static void
reapchild(s)
  int s;
{
  int state;
  while (waitpid(-1, &state, WNOHANG | WUNTRACED) > 0)
  {
    /* printf("reaping child\n"); */
  }
}


static void
dokill(s)
  int s;
{
  kill(0, SIGKILL);
}


static INETDstart = 0;


static int
startfrominetd(flag)
{
  INETDstart = flag;
}


static int
standalonesetup(fd)
  int fd;
{
  int on = 1;
  struct linger foobar;
  if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (char *) &on, sizeof(on)) < 0)
    syslog(LOG_ERR, "setsockopt (SO_REUSEADDR): %m");
  foobar.l_onoff = 0;
  if (setsockopt(fd, SOL_SOCKET, SO_LINGER, (char *) &foobar, sizeof(foobar)) < 0)
    syslog(LOG_ERR, "setsockopt (SO_LINGER): %m");
}


static char *UNIX_SERVER_PATH;
static int (*halt) ();


static void
sethaltfunction(haltfunc)
  int (*haltfunc) ();
{
  halt = haltfunc;
}


static void
docompletehalt(s)
  int s;
{
  exit(0);
  /* dokill(); */
}


static void
doremove(s)
  int s;
{
  if (halt != NULL)
    (*halt) (s);
  else
    docompletehalt(s);
}


static int
initunixserver(path, protocol)
  char *path;
  char *protocol;
{
  struct sockaddr_un s_un;
  /* unix endpoint address */
  register struct protoent *pe;	/* protocol information entry */
  register int s;

  bzero((char *) &s_un, sizeof(s_un));
  s_un.sun_family = AF_UNIX;
  strcpy(s_un.sun_path, path);

  if (protocol == NULL)
    protocol = DEFAULTPROTOCOL;

  /* map protocol name to protocol number */
  pe = getprotobyname(protocol);
  if (pe == NULL)
  {
    fprintf(stderr, "%s: Unknown protocol.\n", protocol);
    return -1;
  }

  /* Allocate a socket */
  s = socket(PF_UNIX, strcmp(protocol, "tcp") ? SOCK_DGRAM : SOCK_STREAM, 0);
  if (s < 0)
  {
    printf("protocol %d\n", pe->p_proto);
    perror("socket");
    return -1;
  }
  /* standalonesetup(s); */
  signal(SIGHUP, SIG_IGN);
  signal(SIGUSR1, SIG_IGN);
  signal(SIGCHLD, reapchild);
  UNIX_SERVER_PATH = path;
  signal(SIGINT, doremove);
  signal(SIGTERM, doremove);

  if (bind(s, (struct sockaddr *) & s_un, sizeof(struct sockaddr_un)) < 0)
  {
    perror("bind");
    perror(path);
    return -1;
  }
  listen(s, 10);
  return s;
}


static int
initinetserver(service, protocol)
  char *service;
  char *protocol;
{
  register struct servent *se;	/* service information entry */
  register struct protoent *pe;	/* protocol information entry */
  struct sockaddr_in sin;	/* Internet endpoint address */
  register int port, s;
  register int randomport = 0;

  bzero((char *) &sin, sizeof(sin));
  sin.sin_family = AF_INET;
  if (!strcmp("0", service))
  {
    randomport = 1;
    sin.sin_addr.s_addr = INADDR_ANY;
  }

  if (service == NULL)
    service = DEFAULTPORT;
  if (protocol == NULL)
    protocol = DEFAULTPROTOCOL;

  /* map service name to port number */
  /* service ---> port */
  se = getservbyname(service, protocol);
  if (se == NULL)
  {
    port = htons((u_short) atoi(service));
    if (port == 0 && !randomport)
    {
      fprintf(stderr, "%s/%s: Unknown service.\n", service, protocol);
      return -1;
    }
  }
  else
    port = se->s_port;
  sin.sin_port = port;

  /* map protocol name to protocol number */
  pe = getprotobyname(protocol);
  if (pe == NULL)
  {
    fprintf(stderr, "%s: Unknown protocol.\n", protocol);
    return -1;
  }

  /* Allocate a socket */
  s = socket(PF_INET, strcmp(protocol, "tcp") ? SOCK_DGRAM : SOCK_STREAM, pe->p_proto);
  if (s < 0)
  {
    perror("socket");
    return -1;
  }
  standalonesetup(s);
  signal(SIGHUP, SIG_IGN);
  signal(SIGUSR1, SIG_IGN);
  signal(SIGCHLD, reapchild);
  signal(SIGINT, dokill);
  signal(SIGTERM, dokill);

  if (bind(s, (struct sockaddr *) & sin, sizeof(struct sockaddr_in)) < 0)
  {
    perror("bind");
    return -1;
  }
  listen(s, 10);

  return s;
}


static int
open_unix_listen(path, protocol, initfunc)
  char *path;
  char *protocol;
  int (*initfunc) ();
{
  register int s;

  s = initunixserver(path, protocol);
  if (s < 0)
  {
    return -1;
  }
  if (initfunc != NULL)
  {
    printf("in inetsingleserver before initfunc s %d\n", s);
    if ((*initfunc) (s) < 0)
    {
      perror("initfunc error");
      return -1;
    }
    printf("end inetsingleserver before initfunc \n");
  }
  return s;
}


static int
open_listen(service, protocol, initfunc)
  char *service;
  char *protocol;
  int (*initfunc) ();
{
  register int s;

  if (!INETDstart)
    s = initinetserver(service, protocol);
  else
    s = 0;
  if (s < 0)
  {
    return -1;
  }
  if (initfunc != NULL)
  {
    printf("in inetsingleserver before initfunc s %d\n", s);
    if ((*initfunc) (s) < 0)
    {
      perror("initfunc error");
      return -1;
    }
    printf("end inetsingleserver before initfunc \n");
  }
  return s;
}


static int
tryaccept(s)
  int s;
{
  register int ns;
  int fromlen = sizeof(struct sockaddr_in);
  struct sockaddr sockaddr;	/* Internet endpoint address */
  extern int errno;

  do
  {
    ns = accept(s, &sockaddr, &fromlen);
    errno = 0;
  } while (ns < 0 && errno == EINTR);
  return ns;
}


static void
channelcreate(client, sock)
  ClientType *client;
  int sock;
{
  register buffer_t *in, *out;

  client->fd = sock;
  FD_SET(sock, &rfd);
  client->Argv.in = fdopen(sock, "r");
  client->Argv.out = fdopen(sock, "w");

  client->buffer[0] = '\0';
  client->mode = 0;
  client->midcheck = 1;
  time(&client->begin);

  in = &client->in;
  out = &client->out;
  if (in->data != NULL)
    free(in->data);
  in->data = (char *) malloc(ChannelSize * 4);
  in->left = ChannelSize * 4;

  if (out->data != NULL)
    free(out->data);
  out->data = (char *) malloc(ChannelSize);
  out->left = ChannelSize;

  in->used = 0;
  out->used = 0;
  client->ihavecount = 0;
  client->ihaveduplicate = 0;
  client->ihavefail = 0;
  client->ihavesize = 0;
  client->statcount = 0;
  client->statfail = 0;
}


static void
channeldestroy(client)
  ClientType *client;
{
  if (client->in.data != NULL)
  {
    free(client->in.data);
    client->in.data = NULL;
  }
  if (client->out.data != NULL)
  {
    free(client->out.data);
    client->out.data = NULL;
  }

  if (client->ihavecount > 0 || client->statcount > 0)
  {
    bbslog("%s T%d S%d R%d dup:%d fail:%d, stat rec:%d fail:%d\n",
      client->hostname, time(NULL) - client->begin,
      client->ihavesize, client->ihavecount, client->ihaveduplicate,
      client->ihavefail, client->statcount, client->statfail);
    INNBBSD_STAT.ihavecount += client->ihavecount;
    INNBBSD_STAT.ihaveduplicate += client->ihaveduplicate;
    INNBBSD_STAT.ihavefail += client->ihavefail;
    INNBBSD_STAT.ihavesize += client->ihavesize;
    INNBBSD_STAT.statcount += client->statcount;
    INNBBSD_STAT.statfail += client->statfail;

    HISflush();			/* flush & sync histroy */
  }
  else
  {
    bbslog("%s T%d stat rec:%d fail:%d\n",
      client->hostname, time(NULL) - client->begin,
      client->statcount, client->statfail);
  }
}


static int
channelreader(client)
  ClientType *client;
{
  register int len, used;
  register char *data, *head;
  register buffer_t *in = &client->in;

  len = in->left;
  used = in->used;
  data = in->data;
  if (len < ReadSize + 3)
  {
    len += (used + ReadSize);
    len += (len >> 3);

    in->data = data = (char *) realloc(data, len);
    len -= used;
    in->left = len;
  }

  head = data + used;
  len = recv(client->fd, head, ReadSize, 0);

  if (len <= 0)
    return len;

  in->lastread = len;
  head[len] = '\0';
  head[len + 1] = '\0';

  if (client->mode)		/* data mode */
  {
    char *dest;
    int cc;

    dest = head - 1;
    client->ihavesize += len;

    for (;;)
    {
      cc = *head;

      if (!cc)
      {
	used = dest - data + 1;
	in->left -= (used - in->used);
	in->used = used;
	return len;
      }

      head++;

      if (cc == '\r')
	continue;

      if (cc == '\n')
      {
	used = *dest;

	if (used == '.')
	{
	  used = dest[-1];
	  if (used == '\n')
	    break;		/* end of article body */
	  if (used == '.' && dest[-2] == '\n')
	    *dest = ' ';	/* strip leading ".." to ". " */
	}
	else
	{
#if 0     
	  /* strip the trailing space */

	  while (used == ' ' || used == '\t')
	    used = *--dest;
#endif
          /* Thor.990110: ���� �Ŧ�\n �� space, for multi-line merge */
	  /* strip the trailing space */

	  while (dest[-1] != '\n' && (used == ' ' || used == '\t'))
	    used = *--dest;
	}
      }

      *++dest = cc;
    }

    /* strip the trailing empty lines */

    *data = '\0';
    while (*--dest == '\n')
      ;
    dest += 2;
    *dest = '\0';

    my_recv(client);
    client->mode = 0;
  }
  else
  {
    /* command mode */

    register argv_t *Argv;
    register struct Daemoncmd *dp;

    head = (char *) strchr(head, '\n');

    if (head == NULL)
    {
      in->used += len;
      in->left -= len;
      return len;
    }

    *head++ = '\0';

    Argv = &client->Argv;
    /* Argv->inputline = data; */
    Argv->argc = argify(data, &Argv->argv);
    Argv->dc = dp = (struct Daemoncmd *) searchcmd(Argv->argv[0]);
    if (dp)
    {
      if (Argv->argc < dp->argc)
      {
	fprintf(Argv->out, "%d Usage: %s\r\n", dp->errorcode, dp->usage);
	fflush(Argv->out);
	verboselog("Put: %d Usage: %s\n", dp->errorcode, dp->usage);
      }
      else if (dp->argno && Argv->argc > dp->argno)
      {
	fprintf(Argv->out, "%d Usage: %s\r\n", dp->errorcode, dp->usage);
	fflush(Argv->out);
	verboselog("Put: %d Usage: %s\n", dp->errorcode, dp->usage);
      }
      else
      {
	int (*Main) ();

	if (Main = Argv->dc->main)
	{
	  (*Main) (client);
	}
      }
    }
    else
    {
      fprintf(Argv->out, "500 Syntax error or bad command\r\n");
      fflush(Argv->out);
      verboselog("Put: 500 Syntax error or bad command\r\n");
    }
  }

   /* Thor.980825:
         gc patch: 
         ��]
         a.�p�G�w�g����L CMDquit, �U�����ʧ@�����ΰ��F(cleint destroied) :) */
#if 0
  if (client->mode == 0)
#endif
  if (client->mode == 0 && client->in.data != NULL)
  {
    int left;

    left = in->left + in->used;

    if (used = *head)
    {
      char *str;

      bbslog("CARRY: %s\n", head);

      str = data;
      while (*str++ = *head++)
	;

      used = str - data;
    }

    in->left = left - used;
    in->used = used;
  }

  return len;
}


/* ----------------------------------------------------- */
/* innd channel						 */
/* ----------------------------------------------------- */


static int Maxclient = MAXCLIENT;
int Junkhistory = 0;

static ClientType *Channel = NULL;

static int inetdstart = 0;


static int CMDhelp();
static int CMDquit();
static int CMDihave();
static int CMDstat();
static int CMDaddhist();
static int CMDgrephist();
static int CMDmidcheck();
static int CMDshutdown();
static int CMDmode();
static int CMDreload();
static int CMDhismaint();
static int CMDverboselog();
static int CMDlistnodelist();
static int CMDlistnewsfeeds();
#ifdef _NoCeM_
static int CMDlistncmperm();
#endif
#ifdef GETRUSAGE
static int CMDgetrusage();
#endif
#ifdef MALLOCMAP
static int CMDmallocmap();
#endif


static daemoncmd_t cmds[] =
{
  /* cmd-name,      cmd-usage, min-argc, max-argc, errorcode, normalcode, cmd-func */
  {"help",          "help [cmd]",                 1, 2, 99, 100, CMDhelp},
  {"quit",          "quit",                       1, 0, 99, 100, CMDquit},
  {"ihave",         "ihave mid",                  2, 2, 435, 335, CMDihave},
  {"stat",          "stat mid",                   2, 2, 223, 430, CMDstat},
  {"addhist",       "addhist <mid> <path>",       3, 3, NNTP_ADDHIST_BAD,  NNTP_ADDHIST_OK,  CMDaddhist},
  {"grephist",      "grephist <mid>",             2, 2, NNTP_GREPHIST_BAD, NNTP_GREPHIST_OK, CMDgrephist},
  {"midcheck",      "midcheck [on|off]",          1, 2, NNTP_MIDCHECK_BAD, NNTP_MIDCHECK_OK, CMDmidcheck},
  {"shutdown",      "shutdown (local)",           1, 1, NNTP_SHUTDOWN_BAD, NNTP_SHUTDOWN_OK, CMDshutdown},
  {"mode",          "mode (local)",               1, 1, NNTP_MODE_BAD, NNTP_MODE_OK, CMDmode},
  {"reload",        "reload (local)",             1, 1, NNTP_RELOAD_BAD, NNTP_RELOAD_OK, CMDreload},
  {"hismaint",      "hismaint (local)",           1, 1, NNTP_RELOAD_BAD, NNTP_RELOAD_OK, CMDhismaint},
  {"verboselog",    "verboselog [on|off](local)", 1, 2, NNTP_VERBOSELOG_BAD, NNTP_VERBOSELOG_OK, CMDverboselog},
  {"listnode",      "listnodelist (local)",       1, 1, NNTP_MODE_BAD, NNTP_MODE_OK, CMDlistnodelist},
  {"listnews",      "listnewsfeeds (local)",      1, 1, NNTP_MODE_BAD, NNTP_MODE_OK, CMDlistnewsfeeds},
#ifdef _NoCeM_
  {"listncm",       "listncmperm (local)",        1, 1, NNTP_MODE_BAD, NNTP_MODE_OK, CMDlistncmperm},
#endif
#ifdef GETRUSAGE
  {"getrusage",     "getrusage (local)",          1, 1, NNTP_MODE_BAD, NNTP_MODE_OK, CMDgetrusage},
#endif
#ifdef MALLOCMAP
  {"mallocmap",     "mallocmap (local)",          1, 1, NNTP_MODE_BAD, NNTP_MODE_OK, CMDmallocmap},
#endif
  {NULL,            NULL,                         0, 0, 99, 100, NULL}
};


static void
installinnbbsd()
{
  installdaemon(cmds, 100, NULL);
}


static int
islocalconnect(client)		/* ���� ctlinnbbsd �ӤU���O�N�O local connect */
  ClientType *client;
{
  if (strcmp(client->hostname, "localhost"))
    return 0;
  return 1;
}


static int shutdownflag = 0;


static void
INNBBSDhalt()
{
  shutdownflag = 1;
}


static int
INNBBSDshutdown()
{
  return shutdownflag;
}


void
clearfdset(fd)
  int fd;
{
  FD_CLR(fd, &rfd);
}


static int
CMDshutdown(client)
  ClientType *client;
{
  register argv_t *argv = &client->Argv;
  register daemoncmd_t *p = argv->dc;
  register FILE *out = argv->out;

  if (!islocalconnect(client))
  {
    fprintf(out, "%d shutdown access denied\r\n", p->errorcode);
    verboselog("Shutdown Put: %d shutdown access denied\n", p->errorcode);
  }
  else
  {
    shutdownflag = 1;
    fprintf(out, "%d shutdown starting\r\n", p->normalcode);
    verboselog("Shutdown Put: %d shutdown starting\n", p->normalcode);
  }
  fflush(out);
  return 1;
}


static int
CMDmode(client)
  ClientType *client;
{
  argv_t *argv = &client->Argv;
  daemoncmd_t *p = argv->dc;
  time_t uptime, now;
  int i, j;
  time_t lasthist;
  ClientType *client1 = &INNBBSD_STAT;

  if (!islocalconnect(client))
  {
    fprintf(argv->out, "%d mode access denied\r\n", p->errorcode);
    fflush(argv->out);
    verboselog("Mode Put: %d mode access denied\n", p->errorcode);
    return 1;
  }
  fprintf(argv->out, "%d mode\r\n", p->normalcode);
  fflush(argv->out);
  verboselog("Mode Put: %d mode\n", p->normalcode);
  uptime = innbbsdstartup();
  time(&now);
  fprintf(argv->out, "up since %salive %.2f days\r\n", ctime(&uptime), (double) (now - innbbsdstartup()) / 86400);
  fprintf(argv->out, "BBSHOME %s\r\n", BBSHOME);
  fprintf(argv->out, "MYBBSID %s\r\n", MYBBSID);
  fprintf(argv->out, "Verbose log: %s\r\n", isverboselog() ? "ON" : "OFF");
  fprintf(argv->out, "History Expire Days %d\r\n", EXPIREDAYS);
  fprintf(argv->out, "History Expire Time %d:%d\r\n", HIS_MAINT_HOUR, HIS_MAINT_MIN);
  lasthist = gethisinfo();
  if (lasthist > 0)
  {
    time_t keep = lasthist, keep1;
    time(&now);
    fprintf(argv->out, "Oldest history entry created: %s", (char *) ctime(&keep));
    keep = EXPIREDAYS * 86400 * 2 + lasthist;
    keep1 = keep - now;
    fprintf(argv->out, "Next time to maintain history: (%.2f days later) %s", (double) keep1 / 86400, (char *) ctime(&keep));
  }
  fprintf(argv->out, "PID is %d\r\n", getpid());
  fprintf(argv->out, "Max connections %d\r\n", Maxclient);

  if (Channel)
  {
    for (i = 0, j = 0; i < Maxclient; i++)
    {
      if (Channel[i].fd == -1)
	continue;
      if (Channel + i == client)
	continue;
      j++;
      fprintf(argv->out, " %d) in->used %d, in->left %d %s\r\n", i,
	Channel[i].in.used, Channel[i].in.left, Channel[i].hostname);
    }
  }
  fprintf(argv->out, "Total connections %d\r\n", j);
  fprintf(argv->out, "Total rec: %d dup: %d fail: %d size: %d, stat rec: %d fail: %d\n", client1->ihavecount, client1->ihaveduplicate, client1->ihavefail, client1->ihavesize, client1->statcount, client1->statfail);
  fprintf(argv->out, ".\r\n");
  fflush(argv->out);
  return 1;
}


static int
CMDlistnodelist(client)
  ClientType *client;
{
  argv_t *argv = &client->Argv;
  daemoncmd_t *p = argv->dc;
  int nlcount;

  if (!islocalconnect(client))
  {
    fprintf(argv->out, "%d listnodelist access denied\r\n", p->errorcode);
    fflush(argv->out);
    verboselog("Mallocmap Put: %d listnodelist access denied\n", p->errorcode);
    return 1;
  }
  fprintf(argv->out, "%d listnodelist\r\n", p->normalcode);
  for (nlcount = 0; nlcount < NLCOUNT; nlcount++)
  {
    nodelist_t *nl = NODELIST + nlcount;
    fprintf(argv->out, "%2d %s <<%s>>\r\n", nlcount + 1, nl->node, nl->feedfp ? "running" : "wait");
    fprintf(argv->out, "   %s:%s:%s\r\n", nl->host, nl->protocol, nl->comment);
  }
  fprintf(argv->out, ".\r\n");
  fflush(argv->out);
  verboselog("Listnodelist Put: %d listnodelist complete\n", p->normalcode);
  return 1;
}


static int
CMDlistnewsfeeds(client)
  ClientType *client;
{
  argv_t *argv = &client->Argv;
  daemoncmd_t *p = argv->dc;
  int nfcount;

  if (!islocalconnect(client))
  {
    fprintf(argv->out, "%d listnewsfeeds access denied\r\n", p->errorcode);
    fflush(argv->out);
    verboselog("Mallocmap Put: %d listnewsfeeds access denied\n", p->errorcode);
    return 1;
  }
  fprintf(argv->out, "%d listnewsfeeds\r\n", p->normalcode);
  for (nfcount = 0; nfcount < NFCOUNT; nfcount++)
  {
    newsfeeds_t *nf = NEWSFEEDS + nfcount;
    fprintf(argv->out, "%3d %s<=>%s\r\n", nfcount + 1, nf->newsgroups, nf->board);
    fprintf(argv->out, "    %s\r\n", nf->path == NULL ? "(Null)" : nf->path);
  }
  fprintf(argv->out, ".\r\n");
  fflush(argv->out);
  verboselog("Listnewsfeeds Put: %d listnewsfeeds complete\n", p->normalcode);
  return 1;
}


#ifdef _NoCeM_
static int
CMDlistncmperm(client)		/* itoc.010309: list ncmperm.bbs */
  ClientType *client;
{
  argv_t *argv = &client->Argv;
  daemoncmd_t *p = argv->dc;
  int ncmcount;

  if (!islocalconnect(client))
  {
    fprintf(argv->out, "%d listncmperm access denied\r\n", p->errorcode);
    fflush(argv->out);
    verboselog("Mallocmap Put: %d listncmperm access denied\n", p->errorcode);
    return 1;
  }
  fprintf(argv->out, "%d listncmperm\r\n", p->normalcode);
  for (ncmcount = 0; ncmcount < NCMCOUNT; ncmcount++)
  {
    ncmperm_t *ncm = NCMPERM + ncmcount;
    fprintf(argv->out, "%3d %s -- %s -- %s\r\n", ncmcount + 1, ncm->issuer, ncm->type, ncm->perm ? "yes" : "no");
  }
  fprintf(argv->out, ".\r\n");
  fflush(argv->out);
  verboselog("Listncmperm Put: %d listncmperm complete\n", p->normalcode);
  return 1;
}
#endif


#ifdef MALLOCMAP
static int
CMDmallocmap(client)
  ClientType *client;
{
  argv_t *argv = &client->Argv;
  buffer_t *in = &client->in;
  daemoncmd_t *p = argv->dc;
  struct rusage ru;
  int savefd;
  if (!islocalconnect(client))
  {
    fprintf(argv->out, "%d mallocmap access denied\r\n", p->errorcode);
    fflush(argv->out);
    verboselog("Mallocmap Put: %d mallocmap access denied\n", p->errorcode);
    return 1;
  }
  fprintf(argv->out, "%d mallocmap\r\n", p->normalcode);
  savefd = dup(1);
  dup2(client->fd, 1);
  mallocmap();
  dup2(savefd, 1);
  close(savefd);
  fprintf(argv->out, ".\r\n");
  fflush(argv->out);
  verboselog("Mallocmap Put: %d mallocmap complete\n", p->normalcode);
  return 1;
}
#endif


#ifdef GETRUSAGE
static int
CMDgetrusage(client)
  ClientType *client;
{
  argv_t *argv = &client->Argv;
  daemoncmd_t *p = argv->dc;
  struct rusage ru;
  if (!islocalconnect(client))
  {
    fprintf(argv->out, "%d getrusage access denied\r\n", p->errorcode);
    fflush(argv->out);
    verboselog("Getrusage Put: %d getrusage access denied\n", p->errorcode);
    return 1;
  }
  fprintf(argv->out, "%d getrusage\r\n", p->normalcode);
  if (getrusage(RUSAGE_SELF, &ru) == 0)
  {
    fprintf(argv->out, "user time used: %.6f\r\n", (double) ru.ru_utime.tv_sec + (double) ru.ru_utime.tv_usec / 1000000.0);
    fprintf(argv->out, "system time used: %.6f\r\n", (double) ru.ru_stime.tv_sec + (double) ru.ru_stime.tv_usec / 1000000.0);
    fprintf(argv->out, "maximum resident set size: %lu\r\n", ru.ru_maxrss * getpagesize());
    fprintf(argv->out, "integral resident set size: %lu\r\n", ru.ru_idrss * getpagesize());
    fprintf(argv->out, "page faults not requiring physical I/O: %d\r\n", ru.ru_minflt);
    fprintf(argv->out, "page faults requiring physical I/O: %d\r\n", ru.ru_majflt);
    fprintf(argv->out, "swaps: %d\r\n", ru.ru_nswap);
    fprintf(argv->out, "block input operations: %d\r\n", ru.ru_inblock);
    fprintf(argv->out, "block output operations: %d\r\n", ru.ru_oublock);
    fprintf(argv->out, "messages sent: %d\r\n", ru.ru_msgsnd);
    fprintf(argv->out, "messages received: %d\r\n", ru.ru_msgrcv);
    fprintf(argv->out, "signals received: %d\r\n", ru.ru_nsignals);
    fprintf(argv->out, "voluntary context switches: %d\r\n", ru.ru_nvcsw);
    fprintf(argv->out, "involuntary context switches: %d\r\n", ru.ru_nivcsw);
  }
  fprintf(argv->out, ".\r\n");
  fflush(argv->out);
  verboselog("Getrusage Put: %d getrusage complete\n", p->normalcode);
  return 1;
}
#endif


static int
CMDhismaint(client)
  ClientType *client;
{
  argv_t *argv = &client->Argv;
  daemoncmd_t *p = argv->dc;
  if (!islocalconnect(client))
  {
    fprintf(argv->out, "%d hismaint access denied\r\n", p->errorcode);
    fflush(argv->out);
    verboselog("Hismaint Put: %d hismaint access denied\n", p->errorcode);
    return 1;
  }
  verboselog("Hismaint Put: %d hismaint start\n", p->normalcode);
  HISmaint();
  fprintf(argv->out, "%d hismaint complete\r\n", p->normalcode);
  fflush(argv->out);
  verboselog("Hismaint Put: %d hismaint complete\n", p->normalcode);
  return 1;
}


static int
CMDreload(client)
  ClientType *client;
{
  register argv_t *argv = &client->Argv;
  register daemoncmd_t *p = argv->dc;
  FILE *out = argv->out;

  if (!islocalconnect(client))
  {
    fprintf(out, "%d reload access denied\r\n", p->errorcode);
    verboselog("Reload Put: %d reload access denied\n", p->errorcode);
    return 1;
  }
  else
  {
    if (!initial_bbs())
    {
      fprintf(out, "%d reload failure\r\n", p->normalcode);
      verboselog("Reload Put: %d reload failure\n", p->normalcode);
    }
    else
    {
      fprintf(out, "%d reload complete\r\n", p->normalcode);
      verboselog("Reload Put: %d reload complete\n", p->normalcode);
    }
  }
  fflush(out);
  return 1;
}


static int
CMDverboselog(client)
  ClientType *client;
{
  argv_t *argv = &client->Argv;
  daemoncmd_t *p = argv->dc;
  if (!islocalconnect(client))
  {
    fprintf(argv->out, "%d verboselog access denied\r\n", p->errorcode);
    fflush(argv->out);
    verboselog("Reload Put: %d verboselog access denied\n", p->errorcode);
    return 1;
  }
  if (client->mode == 0)
  {
    if (argv->argc > 1)
    {
      if (strcasecmp(argv->argv[1], "off") == 0)
      {
	setverboseoff();
      }
      else
      {
	setverboseon();
      }
    }
  }
  fprintf(argv->out, "%d verboselog %s\r\n", p->normalcode,
    isverboselog() ? "ON" : "OFF");
  fflush(argv->out);
  verboselog("%d verboselog %s\r\n", p->normalcode,
    isverboselog() ? "ON" : "OFF");
}


static int
CMDmidcheck(client)
  ClientType *client;
{
  argv_t *argv = &client->Argv;
  daemoncmd_t *p = argv->dc;
  if (client->mode == 0)
  {
    if (argv->argc > 1)
    {
      if (strcasecmp(argv->argv[1], "off") == 0)
      {
	client->midcheck = 0;
      }
      else
      {
	client->midcheck = 1;
      }
    }
  }
  fprintf(argv->out, "%d mid check %s\r\n", p->normalcode,
    client->midcheck == 1 ? "ON" : "OFF");
  fflush(argv->out);
  verboselog("%d mid check %s\r\n", p->normalcode,
    client->midcheck == 1 ? "ON" : "OFF");
}


static int
CMDgrephist(client)
  ClientType *client;
{
  argv_t *argv = &client->Argv;
  daemoncmd_t *p = argv->dc;
  if (client->mode == 0)
  {
    if (argv->argc > 1)
    {
      char *ptr;
      ptr = (char *) DBfetch(argv->argv[1]);
      if (ptr != NULL)
      {
	fprintf(argv->out, "%d %s OK\r\n", p->normalcode, ptr);
	fflush(argv->out);
	verboselog("Addhist Put: %d %s OK\n", p->normalcode, ptr);
	return 0;
      }
      else
      {
	fprintf(argv->out, "%d %s not found\r\n", p->errorcode, argv->argv[1]);
	fflush(argv->out);
	verboselog("Addhist Put: %d %s not found\n", p->errorcode, argv->argv[1]);
	return 1;
      }
    }
  }
  fprintf(argv->out, "%d grephist error\r\n", p->errorcode);
  fflush(argv->out);
  verboselog("Addhist Put: %d grephist error\n", p->errorcode);
  return 1;
}


static int
CMDaddhist(client)
  ClientType *client;
{
  argv_t *argv = &client->Argv;
  daemoncmd_t *p = argv->dc;

  if (client->mode == 0)
  {
    if (argv->argc > 2)
    {
      char *ptr;
      ptr = (char *) DBfetch(argv->argv[1]);
      if (ptr == NULL)
      {
	if (HERwrite(argv->argv[1], argv->argv[2]) < 0)
	{
	  fprintf(argv->out, "%d add hist store DB error\r\n", p->errorcode);
	  fflush(argv->out);
	  verboselog("Addhist Put: %d add hist store DB error\n", p->errorcode);
	  return 1;
	}
	else
	{
	  fprintf(argv->out, "%d add hist OK\r\n", p->normalcode);
	  fflush(argv->out);
	  verboselog("Addhist Put: %d add hist OK\n", p->normalcode);
	  return 0;
	}
      }
      else
      {
	fprintf(argv->out, "%d add hist duplicate error\r\n", p->errorcode);
	fflush(argv->out);
	verboselog("Addhist Put: %d add hist duplicate error\n", p->errorcode);
	return 1;
      }
    }
  }
  fprintf(argv->out, "%d add hist error\r\n", p->errorcode);
  fflush(argv->out);
  verboselog("Addhist Put: %d add hist error\n", p->errorcode);
  return 1;
}


static int
CMDstat(client)
  ClientType *client;
{
  register argv_t *argv = &client->Argv;
  register char *ptr, *data;
  register FILE *out = argv->out;
  /* register daemoncmd_t *p; */

  if (client->mode == 0)
  {
    client->statcount++;
    if (argv->argc > 1)
    {
      data = argv->argv[1];
      if (data[0] != '<')
      {
	fprintf(out, "430 No such article\r\n");
	fflush(out);
	verboselog("Stat Put: 430 No such article\n");
	client->statfail++;
	return 0;
      }
      if (ptr = (char *) DBfetch(data))
      {
	fprintf(out, "223 0 status %s\r\n", data);
	fflush(out);
	client->mode = 0;
	verboselog("Stat Put: 223 0 status %s\n", data);
	return 1;
      }
      else
      {
	fprintf(out, "430 No such article\r\n");
	fflush(out);
	verboselog("Stat Put: 430 No such article\n");
	client->mode = 0;
	client->statfail++;
      }
    }
  }
}


static int
CMDihave(client)
  ClientType *client;
{
  register argv_t *argv = &client->Argv;
  register char *data;
  register FILE *out = argv->out;

  /* register daemoncmd_t *p; */

  if (client->mode == 0)
  {
    client->ihavecount++;
    data = argv->argv[1];
    if (data[0] != '<')
    {
      fprintf(out, "435 Bad Message-ID\r\n");
      fflush(out);
      verboselog("Ihave Put: 435 Bad Message-ID\n");
      client->ihavefail++;
      return 0;
    }

    fprintf(out, "335\r\n");
    /* fflush(out); */
    client->mode = 1;

    strcpy(client->in.data, "\n\n\n");
    client->in.left += client->in.used - 3;
    client->in.used = 3;
    /* verboselog("Ihave Put: 335\n"); */
  }
  fflush(out);
  return 0;
}


static int
CMDhelp(client)
  ClientType *client;
{
  argv_t *argv = &client->Argv;
  daemoncmd_t *p;
  if (argv->argc >= 1)
  {
    fprintf(argv->out, "%d Available Commands\r\n", argv->dc->normalcode);
    for (p = cmds; p->name != NULL; p++)
    {
      fprintf(argv->out, "  %s\r\n", p->usage);
    }
    fprintf(argv->out, "Report problems to the admin\r\n");
  }
  fputs(".\r\n", argv->out);
  fflush(argv->out);
  client->mode = 0;
  return 0;
}


static int
CMDquit(client)
  ClientType *client;
{
  argv_t *argv = &client->Argv;
  fprintf(argv->out, "205 quit\r\n");
  fflush(argv->out);
  verboselog("Quit Put: 205 quit\n");
  clearfdset(client->fd);
  fclose(client->Argv.in);
  fclose(client->Argv.out);
  close(client->fd);
  client->fd = -1;
  client->mode = 0;
  channeldestroy(client);
}


static int
pmain(port)
  char *port;
{
  return open_listen(port, "tcp", NULL);
}


static int
p_unix_main(path)
  char *path;
{
  register int rel;

  rel = unixclient(path, "tcp");
  if (rel < 0)
    unlink(path);
  else
    close(rel);
  return open_unix_listen(path, "tcp", NULL);
}


#ifdef	_ANTI_SPAM_
#define	SPAM_PERIOD	(60 * 45)
#endif


static int
search_nodelist_byhost(site)
  char *site;
{
  nodelist_t *find;
  struct hostent *he;
  char server[512], client[512];
  int i;

  /* itoc.021216: �� site �M NODELIST ������ host�A�o�˪��ܡA
     �p�G nodelist.bbs �̭��񪺤��O���ѡA����٬O�i�H access */

  if (!(he = gethostbyname(site)))
    return 0;

  strcpy(server, (char *) inet_ntoa(*(struct in_addr *) he->h_addr_list[0]));

  for (i = 0; i < NLCOUNT; i++)
  {
    find = &NODELIST[i];
    if (he = gethostbyname(find->host))
    {
      strcpy(client, (char *) inet_ntoa(*(struct in_addr *) he->h_addr_list[0]));
      if (!strcmp(server, client))
	return 1;
    }
  }

  /* �٭� site */
  he = gethostbyname(server);
  inet_ntoa(*(struct in_addr *) he->h_addr_list[0]);

  return 0;
}


static int
inndchannel(port, path)
  char *port, *path;
{
  time_t uptime;		/* time to maintain */

#ifdef	_ANTI_SPAM_
  time_t spam_due;		/* time to expire anti-spam-hash-table */
#endif

  int i;
  int bbsinnd;
  int localbbsinnd;
  int localdaemonready = 0;

  Channel = (ClientType *) malloc(sizeof(ClientType) * Maxclient);

  bbsinnd = pmain(port);
  if (bbsinnd < 0)
  {
    perror("pmain, existing");
    docompletehalt();
    return (-1);
  }

  FD_ZERO(&rfd);

  localbbsinnd = p_unix_main(path);
  if (localbbsinnd < 0)
  {
    perror("local pmain, existing");
    if (!inetdstart)
      fprintf(stderr, "if no other innbbsd running, try to remove %s\n", path);
    close(bbsinnd);
    return (-1);
  }
  else
  {
    FD_SET(localbbsinnd, &rfd);
    localdaemonready = 1;
  }

  FD_SET(bbsinnd, &rfd);

  uptime = time((time_t *) 0);

#ifdef	_ANTI_SPAM_
  spam_due = uptime + SPAM_PERIOD;
#endif

  {
    struct tm *local;

    local = localtime(&uptime);
    i = (HIS_MAINT_HOUR - local->tm_hour) * 3600 + (HIS_MAINT_MIN - local->tm_min) * 60;
    if (i <= 100)		/* �O�d�ɶ��t 100 �� */
      i += 86400;
    uptime += i;
  }

  for (i = 0; i < Maxclient; i++)
  {
    register ClientType *clientp = &Channel[i];

    clientp->fd = -1;
    clientp->buffer[0] = '\0';
    clientp->access = 0;
    clientp->mode = 0;
    clientp->in.left = 0;
    clientp->in.used = 0;
    clientp->in.data = 0;
    clientp->out.left = 0;
    clientp->out.used = 0;
    clientp->out.data = 0;
    clientp->midcheck = 1;
  }

  for (;;)
  {
    static char msg_no_desc[] = "502 no free descriptors\r\n";
    int nsel;
    time_t now;
    struct timeval tout;

    /* When to maintain history files. */
    if (INNBBSDshutdown())
    {
      HISclose();
      bbslog("Shutdown Complete\n");
      docompletehalt();
      exit(0);
    }

    now = time(NULL);
    if (now > uptime)
    {
      bbslog(":Maint: start\n");
      HISmaint();
      bbslog(":Maint: end\n");
      uptime += 86400;
    }

#ifdef	_ANTI_SPAM_
    if (now > spam_due)
    {
      spam_expire();
      spam_due += SPAM_PERIOD;
    }
#endif

    /* in order to maintain history, timeout every 20 minutes in case no connections */

    tout.tv_sec = 60 * 20;
    tout.tv_usec = 0;
    orfd = rfd;
    if ((nsel = select(FD_SETSIZE, &orfd, NULL, NULL, &tout)) <= 0)
    {
      continue;
    }

    if (localdaemonready && FD_ISSET(localbbsinnd, &orfd))	/* �������� ctlinnbbsd �ӳX�� */
    {
      int ns;
      ClientType *clientp;

      ns = tryaccept(localbbsinnd);
      if (ns < 0)
	continue;
      for (i = 0, clientp = Channel; i < Maxclient; i++, clientp++)
      {
	if (clientp->fd == -1)
	  break;
      }
      if (i == Maxclient)
      {
	write(ns, msg_no_desc, sizeof(msg_no_desc) - 1);
	close(ns);
	continue;
      }

      channelcreate(clientp, ns);
      strcpy(clientp->hostname, "localhost");

      bbslog("connected from %s\n", clientp->hostname);
      fprintf(clientp->Argv.out, "200 %s INNBBSD %s (%s)\r\n", MYBBSID, VERSION, clientp->hostname);
      fflush(clientp->Argv.out);
    }

    if (FD_ISSET(bbsinnd, &orfd))				/* �L�H�ӳX�� */
    {
      int ns = tryaccept(bbsinnd);
      char *hostname;
      ClientType *clientp;
      struct hostent *hp;
      struct sockaddr_in there;
      int length;

      if (ns < 0)
	continue;

      length = sizeof(there);
      getpeername(ns, (struct sockaddr *) & there, &length);
      hp = (struct hostent *) gethostbyaddr((char *) &there.sin_addr, sizeof(struct in_addr), there.sin_family);
      hostname = hp ? hp->h_name : (char *) inet_ntoa(there.sin_addr);

      if (!search_nodelist_byhost(hostname))
      {
	char buf[256];

	bbslog(":Err: invalid connection (%s)\n", hostname);
	sprintf(buf, "502 �z���b������ nodelist.bbs �W�椤 (%s).\r\n", hostname);
	write(ns, buf, strlen(buf));
	close(ns);
	continue;
      }

      for (i = 0, clientp = Channel; i < Maxclient; i++, clientp++)
      {
	if (clientp->fd == -1)
	  break;
      }
      if (i == Maxclient)
      {
	write(ns, msg_no_desc, sizeof(msg_no_desc) - 1);
	close(ns);
	continue;
      }

      channelcreate(clientp, ns);
      strncpy(clientp->hostname, hostname, 128);

      bbslog("connected from %s\n", clientp->hostname);
      fprintf(clientp->Argv.out, "200 %s INNBBSD %s (%s)\r\n", MYBBSID, VERSION, clientp->hostname);
      fflush(clientp->Argv.out);
    }

    for (i = 0; i < Maxclient; i++)
    {
      ClientType *clientp = &Channel[i];
      int fd = clientp->fd;

      if (fd < 0)
      {
	continue;
      }
      if (FD_ISSET(fd, &orfd))
      {
	register int nr;

	nr = channelreader(clientp);
	if (nr <= 0)
	{
	  FD_CLR(fd, &rfd);
	  fclose(clientp->Argv.in);
	  fclose(clientp->Argv.out);
	  close(fd);
	  clientp->fd = -1;
	  channeldestroy(clientp);
	  continue;
	}

	if (clientp->access == 0)
	{
	  continue;
	}
      }
    }
  }
}


static void
dopipesig(s)
  int s;
{
  printf("catch sigpipe\n");
  signal(SIGPIPE, dopipesig);
}


#ifdef NO_getdtablesize

#include <sys/resource.h>

static int
getdtablesize()
{
  struct rlimit limit;
  if (getrlimit(RLIMIT_NOFILE, &limit) >= 0)
  {
    return limit.rlim_cur;
  }
  return -1;
}
#endif


static void
standaloneinit(port)
  char *port;
{
  int ndescriptors, s;
  FILE *pf;
  char pidfile[24];

  ndescriptors = getdtablesize();
  if (!inetdstart)
  {
    if (fork())
      exit(0);
  }

  sprintf(pidfile, "run/innbbsd-%s.pid", port);
  if (!inetdstart)
    fprintf(stderr, "PID file is in %s\n", pidfile);

  for (s = 3; s < ndescriptors; s++)
    (void) close(s);

  if (pf = fopen(pidfile, "w"))
  {
    fprintf(pf, "%d\n", getpid());
    fclose(pf);
  }
}


static void
usage(name)
  char *name;
{
  fprintf(stderr, "Usage: %s\t[options] [port [path]]\n"
    "  -v\t(verbose log)\n"
    "  -h|?\t(help)\n"
    "  -n\t(not to use in core dbz)\n"
    "  -i\t(start from inetd with wait option)\n"
    "  -c\tconnections  (maximum number of connections accepted)\n"
    "\tdefault=%d\n"
    "  -j\t(keep history of junk article, default=none)\n", name, Maxclient);
}


static time_t INNBBSDstartup;

int
innbbsdstartup()
{
  return INNBBSDstartup;
}


int
main(argc, argv)
  int argc;
  char **argv;
{
  char *port, *path;
  int c, errflag = 0;

  extern char *optarg;
  extern int optind;

  chdir(BBSHOME);
  umask(077);

  port = INNBBS_PORT;
  path = LOCALDAEMON;

  time(&INNBBSDstartup);
  openlog("innbbsd", LOG_PID | LOG_ODELAY, LOG_DAEMON);
  while ((c = getopt(argc, argv, "c:f:vhidn?j")) != -1)
  {
    switch (c)
    {
    case 'j':
      Junkhistory = 1;
      break;
    case 'v':
      verbosefile("innd/innbbsd.log");
      break;
    case 'n':
      hisincore(0);
      break;
    case 'c':
      Maxclient = atoi(optarg);
      if (Maxclient < 0)
	Maxclient = 0;
      break;

    case 'i':
      {
	struct sockaddr_in there;
	int len = sizeof(there);
	int rel;
	if ((rel = getsockname(0, (struct sockaddr *) & there, &len)) < 0)
	{
	  fprintf(stdout, "You must run -i from inetd with inetd.conf line: \n"
	    "service-port stream  tcp wait  bbs  /home/bbs/innbbsd innbbsd -i port\n");
	  exit(5);
	}
	inetdstart = 1;
	startfrominetd(1);
      }
      break;

    case 'h':
    case '?':
    default:
      errflag++;
    }
  }

  if (errflag > 0)
  {
    usage(argv[0]);
    exit(1);
  }
  if (argc - optind >= 1)
  {
    port = argv[optind];
  }
  if (argc - optind >= 2)
  {
    path = argv[optind + 1];
  }

  standaloneinit(port);

  if (!initial_bbs())
    exit(-1);

  if (!inetdstart)
    fprintf(stderr, "�Ұ� innbbsd �� %s ��\n", port);

  HISmaint();
  HISsetup();
  installinnbbsd();
  sethaltfunction(INNBBSDhalt);

  signal(SIGPIPE, dopipesig);
  inndchannel(port, path);
  HISclose();
}
