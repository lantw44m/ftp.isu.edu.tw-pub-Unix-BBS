#include <sys/types.h>
#include <sys/stat.h>
     
int
isfile(filename)
  char *filename;
{
  struct stat st;

  if (stat(filename, &st))
    return 0;
  if (!S_ISREG(st.st_mode))
    return 0;
  return 1;
}
