<?php
//user list
unset($cuser);
session_start();

require_once('config.php');
require_once('webbbs.class.php');

if(!$way) $way = 0;
if(!$page) $page = 1;
if(!$pal) $pal = 0;

?>
<html>
<head>
<title>UserList</title>
<link rel="stylesheet" type="text/css" href="style.css">
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<style type="text/css">
A {color: #000080}
A:hover {color: #000080}
</style>
<script language="javascript">
<!--hide
function sendmsg(userid, userno){
	var check = "<?echo $cuser[userno];?>";
	if(check == userno || userid == 'guest') return false; //���൹�ۤv�o
  	var prom = "�� �z�Q��"+userid+"������O�H";
	var xx=prompt(prom,'');
	if(xx != '' && xx!=null) top.activeFrame.bmw_send(userno, xx);
    return false;
}

function pickup(way){
	var pid = "<?echo $cuser[pid];?>";
	var page = "<?echo $page;?>";
	document.location = "ulist.php?pid="+pid+"&way="+way+"&page="+page;
}

function goto(page){
	var pid = "<?echo $cuser[pid];?>";
	var check = "<?echo $page;?>";
	var way = "<?echo $way;?>";
	if(check != page)
	document.location = "ulist.php?pid="+pid+"&way="+way+"&page="+page;
}
//-->
</script>
</head>
<body leftmargin="3" topmargin="3" marginwidth="3" marginheight="3" bgcolor="#FFFFFF">

<?php
if(!isset($pid)) {
 if($cuser[pid] > 0)
	 $pid = $cuser[pid];
 else {
  print "
	  <script language=javascript>
	  <!--hide
	  document.location = 'ulist.php?pid='+top.activeFrame.pid;
	  //-->
	  </script>
		  ";
  exit;
 }
}

 $ws = new server_class;
 $ws->connect();

 $cmd = $ws->set_cmd("t_ulist", G_TALK, $pid, $page, $way, $pal);
 $ws->query($cmd);

 $userlist = split("\n", $ws->data);
 array_pop ($userlist);
 $online = count($userlist) - 1;

 $ret = $ws->parse($userlist[0]);
 if($ret[result] != 'OK') {
	 $ws->alert($ws->data);
	 exit;
 }

 $ways = array("FBBS", "�N��", "�ӷ�", "�ʺA");
 $pickString = "��<select onchange='pickup(this.options[this.selectedIndex].value)' style='font-size: 9pt; height: 16'>";

 for($i=1; $i<5; $i++) {
	$pickString .= "<option value='$i'";
	if($i-1 == $ret[way]) $pickString .= " selected";
	$pickString .= ">".$ways[$i-1]."</option>\n";
 }

 $pickString .= " </select>�Ƨ�";


 /* -------------------------------------------------------------------- */
 /* GoTo Page                                                            */
 /* -------------------------------------------------------------------- */

 $totalpage = intval($ret[max]/XO_TALL);  /* 20�OXo_TALL���� */
 if($ret[max] % XO_TALL) $totalpage ++;

 if($page > $totalpage) $page = $totalpage;

 $gotoString = "�����<select onchange='goto(this.options[this.selectedIndex].value)' style='font-size: 9pt; height: 16'>";
 
 for($i=1; $i<=$totalpage; $i++)
 {
	$gotoString .= "<option value='$i'";
	if($i == $page) $gotoString .= " selected";
	$gotoString .= ">".$i."</option>\n";
 }

 $gotoString .= " </select>��";

 if($totalpage - $page > 0)  
 { 
	 $next = $page+1;
	 $gotoString .= " <a href=\"$PHP_SELF?page=$next&way=$way&pid=$cuser[pid]\" style='color: ffffff'>�U�@��</a>";
 }
 if($page > 1) 
 { 
	 $prev = $page-1;
	 $gotoString .= " <a href=\"$PHP_SELF?page=$prev&way=$way&pid=$cuser[pid]\" style='color: ffffff'>�W�@��</a>";
 }

 print "<table width=630 border=0 align=left cellspacing=0 cellpadding=1>\n";

 print "<tr><td colspan=9 align=center>
		<img src=images/ulist.gif width=289 height=55>
        </td></tr>";

 print "<tr> <td colspan=9>
		<table border=0 cellspacing=1 cellpadding=1 bgcolor=#000000 width=100% height=18 style='color: ffffff'>
		<tr bgcolor=#008888 align=center>
		<td> �n��/�b�u: $ret[fnum]/$ret[max] �H </td>
		<td> $pickString </td>
		<td> $ret[pal] (<a href=\"$PHP_SELF?pid=$cuser[pid]&pal=1&page=$page&way=$way\" style='color: ffffff'>��������</a>) </td>
		<td> $gotoString </td>
		</tr>
		</table>
        </td></tr>";
 print "
	<tr>
	<td>�Ǹ�</td>
	<td>�N��</td>
	<td>�O��</td>
	<td>�ӷ�</td>
	<td>P</td>
	<td>M</td>
	<td>���A</td>
	<td>�o�b</td>
    <td>�\��ﶵ</td>
	</tr>
 ";

 for($i=1; $i<=$online; $i++)
 {
  if($i%2) $bgcolor = "#efefef";
  else $bgcolor = "#fefefe";

  $tmp = $ws->parse($userlist[$i]);

  if($tmp[userno] <= 0) 
  {
	  print "<tr bgcolor=$bgcolor><td colspan=9>$tmp[msg]</td></tr>";
	  continue;
  }

  $modestr = ($tmp[cloak] ?  "<font class=col036>".$tmp[mode]."</font>" : $tmp[mode]);
  $userid = "<a href=\"query.php?userid=$tmp[userid]\" title=\"�I���d�߸ԲӸ��\"><font class=col0".$tmp[color].">".$tmp[userid]."</font></a>";

  if($tmp[msg] == "*") 
  {
	  if(($cuser[level] & PERM_ALLACCT) && ($cuser[userid] != $tmp[userid]))
		  $otherstr = "<a href=# onclick=\"return sendmsg('$tmp[userid]', '$tmp[userno]')\" title=\"�j��I�s\"><img src=images/close.gif border=0></a>";

	  else $otherstr = "<img src=images/close.gif border=0 title=\"�����I�s��\">";
  }

  else if($tmp[msg] == "-" || $tmp[msg] == "@") $otherstr = "<img src=images/quiet.gif border=0 title=\"�w�R�Ҧ�\">";
  else if($cuser[level] & PERM_VALID)
  {
      if($tmp[msg] == "O")
  		  $otherstr = "<a href=# onclick=\"return sendmsg('$tmp[userid]', '$tmp[userno]')\" title=\"�����I�s�����i�o�e����\"><img src=images/ok1.gif border=0></a>";
	  else
		  $otherstr = "<a href=# onclick=\"return sendmsg('$tmp[userid]', '$tmp[userno]')\" title=\"�Y�ɵo�e����\"><img src=images/ok.gif border=0></a>";
  }
  else $otherstr = "<img src=images/no.gif border=0>";

  if($cuser[level] & PERM_VALID)
	$otherstr .= " <a href=sendmail.php?receiver=$tmp[userid]&pid=$pid><img src=images/mail.gif border=0 title=\"�g�ʫH��\"></a>";
  else
	$otherstr .= " <img src=images/mail1.gif border=0 title=\"����g�H\">";

  if(($cuser[level] & PERM_VALID) && ($tmp[color] != 32))
    $otherstr .= "  <a href='pal_add.php?userid=$tmp[userid]' ><img src=images/friend.gif border=0 title=\"�[���n��\"></a>";
  else
	$otherstr .= "  <img src=images/friend1.gif border=0 title=\"�w�g�O�n�ͤF\">";
	
  print "<tr bgcolor=$bgcolor>
  <td> $tmp[no] </td>
  <td> $userid </td>
  <td> $tmp[username] </td>
  <td> $tmp[from] </td>
  <td> $tmp[pager] </td>
  <td> $tmp[msg] </td>
  <td> $modestr </td>
  <td> $tmp[idle] </td>
  <td> $otherstr </td>
  </tr>";
 }

 print "</table>";
?>

</body>
</html>

<? exit(); ?>
