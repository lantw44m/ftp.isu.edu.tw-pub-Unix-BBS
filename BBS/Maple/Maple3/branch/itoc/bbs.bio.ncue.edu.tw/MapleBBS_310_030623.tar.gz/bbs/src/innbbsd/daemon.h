#ifndef _DAEMON_H_
#define _DAEMON_H_

#include <stdio.h>
#include <time.h>


typedef struct Argv_t
{
  FILE *in, *out;
  int argc;
  char **argv;
  char *inputline;
  struct Daemoncmd *dc;
}        argv_t;


typedef struct Buffer_t
{
  char *data;
  int used, left, lastread;
}        buffer_t;


typedef struct ClientType
{
  char hostname[1024];
  char buffer[4096];
  int mode;
  argv_t Argv;
  int fd, access, lastread, midcheck;
  buffer_t in, out;
  int ihavecount, ihavesize, ihaveduplicate, ihavefail;
  int statcount, statfail;
  time_t begin;
}          ClientType;


typedef struct Daemoncmd
{
  char *name;
  char *usage;
  int argc, argno, errorcode, normalcode;
  int (*main) ();
}          daemoncmd_t;


/* inndchannel.c */
extern ClientType *Channel;


/* daemon.c */
extern void installdaemon();

#endif		/* _DAEMON_H_ */
