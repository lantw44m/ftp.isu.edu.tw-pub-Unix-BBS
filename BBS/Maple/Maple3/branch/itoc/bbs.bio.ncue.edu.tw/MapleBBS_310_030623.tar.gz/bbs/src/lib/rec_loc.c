#include "dao.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/file.h>


int
rec_loc(fpath, size, fchk)
  char *fpath;
  int size;
  int (*fchk) ();
{
  int fd, pos, rc;
  char pool[REC_SIZ];

  if ((fd = open(fpath, O_RDONLY)) < 0)
    return -1;

  f_exlock(fd);

  rc = -1;

  if (fchk)
  {
    pos = -1;
    fpath = pool;

    lseek(fd, 0, SEEK_SET);
    while (read(fd, fpath, size) == size)
    {
      pos++;
      if ((*fchk) (fpath))
      {
        rc = pos;
        break;
      }
    }
  }

  f_unlock(fd);

  close(fd);

  return rc;
}
