<html>
<head>
<title>TalkPage</title>
<meta http-equiv="Content-Type" content="text/html;charset=big5">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #b751af}
A:visited {color: #b751af}
</style>
</head>
<body leftmargin="3" topmargin="0" marginwidth="3" marginheight="0" bgcolor="#FFFFFF">
<table width="609" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="3"><img src="images/talk/talk_top.jpg" width="609" height="46" usemap="#Map" border="0"></td>
  </tr>
  <tr> 
    <td height="169" width="16" background="images/talk/talk_left_bg.jpg">&nbsp;</td>
    <td height="100%" width="577">&nbsp;	
      <table width="76%" border="0" cellspacing="0" cellpadding="0" height="140">
        <tr> 
          <td rowspan="4" align="center" width="11%">&nbsp;</td>
          <td width="25%"><b><a href="xchat.php" style="font-size: 12pt" target="_self">�u�W��ѫ�</a></b></td>
          <td width="64%"><font size="2" color="#666666">�PBBS����ѫǬ۳q���</font></td>
        </tr>
        <tr> 
          <td width="25%"><b><a href="ulist.php" style="font-size: 12pt">���U�|��</a></b></td>
          <td width="64%"><font size="2" color="#666666">�ݬݦ��֦b���W�C..</font></td>
        </tr>
        <tr> 
          <td width="25%"><b><a href="query.php" style="font-size: 12pt">�d�ߺ���</a></b></td>
          <td width="64%"><font size="2" color="#666666">�Q�n�d�߽֪��W���O�H</font></td>
        </tr>
        <tr> 
          <td width="25%"><b><a href="pal_list.php" style="font-size: 12pt">��ͪ��p</a></b></td>
          <td width="64%"><font size="2" color="#666666">���t�ۤv�������v�q��I�I</font></td>
        </tr>
      </table>	
	</td>
    <td height="169" width="16" background="images/talk/talk_right_bg.jpg">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="3"><img src="images/talk/talk_bottom.jpg" width="609" height="20"></td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="46,13,116,33" href="services.php" alt="�����A�Ȱ�" title="�����A�Ȱ�">
  <area shape="rect" coords="125,13,195,33" href="board.php" alt="�����Q�׶�" title="�����Q�׶�">
  <area shape="rect" coords="205,14,274,33" href="gem.php" alt="��ؤ��G��" title="��ؤ��G��">
  <area shape="rect" coords="283,15,353,33" href="personal.php" alt="�ӤH�u��{" title="�ӤH�u��{">
  <area shape="rect" coords="495,15,565,35" href="group.php" alt="�ڪ��s�հ�" title="�ڪ��s�հ�">
</map>
</body>
</html>
