#!/bin/sh

if [ -e /home/bbs/innbbsd.core ]; then
{
	rm -f /home/bbs/innbbsd.core;
	rm -f /home/bbs/*.LOCK;
	/home/bbs/innd/innbbsd 7777;
}
else
	/home/bbs/innd/ctlinnbbsd reload;
fi
