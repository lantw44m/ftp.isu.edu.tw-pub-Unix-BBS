/*-------------------------------------------------------*/
/* cache.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : cache up data by shared memory		 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#include "bbs.h"
#include <sys/ipc.h>
#include <sys/shm.h>


#ifdef	HAVE_SEM
#include <sys/sem.h>
#endif


#ifdef MODE_STAT 
UMODELOG modelog; 
time_t mode_lastchange; 
#endif


#ifdef	HAVE_SEM

/* ----------------------------------------------------- */
/* semaphore : for critical section			 */
/* ----------------------------------------------------- */


static int ap_semid;


static void
attach_err(shmkey)
  int shmkey;
{
  char buf[20];

  sprintf(buf, "key = %x", shmkey);
  blog("shmget", buf);
  exit(1);
}


void
sem_init()
{
  int semid;

  union semun
  {
    int val;
    struct semid_ds *buf;
    ushort *array;
  }     arg =
  {
    1
  };

  semid = semget(BSEM_KEY, 1, 0);
  if (semid == -1)
  {
    semid = semget(BSEM_KEY, 1, IPC_CREAT | BSEM_FLG);
    if (semid == -1)
      attach_err(BSEM_KEY);
    semctl(semid, 0, SETVAL, arg);
  }
  ap_semid = semid;
}


void
sem_lock(op)
  int op;			/* op is BSEM_ENTER or BSEM_LEAVE */
{
  struct sembuf sops;

  sops.sem_num = 0;
  sops.sem_flg = SEM_UNDO;
  sops.sem_op = op;
  semop(ap_semid, &sops, 1);
}


#endif	/* HAVE_SEM */


/*-------------------------------------------------------*/
/* .UTMP cache						 */
/*-------------------------------------------------------*/


UCACHE *ushm;


void
ushm_init()
{
  ushm = shm_new(UTMPSHM_KEY, sizeof(UCACHE));
}


#ifndef	_BBTP_


void
utmp_mode(mode)
  int mode;
{
  if (bbsmode != mode)
  {
#ifdef MODE_STAT
    time_t now;

    time(&now);
    modelog.used_time[bbsmode] += (now - mode_lastchange);
    mode_lastchange = now;
#endif

    cutmp->mode = bbsmode = mode;
  }
}


int
utmp_new(up)
  UTMP *up;
{
  UCACHE *xshm;
  UTMP *uentp, *utail;

  /* --------------------------------------------------- */
  /* semaphore : critical section			 */
  /* --------------------------------------------------- */

#ifdef	HAVE_SEM
  sem_lock(BSEM_ENTER);
#endif

  xshm = ushm;
  uentp = xshm->uslot;
  utail = uentp + MAXACTIVE;

  /* uentp += (up->pid % xshm->count); */	/* hashing */

  do
  {
    if (!uentp->pid)
    {
      usint offset;

      offset = (void *) uentp - (void *) xshm->uslot;
      memcpy(uentp, up, sizeof(UTMP));
      xshm->count++;
      if (xshm->offset < offset)
	xshm->offset = offset;
      cutmp = uentp;

#ifdef	HAVE_SEM
      sem_lock(BSEM_LEAVE);
#endif

      return 1;
    }
  } while (++uentp < utail);

  /* Thor:�i�Duser���H�n���@�B�F */

#ifdef	HAVE_SEM
  sem_lock(BSEM_LEAVE);
#endif

  return 0;
}


void
utmp_free()
{
  UTMP *uentp;

  uentp = cutmp;
  if (!uentp || !uentp->pid)
    return;

#ifdef	HAVE_SEM
  sem_lock(BSEM_ENTER);
#endif

  uentp->pid = uentp->userno = 0;
  ushm->count--;

#ifdef	HAVE_SEM
  sem_lock(BSEM_LEAVE);
#endif
}


UTMP *
utmp_find(userno)
  int userno;
{
  UTMP *uentp, *uceil;

  uentp = ushm->uslot;
  uceil = (void *) uentp + ushm->offset;
  do
  {
    if (uentp->userno == userno)
      return uentp;
  } while (++uentp <= uceil);

  return NULL;
}


UTMP *
utmp_get(userid)	/* itoc.010306: �ˬd�ϥΪ̬O�_�b���W */
  char *userid;
{
  UTMP *uentp, *uceil;
  int seecloak;
#ifdef HAVE_SUPERCLOAK
  int seesupercloak;
#endif

  /* itoc.020718.����: �ѩ�P�@�����P�˧@�̪����v��b�Ӱ��A�Ҽ{�O�_�O�U�d�ߵ��G�A
     �M����d���e���O���A�Y�䤣��A�h�ϥΪ̦W��� */

  seecloak = HAS_PERM(PERM_SEECLOAK);
#ifdef HAVE_SUPERCLOAK
  seesupercloak = cuser.ufo & UFO_SUPERCLOAK;
#endif
  uentp = ushm->uslot;
  uceil = (void *) uentp + ushm->offset;
  do
  {
    if (uentp->pid && !strcmp(userid, uentp->userid))	/* �w�g���������ˬd */
    {
      if (!seecloak && (uentp->ufo & UFO_CLOAK))/* ���άݤ��� */
	continue;

#ifdef HAVE_BADPAL
      if (!seecloak && is_obad(uentp))		/* �Q�]�a�H�ݤ��� */
	continue;
#endif

#ifdef HAVE_SUPERCLOAK
      if (!seesupercloak && (uentp->ufo & UFO_SUPERCLOAK))	/* �����ݤ��� */
	continue;
#endif

      return uentp;
    }
  } while (++uentp <= uceil);

  return NULL;
}


#ifdef CHECK_ONLINE
UTMP *
utmp_seek(hdr)		/* itoc.010306: �ˬd�ϥΪ̬O�_�b���W */
  HDR *hdr;
{
  if (hdr->xmode & (GEM_GOPHER | POST_INCOME | MAIL_INCOME))
    return NULL;
  return utmp_get(hdr->owner);
}
#endif


void  
utmp_admset(userno)	/* itoc.010811: �ʺA�]�w�u�W�ϥΪ� */
  int userno;
{
  UTMP *uentp, *uceil;

  uentp = ushm->uslot;
  uceil = (void *) uentp + ushm->offset;
  do
  {
    if (uentp->userno == userno)
      uentp->userlevel |= PERM_DATALOCK;	/* �[�W��ƳQ�ܰʹL���X�� */
  } while (++uentp <= uceil);
}


int
utmp_count(userno, show)
  int userno;
  int show;
{
  UTMP *uentp, *uceil;
  int count;

  count = 0;
  uentp = ushm->uslot;
  uceil = (void *) uentp + ushm->offset;
  do
  {
    if (uentp->userno == userno)
    {
      count++;
      if (show)
      {
	prints("(%d) �ثe���A��: %-17.16s(�Ӧ� %s)\n",
	  count, bmode(uentp, 0), uentp->from);
      }
    }
  } while (++uentp <= uceil);
  return count;
}


#ifdef HAVE_IPMAXGUEST
int
utmp_ipcount(userno, address)
  int userno;
  u_long *address;
{
  UTMP *uentp, *uceil;
  int count;
  uschar *addr;
  u_long in_addr;

  count = 0;
  addr = (uschar *) address;
  in_addr = (addr[0] << 24) + (addr[1] << 16) + (addr[2] << 8) + addr[3];
  uentp = ushm->uslot;
  uceil = (void *) uentp + ushm->offset;
  do
  {
    if (uentp->userno == userno && uentp->in_addr == in_addr)
      count++;
  } while (++uentp <= uceil);
  return count;
}
#endif


UTMP *
utmp_search(userno, order)
  int userno;
  int order;			/* �ĴX�� */
{
  UTMP *uentp, *uceil;

  uentp = ushm->uslot;
  uceil = (void *) uentp + ushm->offset;
  do
  {
    if (uentp->userno == userno)
    {
      if (--order <= 0)
	return uentp;
    }
  } while (++uentp <= uceil);
  return NULL;
}


#if 0
int
apply_ulist(fptr)
  int (*fptr) ();
{
  UTMP *uentp;
  int i, state;

  uentp = ushm->uslot;
  for (i = 0; i < USHM_SIZE; i++, uentp++)
  {
    if (uentp->pid)
      if (state = (*fptr) (uentp))
	return state;
  }
  return 0;
}
#endif


/*-------------------------------------------------------*/
/* .BRD cache						 */
/*-------------------------------------------------------*/


BCACHE *bshm;


#if 0
void
bsync()
{
  rec_put(FN_BRD, bshm->bcache, sizeof(BRD) * bshm->number, 0, NULL);
}
#endif


void
bshm_init()
{
  BCACHE *xshm;
  time_t *uptime;
  int n, turn;

  turn = 0;
  xshm = bshm;
  if (xshm == NULL)
  {
    bshm = xshm = shm_new(BRDSHM_KEY, sizeof(BCACHE));
  }

  uptime = &(xshm->uptime);

  for (;;)
  {
    n = *uptime;
    if (n > 0)
      return;

    if (n < 0)
    {
      if (++turn < 30)
      {
	sleep(2);
	continue;
      }
    }

    *uptime = -1;

    if ((n = open(FN_BRD, O_RDONLY)) >= 0)
    {
      xshm->number =
	read(n, xshm->bcache, MAXBOARD * sizeof(BRD)) / sizeof(BRD);
      close(n);
    }

    /* ���Ҧ� boards ��Ƨ�s��A�]�w uptime */

    time(uptime);
    blog("CACHE", "reload bcache");
    return;
  }
}


#if 0
int
apply_boards(func)
  int (*func) ();
{
  extern char brd_bits[];
  BRD *bhdr;
  int i;

  for (i = 0, bhdr = bshm->bcache; i < bshm->number; i++, bhdr++)
  {
    if (brd_bits[i])
    {
      if ((*func) (bhdr) == -1)
	return -1;
    }
  }
  return 0;
}
#endif


int
brd_bno(bname)
  char *bname;
{
  BRD *brdp, *bend;
  int bno;

  brdp = bshm->bcache;
  bend = brdp + bshm->number;
  bno = 0;

  do
  {
    if (!str_cmp(bname, brdp->brdname))
      return bno;

    bno++;
  } while (++brdp < bend);

  return -1;
}


#if 0
BRD *
getbrd(bname)
  char *bname;
{
  BRD *bhdr, *tail;

  bhdr = bshm->bcache;
  tail = bhdr + bshm->number;
  do
  {
    if (!str_cmp(bname, bhdr->brdname))
      return bhdr;
  } while (++bhdr < tail);
  return NULL;
}
#endif


/*-------------------------------------------------------*/
/* etc/movie cache					 */
/*-------------------------------------------------------*/


static FCACHE *fshm;


void
fshm_init()
{
  if (fshm == NULL)
    fshm = shm_new(FILMSHM_KEY, sizeof(FCACHE));
}


/* ----------------------------------------------------- */
/* itoc.020822.����:				`	 */
/* ----------------------------------------------------- */
/* �� 0 �� FILM_MOVIE-1 �i�O�t�εe���λ����e��		 */
/* �� FILM_MOVIE �� fmax-1 �i�O�ʺA�ݪO			 */
/* ----------------------------------------------------- */
/* tag:							 */
/* 0 �� fmax-1 �� ����ӱi�e��				 */
/* >= fmax     �� ����� FILM_MOVIE �i			 */
/* ----------------------------------------------------- */
/* row:							 */
/* >=0 �� �t�εe���A�q (row, 0) �}�l�L			 */
/* <0  �� �����e���A�q (0, 0) �}�l�L�A�̫�| vmsg(NULL)	 */
/* ----------------------------------------------------- */
/* return: �{�b���񪺳o�i tag ���X			 */
/* ----------------------------------------------------- */


int
film_out(tag, row)
  int tag;
  int row;			/* -1 : help */
{
  int fmax, len, *shot;
  char *film, buf[FILM_SIZ];

  len = 0;
  shot = fshm->shot;

  while (!(fmax = *shot))	/* util/camera.c ���b���� */
  {
    sleep(5);
    if (++len >= 6)		/* �Y 30 ���H���٨S���n���A�i��O�S�] camera�A�������} */
      return FILM_MOVIE;
  }

  if (row <= 0)
    clear();
  else
    move(row, 0);

  if (tag >= fmax)		/* �W�L�F fmax�A�q FILM_MOVIE �}�l���s���� */
    tag = FILM_MOVIE;

  film = fshm->film;

  if (tag)
  {
    len = shot[tag];
    film += len;
    len = shot[tag + 1] - len;
  }
  else
  {
    len = shot[1];
  }

  if (len >= FILM_SIZ - MOVIE_LINES)
    return FILM_MOVIE;

  memcpy(buf, film, len);
  buf[len] = '\0';
  outx(buf);

  if (row < 0)			/* help screen */
    vmsg(NULL);

  return tag;
}

#endif	/* _BBTP_ */
