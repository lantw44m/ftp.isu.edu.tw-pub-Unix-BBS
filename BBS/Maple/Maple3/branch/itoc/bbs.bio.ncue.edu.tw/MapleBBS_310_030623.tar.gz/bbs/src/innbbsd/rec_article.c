/*-------------------------------------------------------*/
/* rec_article.c( NTHU CS MapleBBS Ver 3.10 )		 */
/*-------------------------------------------------------*/
/* target : innbbsd receive article			 */
/* create : 95/04/27					 */
/* update :   /  /  					 */
/* author : skhuang@csie.nctu.edu.tw			 */
/*-------------------------------------------------------*/

#if 0
   ���줧�峹���e�M���Y���O�b
   ���� (body)   �b char *BODY
   ���Y          �b char *SUBJECT, *FROM, *SITE, *DATE, *POSTHOST, *PATH, *GROUPS, *MSGID, *CONTROL;
#endif

#if 0	/* itoc.030109.����: rec_article.c ���y�{ */
            �z�� receive_article() �� bbspost_add()    �� bbspost_write_post()
  my_recv() �u�� receive_nocem()   �� �e�h nocem.c �B�z
            �|�� cancel_article()  �� bbspost_cancel()
#endif


#include "innbbsconf.h"
#include "daemon.h"
#include "bbslib.h"
#include "inntobbs.h"


extern int Junkhistory;


/* ----------------------------------------------------- */
/* �B�z DATE						 */
/* ----------------------------------------------------- */


#if 0	/* itoc.030303.����: RFC 822 �� DATE ���FRFC 1123 �N year �令 4-DIGIT */

date-time := [ wday "," ] date time ; dd mm yy, hh:mm:ss zzz 
wday      :=  "Mon" / "Tue" / "Wed" / "Thu" / "Fri" / "Sat" / "Sun" 
date      :=  1*2DIGIT month 4DIGIT ; mday month year
month     :=  "Jan" / "Feb" / "Mar" / "Apr" / "May" / "Jun" / "Jul" / "Aug" / "Sep" / "Oct" / "Nov" / "Dec" 
time      :=  hour zone ; ANSI and Military 
hour      :=  2DIGIT ":" 2DIGIT [":" 2DIGIT] ; 00:00:00 - 23:59:59 
zone      :=  "UT" / "GMT" / "EST" / "EDT" / "CST" / "CDT" / "MST" / "MDT" / "PST" / "PDT" / 1ALPHA / ( ("+" / "-") 4DIGIT )

#endif

static time_t datevalue;

static void
parse_date()		/* ��ŦX "dd mmm yyyy hh:mm:ss" ���榡�A�ন time_t */
{
  static char months[12][4] = {"jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"};
  int i;
  char *ptr, *str, buf[80];
  struct tm ptime;

  str_ncpy(buf, DATE, sizeof(buf));
  str_lower(buf, buf);			/* �q�q���p�g�A�]�� Dec DEC dec �U�س����H�� */

  str = buf + 2;
  for (i = 0; i < 12; i++)
  {
    if (ptr = strstr(str, months[i]))
      break;
  }

  if (ptr)
  {
    ptr[-1] = ptr[3] = ptr[8] = ptr[11] = ptr[14] = ptr[17] = '\0';

    ptime.tm_sec = atoi(ptr + 15);
    ptime.tm_min = atoi(ptr + 12);
    ptime.tm_hour = atoi(ptr + 9);
    ptime.tm_mday = (ptr == buf + 2 || ptr == buf + 7) ? atoi(ptr - 2) : atoi(ptr - 3);	/* RFC 822 ���\ mday �O 1- �� 2- DIGIT */
    ptime.tm_mon = i;
    ptime.tm_year = atoi(ptr + 4) - 1900;
    ptime.tm_isdst = 0;
    ptime.tm_zone = "GMT";
    ptime.tm_gmtoff = 0;

    datevalue = mktime(&ptime);
    str = ptr + 18;
    if (ptr = strchr(str, '+'))
    {
      /* �p�G�� +0100 (MET) �������ɰϡA���զ^ GMT �ɰ� */
      datevalue -= ((ptr[1] - '0') * 10 + (ptr[2] - '0')) * 3600 + ((ptr[3] - '0') * 10 + (ptr[4] - '0')) * 60;
    }
    else if (ptr = strchr(str, '-'))
    {
      /* �p�G�� -1000 (HST) �������ɰϡA���զ^ GMT �ɰ� */
      datevalue += ((ptr[1] - '0') * 10 + (ptr[2] - '0')) * 3600 + ((ptr[3] - '0') * 10 + (ptr[4] - '0')) * 60;
    }
    datevalue += 28800;		/* �x�W�Ҧb�� CST �ɰϤ� GMT �֤K�p�� */
  }
  else
  {
    /* �p�G���R���ѡA���򮳲{�b�ɶ��ӷ��o��ɶ� */
    time(&datevalue);

    bbslog(":Warn: parse_date fail %s\n", DATE);
  }
}


/* ----------------------------------------------------- */
/* process post write					 */
/* ----------------------------------------------------- */


static int
bbspost_write_post(fd, board)
  int fd;
  char *board;
{
  FILE *fp;

  if (!(fp = fdopen(fd, "w")))
  {
    close(fd);
    bbslog("can't fdopen, maybe disk full\n");
    return -1;
  }

  fprintf(fp, "�o�H�H: %.50s �ݪO: %s\n", FROM, board);
  fprintf(fp, "��  �D: %.70s\n", SUBJECT);
  fprintf(fp, "�o�H��: %.27s (%.40s)\n", SITE, DATE);
  fprintf(fp, "��H��: %.70s\n", PATH);

  if (POSTHOST)
    fprintf(fp, "Origin: %.70s\n", POSTHOST);

  fprintf(fp, "\n%s", BODY);	/* chuan: header �� body �n�Ŧ��} */
  fclose(fp);

  close(fd);

  return 0;
}


static char *
bbspost_add(board, userid, usernick, firstpath)
  char *board, *userid, *usernick;
  char *firstpath;
{
  static char name[8];
  char *fname, fpath[128];
  HDR hdr;
  time_t now;
  int fd, linkflag;

  sprintf(fpath, "brd/%s/@/A", board);
  fname = strrchr(fpath, 'A') + 1;

  now = time(NULL);
  while (1)
  {
    archiv32(now, fname);
    fname[-3] = fname[6];

    fd = open(fpath, O_CREAT | O_EXCL | O_WRONLY, 0644);
    if (fd >= 0)
      break;

    if (errno != EEXIST)
    {
      bbslog(" Err: can't write or other errors\n");
      return NULL;
    }
    now++;
  }

  strcpy(name, fname);

  linkflag = 1;

  if (firstpath && *firstpath)
  {
    close(fd);
    unlink(fpath);

    linkflag = link(firstpath, fpath);
    if (linkflag)
    {
      fd = open(fpath, O_CREAT | O_EXCL | O_WRONLY, 0644);
    }
  }
  if (linkflag)
  {
    if (bbspost_write_post(fd, board) < 0)
      return NULL;

    if (firstpath)
      strcpy(firstpath, fpath);	/* opus : write back */
  }

  memset(&hdr, 0, sizeof(HDR));

  hdr.chrono = now;
  hdr.xmode = POST_INCOME;
  strcpy(hdr.xname, --fname);

  /* Thor.980825: ����r��Ӫ��\�L�Y */
  strncpy(hdr.owner, userid, sizeof(hdr.owner) - 1);
  strncpy(hdr.nick, usernick, sizeof(hdr.nick) - 1);

  str_stamp(hdr.date, &datevalue);

  /* Thor.980825: ����r��Ӫ��\�L�Y */
  strncpy(hdr.title, SUBJECT, sizeof(hdr.title) - 1);

  strcpy(fname - 2, FN_DIR);

  rec_add(fpath, &hdr, sizeof(HDR));

  return name;
}


/* ----------------------------------------------------- */
/* process cancel write					 */
/* ----------------------------------------------------- */


static inline void
move_post(hdr, board, filename)
  HDR *hdr;
  char *board, *filename;
{
  HDR post;
  char folder[64];

  brd_fpath(folder, board, FN_DIR);
  hdr_stamp(folder, HDR_LINK | 'A', &post, filename);
  unlink(filename);

  /* �����ƻs trailing data */

  memcpy(post.owner, hdr->owner, TTLEN + 140);

  sprintf(post.title, "[cancel] %-60.60s", FROM);

  rec_add(folder, &post, sizeof(HDR));
}


static void
bbspost_cancel(board, time, filename)
  char *board;
  register time_t time;
  char *filename;
{
  HDR hdr;
  struct stat st;
  long size;
  int fd, ent;
  char folder[64];
  off_t off, len;

  /* XLOG("cancel [%s] %d\n", board, time); */

  brd_fpath(folder, board, FN_DIR);
  if ((fd = open(folder, O_RDWR)) == -1)
    return;

  /* flock(fd, LOCK_EX); */
  /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
  f_exlock(fd);

  fstat(fd, &st);
  size = sizeof(HDR);
  ent = ((long) st.st_size) / size;

  /* itoc.030307.����: �h .DIR ���ǥѤ�� chrono ��X�O���@�g */

  while (1)
  {
    /* itoc.030307.����: �C 16 �g���@�� block */
    ent -= 16;
    if (ent <= 0)
      break;

    lseek(fd, size * ent, SEEK_SET);
    if (read(fd, &hdr, size) != size)
      break;

    if (hdr.chrono <= time)	/* ���b�o�� block �� */
    {
      do
      {
	if (hdr.chrono == time)
	{
          /* Thor.981014: mark ���峹���Q cancel */
	  if (hdr.xmode & POST_MARKED)
	    break;

	  /* itoc.030613: �O�d�Q cancel ���峹�� [deleted] */
	  move_post(&hdr, BN_DELETED, filename);

          /* itoc.030307: �Q cancel ���峹���O�d header */

	  off = lseek(fd, 0, SEEK_CUR);
	  len = st.st_size - off;

	  board = (char *) malloc(len);
	  read(fd, board, len);

          lseek(fd, off - size, SEEK_SET);
	  write(fd, board, len);
	  ftruncate(fd, st.st_size - size);

	  free(board);
	  break;
	}

	if (hdr.chrono > time)
	  break;
      } while (read(fd, &hdr, size) == size);

      break;
    }
  }

  /* flock(fd, LOCK_UN); */
  /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
  f_unlock(fd);

  close(fd);
  return;
}


#ifndef _NoCeM_
static 
#endif
int			/* 0:cancel success  -1:cancel fail */
cancel_article(msgid)
  char *msgid;
{
  register char *ptr;
  register char *filelist;
  char histent[1024], filename[80], cancelfrom[128];
  char buffer[256];
  register char *token;

  /* XLOG("cancel %s <%s>\n", FROM, msgid); */

  if (!(ptr = (char *) DBfetch(msgid)))
    return -1;

  str_from(FROM, cancelfrom, buffer);

  /* XLOG("cancel %s (%s)\n", cancelfrom, buffer); */

  str_ncpy(filelist = histent, ptr, sizeof(histent));

  for (ptr = filelist; ptr && *ptr;)
  {
    register char *file;
    register int fd;

    for (; *ptr && isspace(*ptr); ptr++);
    if (*ptr == '\0')
      break;
    file = ptr;

    /* XLOG("cancel file (%s)\n", file); */

    for (ptr++; *ptr && !isspace(*ptr); ptr++);
    if (*ptr != '\0')
    {
      *ptr++ = '\0';
    }

    /* XLOG("cancel file-2 (%s)\n", file); */

    token = strchr(file, '/');
    if (!token)
      return -1;

    /* XLOG("cancel token (%s)\n", token); */

    *token++ = '\0';
    sprintf(filename, "brd/%s/%c/A%s", file, token[6], token);	/* �h��X���g�峹 */

    /* XLOG("cancel path (%s)\n", filename); */

    if ((fd = open(filename, O_RDONLY)) >= 0)
    {
      register char *xfrom;
      register int len;

      len = read(fd, buffer, 128);
      close(fd);

      /* SoC: get local artilce headers for cancel back */

      if ((len > 8) && !memcmp(buffer, "�o�H�H: ", 8))	/* Thor.981221.����: �~�Ӥ峹 */
      {
	char *str;

	buffer[len] = '\0';
	xfrom = buffer + 8;
	if (str = strchr(xfrom, '\n'))
	  *str = '\0';
	if (str = strrchr(xfrom, ','))
	  *str = '\0';

#ifdef _NoCeM_
	/* gslin.000607: ncm_issuser �i�H��O���o���H */
	if (!strstr(xfrom, cancelfrom) && !search_issuer(FROM, NULL))
#else
	if (!strstr(xfrom, cancelfrom))
#endif
	{
	  /* itoc.030107.����: �Y cancelfrom �M���a�峹 header �O���� xfrom ���P�A�N�O fake cancel */
	  bbslog("Invalid cancel %s, sender: %s, path: %s\n", xfrom, FROM, PATH);
	  return -1;
	}
      }

      bbspost_cancel(file, chrono32(token), filename);
    }
  }

  return 0;
}


#ifdef	_ANTI_SPAM_
/* ----------------------------------------------------- */
/* anti-spam						 */
/* ----------------------------------------------------- */


#define SPAM_HASH_SIZE  2048


typedef struct SpamHeader
{
  unsigned int zauthor;
  unsigned int ztitle;
  unsigned int zbody;

  char *author;
  char *title;
  newsfeeds_t *nf;		/* �Ĥ@���X�{�b���� newsfeeds */

  int count;			/* ���X�g�w�o�{ */
  int cspam;			/* ���X�g�Q�d�I */
  time_t uptime;		/* �̪�X�{�ɶ� */

  struct SpamHeader *next;
}          SpamHeader;


static SpamHeader *SpamBucket[SPAM_HASH_SIZE];


static unsigned int
str_zcode(str, len)
  unsigned char *str;
  int len;
{
  unsigned int code, cc;

  code = 32713;
  while (cc = *str++)
  {
    code = (code << 3) ^ cc ^ len;
    if (--len <= 0)
      break;
  }

  return code;
}


static SpamHeader *
spam_find(spam)
  SpamHeader *spam;
{
  SpamHeader *hash;
  unsigned int zauthor, ztitle, zbody;
  char *author, *title;

  zauthor = spam->zauthor;

  if (hash = SpamBucket[zauthor & (SPAM_HASH_SIZE - 1)])
  {
    ztitle = spam->ztitle;
    zbody = spam->zbody;
    author = spam->author;
    title = spam->title;

    do
    {
      if (zbody == spam->zbody && zauthor == hash->zauthor &&
	ztitle == hash->ztitle && !strcmp(hash->author, author) &&
	!strcmp(hash->title, title))
	break;
    } while (hash = hash->next);
  }

  return hash;
}


static void
spam_add(spam)
  SpamHeader *spam;
{
  SpamHeader *hash;
  int zcode;

  zcode = spam->zauthor & (SPAM_HASH_SIZE - 1);
  spam->author = strdup(spam->author);
  spam->title = strdup(spam->title);

  hash = (SpamHeader *) malloc(sizeof(SpamHeader));
  memcpy(hash, spam, sizeof(SpamHeader));

  time(&hash->uptime);
  hash->next = SpamBucket[zcode];
  SpamBucket[zcode] = hash;
}


void
spam_expire()
{
  time_t now, due;
  int i;
  SpamHeader *spam, **prev, *next;
  FILE *fp;

  due = time(&now) - 60 * 60;
  fp = fopen("innd/spam.log", "a");
  fprintf(fp, "[%d] %s\n", now, ctime(&now));

  for (i = 0; i < SPAM_HASH_SIZE; i++)
  {
    if (spam = SpamBucket[i])
    {
      prev = &SpamBucket[i];
      do
      {
	next = spam->next;
	fprintf(fp, "[%d] %d %d\n  %s\n  %s\n",
	  spam->uptime, spam->count, spam->cspam,
	  spam->author, spam->title);

	if (spam->uptime < due)
	{
	  free(spam->author);
	  free(spam->title);
	  free(spam);
	  *prev = next;
	}
	else
	{
	  prev = &(spam->next);
	}
      } while (spam = next);
    }
  }

  fclose(fp);
}
#endif				/* _ANTI_SPAM_ */


/* ----------------------------------------------------- */
/* process receive article				 */
/* ----------------------------------------------------- */

#define MAXTOK 50
static char *Splitptr[MAXTOK];
static char splitbuf[1024];


static char **
split(line, pat)
  char *line, *pat;
{
  register char *p;
  register int i;

  for (i = 0; i < MAXTOK; ++i)
    Splitptr[i] = NULL;
  strncpy(splitbuf, line, sizeof(splitbuf) - 1);
  /* printf("%d %d\n",strlen(line),strlen(splitbuf)); */
  splitbuf[sizeof(splitbuf) - 1] = '\0';
  for (i = 0, p = splitbuf; *p && i < MAXTOK - 1;)
  {
    for (Splitptr[i++] = p; *p && !strchr(pat, *p); p++);
    if (*p == '\0')
      break;
    for (*p++ = '\0'; *p && strchr(pat, *p); p++);
  }
  return Splitptr;
}


#ifndef _NoCeM_
static 
#endif
newsfeeds_t *
search_newsfeeds_bygroup(newsgroup)
  char *newsgroup;
{
  newsfeeds_t nft, *find;
  nft.newsgroups = newsgroup;
  find = (newsfeeds_t *) bsearch((char *) &nft, NEWSFEEDS, NFCOUNT, sizeof(newsfeeds_t), nf_bygroupcmp);
  return find;
}


static char **
BNGsplit(line)
  char *line;
{
  register char **ptr = split(line, ",");
  register newsfeeds_t *nf1, *nf2;
  register char *n11, *n12, *n21, *n22;
  register char *str, *key;
  register int i, j;

  for (i = 0; str = ptr[i]; i++)
  {
    nf1 = (newsfeeds_t *) search_newsfeeds_bygroup(str);
    for (j = i + 1; key = ptr[j]; j++)
    {
      if (strcmp(str, key) == 0)
      {
	*key = '\0';
	continue;
      }
      nf2 = (newsfeeds_t *) search_newsfeeds_bygroup(key);
      if (nf1 && nf2)
      {
	if (strcmp(nf1->board, nf2->board) == 0)
	{
	  *key = '\0';
	  continue;
	}
	for (n11 = nf1->board, n12 = (char *) strchr(n11, ',');
	  n11 && *n11; n12 = (char *) strchr(n11, ','))
	{
	  if (n12)
	    *n12 = '\0';
	  for (n21 = nf2->board, n22 = (char *) strchr(n21, ',');
	    n21 && *n21; n22 = (char *) strchr(n21, ','))
	  {
	    if (n22)
	      *n22 = '\0';
	    if (strcmp(n11, n21) == 0)
	    {
	      *n21 = '\t';
	    }
	    if (n22)
	    {
	      *n22 = ',';
	      n21 = n22 + 1;
	    }
	    else
	      break;
	  }
	  if (n12)
	  {
	    *n12 = ',';
	    n11 = n12 + 1;
	  }
	  else
	    break;
	}
      }
    }
  }
  return ptr;
}


static int
receive_article()
{
  register char *ngptr, *pathptr;
  register char **splitptr;
  register char *fname;
  register newsfeeds_t *nf;
  register int hislen;
  char xpath[180];
  char xdate[80];
  char hispaths[2048];
  char firstpath[128];
  char myaddr[128], mynick[128];
  static char myfrom[256], mysubject[128];

#ifdef _ANTI_SPAM_
  SpamHeader zart, *spam;
#endif

  /* Thor.980825: gc patch: lib/str_decode �u�౵�� decode �� strlen < 256 */ 
  str_ncpy(hispaths, FROM, 255);
  str_decode(hispaths);
  str_ansi(myfrom, hispaths, 50);	/* 50 �O bbspost_write_post() �o�H�H�һݪ����� */
  FROM = myfrom;

  str_ncpy(hispaths, SUBJECT, 255);
  str_decode(hispaths);
  str_ansi(mysubject, hispaths, 70);	/* 70 �O bbspost_write_post() ���D�һݪ����� */
  SUBJECT = mysubject;

#ifdef _ANTI_SPAM_
  memset(&zart, 0, sizeof(zart));
  zart.zauthor = str_zcode(zart.author = myaddr, 256);
  zart.ztitle = str_zcode(zart.title = (char *) str_ttl(SUBJECT), 128);
  zart.zbody = str_zcode(BODY, 512);

  if (spam = spam_find(&zart))
  {
    time(&spam->uptime);
    if ((++spam->count > 6) || spam->cspam)
    {
      ++spam->cspam;
      return 0;
    }
  }
#endif

  firstpath[0] = *hispaths = '\0';
  hislen = 0;

  /* try to split newsgroups into separate group and check if any duplicated */

  splitptr = (char **) BNGsplit(GROUPS);

  while (ngptr = *splitptr++)
  {
    char *boardptr, *nboardptr;

    if (!*ngptr)
      continue;

    if (!(nf = (newsfeeds_t *) search_newsfeeds_bygroup(ngptr)))
      continue;

#ifdef	_ANTI_SPAM_
    if (spam)
    {
      if (spam->nf == nf)	/* �P�@�� newsgroup ���� post ==> �c�ʭ��j */
      {
	spam->count++;
	spam->cspam++;
	break;
      }
    }
    else
    {
      zart.count++;

      if (!zart.nf)
	zart.nf = nf;
    }
#endif

    if (!(boardptr = nf->board) || !*boardptr)
      continue;
    if (nf->path == NULL || !*nf->path)
      continue;

    /* itoc.030115.����: �䴩�@�� newsgroup ��J�h�ӪO */
    for (nboardptr = (char *) strchr(boardptr, ','); boardptr && *boardptr; nboardptr = (char *) strchr(boardptr, ','))
    {
      if (nboardptr)
      {
	*nboardptr = '\0';
      }
      if (*boardptr != '\t')
      {
	if (!hislen)		/* opus: �Ĥ@�ӪO�~�ݭn�B�z */
	{
	  char poolx[256];

	  str_ncpy(poolx, FROM, 255);
	  str_from(poolx, myaddr, mynick);

	  /* itoc.030218.����: �B�z�u�o�H���v�����ɶ� */
	  parse_date();
	  strcpy(xdate, (char *) Atime(&datevalue));
	  DATE = xdate;

	  /* itoc.030115.����: �B�z�u��H��:�v */
	  sprintf(xpath, "%s!%.*s", MYBBSID, sizeof(xpath) - strlen(MYBBSID) - 2, PATH);

	  /* itoc.030115.����: PATH �p�G�� .edu.tw �N�I�� */
	  for (pathptr = PATH = xpath; pathptr = strstr(pathptr, ".edu.tw");)
	    strcpy(pathptr, pathptr + 7);
	  xpath[71] = '\0';

	  if (*nf->charset == 'g')
	  {
	    gb2b5(BODY);
	    gb2b5(FROM);
	    gb2b5(SUBJECT);
	    gb2b5(SITE);
	  }
	}

	if (fname = (char *) bbspost_add(boardptr, myaddr, mynick, firstpath))
	{
	  register int flen;

	  sprintf(xpath, "%s/%s", boardptr, fname);
	  flen = strlen(fname = xpath);

	  if (flen + hislen < sizeof(hispaths) - 2)
	  {
	    if (hislen)
	    {
	      hispaths[hislen++] = ' ';
	    }

	    strcpy(hispaths + hislen, fname);
	    hislen += flen;
	  }
	}
	else
	{
	  bbslog(":Err: board %s\n", boardptr);
	  return 0;
	}
      }

      /* boardcont: */

      if (nboardptr)
      {
	*nboardptr = ',';
	boardptr = nboardptr + 1;
      }
      else
	break;

    }				/* for board1,board2,... */
  }

  if (hislen || Junkhistory)
  {
    if (HERwrite(MSGID, hispaths) < 0)
    {
      bbslog("store DB fail\n");
      /* I suspect here will introduce duplicated articles */
      /* return -1; */
    }
  }

#ifdef	_ANTI_SPAM_
  if (!spam)
  {
    spam_add(&zart);
  }
#endif

  return 0;
}


static inline int
is_loopback(path, token, len)
  char *path, *token;
  int len;
{
  int cc;

  for (;;)
  {
    cc = path[len];
    if ((!cc || cc == '!') && !memcmp(path, token, len))
      return 1;

    for (;;)
    {
      cc = *path;
      if (!cc)
	return 0;
      path++;
      if (cc == '!')
	break;
    }
  }
}


#ifdef _NoCeM_
extern int receive_nocem();
#endif


int
my_recv(client)
  ClientType *client;
{
  FILE *fout;
  int rel;
  char *ptr;

  fout = client->Argv.out;
  rel = 0;

  readlines(client);

  if (SUBJECT && FROM && SITE && DATE && PATH && GROUPS && MSGID && BODY)	/* ���ƪ����Y��� */
  {				/* �u�� POSTHOST �M CONTROL �i�H�O NULL */
    if (ptr = CONTROL)
    {
      if (!strncasecmp(ptr, "cancel ", 7))
      {
	/* itoc.030127: rel = 0 �٬O�~�򦬨�L�ʫH */
	/* rel = cancel_article(ptr + 7); */
	cancel_article(ptr + 7);
	rel = 0;
      }
    }
    else
    {
      /* itoc.030223.����: �ݨ� path �̭����ۤv�����W�٥H��A�H�N���|�i�ӡA
         �קK���W���H�Q bbslink �e�h news server �H��A�S�Q�ۤv�� bbsnnrp ���^ */
      
      ptr = PATH;
      if (ptr && is_loopback(ptr, MYBBSID, strlen(MYBBSID)))
      {
	/* bbslog(":Warn: Loop back article: %s\n", ptr); */
      }
      else
      {
	/* opus : anti-spam */
	int cc;

	ptr = GROUPS;
	for (;;)
	{
	  cc = *ptr++;
	  if (cc == 0)
	  {
#ifdef _NoCeM_
	    if (strstr(SUBJECT, "@@") && strstr(BODY, "NCM") && strstr(BODY, "PGP"))
	      rel = receive_nocem();
	    else
#endif
	      rel = receive_article();
	    break;
	  }
	  if (cc == ',')
	  {
	    if (++rel > 10)	/* �W�L 10 �� news groups */
	    {
	      rel = 0;
	      break;
	    }
	  }
	}
      }
    }

    if (rel == -1)
    {
      fprintf(fout, "400 server side failed\r\n");
      fflush(fout);
      fclose(fout);
      verboselog("Ihave Put: 400\n");
      clearfdset(client->fd);
      fclose(client->Argv.in);
      close(client->fd);
      client->fd = -1;
      client->mode = 0;
      client->ihavefail++;
      return -1;
    }
    else
    {
      fprintf(fout, "235\r\n");
    }
  }
  else						/* ���Y��줣���� */
  {
    fputs("437\r\n", fout);
    client->ihavefail++;
  }

  fflush(fout);

  return 0;
}
