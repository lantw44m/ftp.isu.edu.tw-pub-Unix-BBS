/*-------------------------------------------------------*/
/* innbbsconf.h	( NTHU CS MapleBBS Ver 3.10 )		 */
/*-------------------------------------------------------*/
/* target : innbbsd configurable settings		 */
/* create : 95/04/27					 */
/* modify :   /  /  					 */
/* author : skhuang@csie.nctu.edu.tw			 */
/*-------------------------------------------------------*/


#ifndef _INNBBSCONF_H_
#define _INNBBSCONF_H_

#include <stdio.h>
#include <syslog.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/un.h>
#include <sys/param.h>
#include <sys/wait.h>

#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/file.h>

#include "bbs.h"


/* ----------------------------------------------------- */
/* �@��պA						 */
/* ----------------------------------------------------- */

#define VERSION		"0.52-MapleBBS"		/* �����ŧi */

#define	LOCALDAEMON	"innd/.innbbsd"		/* InnBBSD �� */


/* ----------------------------------------------------- */
/* innbbsd ���]�w					 */
/* ----------------------------------------------------- */

  /* --------------------------------------------------- */
  /* channel ���]�w					 */
  /* --------------------------------------------------- */

#define MAXCLIENT 	3		/* Maximum number of connections accepted by innbbsd */

#define ChannelSize	4096
#define ReadSize	4096

  /* --------------------------------------------------- */
  /* rec_article ���]�w					 */
  /* --------------------------------------------------- */

#define	_NoCeM_				/* No See Them �׫H���� */
#undef	_ANTI_SPAM_			/* �d�I���� post */


/* ----------------------------------------------------- */
/* bbsnnrp ���]�w					 */
/* ----------------------------------------------------- */

#define MAX_ARTS	100		/* Maximum number of articles received for a newsgroup by bbsnnrp each time */


/* ----------------------------------------------------- */
/* connectsock ���]�w					 */
/* ----------------------------------------------------- */

#define DEFAULTPORT	"nntp"
#define DEFAULTPROTOCOL	"tcp"

#ifndef INADDR_NONE
#define INADDR_NONE	0xffffffff
#endif


/* ----------------------------------------------------- */
/* History ��H�O�����@					 */
/* ----------------------------------------------------- */

#define EXPIREDAYS	5		/* ��H�O���O�d�Ѽ� */
#define HIST_SIZE	100000		/* ��H�O���ɮפj�p */
#define HIS_MAINT_HOUR	4		/* time to maintain history database */
#define HIS_MAINT_MIN	30		/* time to maintain history database */


/* ----------------------------------------------------- */
/* �r�����						 */
/* ----------------------------------------------------- */

#define MAXBUFLEN	256		/* buffer length */
#define MAXFPATHLEN	128		/* file path length */


/* ----------------------------------------------------- */
/* machine dependent					 */
/* ----------------------------------------------------- */

#if defined(__linux)
# ifndef LINUX
#  define LINUX
# endif
#endif

#if !defined(__svr4__) || defined(sun)
#  define WITH_TM_GMTOFF  
#endif

#if defined(__svr4__) && defined(sun)
#  define SOLARIS
#endif

#ifdef SOLARIS
#  define NO_getdtablesize
#  define NO_bcopy
#  define NO_bzero
#endif

#if defined(HPUX)
#  define NO_getdtablesize
#endif

#ifdef NO_bcopy
# ifndef bcopy
#    define bcopy(a,b,c) memcpy(b,a,c)
# endif
#endif

#ifdef NO_bzero
# ifndef bzero
#   define bzero(mem, size) memset(mem,'\0',size)
# endif
#endif

#ifndef LOCK_EX
# define LOCK_EX	2	/* exclusive lock */
# define LOCK_UN	8	/* unlock */
#endif

#ifdef DEC_ALPHA
#  define ULONG unsigned int
#else
#  define ULONG unsigned long
#endif

#endif	/* _INNBBSCONF_H_ */
