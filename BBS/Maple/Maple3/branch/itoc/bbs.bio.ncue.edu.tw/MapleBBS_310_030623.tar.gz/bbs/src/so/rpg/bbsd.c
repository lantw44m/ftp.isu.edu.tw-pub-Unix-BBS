void
u_exit(mode)
  char *mode;
{
  ...
  ...

  /* �g�^ .ACCT */

  usr_fpath(fpath, cuser.userid, fn_acct);
  fd = open(fpath, O_RDWR);
  if (fd >= 0)
  {
    ...
    ...

    close(fd);
  }

#ifdef HAVE_RPG
  rpg_save(&crpg, cuser.userid);
#endif
}


static void
acct_apply()
{
  ...
  ...

  usr_fpath(buf, userid, fn_acct);
  fd = open(buf, O_WRONLY | O_CREAT, 0600);
  write(fd, &cuser, sizeof(cuser));
  close(fd);
  /* Thor.990416: �`�N: ���|�� .ACCT���׬O0��, �ӥB�u�� @�ؿ�, �����[� */

#ifdef HAVE_RPG
  rpg_apply(&crpg, userid);

  usr_fpath(buf, userid, FN_RPG);
  fd = open(buf, O_WRONLY | O_CREAT, 0600);
  write(fd, &crpg, sizeof(crpg));
  close(fd);
#endif

  sprintf(buf, "%d", try);
  blog("APPLY", buf);
}


static void
tn_login()
{
  ...
  ...

#ifdef HAVE_RPG
        rpg_load(&crpg, uid);
#endif

        level = cuser.userlevel;        

	ufo = cuser.ufo & ~(HAS_PERM(PERM_ALLADMIN) ?
          (UFO_BIFF | UFO_SOCKET) :
          (UFO_BIFF | UFO_SOCKET | UFO_CLOAK));

  ...                            
  ...
}

