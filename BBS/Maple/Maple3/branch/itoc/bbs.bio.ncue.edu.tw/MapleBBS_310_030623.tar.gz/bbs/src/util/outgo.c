/*-------------------------------------------------------*/
/* util/outgo.c        ( YZU CSE WindTop BBS )           */
/*-------------------------------------------------------*/
/* target : �۰ʰe�H�{��                                 */
/* create : 2000/06/22                                   */
/* update :                                              */
/*-------------------------------------------------------*/
/* syntax : outgo [board] [start] [end]                  */
/* NOTICE : �N�ݪO�峹���s�e�� news                      */
/*-------------------------------------------------------*/


#include "bbs.h"


static inline void
outgo_post(hdr, board)
  HDR *hdr;
  char *board;
{
  char *fpath, buf[256];

  fpath = "innd/out.bntp";

  /* itoc.030325: �קK�S�� nick �ɷ|�y���榡���~ */
  sprintf(buf, "%s\t%s\t%s\t%s\t%s\n",
    board, hdr->xname, hdr->owner, hdr->nick[0] ? hdr->nick : " ", hdr->title);
  f_cat(fpath, buf);
}


int
main(argc, argv)
  int argc;
  char *argv[];
{
  char fpath[128];
  int start, end, fd;
  char *board;
  HDR hdr;

  if (argc > 3)
  {
    chdir(BBSHOME);

    board = argv[1];
    start = atoi(argv[2]);
    end = atoi(argv[3]);
    brd_fpath(fpath, board, FN_DIR);
    if (fd = open(fpath, O_RDONLY))
    {
      lseek(fd, (off_t) ((start - 1) * sizeof(HDR)), SEEK_SET);
      while (read(fd, &hdr, sizeof(HDR)) == sizeof(HDR) && start <= end)
      {
        outgo_post(&hdr, board);
        start++;
      }
      close(fd);
    }
  }
  else
  {
    printf("usage: %s �ݪO �_�I ���I\n", argv[0]);
  }
  
  return 0;
}
