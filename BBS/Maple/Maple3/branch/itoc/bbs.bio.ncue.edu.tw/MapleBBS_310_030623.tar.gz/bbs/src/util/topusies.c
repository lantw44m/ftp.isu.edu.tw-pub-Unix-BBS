/*-------------------------------------------------------*/
/* util/topusr.c        ( NTHU CS MapleBBS Ver 3.00 )    */
/*-------------------------------------------------------*/
/* target : �Q�װϤQ�j�Ʀ�]                             */
/* create :   /  /                                       */
/* update :   /  /                                       */
/*-------------------------------------------------------*/
/* syntax : topusies                                     */
/*-------------------------------------------------------*/


#include <stdio.h>
#include <stdlib.h>


#include "bbs.h"


#define HASHSIZE        1024
#define TOPCOUNT        10
#undef  DEBUG


static
struct usiesrec
{
  char board[13];               /* board name */
  int number;                   /* post number */
  struct usiesrec *next;         /* next rec */
}      *bucket[HASHSIZE];
            

static
struct usiestop
{
  char board[13];               /* board name */
  int number;                   /* post number */
}       top[TOPCOUNT];


static int
hash(key)
  char *key;
{
  int i, ch, value = 0;

  for (i = 0; (ch = key[i]) && i < 80; i++)
  {
    value = (value << 5) - value + ch;
  }

  return value;
}


/* ---------------------------------- */
/* hash structure : array + link list */
/* ---------------------------------- */


static void
search(t)
  struct usiestop *t;
{
  struct usiesrec *p, *q, *s;
  int i, found = 0;

  i = hash(t->board) & (HASHSIZE - 1);
  q = NULL;
  p = bucket[i];
  while (p && (!found))
  {
    if (!strcmp(p->board, t->board))
      found = 1;
    else
    {
      q = p;
      p = p->next;
    }
  }
  if (found)
  {
    p->number += t->number;
  }
  else
  {
    s = (struct usiesrec *) malloc(sizeof(struct usiesrec));
    memcpy(s, t, sizeof(struct usiestop));
    s->next = NULL;
    if (q == NULL)
      bucket[i] = s;
    else
      q->next = s;
  }
}


static int
sort(pp, count)
  struct usiesrec *pp;
{
  int i, j;

  for (i = 0; i <= count; i++)
  {
    if (pp->number > top[i].number)
    {
      if (count < TOPCOUNT - 1)
	count++;
      for (j = count - 1; j >= i; j--)
	memcpy(&top[j + 1], &top[j], sizeof(struct usiestop));

      memcpy(&top[i], pp, sizeof(struct usiestop));
      break;
    }
  }
  return count;
}
          
          
int
main(void)
{
  int i, j;
  FILE *fp;
  struct usiesrec *pp;
  struct usiestop mytop;
  
  chdir(BBSHOME);
  if (fp = fopen(FN_RUN_BRDUSIES, "r"))
  {
    char buf[256], *ptr;
    
    while (fgets(buf, sizeof(buf), fp))
    {
      ptr = strtok(buf, " ");
      strcpy(mytop.board, ptr);
      mytop.number = 1;
      search(&mytop);
    }
    fclose(fp);
  }
  
  /* ---------------------------------------------- */
  /* sort top 100 issue and save results            */
  /* ---------------------------------------------- */

  memset(top, 0, sizeof(top));
  for (i = j = 0; i < HASHSIZE; i++)
  {
    for (pp = bucket[i]; pp; pp = pp->next)
    {

#ifdef	DEBUG
      printf("Board: %s\nBoardNo : %d\n"
	,pp->board
	,pp->number);
#endif
      j = sort(pp, j);
    }
  }

  if (fp = fopen("run/brd_usies.top", "w"))
  {
    fprintf(fp, "\t\t-----========== �����Q�װϤQ�j�Ʀ� ==========-----\n\n");
    for (i = 0; i <= j; i++)
      fprintf(fp, "�� %2d �W �ݪO : %-16s �s���H�� %3d\n", i+1, top[i].board, top[i].number);
    fclose(fp);
  }
}
