#ifndef _INNTOBBS_H_
#define _INNTOBBS_H_

/* inntobbs.c */
extern char *BODY;
extern char *SUBJECT, *FROM, *SITE, *DATE, *POSTHOST, *PATH, *GROUPS, *MSGID, *CONTROL;

#endif	/* _INNTOBBS_H_ */
