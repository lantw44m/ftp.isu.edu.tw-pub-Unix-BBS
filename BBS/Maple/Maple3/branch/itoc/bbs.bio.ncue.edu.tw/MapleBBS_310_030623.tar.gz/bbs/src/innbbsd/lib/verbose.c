/* ----------------------------------------------------- */
/* log function						 */
/* ----------------------------------------------------- */

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <varargs.h>


static int verboseFlag = 0;
static char verbosename[128];


void
verbosefile(filename)
  char *filename;
{
  verboseFlag = 1;
  strncpy(verbosename, filename, sizeof(verbosename));
}


void
setverboseon()
{
  verboseFlag = 1;
}


void
setverboseoff()
{
  verboseFlag = 0;
}


int
isverboselog()
{
  return verboseFlag;
}


void
verboselog(va_alist)	/* �� verboseFlag ���L ON �ӨM�w�n���n log�A�B�i�H���w logfile */
va_dcl
{
  va_list ap;
  register char *fmt;
  char datebuf[40];
  time_t now;
  FILE *fp;

  if (verboseFlag == 0)
    return;

  if (!(fp = fopen(verbosename, "a")))
    return;

  va_start(ap);

  time(&now);
  strftime(datebuf, sizeof(datebuf), "%b %d %X ", localtime(&now));
  fmt = va_arg(ap, char *);

  fprintf(fp, "%s[%d] ", datebuf, getpid());
  vfprintf(fp, fmt, ap);
  va_end(ap);

  fclose(fp);
}


#define LOGFILE		"innd/innbbs.log"

void
bbslog(va_alist)	/* �@�� log �b LOGFILE */
va_dcl
{
  va_list ap;
  register char *fmt;
  char datebuf[40];
  time_t now;
  FILE *fp;

  if (!(fp = fopen(LOGFILE, "a")))
    return;

  va_start(ap);

  time(&now);
  strftime(datebuf, sizeof(datebuf), "%b %d %X ", localtime(&now));
  fmt = va_arg(ap, char *);

  fprintf(fp, "%s ", datebuf);
  vfprintf(fp, fmt, ap);
  va_end(ap);

  fclose(fp);
}
