/*-------------------------------------------------------*/
/* util/transbmw.c                   			 */
/*-------------------------------------------------------*/
/* target : WD �� Maple 3.02 ���y�O���ഫ           	 */
/* create : 02/01/22                     		 */
/* update :   /  /                   			 */
/* author : itoc.bbs@bbs.ee.nctu.edu.tw          	 */
/*-------------------------------------------------------*/
/* syntax : transbmw                     		 */
/*-------------------------------------------------------*/


#if 0

   1. �ק� transbmw()

   ps. �ϥΫe�Х���ƥ��Ause on ur own risk. �{����H�Х]�[ :p
   ps. �P�� lkchu �� Maple 3.02 for FreeBSD

#endif

#define NO_RADIX

#include "wd.h"


/* ----------------------------------------------------- */
/* 3.02 functions                    			 */
/* ----------------------------------------------------- */


static void
_mail_self(userid, fpath, owner, title)		/* itoc.011115: �H�ɮ׵��ۤv */
  char *userid;		/* ����� */
  char *fpath;		/* �ɮ׸��| */
  char *owner;		/* �H��H */
  char *title;		/* �l����D */
{
  HDR fhdr;
  char folder[64];

  usr_fpath(folder, userid, FN_DIR);
  close(hdr_stamp(folder, HDR_LINK, &fhdr, fpath));
  strcpy(fhdr.owner, owner);
  strcpy(fhdr.title, title);
  fhdr.xmode = 0;
  rec_add(folder, &fhdr, sizeof(fhdr));
}


/* ----------------------------------------------------- */
/* �ഫ�D�{��                                            */
/* ----------------------------------------------------- */


static void
transbmw(userid)
  char *userid;
{
  ACCT acct;
  int fd;
  char buf[64];

  /* sob �� usr �ؿ������j�p�g�A�ҥH�n�����o�j�p�g */
  usr_fpath(buf, userid, FN_ACCT);
  if ((fd = open(buf, O_RDONLY)) >= 0)
  {
    read(fd, &acct, sizeof(ACCT));
    close(fd);
  }
  else
  {
    return;
  }

  sprintf(buf, OLD_BBSHOME"/home/%s/writelog", acct.userid);	/* �ª����y�O�� */

  if (dashf(buf))
    _mail_self(acct.userid, buf, "[�Ƨѿ�]", "���u\033[41m�O��\033[m");
}


int  
main(argc, argv)
  int argc;
  char *argv[];
{
  char c;
  char buf[64];
  struct dirent *de;
  DIR *dirp;

  /* argc == 1 ������ϥΪ� */
  /* argc == 2 ��Y�S�w�ϥΪ� */

  if (argc > 2)
  {
    printf("Usage: %s [target_user]\n", argv[0]);
    exit(-1);
  }

  chdir(BBSHOME);

  if (argc == 2)
  {
    transbmw(argv[1]);
    exit(1);
  }

  /* �ഫ�ϥΪ̤��y�O�� */
  for (c = 'a'; c <= 'z'; c++)
  {
    sprintf(buf, "usr/%c", c);

    if (!(dirp = opendir(buf)))
      continue;

    while (de = readdir(dirp))
    {
      char *str;

      str = de->d_name;
      if (*str <= ' ' || *str == '.')
	continue;

      transbmw(str);
    }

    closedir(dirp);    
  }
  return 0;
}
