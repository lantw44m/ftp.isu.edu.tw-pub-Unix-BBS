/*-------------------------------------------------------*/
/* util/transusr.c                                       */
/*-------------------------------------------------------*/
/* target : Magic �� Maple 3.02 �ϥΪ��ഫ               */
/* create : 02/09/09                                     */
/* update :   /  /                                       */
/* author : itoc.bbs@bbs.tnfsh.tn.edu.tw                 */
/*-------------------------------------------------------*/


#if 0

   0. �A�� Magic �� .ACCT �ΫH�c
   1. �]�w FN_PASSWDS �� OLD_MAILPATH

   ps. User on ur own risk.

#endif


#include "bbs.h"


#define FN_PASSWDS	"bak/passwds"
#define OLD_MAILPATH	"bak/mail"


/*-------------------------------------------------------*/
/* �ഫ.ACCT                                             */
/*-------------------------------------------------------*/


typedef struct
{
  char userid[14];
  time_t firstlogin;
  char termtype[16];
  unsigned int numlogins;
  unsigned int numposts;
  char flags[2];
  char passwd[14];
  char username[40];
  char ident[40];
  char lasthost[40];
  char realemail[40];
  unsigned userlevel;
  time_t lastlogin;
  time_t stay;
  char realname[40];
  char address[80];
  char email[80];
  int signature;
  unsigned int userdefine;
  int editor;
  unsigned int showfile;
  int magic;
  int addmagic;
  uschar bmonth;
  uschar bday;
  uschar byear;
  uschar sex;
  int money;
  int bank;
  int lent;

  int card;
  uschar mind;
  int unused1;
  usint unsign_0000;
  usint unsign_ffff;
}      userec;


static void
trans_acct()
{
  int num, count, fd;
  char *userid, buf[128];
  userec old;
  ACCT new;

  num = 0;
  count = 1;	/* userno �q 1 �_�� */

  while (!rec_get(FN_PASSWDS, &old, sizeof(userec), num))
  {
    num++;

    if (!isalpha(old.userid[0]))
      continue;

    new.userno = count;
    count++;

    str_ncpy(new.userid, old.userid, IDLEN + 1);
    str_ncpy(new.passwd, old.passwd, PASSLEN);
    str_ncpy(new.realname, old.realname, RNLEN + 1);
    str_ncpy(new.username, old.username, UNLEN + 1);

    new.userlevel = PERM_BASIC | PERM_CHAT | PERM_PAGE | PERM_POST | PERM_VALID;
    new.ufo = UFO_DEFAULT_NEW;

    new.signature = 0;
    new.year = old.byear;
    new.month = old.bmonth;
    new.day = old.bday;
    new.sex = 0;		/* default to female */

    new.money = old.money;
    new.gold = 0;

    new.numlogins = old.numlogins;
    new.numposts = old.numposts;
    new.numemails = 0;

    new.firstlogin = old.firstlogin;
    new.lastlogin = old.lastlogin;
    new.tcheck = time(&new.tvalid);

    str_ncpy(new.lasthost, old.lasthost, sizeof(new.lasthost));
    str_ncpy(new.email, old.email, sizeof(new.email));

    userid = new.userid;
    usr_fpath(buf, userid, NULL);
    mkdir(buf, 0700);
    strcat(buf, "/@");
    mkdir(buf, 0700);
    usr_fpath(buf, userid, "gem");	/* itoc.010727: �ӤH��ذ� */
    mak_links(buf);			/* itoc.010924: ��֭ӤH��ذϥؿ� */
#ifdef MY_FAVORITE
    usr_fpath(buf, userid, "MF");
    mkdir(buf, 0700);
#endif

    usr_fpath(buf, userid, FN_ACCT);
    fd = open(buf, O_WRONLY | O_CREAT, 0600);
    write(fd, &new, sizeof(ACCT));
    close(fd);
  }
}


/*-------------------------------------------------------*/
/* �ഫ�H�c                                              */
/*-------------------------------------------------------*/


typedef struct 		/* the DIR files */
{
  char filename[80];
  char owner[80];
  char title[80];
  unsigned level;
  unsigned char accessed[12];
}	fileheader;	 /* 256 bytes */


static time_t
trans_hdr_chrono(filename)
  char *filename;
{
  char time_str[11];

  if (filename[2] == '1')	/* M.1087654321.A */
  {
    strncpy(time_str, filename + 2, 10);
    time_str[10] = '\0';
  }
  else				/* M.987654321.A */
  {
    strncpy(time_str, filename + 2, 9);
    time_str[9] = '\0';
  }

  return (time_t) atoi(time_str);
}


static void
trans_owner(hdr, old)
  HDR *hdr;
  char *old;
{
  char *left, *right;
  char owner[128];

  str_ncpy(owner, old, sizeof(owner));

  if (strchr(owner, '.'))	/* innbbsd ==> bbs */
  {
    /* itoc.bbs@bbs.tnfsh.tn.edu.tw (�ڪ��ʺ�) */

    left = strchr(owner, '(');
    right = strrchr(owner, ')');

    if (!left || !right)
    {
      strcpy(hdr->owner, "�H�W");
    }
    else
    {
      *(left - 1) = '\0';
      str_ncpy(hdr->owner, owner, sizeof(hdr->owner));
      *right = '\0';
      str_ncpy(hdr->nick, left + 1, sizeof(hdr->nick));
    }
  }
  else if (left = strchr(owner, '('))	/* local post */
  {
    /* itoc (�ڪ��ʺ�) */

    *(left - 1) = '\0';
    str_ncpy(hdr->owner, owner, sizeof(hdr->owner));
    if (right = strchr(owner, ')'))
    {
      *right = '\0';
      str_ncpy(hdr->nick, left + 1, sizeof(hdr->nick));
    }
  }
  else
  {
    /* itoc */

    str_ncpy(hdr->owner, owner, sizeof(hdr->owner));
  }
}


static void
trans_mail(userid)
  char *userid;
{
  int num;
  char ch;
  char index[80], folder[80], buf[80], fpath[80], cmd[256];
  fileheader fh;
  HDR hdr;

  ch = userid[0];
  if (ch >= 'a' && ch <= 'z')	/* ���j�g */
    ch -= 32;

  sprintf(index, "%s/%c/%s/.DIR", OLD_MAILPATH, ch, userid);	/* �ª� header */
  usr_fpath(folder, userid, FN_DIR);				/* �s�� header */

  num = 0;
  while (!rec_get(index, &fh, sizeof(fh), num))
  {
    sprintf(buf, "%s/%c/%s/%s", OLD_MAILPATH, ch, userid, fh.filename);

    if (dashf(buf))		/* �峹�ɮצb�~���ഫ */
    {
      time_t chrono;
      char new_name[10] = "@";

      /* �ഫ�峹 .DIR */

      memset(&hdr, 0, sizeof(HDR));
      chrono = trans_hdr_chrono(fh.filename);
      new_name[1] = radix32[chrono & 31];
      archiv32(chrono, new_name + 1);

      hdr.chrono = chrono;
      strcpy(hdr.xname, new_name);
      trans_owner(&hdr, fh.owner);
      str_ncpy(hdr.title, fh.title, sizeof(hdr.title));
      str_stamp(hdr.date, &hdr.chrono);
      hdr.xmode = MAIL_READ;
      if (fh.accessed[0] & 0x8)	/* FILE_MARDKED */
	hdr.xmode |= POST_MARKED;

      rec_add(folder, &hdr, sizeof(HDR));

      /* �����ɮ� */

      usr_fpath(fpath, userid, "@/");
      strcat(fpath, new_name);
      sprintf(cmd, "cp %s %s", buf, fpath);

      system(cmd);
    }

    num++;
  }
}

int
main()
{
  char c, *userid;
  char buf[64];

  chdir(BBSHOME);

  /* ���� .ACCT�A�إؿ� */
  trans_acct();

  /* �Ѧ��Ī��ϥΪ� ID ���ഫ�H�c */
  for (c = 'a'; c <= 'z'; c++)
  {
    struct dirent *de;
    DIR *dirp;

    sprintf(buf, "usr/%c", c);

    if (!(dirp = opendir(buf)))
      continue;

    while (de = readdir(dirp))
    {
      userid = de->d_name;
      if (*userid <= ' ' || *userid == '.')
	continue;

      trans_mail(userid);
    }

    closedir(dirp);
  }

  return 0;
}


