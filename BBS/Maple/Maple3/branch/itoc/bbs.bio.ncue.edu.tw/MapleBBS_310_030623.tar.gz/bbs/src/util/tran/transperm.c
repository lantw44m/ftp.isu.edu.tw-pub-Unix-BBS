/*-------------------------------------------------------*/
/* transperm.c       ( NTHU CS MapleBBS Ver 3.00 )       */
/*-------------------------------------------------------*/
/* target : M3 -> M3 change user perm and ufo            */
/* create : 00/03/20                                     */
/* update :   /  /                                       */
/*-------------------------------------------------------*/
/* syntax : transperm                                    */
/*-------------------------------------------------------*/


#include "bbs.h"

int
main()
{
  FILE *fp;
  char *str, buf[128], fpath[128];
  int fd;
  ACCT acct;

  if (fp = fopen("/tmp/new", "r"))		/* �u�� /tmp/new ���ҰO�����H */
  {
    while (fgets(buf, sizeof(buf), fp))
    {
      fprintf(stderr, buf);

      str = strchr(buf + 1, ' ');
      *str = '\0';

      usr_fpath(fpath, buf + 1, FN_ACCT);
      fd = open(fpath, O_RDWR);

      if (fd >= 0)
      {
	if (read(fd, &acct, sizeof(ACCT)) == sizeof(ACCT))
	{
	  if (acct.userlevel & PERM_VALID)
	    acct.userlevel = PERM_DEFAULT | PERM_VALID;
	  else
	    acct.userlevel = PERM_DEFAULT;
	  acct.ufo = UFO_DEFAULT_NEW;
	  lseek(fd, (off_t) 0, SEEK_SET);
	  write(fd, &acct, sizeof(ACCT));
	}
	close(fd);
      }
    }
    fclose(fp);
  }

  return 0;
}
