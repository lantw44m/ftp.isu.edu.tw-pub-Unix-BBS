/*-------------------------------------------------------*/
/* nocem.c	( NTHU CS MapleBBS Ver 3.10 )		 */
/*-------------------------------------------------------*/
/* target : NoCeM-INNBBSD				 */
/* create : 99/02/25					 */
/* update :   /  /  					 */
/* author : leeym@cae.ce.ntu.edu.tw			 */
/*-------------------------------------------------------*/


#if 0	/* itoc.030109.����: nocem.c ���y�{ */
  �q rec_article.c ���� receive_nocem() �H��
  receive_nocem() �� NCMparse() �� notice parse �X�� �� NCMverify() ���ҬO���O�u��
  �� NCMcancel() �A�e�^ rec_article.c �� cancel_article() �B�z
#endif
                          

#include "innbbsconf.h"

#ifdef _NoCeM_

#include "bbslib.h"
#include "inntobbs.h"
#include "nocem.h"

#ifdef SOLARIS
#include <stdarg.h>          /* for va_start() problem */
#else
#include <varargs.h>
#endif


#undef	PGP5		/* �����˦� pgp5 �~�i define�A�ý��ˬd pgpv �����| */


static int ncmdebug = 0;

static int num_spammid = 0;
static char NCMVER[8];
static char ISSUER[STRLEN];
static char TYPE[8];
static char ACTION[8];
static char NCMID[STRLEN];
static char COUNT[8];
static char THRESHOLD[STRLEN];
static char SPAMMID_NOW[STRLEN];
static char SPAMMID[MAXSPAMMID][STRLEN];
static char errmsg[1024] = "nothing";


/* ----------------------------------------------------- */
/* NCM maintain						 */
/* ----------------------------------------------------- */


ncmperm_t *
search_issuer(issuer, type)
  char *issuer;
  char *type;		/* �Y type == NULL ���ܥu��� issuer */
{
  ncmperm_t *find;
  int i;
  for (i = 0; i < NCMCOUNT; i++)
  {
    find = &NCMPERM[i];
    if (strstr(issuer, find->issuer) && 
      (!type || !strcmp(find->type, "*") || !strcasecmp(find->type, type)))
      return find;
  }
  return NULL;
}


static void
NCMupdate(issuer, type)
  char *issuer, *type;
{
  FILE *fp;
  char buff[LINELEN];

  if ((fp = fopen("innd/ncmperm.bbs", "a")) == NULL)
  {
    fprintf(stderr, "attach fail %s", buff);
    return;
  }
  fprintf(fp, "%s\t%s\tno\n", issuer, type);
  fflush(fp);
  fclose(fp);
  bbslog("NCMupdate add Issuer: %s , Type: %s\n", ISSUER, TYPE);
  sleep(1);
  if (readNCMfile() != 0)
    bbslog("fail to readNCMfile\n");
}


/* ----------------------------------------------------- */
/* PGP verify						 */
/* ----------------------------------------------------- */


#ifdef  PGP5
static int
run_pgp(cmd, in, out)
  char *cmd;
  FILE **in, **out;
{
  int pin[2], pout[2], child_pid;
  char PGPPATH[80];

  sprintf(PGPPATH, "%s/.pgp", BBSHOME);
  setenv("PGPPATH", PGPPATH, 1);

  *in = *out = NULL;

  pipe(pin);
  pipe(pout);

  if (!(child_pid = fork()))
  {
    /* We're the child. */
    close(pin[1]);
    dup2(pin[0], 0);
    close(pin[0]);

    close(pout[0]);
    dup2(pout[1], 1);
    close(pout[1]);

    execl("/bin/sh", "sh", "-c", cmd, NULL);
    _exit(127);
  }
  /* Only get here if we're the parent. */
  close(pout[1]);
  *out = fdopen(pout[0], "r");

  close(pin[0]);
  *in = fdopen(pin[1], "w");

  return (child_pid);
}


static int
verify_buffer(buf, passphrase)
  char *buf, *passphrase;
{
  FILE *pgpin, *pgpout;
  char tmpbuf[1024] = " ";
  int ans = NOPGP;

  setenv("PGPPASSFD", "0", 1);
  run_pgp("/usr/local/bin/pgpv -f +batchmode=1 +OutputInformationFD=1", &pgpin, &pgpout);
  if (pgpin && pgpout)
  {
    fprintf(pgpin, "%s\n", passphrase);	/* Send the passphrase in, first */
    bzero(passphrase, strlen(passphrase));	/* Burn the passphrase */
    fprintf(pgpin, "%s", buf);
    fclose(pgpin);

    *buf = '\0';
    fgets(tmpbuf, sizeof(tmpbuf), pgpout);
    while (!feof(pgpout))
    {
      strcat(buf, tmpbuf);
      fgets(tmpbuf, sizeof(tmpbuf), pgpout);
    }

    wait(NULL);

    fclose(pgpout);
  }

  if (strstr(buf, "BAD signature made"))
  {
    strcpy(errmsg, "BAD signature");
    ans = PGPBAD;
  }
  else if (strstr(buf, "Good signature made"))
  {
    strcpy(errmsg, "Good signature");
    ans = PGPGOOD;
  }
  else if (strcpy(tmpbuf, strstr(buf, "Signature by unknown keyid:")))
  {
    sprintf(errmsg, "%s ", strtok(tmpbuf, "\r\n"));
    /* strcpy(KEYID, strrchr(tmpbuf, ' ') + 1); */
    ans = PGPUN;
  }

  unsetenv("PGPPASSFD");
  return ans;
}


static int	/* return 0 success, otherwise fail */
NCMverify()
{
  int ans;
  char passphrase[80] = "Haha, I am Leeym..";
  ans = verify_buffer(BODY, passphrase);
  return ans;
}
#endif


/* ----------------------------------------------------- */
/* parse NoCeM Notice Headers/Body			 */
/* ----------------------------------------------------- */


static int
readNCMheader(line)
  char *line;
{
  if (!strncasecmp(line, "Version", strlen("Version")))
  {
    strcpy(NCMVER, line + strlen("Version") + 2);
    if (!strstr(NCMVER, "0.9"))
    {
      sprintf(errmsg, "unknown version: %s", NCMVER);
      return P_FAIL;
    }
  }
  else if (!strncasecmp(line, "Issuer", strlen("Issuer")))
  {
    strcpy(ISSUER, line + strlen("Issuer") + 2);
    FROM = ISSUER;
  }
  else if (!strncasecmp(line, "Type", strlen("Type")))
  {
    strcpy(TYPE, line + strlen("Type") + 2);
  }
  else if (!strncasecmp(line, "Action", strlen("Action")))
  {
    strcpy(ACTION, line + strlen("Action") + 2);
    if (!strstr(ACTION, "hide"))
    {
      sprintf(errmsg, "unsupported action: %s", ACTION);
      return P_FAIL;
    }
  }
  else if (!strncasecmp(line, "Notice-ID", strlen("Notice-ID")))
  {
    strcpy(NCMID, line + strlen("Notice-ID") + 2);
  }
  else if (!strncasecmp(line, "Count", strlen("Count")))
  {
    strcpy(COUNT, line + strlen("Count") + 2);
  }
  else if (!strncasecmp(line, "Threshold", strlen("Threshold")))
  {
    strcpy(THRESHOLD, line + strlen("Threshold") + 2);
  }

  return P_OKAY;
}


static int
readNCMbody(char *line)
{
  char buf[LINELEN], *group;
  strcpy(buf, line);

  if (!strstr(buf, "\t"))
    return P_FAIL;

  group = strrchr(line, '\t') + 1;

  if (buf[0] == '<' && strstr(buf, ">"))
  {
    strtok(buf, "\t");
    strcpy(SPAMMID_NOW, buf);
  }

  if (num_spammid && !strcmp(SPAMMID[num_spammid - 1], SPAMMID_NOW))
    return 0;

  if (search_newsfeeds_bygroup(group))
    strcpy(SPAMMID[num_spammid++], SPAMMID_NOW);
}


static int	/* return 0 success, otherwise fail */
NCMparse()
{
  char *fptr, *ptr;
  int type = TEXT;

  if (!(fptr = strstr(BODY, "-----BEGIN PGP SIGNED MESSAGE-----")))
  {
    strcpy(errmsg, "notice isn't signed");
    return P_FAIL;
  }

  for (ptr = strchr(fptr, '\n'); ptr != NULL && *ptr != '\0'; fptr = ptr + 1, ptr = strchr(fptr, '\n'))
  {
    int ch = *ptr;
    int ch2 = *(ptr - 1);

    *ptr = '\0';
    if (*(ptr - 1) == '\r')
      *(ptr - 1) = '\0';

    if (num_spammid > MAXSPAMMID)
      return P_OKAY;

    if (ncmdebug >= 2)
      bbslog("NCMparse: %s\n", fptr);

    if (!strncmp(fptr, "@@", 2))
    {
      if (strstr(fptr, "BEGIN NCM HEADERS"))
	type = NCMHDR;
      else if (strstr(fptr, "BEGIN NCM BODY"))
      {
	if (NCMVER && ISSUER && TYPE && ACTION && COUNT && NCMID)
	{
	  ncmperm_t *ncmt;
	  ncmt = (ncmperm_t *) search_issuer(ISSUER, TYPE);
	  if (ncmt == NULL)
	  {
	    NCMupdate(ISSUER, TYPE);
	    sprintf(errmsg, "unknown issuer: %s, %s", ISSUER, MSGID);
	    return P_UNKNOWN;
	  }
	  if (!ncmt->perm)
	  {
	    sprintf(errmsg, "disallow issuer: %s, %s", ISSUER, MSGID);
	    return P_DISALLOW;
	  }
	}
	else
	{
	  strcpy(errmsg, "HEADERS syntax not correct");
	  return P_FAIL;
	}
	type = NCMBDY;
      }
      else if (strstr(fptr, "END NCM BODY"))
      {
        *ptr = ch;
        *(ptr - 1) = ch2;
        break;
      }
      else
      {
	strcpy(errmsg, "NCM Notice syntax not correct");
	return P_FAIL;
      }
      *ptr = ch;
      *(ptr - 1) = ch2;
      continue;
    }

    if (type == NCMHDR && readNCMheader(fptr) == P_FAIL)
      return P_FAIL;
    else if (type == NCMBDY)
      readNCMbody(fptr);
    *ptr = ch;
    *(ptr - 1) = ch2;
  }
  if (NCMVER && ISSUER && TYPE && ACTION && COUNT && NCMID)
    return P_OKAY;
  else
  {
    strcpy(errmsg, "HEADERS syntax not correct");
    return P_FAIL;
  }

  strcpy(errmsg, "I don't know..");
  return P_FAIL;
}


extern int cancel_article();

static void
NCMcancel()
{
  int i, rel, num_ok, num_fail;

  for (i = rel = num_ok = num_fail = 0; i < num_spammid; i++)
  {
    rel = cancel_article(SPAMMID[i]);
    if (rel)
      num_fail++;
    else
      num_ok++;
  }
  bbslog("NCMcancel %s %s, count:%d spam:%d, ok:%d fail:%d\n",
    ISSUER, MSGID, atoi(COUNT), num_spammid, num_ok, num_fail);
}


/* ----------------------------------------------------- */
/* NoCeM-innbbsd					 */
/* ----------------------------------------------------- */


static void
initial_nocem()
{
  bzero(SPAMMID[0], strlen(SPAMMID[0]) * num_spammid);
  num_spammid = 0;
  bzero(SPAMMID_NOW, strlen(SPAMMID_NOW));
}


int			/* 0:success  -1:fail */
receive_nocem()
{
  int cc;

  if (ncmdebug)
    bbslog("NCM: receive %s\n", MSGID);

  initial_nocem();

  cc = NCMparse();

  if (cc != P_OKAY)
  {
    if (cc != P_DISALLOW)
      bbslog("NCMparse %s\n", errmsg);
    return 0;
  }

  if (!num_spammid)
  {
    bbslog("NCMparse: nothing to cancel\n");
    return 0;
  }
#ifdef  PGP5
  if (ncmdebug)
    bbslog("NCM: verifying PGP sign\n");

  cc = NCMverify();

  if (cc != PGPGOOD)
  {
    bbslog("NCMverify %s, %s, %s\n", errmsg, MSGID, ISSUER);
    return -1;
  }
#endif

  if (ncmdebug)
    bbslog("NCM: canceling spam in NCM Notice\n");
  NCMcancel();

  return 0;
}
#endif	/* _NoCeM_ */
