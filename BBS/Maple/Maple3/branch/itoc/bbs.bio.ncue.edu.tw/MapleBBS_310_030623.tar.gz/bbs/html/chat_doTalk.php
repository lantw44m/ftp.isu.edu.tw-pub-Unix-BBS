<?php
require_once("config.php");
require_once("webbbs.class.php");

session_start();
$pid = $cuser[pid];

if(!$message) $message="/z";

$message = stripslashes($message);

$ws = new server_class;
$ws->connect();

$cmd = $ws->set_cmd("say_chat", G_TALK, $pid, $message);
$ws->query($cmd);
$ws->close();
exit;
?>
