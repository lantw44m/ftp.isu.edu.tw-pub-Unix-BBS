#ifndef _DBZ_H_
#define _DBZ_H_

/* for dbm ans dbz */

typedef struct 
{
  char *dptr;
  int dsize;
} datum;


/* dbz.c */
extern int dbminit();
extern int dbmclose();
extern int dbzfresh();
extern datum dbzfetch();
extern int dbzstore();
extern int dbzsync();
extern long dbzsize();
extern int dbzincore();

/* his.c */
extern void CloseOnExec();

#endif	/* _DBZ_H_ */
