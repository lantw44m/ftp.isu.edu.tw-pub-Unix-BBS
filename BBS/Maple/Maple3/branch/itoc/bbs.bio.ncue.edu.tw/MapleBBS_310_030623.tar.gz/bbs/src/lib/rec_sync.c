#include "dao.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>


int
rec_sync(fpath, size, fsync)
  char *fpath;
  int size;
  int (*fsync) ();
{
  int fd, fsize;
  struct stat st;

  if ((fd = open(fpath, O_RDWR, 0600)) < 0)
    return -1;

  if (!fstat(fd, &st) && (fsize = st.st_size) > 0)
  {
    void *base;

    base = (void *) malloc(fsize);
    fsize = read(fd, base, fsize);

    if (fsize >= size)
    {
      xsort(base, fsize / size, size, fsync);
      lseek(fd, 0, SEEK_SET);
      write(fd, base, fsize);
      ftruncate(fd, fsize);
    }
    free(base);
  }
  close(fd);

  if (fsize <= 0)
    unlink(fpath);

  return 0;
}
