/*-------------------------------------------------------*/
/* util/brdmail.c	( NTHU CS MapleBBS Ver 3.00 )	 */
/*-------------------------------------------------------*/
/* target : �� Internet �H�H�� BBS �����ݪO�A���� post	 */
/* create : 95/03/29					 */
/* update : 97/03/29					 */
/*-------------------------------------------------------*/


#include "bbs.h"

#include <sysexits.h>

#undef	ANTI_HTMLMAIL		/* itoc.021014: �� html_mail */

static void
mailog(msg)
  char *msg;
{
  FILE *fp;

  if (fp = fopen(BMTA_LOGFILE, "a"))
  {
    time_t now;
    struct tm *p;

    time(&now);
    p = localtime(&now);
    fprintf(fp, "%02d/%02d %02d:%02d:%02d <brdmail> %s\n",
      p->tm_mon + 1, p->tm_mday,
      p->tm_hour, p->tm_min, p->tm_sec,
      msg);
    fclose(fp);
  }
}


/* ----------------------------------------------------- */
/* brd�G�h .BRD �䯸�W�O�_���o�ӬݪO			 */
/* ----------------------------------------------------- */


static int			/* 1: ���F�o�ӪO�A�B�O�W�b brdname */
getbrdname(brdname, arg)
  char *brdname;
  char *arg;
{
  int fd, rc;
  BRD brd;

  rc = 0;
  if ((fd = open(FN_BRD, O_RDONLY)) >= 0)
  {
    while(read(fd, &brd, sizeof(BRD)) == sizeof(BRD))
    {
      if (!strcasecmp(brd.brdname, arg))
      {
	/* �ˬd�ݪO�v��: �n�O���}�ݪO�~�i�g�J */
	if ((brd.readlevel | brd.postlevel) < (PERM_VALID << 1)) /* (BASIC + ... + VALID) < (VALID << 1) */
	{
	  strcpy(brdname, brd.brdname);
	  rc = 1;
	}
	break;
      }
    }
    close(fd);
  }

  return rc;
}


/* ----------------------------------------------------- */
/* �D�{��						 */
/* ----------------------------------------------------- */


static int
mail2brd(brdname)
  char *brdname;
{
  HDR mhdr;
  char buf[512], title[256], sender[256], fpath[64], *str, *ptr, *family;
  int fd, fx;
  time_t chrono;
  FILE *fp;
  struct stat st;

  /* check if the brdname is in our bbs now */

  brd_fpath(fpath, brdname, FN_DIR);
  fx = open(fpath, O_WRONLY | O_CREAT | O_APPEND, 0600);
  if ((fx < 0) || fstat(fx, &st))
  {
    sprintf(buf, "BBS brd <%s> not existed", brdname);
    mailog(buf);
    puts(buf);
    return EX_NOUSER;
  }

#ifdef	DEBUG
  printf("dir: %s\n", fpath);
#endif

  /* allocate a file for the new mail */

  family = strchr(fpath, '.');
  ptr = family + 1;
  *ptr++ = '/';
  *ptr++ = 'A';
  time(&chrono);

  for (;;)
  {
    *family = radix32[chrono & 31];
    archiv32(chrono, ptr);
    fd = open(fpath, O_WRONLY | O_CREAT | O_EXCL, 0600);
    if (fd >= 0)
      break;

    if (errno != EEXIST)
    {
      close(fx);
      sprintf(buf, "ERR create board <%s> file", brdname);
      mailog(buf);
      return EX_NOUSER;
    }

    chrono++;
  }

  /* copy the stdin to the specified file */

  if (!(fp = fdopen(fd, "w")))
  {
    printf("Cannot open file <%s>\n", fpath);
    close(fx);
    close(fd);
    return -1;
  }

#ifdef	DEBUG
  printf("file: %s\n", fpath);
#endif

  memset(&mhdr, 0, sizeof(HDR));
  mhdr.chrono = chrono;
  mhdr.xmode = POST_INCOME;
  strcpy(mhdr.xname, ptr - 1);
  str_stamp(mhdr.date, &mhdr.chrono);

  /* parse header */

  title[0] = sender[0] = '\0';

  while (fgets(buf, sizeof(buf), stdin) && buf[0])
  {
    buf[511] = 0;	/* chunhan.020427: �j�� crop, �קK SIGSEGV */

    if (!memcmp(buf, "From", 4))
    {
      if ((str = strchr(buf, '<')) && (ptr = strrchr(str, '>')))
      {
	if (str[-1] == ' ')
	  str[-1] = '\0';

	if (strchr(++str, '@'))
	  *ptr = '\0';
	else					/* �� local host �H�H */
	  strcpy(ptr, "@" MYHOSTNAME);

	ptr = (char *) strchr(buf, ' ');
	while (*++ptr == ' ');
	if (*ptr == '"')
	{
	  char *right;

	  if (right = strrchr(++ptr, '"'))
	    *right = '\0';

	  str_decode(ptr);
	  sprintf(sender, "%s (%s)", str, ptr);
	  strcpy(mhdr.nick, ptr);
	  strcpy(mhdr.owner, str);
	}
	else
	{ /* Thor.980907: �S�� finger name, �S�O�B�z */
	  strcpy(sender, str);
	  strcpy(mhdr.owner, str);
	}
      }
      else
      {
	strtok(buf, " \t\n\r");
	strcpy(sender, (char *) strtok(NULL, " \t\n\r"));

	if (strchr(sender, '@') == NULL)	/* �� local host �H�H */
	  strcat(sender, "@" MYHOSTNAME);
	strcpy(mhdr.owner, sender);
      }
      continue;
    }

    if (!memcmp(buf, "Subject: ", 9))
    {
      str_ansi(title, buf + 9, sizeof(title));
      str_decode(title);
      continue;
    }

#ifdef ANTI_HTMLMAIL

    /* �@�� BBS �ϥΪ̳q�`�u�H��r�l��άO�q��L BBS ���H�峹��ۤv���H�c
       �Ӽs�i�H��q�`�O html �榡�άO�̭������a��L�ɮ�
       �Q�ζl�����Y�� Content-Type: ���ݩʧⰣ�F text/plain (��r�l��) ���H�󳣾פU�� */

    if (!memcmp(buf, "Content-Type: ", 14))
    {
      char *content = buf + 14;
      if (*content != '\0' && memcmp(content, "text/plain", 10))
      {
	sprintf(buf, "ANTI-HTML [%d] %s => %s\t%s", getppid(), sender, userid, fpath);
	mailog(buf);
 	fclose(fp);
 	unlink(fpath);
 	close(fx);
	return EX_NOUSER;
      }

      continue;
    }
#endif

    if (buf[0] == '\n')
      break;
  }

  if (!title[0])
    sprintf(title, "�Ӧ� %.64s", sender);

  fprintf(fp, "�@��: %s\n���D: %s\n�ɶ�: %s\n",
    sender, title, ctime(&mhdr.chrono));

  while (fgets(buf, sizeof(buf), stdin) && buf[0])
    fputs(buf, fp);

  fclose(fp);

  /* sprintf(buf, "%s => %s", sender, brdname); */
  /* Thor.0827: �[�W parent process id ���ɦW, �H�K��U���H */
  sprintf(buf, "[%d] %s => %s\t%s", getppid(), sender, brdname, fpath); 

  mailog(buf);

  /* append the record to the MAIL control file */

  title[TTLEN] = '\0';
  strcpy(mhdr.title, title);
  write(fx, &mhdr, sizeof(HDR));
  close(fx);

  return 0;
}


static void
sig_catch(sig)
  int sig;
{
  char buf[512];

  while (fgets(buf, sizeof(buf), stdin) && buf[0]);
  sprintf(buf, "signal [%d]", sig);
  mailog(buf);
  exit(0);
}


int
main(argc, argv)
  int argc;
  char *argv[];
{
  char buf[512];

  /* argv[1] is brdname in bbs */

  if (argc < 2)
  {
    printf("Usage:\t%s <bbs_brdname>\n", argv[0]);
    exit(-1);
  }

  setgid(BBSGID);
  setuid(BBSUID);
  chdir(BBSHOME);

  signal(SIGBUS, sig_catch);
  signal(SIGSEGV, sig_catch);
  signal(SIGPIPE, sig_catch);

  getbrdname(buf, argv[1]);

  if (mail2brd(buf))
  {
    /* eat mail queue */
    while (fgets(buf, sizeof(buf), stdin) && buf[0])
      ;
  }
  exit(0);
}
