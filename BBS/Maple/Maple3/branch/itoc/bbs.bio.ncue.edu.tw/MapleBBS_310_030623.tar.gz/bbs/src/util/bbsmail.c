/*-------------------------------------------------------*/
/* util/bbsmail.c	( NTHU CS MapleBBS Ver 3.00 )	 */
/*-------------------------------------------------------*/
/* target : �� Internet �H�H�� BBS �����ϥΪ�		 */
/* create : 95/03/29					 */
/* update : 97/03/29					 */
/*-------------------------------------------------------*/


#include "bbs.h"

#include <sysexits.h>

#define	ANTI_HTMLMAIL		/* itoc.021014: �� html_mail */
#define	ANTI_NOTMYCHARSETMAIL	/* itoc.030513: �� not-mycharset mail */


static void
mailog(msg)
  char *msg;
{
  FILE *fp;

  if (fp = fopen(BMTA_LOGFILE, "a"))
  {
    time_t now;
    struct tm *p;

    time(&now);
    p = localtime(&now);
    fprintf(fp, "%02d/%02d %02d:%02d:%02d <bbsmail> %s\n",
      p->tm_mon + 1, p->tm_mday,
      p->tm_hour, p->tm_min, p->tm_sec,
      msg);
    fclose(fp);
  }
}


/* ----------------------------------------------------- */
/* user�Gshm �������P cache.c �ۮe			 */
/* ----------------------------------------------------- */


static UCACHE *ushm;


static inline void
init_ushm()
{
  ushm = shm_new(UTMPSHM_KEY, sizeof(UCACHE));
}


static inline void
bbs_biff(userid)
  char *userid;
{
  UTMP *utmp, *uceil;
  usint offset;

  offset = ushm->offset;
  if (offset > (MAXACTIVE - 1) * sizeof(UTMP))	/* Thor.980805: ���Mcall���� */
    offset = (MAXACTIVE - 1) * sizeof(UTMP);

  utmp = ushm->uslot;
  uceil = (void *) utmp + offset;

  do
  {
    if (!strcasecmp(utmp->userid, userid))
      utmp->ufo |= UFO_BIFF;
  } while (++utmp <= uceil);
}


/* ----------------------------------------------------- */
/* �D�{��						 */
/* ----------------------------------------------------- */


#ifdef ANTI_NOTMYCHARSETMAIL
static int
is_notmycharset(str)
  char *str;
{
  int i;
  char *ptr, delim;
  char charset[32];

  /* �S���w charset �N�� not-mycharset */
  if (!(ptr = (char *) strstr(str, "charset=")))
    return 1;

  ptr += 8;
  delim = '\0';
  i = 0;

  for (; *ptr && *ptr != delim && !isspace(*ptr); ptr++)
  {
    if (*ptr == '\"')
    {
      delim = *ptr;
      continue;
    }

    charset[i] = *ptr;
    if (++i >= sizeof(charset))
      break;
  }
  charset[i] = '\0';

  if (!strcasecmp(charset, MYCHARSET) || !strcasecmp(charset, "iso-8859-1"))
    return 0;
  return 1;
}
#endif


static int
mail2bbs(userid)
  char *userid;
{
  HDR mhdr;
  char buf[512], title[256], sender[256], fpath[64], *str, *ptr;
  int fd, fx;
  time_t chrono;
  FILE *fp;
  struct stat st;

  /* check if the userid is in our bbs now */

  usr_fpath(fpath, userid, FN_DIR);
  fx = open(fpath, O_WRONLY | O_CREAT | O_APPEND, 0600);
  if ((fx < 0) || fstat(fx, &st))
  {
    sprintf(buf, "BBS user <%s> not existed", userid);
    mailog(buf);
    puts(buf);
    return EX_NOUSER;
  }

  if (st.st_size > MAX_BBSMAIL * sizeof(HDR))
  {
    close(fx);
    sprintf(buf, "BBS user <%s> over-spammed", userid);
    mailog(buf);
    puts(buf);
    return EX_NOUSER;
  }

#ifdef	DEBUG
  printf("dir: %s\n", fpath);
#endif

  /* allocate a file for the new mail */

  ptr = strchr(fpath, '.');
  *ptr++ = '@';
  *ptr++ = '/';
  *ptr++ = '@';
  time(&chrono);

  for (;;)
  {
    archiv32(chrono, ptr);
    fd = open(fpath, O_WRONLY | O_CREAT | O_EXCL, 0600);
    if (fd >= 0)
      break;

    if (errno != EEXIST)
    {
      close(fx);
      sprintf(buf, "ERR create user <%s> file", userid);
      mailog(buf);
      return EX_NOUSER;
    }

    chrono++;
  }

  /* copy the stdin to the specified file */

  if (!(fp = fdopen(fd, "w")))
  {
    printf("Cannot open file <%s>\n", fpath);
    close(fx);
    close(fd);
    return -1;
  }

#ifdef	DEBUG
  printf("file: %s\n", fpath);
#endif

  memset(&mhdr, 0, sizeof(HDR));
  mhdr.chrono = chrono;
  mhdr.xmode = MAIL_INCOME;
  strcpy(mhdr.xname, ptr - 1);
  str_stamp(mhdr.date, &mhdr.chrono);

  /* parse header */

  title[0] = sender[0] = '\0';

  while (fgets(buf, sizeof(buf), stdin) && buf[0])
  {
    buf[511] = 0;	/* chunhan.020427: �j�� crop, �קK SIGSEGV */

    if (!memcmp(buf, "From", 4))
    {
      if ((str = strchr(buf, '<')) && (ptr = strrchr(str, '>')))
      {
	if (str[-1] == ' ')
	  str[-1] = '\0';

	if (strchr(++str, '@'))
	  *ptr = '\0';
	else					/* �� local host �H�H */
	  strcpy(ptr, "@" MYHOSTNAME);

	ptr = (char *) strchr(buf, ' ');
	while (*++ptr == ' ');
	if (*ptr == '"')
	{
	  char *right;

	  if (right = strrchr(++ptr, '"'))
	    *right = '\0';

	  str_decode(ptr);
	  sprintf(sender, "%s (%s)", str, ptr);
	  strcpy(mhdr.nick, ptr);
	  strcpy(mhdr.owner, str);
	}
	else
	{ /* Thor.980907: �S�� finger name, �S�O�B�z */
	  strcpy(sender, str);
	  strcpy(mhdr.owner, str);
	}
      }
      else
      {
	strtok(buf, " \t\n\r");
	strcpy(sender, (char *) strtok(NULL, " \t\n\r"));

	if (strchr(sender, '@') == NULL)	/* �� local host �H�H */
	  strcat(sender, "@" MYHOSTNAME);
	strcpy(mhdr.owner, sender);
      }
      continue;
    }

    if (!memcmp(buf, "Subject: ", 9))
    {
      str_ansi(title, buf + 9, sizeof(title));
      str_decode(title);
      continue;
    }

    if (!memcmp(buf, "Content-Type: ", 14))
    {
#ifdef ANTI_HTMLMAIL

    /* �@�� BBS �ϥΪ̳q�`�u�H��r�l��άO�q��L BBS ���H�峹��ۤv���H�c
       �Ӽs�i�H��q�`�O html �榡�άO�̭������a��L�ɮ�
       �Q�ζl�����Y�� Content-Type: ���ݩʧⰣ�F text/plain (��r�l��) ���H�󳣾פU�� */

      char *content = buf + 14;
      if (*content != '\0' && memcmp(content, "text/plain", 10))
      {
	sprintf(buf, "ANTI-HTML [%d] %s => %s\t%s", getppid(), sender, userid, fpath);
	mailog(buf);
 	fclose(fp);
 	unlink(fpath);
 	close(fx);
	return EX_NOUSER;
      }
#endif

#ifdef ANTI_NOTMYCHARSETMAIL
      if (is_notmycharset(buf + 14))
      {
	sprintf(buf, "ANTI-NONMYCHARSET [%d] %s => %s\t%s", getppid(), sender, userid, fpath);
	mailog(buf);
	fclose(fp);
	unlink(fpath);
	close(fx);
	return EX_NOUSER;
      }
#endif

      continue;
    }

    if (buf[0] == '\n')
      break;
  }

  if (!title[0])
    sprintf(title, "�Ӧ� %.64s", sender);

  fprintf(fp, "�@��: %s\n���D: %s\n�ɶ�: %s\n",
    sender, title, ctime(&mhdr.chrono));

  while (fgets(buf, sizeof(buf), stdin) && buf[0])
    fputs(buf, fp);

  fclose(fp);

  /* sprintf(buf, "%s => %s", sender, userid); */
  /* Thor.980827: �[�W parent process id ���ɦW, �H�K��U���H */
  sprintf(buf, "[%d] %s => %s\t%s", getppid(), sender, userid, fpath); 

  mailog(buf);

  /* append the record to the MAIL control file */

  title[TTLEN] = '\0';
  strcpy(mhdr.title, title);
  write(fx, &mhdr, sizeof(HDR));
  close(fx);

  bbs_biff(userid);	/* itoc.021113: �q�� user ���s�H�� */

  return 0;
}


static void
sig_catch(sig)
  int sig;
{
  char buf[512];

  while (fgets(buf, sizeof(buf), stdin) && buf[0]);
  sprintf(buf, "signal [%d]", sig);
  mailog(buf);
  exit(0);
}


int
main(argc, argv)
  int argc;
  char *argv[];
{
  char buf[512];

  /* argv[1] is userid in bbs */

  if (argc < 2)
  {
    printf("Usage:\t%s <bbs_userid>\n", argv[0]);
    exit(-1);
  }

  setgid(BBSGID);
  setuid(BBSUID);
  chdir(BBSHOME);

  signal(SIGBUS, sig_catch);
  signal(SIGSEGV, sig_catch);
  signal(SIGPIPE, sig_catch);

  init_ushm();

  str_lower(buf, argv[1]);	/* �� userid �����p�g */

  if (mail2bbs(buf))
  {
    /* eat mail queue */
    while (fgets(buf, sizeof(buf), stdin) && buf[0])
      ;
  }
  exit(0);
}
