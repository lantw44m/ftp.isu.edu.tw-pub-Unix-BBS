<?php
//Read Mail List

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
$level = $cuser[level];
if(!$pid || !($level & PERM_BASIC)) {
	echo "<html>�Х��n��! <a href='main.php'> [������^] </a></html>";
	exit; 
}

if(!$page) $page = 0;

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
 
<html>
<head>
<title>ReadMailList</title>
<meta http-equiv="Content-Type" content="text/html;charset=big5">
<link rel="stylesheet" type="text/css" href="style.css">
<script language="JavaScript">
<!--
function goto(page){
	var pid = "<?echo $pid;?>";
	var check = "<?echo $page;?>";
	if(check != page)
	document.location = "maillist.php?page="+page;
}

function clr_biff(){
	top.bottomFrame.new_mail(0);
}
//-->
</script>
</head>
<body bgcolor="#ffffff" leftmargin="3" topmargin="0" marginwidth="3" marginheight="0" onload="clr_biff()">
<table width="635" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="80"><img src="images/mail_top.gif" width="474" height="80" usemap="#Map" border="0"></td>
  </tr>
  <tr>
    <td valign="top" align="right">
	
	<?php
	//maillist
	require_once('webbbs.class.php');
	require_once('ansi2web.inc.php');
	
	$ws = new server_class;
	$ws->connect();

	$cmd = $ws->set_cmd("m_list", G_MAIL, $pid, $page);
	$ws->query($cmd);

	$list = split("\n", $ws->data); /* ���ӪŮ�@�j�} */
	$ret = $ws->parse($list[0]);
	if($ret[result] != 'OK') {
		echo "<br><br>";
		echo alertMsg($ws->data);
		echo "<br><br><a href='main.php'>[������^]</a>";
		exit;
	}
	
	$totalpage = intval($ret[max]/XO_TALL);  /* 20�OXo_TALL���� */
	if($ret[max] % XO_TALL) $totalpage ++;
	
	$page = intval($ret[page]);
	if($page > $totalpage) $page = $totalpage;
	
	$gotoString = "�����<select onchange='goto(this.options[this.selectedIndex].value)' style='font-size: 9pt; height: 16'>";
	
	for($i=1; $i<=$totalpage; $i++) {
		$gotoString .= "<option value='$i'";
		if($i == $page) $gotoString .= " selected";
		$gotoString .= ">".$i."</option>\n";
	}
	
	$gotoString .= " </select>��";
	
	if($page > 1) {
		$prev = $page-1;
		$gotoString .= " <a href=\"$PHP_SELF?page=$prev\">�W�@��</a>";
	}

	if($totalpage - $page > 0) {
		$next = $page+1;
		$gotoString .= " <a href=\"$PHP_SELF?page=$next\">�U�@��</a>";
	}

	//start to show
	print "<table width='100%' border='0' cellspacing='0' cellpadding='0' align='right'>\n";
	print "
		<tr bgcolor='#dddddd'> <td colspan=6>
		<table border=0 cellspacing=1 cellpadding=1 bgcolor=#ffffff width=100% height=18>
		<tr bgcolor='#dddddd'>
		<td> �����H��: $ret[max] �� </td>
		<td> $gotoString </td>
		</tr>
		</table>
        </td></tr>
		";
		
	print "
		<tr height=20>
		<td>�Ǹ�</td>
		<td></td>
		<td>�ɶ�</td>
		<td>�@��</td>
		<td>�H����D</td>
	    <td>�\��ﶵ</td>
		</tr>
		";
		
	for($i=1; $i<= XO_TALL; $i++) {
	//for($i=XO_TALL; $i>0; $i--) {
		if($i%2)
			$bgcolor = "#efefef";
		else
			$bgcolor = "#fefefe";
		
		$tmp = $ws->parse($list[$i]);
		
		if($tmp[num] <= 0) 
			break;
		
		$tmp[attr] = ansi2web($tmp[attr]);
		
		$token = ord(strtoupper($tmp[author][0]));
		if($token < 65 || $token > 90) $tmp[noreply] = 1;
		
		if(!$tmp[noreply]) {  
			$otherstr = "<a href='mail_reply.php?num=$tmp[num]' title='�^��'><img src='images/reply.gif' border='0'></a>";
		} else {
			$otherstr = "<img src='images/reply1.gif' title='����^��' border='0'>";
		}
		
		$otherstr .= "
			<a href='mail_mark.php?num=$tmp[num]' title='�аO'><img src='images/mark.gif' border='0'></a>
			<a href='mail_delete.php?num=$tmp[num]' title='�R��'><img src='images/del.gif' border='0'></a>
			";
		
		if(!$tmp[title]) {
			$tmp[title] = "�S�D�D";
		}
		
		if($tmp[attr] == '+') {
			$tmp[attr] = "<font color='red'>+</font>";
		}

		print "
		   <tr bgcolor=$bgcolor>
			<td> $tmp[num] </td>
			<td> $tmp[attr] </td>
			<td> $tmp[date] </td>
			<td> $tmp[author] </td>
			<td> $tmp[type] <a href=\"mail_read.php?num=".$tmp[num]."\">$tmp[title]</a> </td>
			<td> $otherstr </td>
		   </tr>
			";
	}
	
	print "
		<tr bgcolor='#dddddd'> <td colspan=6>
		<table border=0 cellspacing=1 cellpadding=1 bgcolor=#ffffff width=100% height=18>
		<tr bgcolor='#dddddd'>
		<td> �����H��: $ret[max] �� </td>
		<td> $gotoString </td>
		</tr>
		</table>
        </td></tr>
		";

	echo "</table>\n";

	?>	
	</td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="93,62,172,77" href="maillist.php" alt="�\Ū�l��" title="�\Ū�l��">
  <area shape="rect" coords="179,62,256,77" href="sendmail.php" alt="�g�ʶl��" title="�g�ʶl��">
  <area shape="rect" coords="266,62,369,77" href="mail_internet.php" alt="�H�H��Internet" title="�H�H��Internet">
  <area shape="rect" coords="378,63,467,77" href="mail_sysop.php" alt="�g�H������" title="�g�H������">
  <area shape="rect" coords="467,73,469,80" href="#">
</map>
</body>
</html>
