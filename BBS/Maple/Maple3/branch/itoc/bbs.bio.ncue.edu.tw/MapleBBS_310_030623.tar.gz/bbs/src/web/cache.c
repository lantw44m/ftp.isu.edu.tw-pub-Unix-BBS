/*-------------------------------------------------------*/
/* cache.c	( NTHU CS MapleBBS Ver 3.10 )		 */
/*-------------------------------------------------------*/
/* target : cache up data by shared memory		 */
/* create : 95/03/29				 	 */
/* update : 02/11/05				 	 */
/*-------------------------------------------------------*/


#include "web.h"
#include <sys/ipc.h>
#include <sys/shm.h>

#ifdef	HAVE_SEM
#include <sys/sem.h>
#endif


#ifdef	HAVE_SEM

static void
attach_err(shmkey, name)
  int shmkey;
  char *name;
{
  char buf[80];

  sprintf(buf, "key = %x", shmkey);
  blog(name, buf);
  exit(1);
}


/* ----------------------------------------------------- */
/* semaphore : for critical section			 */
/* ----------------------------------------------------- */


static int ap_semid;


void
sem_init()
{
  int semid;

  union semun
  {
    int val;
    struct semid_ds *buf;
    ushort *array;
  }     arg =
  {
    1
  };

  semid = semget(BSEM_KEY, 1, 0);
  if (semid == -1)
  {
    semid = semget(BSEM_KEY, 1, IPC_CREAT | BSEM_FLG);
    if (semid == -1)
      attach_err(BSEM_KEY, "semget");
    semctl(semid, 0, SETVAL, arg);
  }
  ap_semid = semid;
}


void
sem_lock(op)
  int op;			/* op is BSEM_ENTER or BSEM_LEAVE */
{
  struct sembuf sops;

  sops.sem_num = 0;
  sops.sem_flg = SEM_UNDO;
  sops.sem_op = op;
  semop(ap_semid, &sops, 1);
}
#endif				/* HAVE_SEM */


/*-------------------------------------------------------*/
/* .UTMP cache						 */
/*-------------------------------------------------------*/


UCACHE *ushm;


void
ushm_init()
{
  UCACHE *xshm;

  ushm = xshm = shm_new(UTMPSHM_KEY, sizeof(UCACHE));

}


#ifndef	_BBTP_
int
utmp_new(up)
  UTMP *up;
{
  UCACHE *xshm;
  UTMP *uentp, *utail;

  /* --------------------------------------------------- */
  /* semaphore : critical section			 */
  /* --------------------------------------------------- */

#ifdef	HAVE_SEM
  sem_lock(BSEM_ENTER);
#endif

  xshm = ushm;
  uentp = xshm->uslot;
  utail = uentp + MAXACTIVE;

  do
  {
    if (!uentp->pid && !uentp->userno)
    {
      usint offset;

      offset = (void *)uentp - (void *)xshm->uslot;
      memcpy(uentp, up, sizeof(UTMP));
      xshm->count++;
      if (xshm->offset < offset)
	xshm->offset = offset;
      cutmp = uentp;

#ifdef	HAVE_SEM
      sem_lock(BSEM_LEAVE);
#endif

      return 1;
    }
  } while (++uentp < utail);

#ifdef	HAVE_SEM
  sem_lock(BSEM_LEAVE);
#endif

  return 0;
}


void
utmp_free()
{
  UTMP *uentp;

  uentp = cutmp;
  if (!uentp || !uentp->pid)
    return;

#ifdef	HAVE_SEM
  sem_lock(BSEM_ENTER);
#endif

  memset(uentp, 0, sizeof(UTMP));
  ushm->count--;

#ifdef	HAVE_SEM
  sem_lock(BSEM_LEAVE);
#endif
}


UTMP *
utmp_find(userno)
  int userno;
{
  UTMP *uentp, *uceil;

  uentp = ushm->uslot;
  uceil = (void *)uentp + ushm->offset;
  do
  {
    if (uentp->userno == userno)
      return uentp;
  } while (++uentp <= uceil);

  return NULL;
}


UTMP *
utmp_locate(pid)
  pid_t pid;
{
  UTMP *uentp, *uceil;

  uentp = ushm->uslot;
  uceil = (void *)uentp + ushm->offset;
  do
  {
    if (uentp->pid == pid)
      return uentp;
  } while (++uentp <= uceil);

  return NULL;
}


int
utmp_num()		/* ��u�W���X�ӤH */
{
  UTMP *uentp, *uceil;
  int cnt = 0;

  uentp = ushm->uslot;
  uceil = (void *)uentp + ushm->offset;
  do
  {
    if (uentp->mode == M_WEB)
      cnt++;
  } while (++uentp <= uceil);

  return cnt;
}


/*-------------------------------------------------------*/
/* .BRD cache						 */
/*-------------------------------------------------------*/


BCACHE *bshm;


void
bshm_init()
{
  BCACHE *xshm;
  time_t *uptime;
  int n, turn;

  turn = 0;
  xshm = bshm;
  if (xshm == NULL)
  {
    bshm = xshm = shm_new(BRDSHM_KEY, sizeof(BCACHE));
  }

  uptime = &(xshm->uptime);

  for (;;)
  {
    n = *uptime;
    if (n > 0)
      return;

    if (n < 0)
    {
      if (++turn < 30)
      {
	sleep(2);
	continue;
      }
    }

    *uptime = -1;

    if ((n = open(FN_BRD, O_RDONLY)) >= 0)
    {
      xshm->number =
	read(n, xshm->bcache, MAXBOARD * sizeof(BRD)) / sizeof(BRD);
      close(n);
    }

    /* ���Ҧ� boards ��Ƨ�s��A�]�w uptime */

    time(uptime);
    blog("CACHE", "reload bcache");
    return;
  }
}


int
brd_bno(bname)
  char *bname;
{
  BRD *brdp, *bend;
  int bno;

  brdp = bshm->bcache;
  bend = brdp + bshm->number;
  bno = 0;

  do
  {
    if (!str_cmp(bname, brdp->brdname))
      return bno;

    bno++;
  } while (++brdp < bend);

  return -1;
}


/*-------------------------------------------------------*/
/* etc/movie cache					 */
/*-------------------------------------------------------*/


static FCACHE *fshm;

void
fshm_init()
{
  if (fshm == NULL)
    fshm = shm_new(FILMSHM_KEY, sizeof(FCACHE));
}


static inline void
outs(str)
  uschar *str;
{
  int cc, len;
  char buf[FILM_SIZ];
#ifdef SHOW_USER_IN_TEXT
  uschar *t_name, *t_nick, *t_logins, *t_posts;
  uschar numlogins[5], numposts[5];

  sprintf(numlogins, "%d", cuser.numlogins);
  sprintf(numposts, "%d", cuser.numposts);
  t_name = cuser.userid;
  t_nick = cuser.username;
  t_logins = numlogins;
  t_posts = numposts;
#endif

  len = 0;

  while (cc = *str)
  {
    str++;

#ifdef SHOW_USER_IN_TEXT
    switch (cc)
    {
    case 1:
      if (cc = *t_name)
	t_name++;
      else
	cc = ' ';
      break;

    case 2:
      if (cc = *t_nick)
	t_nick++;
      else
	cc = ' ';
      break;

    case 3:
      if (cc = *t_logins)
	t_logins++;
      else
	cc = ' ';
      break;

    case 4:
      if (cc = *t_posts)
	t_posts++;
      else
	cc = ' ';
      break;
    }
#endif
    buf[len++] = cc;
  }
  buf[len] = '\0';
  www_cache_write(buf, len);
}


int
film_out(tag)
  int tag;			/* -1 : help */
{
  int fmax, len, *shot;
  char *film, buf[FILM_SIZ];

  len = 0;
  shot = fshm->shot;
  film = fshm->film;

  while (!(fmax = *shot))	/* util/camera.c ���b���� */
  {
    sleep(5);
    if (++len > 10)
      return FILM_MOVIE;
  }

  if (tag >= FILM_MOVIE)	/* random select */
  {
    tag += (time(0) & 7);	/* 7 steps forward */
    if (tag >= fmax)
      tag = FILM_MOVIE;
  }				/* Thor.980804: �i��O�G�N���a? �Ĥ@�i random
				 * select�e�K�Ө䤤�@�� */

  if (tag)
  {
    len = shot[tag];
    film += len;
    len = shot[++tag] - len;
  }
  else
  {
    len = shot[1];
  }

  if (len >= FILM_SIZ - 10)
    return tag;

  memcpy(buf, film, len);
  buf[len] = '\0';
  outs(buf);

  return tag;
}
#endif				/* _BBTP_ */
