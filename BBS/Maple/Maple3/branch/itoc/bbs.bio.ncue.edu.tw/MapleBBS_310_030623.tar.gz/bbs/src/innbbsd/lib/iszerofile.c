#include <sys/types.h>
#include <sys/stat.h>
     
int
iszerofile(filename)
  char *filename;
{
  struct stat st;

  if (stat(filename, &st))
    return 0;
  if (st.st_size == 0)
    return 1;
  return 0;
}
