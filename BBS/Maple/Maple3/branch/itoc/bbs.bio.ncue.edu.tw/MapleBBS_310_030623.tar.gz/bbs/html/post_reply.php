<?php
//Post Read
require_once('config.php');

unset($cuser);
session_start();

if(!isset($board)) $board = BN_DEFAULT;

$pid = $cuser[pid];
if(!$pid) {
	echo "<html>�z�w�g�_�}�s��! �Ы�F5��s����!</html>";
	exit; 
}

$level = $cuser[level];
if(!($level & PERM_POST) && $board != BN_DEFAULT) {
	echo "<html>�z�S���v���o���峹! <a href='postlist.php?board=$board'> [������^] </a></html>";
	exit; 
}

if(!isset($num)) $num = 1;

$page = intval($num / XO_TALL);	/* �D�Xpage */
if($num % XO_TALL) $page++;

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
 
<html>
<head>
<title>Post Reply</title>
<meta http-equiv="Content-Type" content="text/html;charset=big5">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #0000a0}
A:visited {color: #0000a0}
PRE {color: #c0c0c0}
</style>
<script language="javascript">
<!--
 function do_go() {
	 var num = document.go.num.value;
	 var page = num / 20;

	 if(num % 20) page++;
	 document.go.page.value = page;
}
//-->
</script>
</head>
<body leftmargin="3" topmargin="0" marginwidth="3" marginheight="0" bgcolor="#FFFFFF">
<table width="617" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="3"><img src="images/brd/brd_top.jpg" width="618" height="54" usemap="#Map" border="0"></td>
  </tr>
  <tr> 
    <td width="20" background="images/brd/brd_left_bg.jpg">&nbsp;</td>
    <td height="100%" width="585">
		<?php

			require_once('webbbs.class.php');

			$ws = new server_class;
			$ws->connect();

			$cmd = $ws->set_cmd("p_reply", G_BOARD, $pid, $board, $num);
			$ws->query($cmd);

			$data = split("\n\n", $ws->data, 2);
	
			$ret = $ws->parse($data[0]);

			if($ret[result] != 'OK') {
				echo "<br><br>";
				echo alertMsg($ws->data);
				echo "<br><br><a href='postlist.php?board=$board&page=$page'>[������^]</a>";
				exit;
			}
	
			/* �]�mGoTo Page */
			$gotoString  = "�^�Ф峹�G �� <font color=000000>".$num."</font> �g  | �ݪO ".$board;
			$gotoString .= " | <a href=\"postlist.php?board=".$board."&page=".$page."&num=".$num."\">��^�C��</a>";
	
			if(!eregi("^Re: ", $ret[title])) {
				$title = "Re: ".$ret[title];
			} else {
				$title = $ret[title];
			}

			//start to show

			print "<table width='95%' align='center' bgcolor='f0f0f0' border='1' bordercolor='efefef'>\n";
			
			print "
				<tr><td><font color='00a000'>
				<b>�T���F��</b>: (1) �קK��|�B�����B������峹�C(2) �קK�@�Z�h��B�L����ڡC(3) �קK�b�����Q�װϰQ�רp�H�ưȡC<br>
				<b>�T�ӫ�ĳ</b>: (1) �б`�� Announce �s����ذϡC (2) �оA�פޥΤ峹�C(3) �п�ܾA�����Q�װϵo���峹�C</font><br>
				</td></tr>
				<tr bgcolor='#dddddd' height='20'><td>
				$gotoString
		        </td></tr>
				";

			print "
				<form action='post_add.php' method=POST>
				 <tr><td>
					�峹���D: <input type=text name=title value='".$title."' size=40 maxlength=60> �Q�װ�: [<a href='postlist.php?board=$board'>$board</a>]
				 </td></tr>
				 <tr><td>
					�@��: <u>$cuser[userid]</u>
					�ϥ�ñ�W�� <input type=radio name=sign value=1 checked>1 <input type=radio name=sign value=2>2
							  <input type=radio name=sign value=3>3 <input type=radio name=sign value=0>0 
					<a href='personal.php?action=sign' target='_blank'>�d��ñ�W��</a>
				";
			if(intval($anony) == 1)
				print "�n�ΦW��?<input type=checkbox value=1 name=anony checked>";

			print "
				</td></tr>
				<tr><td><textarea name=content wrap=hard cols=73 rows=20>".$data[1]."</textarea></td></tr>
				<tr><td align=center>
				<input type=hidden name=board value='$board'>
				<input type=submit name=submit value=' �o �e '>
				<input type=button onclick='top.window.history.go(-1)' value=' �� �^ '>
				</td></tr></form>
				";
			print "
				<tr bgcolor='#dddddd' height='20'><td>
				$gotoString
		        </td></tr>
				</table>
				";	
		?>
	</td>
    <td background="images/brd/brd_right_bg.jpg" width="20">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="3" height="2"><img src="images/brd/brd_bottom.jpg" width="618" height="25"></td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="47,18,117,38" href="services.php" alt="�����A�Ȱ�" title="�����A�Ȱ�">
  <area shape="rect" coords="258,20,327,39" href="gem.php" alt="��ؤ��G��" title="��ؤ��G��">
  <area shape="rect" coords="336,20,408,40" href="personal.php" alt="�ӤH�u��{" title="�ӤH�u��{">
  <area shape="rect" coords="416,20,488,40" href="talk.php" alt="�𶢲�Ѧa" title="�𶢲�Ѧa">
  <area shape="rect" coords="497,19,567,39" href="group.php" alt="�ڪ��s�հ�" title="�ڪ��s�հ�">
</map>
</body>
</html>
