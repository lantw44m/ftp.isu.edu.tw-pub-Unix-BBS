/*-------------------------------------------------------*/
/* util/fix_uno.c	( NTHU CS MapleBBS Ver 3.00 )    */
/*-------------------------------------------------------*/
/* target : �ק� .ACCT �� user no.   	                 */
/* create :   /  /                                       */
/* update :   /  /                                       */
/* author : ernie@bbs.ee.nthu.edu.tw                     */
/*-------------------------------------------------------*/
/* syntax : fix_uno userid                               */
/*-------------------------------------------------------*/


#include "bbs.h"


int
main(argc, argv)
  int argc;
  char *argv[];
{
  int fd, new_uno;
  char path[80];
  ACCT my;

  if (argc != 2)
  {
    printf("usage: %s <userid>\n", argv[0]);
    return -1;
  }

  chdir(BBSHOME);

  sprintf(path, "usr/%c/%s/", *argv[1], argv[1]);
  str_lower(path, path);
  strcat(path, FN_ACCT);
  printf("%s\n", path);
  fd = open(path, O_RDWR);
  if (fd > 0)
  {
    read(fd, &my, sizeof(my));
    printf("uno: %d\nid: %s\n", my.userno, my.userid);
    printf("input new uno: ");
    scanf("%d", &new_uno);
    my.userno = new_uno;
    lseek(fd, 0, SEEK_SET);
    write(fd, &my, sizeof(my));
    close(fd);
  }
}
