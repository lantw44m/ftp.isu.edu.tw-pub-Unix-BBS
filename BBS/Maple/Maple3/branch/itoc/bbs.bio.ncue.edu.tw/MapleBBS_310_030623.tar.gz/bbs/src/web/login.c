/*-------------------------------------------------------*/
/* login.c	( NTHU CS MapleBBS Ver 3.10 )		 */
/*-------------------------------------------------------*/
/* target : Login Porgram for WebBBS			 */
/* author : hightman.bbs@bbs.dot66.net			 */
/* create : 01/09/20                                     */
/* update : 02/11/05                                     */
/*-------------------------------------------------------*/


#include "web.h"

extern UCACHE *ushm;
extern u_long tn_addr;


static void
login_abort(msg)
  char *msg;
{
  www_printf(msg);
  blog("LOGIN", currtitle);
  exit(0);
}


static void
vt_utmp_setup(mode)
  int mode;
{
  UTMP utmp;

  memset(&utmp, 0, sizeof(utmp));
  utmp.pid = currpid;
  utmp.userno = cuser.userno;
  utmp.mode = bbsmode = M_WEB;		/* �b WebBBS �W���� mode */
  utmp.ufo = cuser.ufo;
  utmp.in_addr = tn_addr;

#ifdef DETAIL_IDLETIME	/* �Y #define DETAIL_IDLETIME�A�h idle_time �W�����ɶ�(��) */
  utmp.idle_time = ap_start;
#else			/* �Y #undef DETAIL_IDLETIME�A�h idle_time ���ܤw�g���m�F�h�[(��) */
  utmp.idle_time = 0;
#endif

  strcpy(utmp.userid, cuser.userid);
  strcpy(utmp.username, cuser.username);
  str_ncpy(utmp.from, fromhost, sizeof(utmp.from));

  if (!utmp_new(&utmp))
  {
    login_abort("<html>�z���諸��l�w�g�Q�H�������n�F�A�ФU���A��</html>\n");
  }
}


static int
vt_login()	/* �����n�� */
{
  char *ptr, *host;
  u_long in_addr;
 
  ptr = myWRC.query;
  host = nextword(&ptr);
  if (*host)
    sprintf(fromhost, "!%s", host);
 
  in_addr = atol(nextword(&ptr));
  if (in_addr)
    tn_addr = in_addr;
 
  currpid = getpid();

  /* �򥻿�X */
  www_printf("<html><head><!--base href='%s' --><title>%s</title>"
    "<meta http-equiv='Content-Type' content='text/html; charset=%s'></head>\n", 
    BASEURL, BBSNAME, BBSCHARSET);
 
  www_printf("<script language='JavaScript'><!--hide var pid = %d;"
    "function bmw_send(uno, msg)"
    "{"
      "if(msg == '' || msg == null) return false;"
      "document.sendmsg.uno.value = uno;"
      "document.sendmsg.msg.value= msg;"
      "document.sendmsg.submit();"
      "return true;"
    "}\n",
    currpid);
  
  www_printf(""
    "function bmw_rqst(uno, msg)"
    "{"
      "top.bmwFrame.addOne(uno, msg);"
      "var prom = msg+'\\n�^�_: (���^�_���^�Y�i)';"
      "var xx=prompt(prom,'');"
      "if(xx=='' || xx==null) return false;"
      "return bmw_send(uno, xx);"
    "}"
    "//--></script><body>\n");
  
  www_printf("<form name='sendmsg' target='hideFrame' action='sendmsg.php'>"
    "<input type='hidden' name='pid' value='%d'>"
    "<input type='hidden' name='uno'>"
    "<input type='hidden' name='msg'>"
    "</form>\n", currpid);
 
  acct_load(&cuser, STR_GUEST);		/* �@�}�l���H guest �n�J */
 
  /* �W���᪺�B�z */
  cuser.lastlogin = ap_start;
  str_ncpy(cuser.lasthost, fromhost, sizeof(cuser.lasthost));
  acct_save(&cuser, ACCTSAV_HOST | ACCTSAV_LOGIN);
 
  vt_utmp_setup(M_LOGIN);
  bbstate = STAT_STARTED;

  www_printf("<script>top.activeFrame.pid=%d;</script>\n", currpid);
  sleep(2);
  www_printf("<script>if(top.bottomFrame.update_online) top.bottomFrame.update_online('%d', '%d');</script>\n", 
    ushm->count, utmp_num());
  www_printf("<!--LOGIN-END-->\n");

  while(1)
  {
    if (cutmp->ufo & UFO_BIFF)
    {
      cutmp->ufo ^= UFO_BIFF;
      www_printf("<script>top.bottomFrame.new_mail(1);</script>\n");
    }

    /* �C 30 ���ˬd�G
       1) �O�_�w�_�u�A�Y�w�_�u�N abort_bbs
       2) �O�_���s�H�A�Y���s�H�N�q��       */

    sleep(30);

    if (www_printf("<script>top.bottomFrame.update_online('%d', '%d');</script>\n", ushm->count, utmp_num()) <= 0)
      abort_bbs();
  }
 
  return 1;
}


static int
chg_usr()			/* �����h�X�εn���A����userid */
{
  char *ptr, *userid, *passwd;
  pid_t pid, opid;
  char fpath[80];
  WebReqCmd wrc;
  usint level;

  ptr = myWRC.query;

  pid = atoi(nextword(&ptr));
  cutmp = utmp_locate(pid);

  if (!cutmp)
    msg_quit(err_uid);

  userid = nextword(&ptr);

  if (!str_cmp(userid, cutmp->userid))
  {
    sprintf(fpath, "�z���ӴN�O%s��!", userid);
    msg_quit(fpath);
  }

  if (acct_load(&cuser, userid) < 0)
    msg_quit(err_uid);

  passwd = nextword(&ptr);

  if (str_cmp(cuser.userid, STR_GUEST) && chkpasswd(cuser.passwd, passwd))
    msg_quit(ERR_PASSWD);

  /* �]�w���O */
  memset(&wrc, 0, sizeof(WebReqCmd));
  wrc.group = G_CMD;
  strcpy(wrc.funckey, "chgusr");
  str_ncpy(wrc.query, cuser.userid, sizeof(cuser.userid));
  usr_fpath(fpath, cutmp->userid, FN_WEBCMD);	/* �@�w�����cuser.userid, ��b�ѱb���W */
  if (access(fpath, 0))
    unlink(fpath);
  if (rec_add(fpath, &wrc, sizeof(WebReqCmd)) < 0)
    msg_quit("�t�Τ���, �}�ɥX��!");

  kill(cutmp->pid, SIGUSR1);	/* ���i�৹�������Ȼ�? */

  /* �B�z�@�U�ѪF�� */
  opid = atoi(nextword(&ptr));
  if (opid > 0 && utmp_locate(opid))
    kill(opid, SIGTERM);

  level = cuser.userlevel;
  if (level)			/* not guest */
  {
    /* ------------------------------------------------- */
    /* �ֹ� user level					 */
    /* ------------------------------------------------- */

#ifdef JUSTIFY_PERIODICAL
    if ((level & PERM_VALID) && !(level & PERM_ALLADMIN))
    {				/* Thor.980819: �������@�w�������{�� */
      if (cuser.tvalid + VALID_PERIOD < ap_start)
	level ^= PERM_VALID;
    }
#endif

    level |= (PERM_POST | PERM_PAGE | PERM_CHAT);	/* itoc.010804.����: �� PERM_VALID �̦۰ʵo�� PERM_POST PERM_PAGE PERM_CHAT */

    if (!(level & PERM_ALLADMIN))
    {
#ifdef NEWUSER_LIMIT
      if (ap_start - cuser.firstlogin < 3 * 86400)
	level &= ~PERM_POST;	/* �Y�Ϥw�g�q�L�{�ҡA�٬O�n���ߤT�� */
#endif

      /* Thor.980629: ���g�����{��, �T�� chat/talk/write */
      if (!(level & PERM_VALID))
        level &= ~(PERM_POST | PERM_CHAT | PERM_PAGE);

      if (level & PERM_DENYPOST)
	level &= ~PERM_POST;

      if (level & PERM_DENYTALK)
	level &= ~PERM_PAGE;

      if (level & PERM_DENYCHAT)
	level &= ~PERM_CHAT;

      if ((cuser.numemails >> 4) > (cuser.numlogins + cuser.numposts))
	level |= PERM_DENYMAIL;
    }
  }
  /* ok �^�Ǥ@�ǪF�� */
  www_printf("result=OK&pid=%d&userno=%d&level=%d", cutmp->pid, cuser.userno, level);
  return 1;
}


WebKeyFunc login_cb[] =
{
  {"vt_login", vt_login},
  {"chg_usr", chg_usr},
  {NULL, NULL}
};
