/*-------------------------------------------------------*/
/* util/transman.c                                       */
/*-------------------------------------------------------*/
/* target : Magic �� Maple 3.02 ��ذ��ഫ		 */
/* create : 01/10/03                                     */
/* update :   /  /  					 */
/* author : itoc.bbs@bbs.tnfsh.tn.edu.tw                 */
/*-------------------------------------------------------*/
/* syntax : transman brdname		                 */
/*-------------------------------------------------------*/


#if 0

   0. �A�� Magic/Napoleon �� Maple ��ذ�
   1. �� �¯��� 0Announce/groups/ooxx.faq/brdname ���� OLD_MANPATH/brdname
   2. �]�w OLD_MANPATH
   3. �{�����}�ؿ��A�ϥΫe���T�w gem/target_board/? �ؿ��s�b
     if not�A���}�s�O or transbrd
   4. �p�G�ؿ��Ӧh�h�A�i��|�y���ɮ׶}�ҹL�h�ӥ��ѡA�Х��N���j�h�Ƨ�֤@�I

   ps. User on ur own risk.

#endif

#include "bbs.h"

#define OLD_MANPATH	"bak/groups"


/* ----------------------------------------------------- */
/* 3.10 functions					 */
/* ----------------------------------------------------- */


static int		/* 1: �O�ɮ� */
_dashf(fname)
  char *fname;
{
  struct stat st;

  return (!stat(fname, &st) && S_ISREG(st.st_mode));
}


static int		/* 1: �O�ؿ� */
_dashd(fname)
  char *fname;
{
  struct stat st;

  return (!stat(fname, &st) && S_ISDIR(st.st_mode));
}


static void
merge_msg(msg)		/* fget() �r��̫ᦳ '\n' �n�B�z�� */
  char *msg;
{
  int end;

  end = 0;
  while (end <= 79)
  {
    if (msg[end] == '\n')
      msg[end] = '\0';

    end++;
  }
}


static int
get_record(src, src_folder, title, path, num)
  char *src;
  char *src_folder;
  char *title, *path;
  int num;
{
  FILE *fp;
  char Name[80], Path[80], buf[80];
  int i, j;

  if (fp = fopen(src_folder, "r"))
  {
    /* �e�T��S�� */
    j = num * 4 + 3;
    for (i = 0; i < j; i++)
    {
      fgets(buf, 80, fp);
    }

    /* �C�ӯ��ަ��|�� */
    fgets(Name, 80, fp);
    fgets(Path, 80, fp);
    fgets(buf, 80, fp);
    fgets(buf, 80, fp);

    fclose(fp);

    if (Name[0] != '#' && Path[0] != '#')
    {
      merge_msg(Name);
      merge_msg(Path);

      strcpy(title, Name + 5);
      strcpy(path, Path + 7);

      sprintf(buf, "%s/%s", src, path);

      if (_dashf(buf))
        return 'A';
      else if (_dashd(buf))
        return 'F';
    }
  }

  return 0;
}


static void
transman(brdname, src, dst_folder)
  char *brdname;	/* �ݪO�O�W */
  char *src;		/* �¯����ؿ� */
  char *dst_folder;	/* �s���� .DIR ��  FXXXXXXX */
{
  int num;
  int type;
  char src_folder[80];		/* �¯��� .Names */
  char sub_src[80];		
  char sub_dst_folder[80];
  char title[80], path[80], cmd[256];
  HDR hdr;

  num = 0;
  sprintf(src_folder, "%s/.Names", src);

  while ((type = get_record(src, src_folder, title, path, num)))
  {
    if (type == 'A')		/* ��� */
    {
      close(hdr_stamp(dst_folder, 'A', &hdr, cmd));
      strcpy(hdr.title, title);
      rec_add(dst_folder, &hdr, sizeof(HDR));

      sprintf(cmd, "cp %s/%s gem/brd/%s/%c/%s", src, path, brdname, hdr.xname[7], hdr.xname);
      system(cmd);
    }
    else if (type == 'F')	/* �ؿ� */
    {
      close(hdr_stamp(dst_folder, 'F', &hdr, cmd));
      hdr.xmode = GEM_FOLDER;
      strcpy(hdr.title, title);
      rec_add(dst_folder, &hdr, sizeof(HDR));

      sprintf(sub_src, "%s/%s", src, path);
      sprintf(sub_dst_folder, "gem/brd/%s/%c/%s", brdname, hdr.xname[7], hdr.xname);
      transman(brdname, sub_src, sub_dst_folder);
    }
    num++;
  }
}


#if 0		/* itoc.011003: ���n�@���]�����O�A��ʤ@�Ӥ@�Ӷ]�n�F */
int
main()
{
  char src[80], dst_folder[80];
  BRD brd;
  int num;

  chdir(BBSHOME);

  num = 0;
  while (!rec_get(FN_BRD, &brd, sizeof(BRD), num))
  {
    sprintf(src, OLD_MANPATH "/%s", brd.brdname);

    if (_dashd(src))
    {
      sprintf(dst_folder, "gem/brd/%s", brd.brdname);
      
      if (_dashd(dst_folder))
      {
	sprintf(dst_folder, "gem/brd/%s/.DIR", brd.brdname);
	transman(brd.brdname, src, dst_folder);	/* �s�¯����n���o�ӬݪO�~�� */
      }
    }

    num++;
  }

  exit(0);
}
#endif

int
main(argc, argv)
  int argc;
  char *argv[];
{
  char src[80], dst_folder[80];
  char *brdname;

  if (argc < 2)
  {
    printf("Usage: %s target_board\n", argv[0]);
    return -1;
  }

  chdir(BBSHOME);

  brdname = argv[1];
  sprintf(src, OLD_MANPATH "/%s", brdname);

  if (_dashd(src))
  {
    sprintf(dst_folder, "gem/brd/%s", brdname);
      
    if (_dashd(dst_folder))
    {
      sprintf(dst_folder, "gem/brd/%s/.DIR", brdname);
      transman(argv[1], src, dst_folder);	/* �s�¯����n���o�ӬݪO�~�� */
      printf("%s transfer gem complete!\n", brdname);
      return 0;
    }
  }

  printf("%s transfer gem failure!\n", brdname);
  return -1;
}
