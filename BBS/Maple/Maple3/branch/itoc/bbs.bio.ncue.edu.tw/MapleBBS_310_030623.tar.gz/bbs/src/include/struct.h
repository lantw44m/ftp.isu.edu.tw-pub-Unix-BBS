/*-------------------------------------------------------*/
/* struct.h	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : all definitions about data structure	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#ifndef _STRUCT_H_
#define _STRUCT_H_


/* screen control */

#define STRLEN		80	/* Length of most string data�A�]�O�ù����e�� */
#define ANSILINELEN	250	/* Maximum Screen width in chars�A�̦h�i�H�� 255 */

#define t_lines		50	/* maximum total lines */

/* board structure */

#define BTLEN		48	/* Length of board title */
#define BCLEN		5	/* Length of board class prefix, �]�A�b BTLEN �� */
#define BMLEN		36	/* Length of board managers */

/* file structure */

#define TTLEN		72	/* Length of title */
#define FNLEN		28	/* Length of filename  */

/* user structure */

#define IDLEN		12	/* Length of board / user id */
#define PASSLEN		14	/* Length of encrypted passwd field */
#define PSWDLEN		8	/* Length of passwd (���[�K������) */
#define RNLEN		19	/* Length of real name */
#define UNLEN		23	/* Length of user name */


typedef char const *STRING;
typedef unsigned char uschar;	/* length = 1 */
typedef unsigned int usint;	/* length = 4 */
typedef struct UTMP UTMP;


/* ----------------------------------------------------- */
/* �ϥΪ̱b�� .ACCT struct : 512 bytes			 */
/* ----------------------------------------------------- */


typedef struct
{
  int userno;			/* unique positive code */

  char userid[IDLEN + 1];	/* ID */
  char passwd[PASSLEN];		/* �K�X passwd �O�t�X�A���ݭn�O�d 1 byte �� '\0' */
  char realname[RNLEN + 1];	/* �u��m�W */
  char username[UNLEN + 1];	/* �ʺ� */

  usint userlevel;		/* �v�� */
  usint ufo;			/* habit */
  uschar signature;		/* �w�]ñ�W�� */

  char year;			/* �ͤ�(����~) */
  char month;			/* �ͤ�(��) */
  char day;			/* �ͤ�(��) */
  char sex;			/* �ʧO 1:�k 0:�k */
  int money;			/* �ȹ� */
  int gold;			/* ���� */

  int numlogins;		/* �W������ */
  int numposts;			/* �o������ */
  int numemails;		/* �H�o Inetrnet E-mail ���� */
 
  time_t firstlogin;		/* �Ĥ@���W���ɶ� */
  time_t lastlogin;		/* �W�@���W���ɶ� */
  time_t tcheck;		/* �W�� check �H�c/�n�ͦW�檺�ɶ� */
  time_t tvalid;		/* �q�L�{�Ҫ��ɶ� */

  char lasthost[30];		/* �W���n�J�ӷ� */
  char email[60];		/* �ثe�n�O���q�l�H�c */
}      ACCT;


typedef struct			/* 16 bytes */
{
  time_t uptime;
  char userid[IDLEN];
}      SCHEMA;


#ifdef	HAVE_REGISTER_FORM

typedef struct	/* ���U���� (Register From) 256 bytes */
{
  int userno;
  time_t rtime;
  char userid[IDLEN + 1];
  char agent[IDLEN + 1];
  char realname[RNLEN + 1];
  char career[50];
  char address[60];
  char phone[20];
  char reply[72];
}      RFORM;

#endif


#include "hdr.h"


/* ----------------------------------------------------- */
/* control of board vote : 256 bytes			 */
/* ----------------------------------------------------- */


typedef struct VoteControlHeader
{
  time_t chrono;		/* �벼�}��ɶ� */	/* Thor: �� key �ӥB match HDR chrono */
  time_t bstamp;		/* �ݪO���ѥN�X */	/* Thor: �� key */
  time_t vclose;		/* �벼�����ɶ� */

  char xname[17];		/* �D�ɦW */		/* Thor: match HDR �� xname */
  char date[9];			/* �}�l��� */		/* Thor: match HDR �� date */
  char cdate[9];		/* ������� */		/* Thor: �u����ܡA������� */  
  char owner[129];		/* �|��H */		/* itoc: �o�ӤӪ��F�A�i�H��h����L�\�� */
  char title[TTLEN + 1];	/* �벼�D�D */

  char vsort;			/* �}�����G�O�_�Ƨ�  's':�Ƨ�  ' ':���Ƨ� */
  char vpercent;		/* �O�_��ܦʤ����  '%':�ʤ�  ' ':�@�� */
  char vprivate;		/* �O�_���p�H�벼    ')':�p�H  ' ':���} */
  int maxblt;			/* �C�H�i��X�� */
}           VCH;


typedef char vitem_t[32];	/* �벼�ﶵ */

/* filepath : brd/<board>/.VCH, brd/<board>/@/... */


/* ----------------------------------------------------- */
/* Mail-Queue struct : 256 bytes			 */
/* ----------------------------------------------------- */


typedef struct
{
  time_t mailtime;		/* �H�H�ɶ� */
  char method;
  char sender[IDLEN + 1];
  char username[UNLEN + 1];
  char subject[TTLEN + 1];
  char rcpt[60];
  char filepath[77];
  char *niamod;			/* reverse domain */
}      MailQueue;


#define	MQ_UUENCODE	0x01	/* �� uuencode �A�H�X */
#define	MQ_JUSTIFY	0x02	/* �����{�ҫH�� */


/* ----------------------------------------------------- */
/* PAL : friend struct : 64 bytes			 */
/* ----------------------------------------------------- */


typedef struct
{
  char userid[IDLEN + 1];
  char ftype;
  char ship[46];
  int userno;
}      PAL;

#define	PAL_BAD		0x02	/* �n�� vs �l�� */


#ifdef	HAVE_ALOHA

/* ----------------------------------------------------- */
/* ALOHA : �W���q���W��                                  */
/* ----------------------------------------------------- */


typedef struct
{
  char userid[IDLEN + 1];
  int userno;
}      ALOHA;

#endif	/* HAVE_ALOHA */


/* ----------------------------------------------------- */
/* structure for call-in message : 100 bytes		 */
/* ----------------------------------------------------- */


typedef struct
{
  time_t btime;
  UTMP *caller;			/* who call-in me ? */
  int sender;			/* calling userno */
  int recver;			/* called userno */
  char userid[IDLEN + 1 + 2];	/* itoc.010529: �O�d 2 byte ���s���Ÿ� > */
  char msg[69];			/* ���y */
}      BMW;			/* bbs message write */


/* ----------------------------------------------------- */
/* Structure used in UTMP file : 128 bytes		 */
/* ----------------------------------------------------- */


struct UTMP
{
  pid_t pid;			/* process ID */
  int userno;			/* user number in .PASSWDS */

  time_t idle_time;		/* active time for last event */
  usint mode;			/* bbsmode */
  usint ufo;			/* the same as userec.ufo */
  u_long in_addr;		/* Internet address */
  int sockport;			/* socket port for talk */
  UTMP *talker;			/* who talk-to me ? */

  BMW *mslot[BMW_PER_USER];

  char userid[IDLEN + 1];	/* user's ID */
  char mateid[IDLEN + 1];	/* partner's ID */
  char username[UNLEN + 1];	/* user's nickname */
  char from[34];		/* remote host */

  /* itoc.010309: �� userlevel �]��J cache �� */
  usint userlevel;		/* user level */

  /* itoc.001223: ��n�ͤ]��J cache �� */
  int pal_max;
  int pal_spool[PAL_MAX];

#ifdef BMW_COUNT
  /* itoc.020814: �O�����F�X�Ӥ��y */
  int bmw_count;
#endif

#ifdef PREFORK
  int bgen;			/* generation */
#endif

#ifdef SHOW_REALNAME
  char realname[20];
#endif
};


/* ----------------------------------------------------- */
/* BOARDS struct : 128 bytes				 */
/* ----------------------------------------------------- */


typedef struct BoardHeader
{
  char brdname[IDLEN + 1];	/* board ID */
  char title[BTLEN + 1];
  char BM[BMLEN + 1];		/* BMs' uid, token '/' */

  uschar bvote;			/* �@���X���벼�|�椤 */

  time_t bstamp;		/* �إ߬ݪO���ɶ�, unique */
  usint readlevel;		/* �\Ū�峹���v�� */
  usint postlevel;		/* �o���峹���v�� */
  usint battr;			/* �ݪO�ݩ� */
  time_t btime;			/* .DIR �� st_mtime */
  int bpost;			/* �@���X�g post */
  time_t blast;			/* �̫�@�g post ���ɶ� */
}           BRD;


#define	BRD_NOZAP	0x01	/* ���i zap */
#define	BRD_NOTRAN	0x02	/* ����H */
#define	BRD_NOCOUNT	0x04	/* ���p�峹�o���g�� */
#define	BRD_NOSTAT	0x08	/* ���ǤJ�������D�έp */
#define	BRD_NOVOTE	0x10	/* �����G�벼���G�� [record] �O */
#define	BRD_ANONYMOUS	0x20	/* �ΦW�ݪO */

#define NUMATTRS	6

#define STR_BATTR	"zTcsvA"


/* ----------------------------------------------------- */
/* Class image						 */
/* ----------------------------------------------------- */


#define CLASS_INIFILE		"Class"

/* itoc.010413: �� class.img �����G�� */
#define CLASS_IMGFILE_NAME	"run/classname.img"
#define CLASS_IMGFILE_TITLE	"run/classtitle.img"

#define CLASS_CHNFILE		"run/classchn.num"	/* �O���`�@���X�Ӥ��� */


#define CH_MAX		100	/* �̤j�����ƥ� */
#define	CH_END		-1
#define	CH_TTLEN	64


typedef	struct
{
  int count;
  char title[CH_TTLEN];
  short chno[0];
}	ClassHeader;


#ifdef MY_FAVORITE

/* ----------------------------------------------------- */
/* favor.c ���B�Ϊ���Ƶ��c                              */
/* ----------------------------------------------------- */


typedef struct MF
{
  time_t chrono;		/* �إ߮ɶ� */
  int mftype;			/* type */
  char xname[IDLEN + 1];	/* �ɦW */
  char title[BTLEN + 1];	/* ���D */
}	MF;

#define	MF_MARK		0x01	/* �Q mark �_�Ӫ� */
#define	MF_BOARD    	0x02	/* �ݪO���|       */
#define	MF_FOLDER   	0x04	/* Fxxxxxxx       */
#define	MF_GEM      	0x08	/* ��ذϱ��|     */

#endif  /* MY_FAVORITE */


#ifdef HAVE_COSIGN

/* ----------------------------------------------------- */
/* newbrd.c ���B�Ϊ���Ƶ��c                             */
/* ----------------------------------------------------- */


typedef struct NewBoardHeader
{
  char brdname[IDLEN + 1];
  char title[49];
  time_t btime;
  time_t etime;
  char xname[32];
  char owner[IDLEN + 1];
  char date[9];
  usint mode;
  int total;
}	NBRD;


#define NBRD_ING	0x01	/* �s�p�� */
#define NBRD_OPEN	0x02	/* �w�}�� */
#define NBRD_CLOSE	0x04	/* ���F�s�p�H�� */
#define NBRD_STOP	0x08	/* �T��}�� ����s�p */
#define NBRD_OK		0x10	/* �s�p���� */
#define NBRD_START	0x20	/* �ӽгq�L */
#define NBRD_REJECT	0x40	/* �ӽФ��q�L */
#define NBRD_ANONYMOUS	0x80	/* �s�p�ΦW */
#define NBRD_NBRD	0x1000	/* �}�s�O */
#define NBRD_OBRD	0x2000	/* �Ϲ�}�s�O(�ΦW) */
#define NBRD_CANCEL	0x4000	/* �o���D */
#define NBRD_OTHER	0x8000	/* �䥦 */

#define NBRD_MASK	(NBRD_NBRD | NBRD_OBRD | NBRD_CANCEL | NBRD_OTHER)

#endif	/* HAVE_COSIGN */


#ifdef LOG_SONG_USIES

/* ----------------------------------------------------- */
/* SONG log ���B�Ϊ���Ƶ��c                             */
/* ----------------------------------------------------- */

typedef struct SONGDATA
{
  time_t chrono;
  int count;		/* �Q�I���� */
  char title[80];
}	SONGDATA;

#endif	/* LOG_SONG_USIES */


/* ----------------------------------------------------- */
/* cache.c ���B�Ϊ���Ƶ��c				 */
/* ----------------------------------------------------- */


typedef struct
{
  int shot[MOVIE_MAX];	/* Thor.980805: �X�z�d�� 0..MOVIE_MAX - 1 */
  char film[MOVIE_SIZE];
} FCACHE;


#define	FILM_SIZ	4000	/* max size for each film */


#define FILM_OPENING0	0
#define FILM_OPENING1	1
#define FILM_OPENING2	2
#define	FILM_WELCOME	3
#define FILM_GOODBYE	4
#define	FILM_APPLY	5	/* new account */
#define FILM_JUSTIFY	6
#define FILM_REREG	7
#define FILM_EMAIL	8
#define FILM_NEWUSER	9
#define	FILM_TRYOUT	10
#define	FILM_POST	11
#define	FILM_MOVIE	12	/* �ʺA�ݪO FILM_MOVIE �n��b�̫᭱ */


typedef struct
{
  UTMP uslot[MAXACTIVE];	/* UTMP slots */
  usint count;			/* number of active session */
  usint offset;			/* offset for last active UTMP */

  double sysload[3];
  int avgload;

  BMW *mbase;			/* sequential pointer for BMW */
  BMW mpool[BMW_MAX];
} UCACHE;


typedef struct
{
  BRD bcache[MAXBOARD];
  int number;			/* �����ݪO���ƥ� */
  time_t uptime;
} BCACHE;


/* ----------------------------------------------------- */
/* screen.c ���B�Ϊ���Ƶ��c				 */
/* ----------------------------------------------------- */


/* Screen Line buffer modes */


#define SL_MODIFIED	(1)	/* if line has been modifed, screen output */
#define SL_STANDOUT	(2)	/* if this line contains standout code */
#define SL_ANSICODE	(4)	/* if this line contains ANSI code */


typedef struct screenline
{
  uschar oldlen;		/* previous line length */
  uschar len;			/* current length of line */
  uschar width;			/* padding length of ANSI codes */
  uschar mode;			/* status of line, as far as update */
  uschar smod;			/* start of modified data */
  uschar emod;			/* end of modified data */
  uschar sso;			/* start of standout data */
  uschar eso;			/* end of standout data */
  uschar data[ANSILINELEN];
}          screenline;


typedef struct LinkList
{
  struct LinkList *next;
  char data[0];
}        LinkList;


/* ----------------------------------------------------- */
/* xover.c ���B�Ϊ���Ƶ��c				 */
/* ----------------------------------------------------- */


typedef struct OverView
{
  int pos;			/* current position */
  int top;			/* top */
  int max;			/* max */
  int key;			/* key */
  char *xyz;			/* staff */
  struct OverView *nxt;		/* next */
  char dir[0];			/* data path */
}        XO;


typedef struct
{
  int key;
  int (*func) ();
}      KeyFunc;


typedef struct
{
  XO *xo;
  KeyFunc *cb;
  int mode;
} XZ;


typedef struct
{
  time_t chrono;
  int recno;
}      TagItem;


#ifdef MODE_STAT

/* ----------------------------------------------------- */
/* modestat.c ���B�Ϊ���Ƶ��c                           */
/* ----------------------------------------------------- */

typedef struct
{
  time_t logtime;
  time_t used_time[M_MAX + 1];	/* itoc.010901: depend on mode.h */
} UMODELOG;


typedef struct
{
  time_t logtime;
  time_t used_time[M_MAX + 1];	/* itoc.010901: depend on mode.h */
  int count[30];
  int usercount;
} MODELOG;

#endif	/* MODE_STAT */


#ifdef HAVE_NETTOOL

/* ----------------------------------------------------- */
/* enews-open.c ���B�Ϊ���Ƶ��c : 256 bytes		 */
/* ----------------------------------------------------- */


typedef struct
{
  time_t chrono;		/* �s�� */
  char kind;			/* ���� */
  char xname[50];		/* �ɮצW�� */

  char link[128];		/* �s�����| */
  char title[TTLEN + 1];	/* �峹���D */
} ENEWS;

#endif	/* HAVE_NETTOOL */

#endif				/* _STRUCT_H_ */
