/*-------------------------------------------------------*/
/* util/collect_uno.c	( NTHU CS MapleBBS Ver 3.00 )    */
/*-------------------------------------------------------*/
/* target : ���� user number                             */
/* create :   /  /                                       */
/* update :   /  /                                       */
/* author : ernie@bbs.ee.nthu.edu.tw			 */
/*-------------------------------------------------------*/
/* syntax : collect_uno for_all/(userid)                 */
/*-------------------------------------------------------*/


#include "bbs.h"


static FILE *fp;


static int
transufo(path)
  char *path;
{
  char *fname;
  int fd;
  ACCT my;

  fname = strrchr(path, '/');
  sprintf(++fname, "%s", FN_ACCT);

  fd = open(path, O_RDWR);
  if (fd < 0)
    return 1;

  read(fd, &my, sizeof(my));

  fprintf(fp, "%5d %-s\n", my.userno, my.userid);

  close(fd);
  return 0;
}


int
main(argc, argv)
  int argc;
  char *argv[];
{
  DIR *dirp, *dirp1;
  struct dirent *de1;
  char path[80], ch, *ptr;
  int cnt = 0;

  if (argc != 2)
  {
    printf("usage: %s for_all/(userid)\n", argv[0]);
    printf("  for_all  ���ܩҦ��ϥΪ�\n");	/* ID ���঳���u�A�ҥH�i���Ѽ� */
    printf("  (userid) �i���Y�@�ϥΪ� ID\n");
    return 0;
  }

  chdir(BBSHOME);

  if (!(fp = fopen("tmp/all_user_uno", "w")))
    return -1;

  if (strcmp(argv[1], "for_all"))
  {
    char buf[13];

    strncpy(buf, argv[1], 12);
    str_lower(buf, buf);
    sprintf(path, "usr/%c/%s/", *buf, buf);

    transufo(path);

    fclose(fp);
    return 0;
  }

  sprintf(path, "usr/");

  if (!(dirp = opendir(path)))
  {
    printf("Can't open dir %s\n", path);
    fclose(fp);
    return -1;
  }

  for (ch = 'a'; ch <= 'z'; ch++)
  {
    path[4] = ch;
    path[5] = '/';
    path[6] = '\0';
    ptr = &path[6];		/* �����u���@�Ӧr���A�i�������w */

    if (!(dirp1 = opendir(path)))
    {
      printf("Can't open dir %s\n", path);
      continue;      
    }

    printf("processing %s\n", path);
    while (de1 = readdir(dirp1))
    {
      if (de1->d_name[0] == '.')
	continue;

      sprintf(ptr, "%s/", de1->d_name);	/* de1->d_name �� userid */

      if (transufo(path))	/* �즹 path �� usr/x/xxx/ ���榡 */
	cnt++;
    }

    closedir(dirp1);
  }

  closedir(dirp);
  fclose(fp);
  printf("%d users don't have .ACCT\n", cnt);
  return 0;
}
