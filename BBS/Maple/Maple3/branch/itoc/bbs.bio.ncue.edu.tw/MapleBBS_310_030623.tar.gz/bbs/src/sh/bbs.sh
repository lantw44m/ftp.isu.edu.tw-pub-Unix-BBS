#!/bin/sh
case "$1" in
start)
        [ -x /home/bbs/bin/account ] && {
                su -l bbs -c 'exec /home/bbs/bin/account'
                su -l bbs -c 'exec /home/bbs/bin/camera'
                su -l bbs -c 'exec /home/bbs/bin/xchatd'
                su -l bbs -c 'exec /home/bbs/innd/innbbsd'
                su -l bbs -c 'exec /home/bbs/bin/bbsd 9999'
                /home/bbs/bin/bguard
        }
        ;;
stop)
        [ -x /home/bbs/bin/account ] && {
                killall -9 xchatd
                su -l bbs -c 'exec /home/bbs/innd/ctlinnbbsd shutdown'
                killall -9 bbsd
                killall -9 bguard
                for i in `ipcs | grep bbs | awk '{print $3}'`
                do
                  if [ $OSTYPE = "FreeBSD" ]; then
                    ipcrm -M $i
                  fi
                done
        }
        ;;
*)
        echo "Usage: bbs.sh {start|stop}" >&2
        exit 64
        ;;
esac
