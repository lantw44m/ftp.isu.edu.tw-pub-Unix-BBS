/*-------------------------------------------------------*/
/* pal.c	( NTHU CS MapleBBS Ver 3.00 )		 */
/*-------------------------------------------------------*/
/* target : pal routines	 	 		 */
/* create : 95/03/29				 	 */
/* update : 97/03/29				 	 */
/*-------------------------------------------------------*/


#include "bbs.h"


static int pal_count;
static int *pal_pool;


extern XZ xz[];
extern char xo_pool[];


/* ----------------------------------------------------- */
/* �n�ͦW��G�s�W�B�R���B�ק�B���J�B�P�B		 */
/* ----------------------------------------------------- */


int
is_mypal(userno)		/*  1: �ڳ]��謰�n�� */
  int userno;
{
  int count, *cache, datum, mid;

  if (cache = pal_pool)
  {
    for (count = pal_count; count > 0;)
    {
      datum = cache[mid = count >> 1];
      if (userno == datum)
       return 1;
      if (userno > datum)
      {
        cache += (++mid);
        count -= mid;
      }
      else
      {
        count = mid;
      }
    }
  }

  return 0;
}


#ifdef HAVE_BADPAL
int
is_mybad(userno)		/*  1: �ڳ]��謰�a�H */
  int userno;
{
  int count, *cache, datum, mid;

  if (cache = pal_pool)
  {
    for (count = pal_count; count > 0;)
    {
      datum = cache[mid = count >> 1];
      if ((-userno) == datum)
        return 1;
      if ((-userno) > datum)
      {
        cache += (++mid);
        count -= mid;
      }
      else
      {
        count = mid;
      }
    }
  }

  return 0;
}
#else
inline int
is_mybad(userno)
  int userno;
{
  return 0;
}
#endif	/* HAVE_BADPAL */


static int
int_cmp(a, b)
  int *a;
  int *b;
{
  return *a - *b;
}


/* itoc.001223: ���a�H�]���J CACHE�A����y�~���Τ@���}�� FN_PAL �ˬd */
void
pal_cache()
{
  int count, fsize, ufo, fd;
  int *plist, *cache;
  PAL *phead, *ptail;
  char *fimage, fpath[64];
  UTMP *up;

  up = cutmp;
  cutmp->userno = cuser.userno;
  
  cache = NULL;
  count = 0;
  ufo = cuser.ufo & ~UFO_REJECT;

  fsize = 0;
  usr_fpath(fpath, cuser.userid, fn_pal);
  fimage = f_img(fpath, &fsize);

  if (fimage != NULL)
  {
    if (fsize > PAL_MAX * sizeof(PAL))
    {
      if (fd = open(fpath, O_RDWR))
      {
        ftruncate(fd, PAL_MAX * sizeof(PAL));
        close(fd);
      }

      /* �����ӶW�L PAL_MAX �~��A�p�G�z�F�A�N�O���U�� */
      sprintf(fpath, "%-13s%d > %d * %d\n", cuser.userid, fsize, PAL_MAX, sizeof(PAL));
      f_cat(FN_RUN_PAL, fpath);
      fsize = PAL_MAX * sizeof(PAL);
    }

    count = fsize / sizeof(PAL);
    if (count)
    {
      cache = plist = up->pal_spool;
      phead = (PAL *) fimage;
      ptail = (PAL *) (fimage + fsize);
      ufo |= UFO_REJECT;

      do
      {
  	if (phead->ftype & PAL_BAD)		/* �Y�O�a�H�A�s -userno */
	  *plist++ = -(phead->userno);
        else
	  *plist++ = phead->userno;		/* �Y�O�n�͡A�s +userno */
      } while (++phead < ptail);

      if (count > 0)
      {
	if (count > 1)
	  xsort(cache, count, sizeof(int), int_cmp);
      }
      else
      {
        cache = NULL;
      }
    }
  }

  pal_pool = cache;
  up->pal_max = pal_count = count;
  if (cutmp)
  {
    ufo = (ufo & ~(UFO_UTMP_MASK | UFO_REJECT)) | (cutmp->ufo & UFO_UTMP_MASK);
    cutmp->ufo = ufo & (~UFO_REJECT);
  }

  if (fimage)
    free(fimage);

  cuser.ufo = ufo;
}


void
pal_sync(fpath)
  char *fpath;
{
  int fd, size;
  struct stat st;
  char buf[64];

  if (!fpath)
  {
    fpath = buf;
    usr_fpath(fpath, cuser.userid, fn_pal);
  }

  if ((fd = open(fpath, O_RDWR, 0600)) < 0)
    return;

  outz(MSG_CHKDATA);
  refresh();

  if (!fstat(fd, &st) && (size = st.st_size) > 0)
  {
    PAL *pbase, *phead, *ptail;
    int userno;

    pbase = phead = (PAL *) malloc(size);
    size = read(fd, pbase, size);
    if (size >= sizeof(PAL))
    {
      ptail = (PAL *) ((char *) pbase + size);
      while (phead < ptail)
      {
	userno = phead->userno;
	if (userno > 0 && userno == acct_userno(phead->userid))
	{
	  phead++;
	  continue;
	}

	ptail--;
	if (phead >= ptail)
	  break;
	memcpy(phead, ptail, sizeof(PAL));
      }

      size = (char *) ptail - (char *) pbase;
      if (size > 0)
      {
	if (size > sizeof(PAL))
	{
	  if (size > PAL_MAX * sizeof(PAL))
	    vmsg("�z���n�ͦW��Ӧh�A�е��[��z");
	  xsort(pbase, size / sizeof(PAL), sizeof(PAL), str_cmp);
	}

	/* Thor.980709: �O�_�n�[�W�������Ъ��n�ͪ��ʧ@? */

	lseek(fd, 0, SEEK_SET);
	write(fd, pbase, size);
	ftruncate(fd, size);
      }
    }
    free(pbase);
  }
  close(fd);

  if (size <= 0)
    unlink(fpath);
}


int
pal_list(reciper)
  int reciper;
{
  int userno, fd;
  char buf[32], fpath[64];
  ACCT acct;
#ifdef HAVE_LIST
  int ch;
#endif

  userno = 0;

  for (;;)
  {
#ifdef HAVE_LIST
    switch (ch = vget(1, 0, "(A)�W�[ (D)�R�� (F)�n�� (G)�s�� (M)�w�� (1~5)�S�O�W�� (Q)�����H[M] ", buf, 3, LCECHO))
#else
    switch (vget(1, 0, "(A)�W�[ (D)�R�� (F)�n�� (G)�s�� (M)�w�� (Q)�����H[M] ", buf, 3, LCECHO))
#endif
    {
    case 'a':
      while (acct_get("�п�J�N��(�u�� ENTER �����s�W): ", &acct) > 0)
      {
	if (!ll_has(acct.userid))
	{
	  ll_add(acct.userid);
	  reciper++;
	  ll_out(3, 0, MSG_LL);
	}
      }
      break;

    case 'd':
      while (reciper)
      {
	if (!vget(1, 0, "�п�J�N��(�u�� ENTER �����R��): ", buf, IDLEN + 1, GET_LIST))
	  break;
	if (ll_del(buf))
	  reciper--;
	ll_out(3, 0, MSG_LL);
      }
      break;

#ifdef HAVE_LIST
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
      /* itoc.010923: �ޥίS�O�W��A���K�ϥθs�ձ��� */
      sprintf(buf, "%s.%c", FN_LIST, ch);
      usr_fpath(fpath, cuser.userid, buf);
#endif

    case 'g':
      if (userno = vget(b_lines, 0, "�s�ձ���G", buf, 16, DOECHO))
	str_lower(buf, buf);

    case 'f':
#ifdef HAVE_LIST
      if (ch == 'g' || ch == 'f')
#endif
	usr_fpath(fpath, cuser.userid, fn_pal);

      if ((fd = open(fpath, O_RDONLY)) >= 0)
      {
	PAL *pal;
	char *userid;

	mgets(-1);
	while (pal = mread(fd, sizeof(PAL)))
	{
	  userid = pal->userid;
	  if (!ll_has(userid) && /* (pal->userno != cuser.userno) && */	/* itoc.010923: �n�ͦW�椤���|���ۤv */
	    !(pal->ftype & PAL_BAD) &&
	    (!userno || str_str(pal->ship, buf)))
	  {
	    ll_add(userid);
	    reciper++;
	  }
	}
	close(fd);
      }
      ll_out(3, 0, MSG_LL);
      userno = 0;
      break;

    case 'q':
      return 0;

    default:
      return reciper;
    }
  }
}



/* ----------------------------------------------------- */
/* �n�ͦW��G��榡�ާ@�ɭ��y�z				 */
/* ----------------------------------------------------- */


static int pal_add();


static void
pal_item(num, pal)
  int num;
  PAL *pal;
{
  prints("%6d %-3s%-14s%s\n", num, pal->ftype & PAL_BAD ? "��" : "",
    pal->userid, pal->ship);
}


static int
pal_body(xo)
  XO *xo;
{
  PAL *pal;
  int num, max, tail;

  max = xo->max;
  if (max <= 0)
  {
    if (vans("�n��s�B�Ͷ�(Y/N)�H[N] ") == 'y')
      return pal_add(xo);
    return XO_QUIT;
  }

  pal = (PAL *) xo_pool;
  num = xo->top;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  move(3, 0);
  do
  {
    pal_item(++num, pal++);
  } while (num < max);
  clrtobot();

  /* return XO_NONE; */
  return XO_FOOT;	/* itoc.010403: �� b_lines ��W feeter */
}


static int
pal_head(xo)
  XO *xo;
{
  vs_head("�n�ͦW��", str_site);
  outs(NECKER_PAL);
  return pal_body(xo);
}


static int
pal_load(xo)
  XO *xo;
{
  xo_load(xo, sizeof(PAL));
  return pal_body(xo);
}


static int
pal_init(xo)
  XO *xo;
{
  xo_load(xo, sizeof(PAL));
  return pal_head(xo);
}


void
pal_edit(pal, echo)
  PAL *pal;
  int echo;
{
  if (echo == DOECHO)
    memset(pal, 0, sizeof(PAL));
  vget(b_lines, 0, "�ͽˡG", pal->ship, sizeof(pal->ship), echo);
#ifdef HAVE_BADPAL
  pal->ftype = vans("�a�H(Y/N)�H[N] ") == 'y' ? PAL_BAD : 0;
#else
  pal->ftype = 0;
#endif
}


/* static */ 			/* itoc.020117: �� vote.c �� */
int
pal_find(fpath, userno)		/* itoc.010923: �n�ͦW�椤�O�_�w�����H */
  char *fpath;
  int userno;
{        
  PAL old;
  int pos, fd;
        
  pos = 0;
  fd = open(fpath, O_RDONLY);

  while (fd)
  {     
    lseek(fd, (off_t) (sizeof(PAL) * pos), SEEK_SET);
    if (read(fd, &old, sizeof(PAL)) == sizeof(PAL))
    {
      if (userno == old.userno)
      {
        close(fd);
        return 1;
      }
      pos++;
    }
    else
    {
      close(fd);
      return 0;
    }
  }
  return 0;
}


static int
pal_add(xo)
  XO *xo;
{
  ACCT acct;
  int userno;

  if (xo->max >= PAL_MAX)
  {
    vmsg("�z���n�ͦW��Ӧh�A�е��[��z");
    return XO_FOOT;
  }

  userno = acct_get(msg_uid, &acct);

  if (userno == cuser.userno)	/* lkchu.981201: �n�ͦW�椣�i�[�ۤv */
  {
    vmsg("�ۤv�����[�J�n�ͦW�椤");
    return XO_HEAD;
  }
  else if (pal_find(xo->dir, userno))
  /* itoc.010923: �����h�}�ɮר��ˬd�A�i�H���ݭn�b�[��n�ͮɴN pal_cache�A�٥i�קK�b�ݪO�n�ͦW��/�s�զW��ɭ��Х[�J */
  {
    vmsg("�W�椤�w�����H");
    return XO_HEAD;
  }

  if (userno > 0)
  {
    PAL pal;

    pal_edit(&pal, DOECHO);
    strcpy(pal.userid, acct.userid);
    pal.userno = userno;
    rec_add(xo->dir, &pal, sizeof(PAL));

    xo->pos = XO_TAIL;
    xo_load(xo, sizeof(PAL));
  }

  return pal_head(xo);
}


static int
pal_delete(xo)
  XO *xo;
{
  if (vans(msg_del_ny) == 'y')
  {
    if (!rec_del(xo->dir, sizeof(PAL), xo->pos, NULL))
      return pal_load(xo);
  }
  return XO_FOOT;
}


static int
pal_change(xo)
  XO *xo;
{
  PAL *pal, mate;
  int pos, cur;
  
  pos = xo->pos;
  cur = pos - xo->top;
  pal = (PAL *) xo_pool + cur;

  mate = *pal;
  pal_edit(pal, GCARRY);
  if (memcmp(pal, &mate, sizeof(PAL)))
  {
    rec_put(xo->dir, pal, sizeof(PAL), pos, NULL);
    move(3 + cur, 0);
    pal_item(++pos, pal);
  }

  return XO_FOOT;
}


static int
pal_mail(xo)
  XO *xo;
{
  PAL *pal;
  char *userid;

  pal = (PAL *) xo_pool + (xo->pos - xo->top);
  userid = pal->userid;
  if (*userid)
  {
    vs_bar("�H  �H");
    prints("���H�H�G%s", userid);
    my_send(userid);
  }
  return pal_head(xo);
}


static int
pal_write(xo)
  XO *xo;
{
  if (HAS_PERM(PERM_PAGE))
  {
    PAL *pal;
    UTMP *up;

    pal = (PAL *) xo_pool + (xo->pos - xo->top);

    if (up = utmp_find(pal->userno))
      do_write(up);
  }
  return XO_NONE;
}


#ifdef HAVE_MODERATED_BOARD
static int
pal_loadpal(xo)
  XO *xo;
{
  int i, j;
  char fpath[64], *dir;
  PAL pal;

  dir = xo->dir;
  if (*dir != 'b')	/* �u���b�O�ͦW��~��ޥΦn�ͦW�� */
    return XO_NONE;

  if (vans("�n�ޤJ�n�ͦW���(Y/N)�H[N] ") == 'y')
  {
    usr_fpath(fpath, cuser.userid, fn_pal);
    j = PAL_MAX - xo->max;

    /* itoc.001224: �ޤJ�W��u�[�� PAL_MAX */
    for (i = 0; j > 0; i++)
    {
      if (rec_get(fpath, &pal, sizeof(PAL), i) >= 0 && !(pal.ftype & PAL_BAD))
      {
	rec_add(dir, &pal, sizeof(PAL));
	xo->pos = XO_TAIL;
	j--;
      }
      else
	break;
    }
    return pal_load(xo);
  }
  return XO_FOOT;
}
#endif


static int
pal_sort(xo)
  XO *xo;
{
  pal_sync(xo->dir);
  return pal_load(xo);
}


static int
pal_query(xo)
  XO *xo;
{
  PAL *pal;

  pal = (PAL *) xo_pool + (xo->pos - xo->top);
  move(1, 0);
  clrtobot();
  /* if (*pal->userid) */	/* Thor.980806: �����n���@�U, ���ӨS�t */
  my_query(pal->userid);
  return pal_head(xo);
}


static int
pal_help(xo)
  XO *xo;
{
  xo_help("pal");
  return pal_head(xo);
}


KeyFunc pal_cb[] =
{
  XO_INIT, pal_init,
  XO_LOAD, pal_load,
  XO_HEAD, pal_head,
  XO_BODY, pal_body,

  'a', pal_add,
  'c', pal_change,
  'd', pal_delete,
  'm', pal_mail,
  'w', pal_write,
  'r', pal_query,
  Ctrl('Q'), pal_query,
  's', pal_sort,

#ifdef HAVE_MODERATED_BOARD
  'f', pal_loadpal,
#endif

  'h', pal_help
};


int
t_pal()
{
  XO *xo;
  char fpath[64];

  usr_fpath(fpath, cuser.userid, fn_pal);
  xz[XZ_PAL - XO_ZONE].xo = xo = xo_new(fpath);
  xz[XZ_PAL - XO_ZONE].cb = pal_cb;
  xover(XZ_PAL);
  pal_cache();		/* itoc.010923: ���}�n�ͦW��A�@�֦P�B cache */
  free(xo);

  return 0;
}


#ifdef HAVE_LIST
int
t_list()
{
  int n;
  char fpath[64], buf[8];
  XO *xo;

  move(MENU_XPOS, 0);
  clrtobot();

  for (n = 1; n <= 5; n++)
  {
    move(n + MENU_XPOS - 1, MENU_YPOS - 1);
    prints("(\033[1;36m%d\033[m) �s�զW��.%d", n, n);
  }

  n = vans("�п���ɮ׽s���A�Ϋ� [0] �����G") - '0';
  if (n <= 0 || n > 5)
    return 0;

  sprintf(buf, "%s.%d", FN_LIST, n);
  usr_fpath(fpath, cuser.userid, buf);

  switch(vget(b_lines, 36, "(D)�R�� (E)�s�� [Q]�����H", buf, 3, LCECHO))
  {
  case 'd':
    unlink(fpath);
    break;

  case 'e':
    /* �ɥ� XZ_PAL �Y�i */
    xz[XZ_PAL - XO_ZONE].xo = xo = xo_new(fpath);
    xz[XZ_PAL - XO_ZONE].cb = pal_cb;
    xover(XZ_PAL);
    free(xo);
    break;
  }

  return 0;
}
#endif
