/*-------------------------------------------------------*/
/* util/show_id_in_USR.c  ( NTHU CS MapleBBS Ver 3.00 )  */
/*-------------------------------------------------------*/
/* target : �i�q�X .USR �ɸ̲� n �� slot �� id		 */
/* create :   /  /                                       */
/* update :   /  /                                       */
/* author : ernie@bbs.ee.nthu.edu.tw                     */
/*-------------------------------------------------------*/
/* syntax : show_id_in_USR ##                            */
/*-------------------------------------------------------*/


#include "bbs.h"


static void
slot_show(uno, slot)
  int uno;
  SCHEMA *slot;
{
  printf("Slot: %d\nID: %s\nUptime: %s\n", uno, slot->userid, ctime(&slot->uptime));
}


int
main(argc, argv)
  int argc;
  char *argv[];
{
  char *str;
  SCHEMA slot;
  int uno;

  if (argc != 3)
  {
    str = argv[0];
    printf("Usage: %s -# userno\t�q�X�� user-no �����\n"
      "       %s -i userno\t�q�X�� user-id �����\n", str, str);

    return -1;
  }

  chdir(BBSHOME);

  str = argv[1] + 1;

  switch(*str)
  {
  case '#':
    uno = atoi(argv[2]);
    if (!rec_get(".USR", &slot, sizeof(SCHEMA), uno - 1))
      slot_show(uno, &slot);
    break;

  case 'i':
    uno = 0;
    str = argv[2];
    while (!rec_get(".USR", &slot, sizeof(SCHEMA), uno))
    {
      if (!strcasecmp(str, slot.userid))
      {
        slot_show(uno + 1, &slot);	/* �� n �� slot �O userno n+1 */
        break;
      }
      uno++;
    }
    break;
  }

  return 0;
}
