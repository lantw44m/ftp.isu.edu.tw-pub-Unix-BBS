<?php
//login.php �ǤJpid

require_once('config.php');
require_once('webbbs.class.php');

session_start();

$this_is_login = 0;

/* �Y�L�ǤJpid �N����! */
if(!$pid) {
	print "<html>���~���եΤ�k!</html>";
	exit;
}

/* session ���򥻳B�z */
if(!session_is_registered("cuser")) {
	$cuser = array();
	$cuser[pid] = $pid;
	$cuser[userid] = STR_GUEST;
	$cuser[passwd] = "";
	$cuser[level] = 0;
	$cuser[login] = "no";
	session_register("cuser");
}
else if($pid != $cuser[pid]) {
	$opid = $cuser[pid];	/* �O�Uopid, �n����� */
	$cuser[pid] = $pid;		/* autoLogin */
	$userid = $cuser[userid];
	$passwd = $cuser[passwd];
	$submit = 1;
}

/* �p�G�ݭn�n�� */
if($userid && $passwd && $submit) {
	$pid = $cuser[pid];

	$ws = new server_class;
	$ws->connect();

	$opid = intval($opid);
	$cmd = $ws->set_cmd("chg_usr", G_LOGIN, $pid, $userid, $passwd, $opid);
	$ws->query($cmd);
	$ret = $ws->parse();
	
	if($ret[result] == 'OK') {	/* �n�����\ */
		$cuser[pid] = intval($ret[pid]);
		$cuser[userno] = intval($ret[userno]);
		$cuser[userid] = $userid;
		$cuser[passwd] = $passwd;
		$cuser[level] = intval($ret[level]);	/* Server�A�ˬd, ���w�����D! */					
		$cuser[login] = 'ok';
		$this_is_login = 1;
	}
	else {
		session_unregister("cuser");
		unset($cuser);
		$ws->data .= "��ĳ�����s�����A���s�s��~";
		$ws->alert($ws->data);

		if(ereg('pid�L��', $ws->data)) {
			print "<html><script>top.document.location.reload();</script></html>";
		}
		exit;
	}
}

print "<!-- This Process ID: $cuser[pid] -->\n";
?>

<html>
<head>
<title>Login Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #000080}
A:hover {color: #000080}
BODY {BACKGROUND-COLOR: #d0f0c0; FONT-SIZE: 12px;}
</style>
<script language="JavaScript">
<!--
 function init()
 {
	 top.mainFrame.document.location.reload();
 }

 function closebut(x, y) {
	 if(document.img0) document.img0.src='images/folder.gif';
	 if(document.img1) document.img1.src='images/folder.gif';
	 if(document.img2) document.img2.src='images/folder.gif';
	 if(document.img3) document.img3.src='images/folder.gif';
	 if(document.img4) document.img4.src='images/folder.gif';
	 if(document.img5) document.img5.src='images/folder.gif';
	 if(document.all.div0) document.all.div0.style.display='none';
	 if(document.all.div1) document.all.div1.style.display='none';
	 if(document.all.div2) document.all.div2.style.display='none';
	 if(document.all.div3) document.all.div3.style.display='none';
	 if(document.all.div4) document.all.div4.style.display='none';
	 if(document.all.div5) document.all.div5.style.display='none';
	 x.style.display='block';
	 y.src='images/folder2.gif';
 }
 
 function t(x, y) {
	 if(x.style.display!='none') {
		 x.style.display='none';
		 y.src='images/folder.gif';
	 } 
	 else
		 closebut(x, y);
 }
//-->
</script>
<base target="mainFrame">
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" onLoad="init()">
<table width="119" border="0" cellspacing="0" cellpadding="0" height="100%" background="images/leftBg.jpg">
  <tr>
    <td valign="top" align="left">
<?php

if($cuser[login] != "ok") {
	print "
    <table border='0' width='100%' align='center'>
	<form action='$PHP_SELF' method='post' target='_self'>
	<tr><td><b>BBS�b���n��</b></td></tr>
	<tr><td>�b�� <input style='height:20px;' type='text' name='userid' maxlength='12' size='8' value='$userid'></td></tr>
	<tr><td>�K�X <input style='height:20px;' type='password' name='passwd' maxlength='12' size='8'></td></tr>
	<tr><td align='center'><input type='hidden' name='pid' value='$pid'>
	<input style='width:34px; height:22px; BACKGROUND-COLOR: #9CA4C8' onclick=\"top.mainFrame.document.location.href='register.php'\" type='button' name='register' value='���U'>
	<input style='width:34px; height:22px; BACKGROUND-COLOR: #9CA4C8' type='submit' name='submit' value='�n��'>
	</td></tr>
	</form>
	<tr><td><hr noshade size='1' color='#2020f0' width='100' align='left'></td></tr>
	</table>
	  ";
} else {
	print "
    <table border='0' width='100%' align='center'>
    <tr><td>�b��: <a href='query.php?userid=$cuser[userid]'>$cuser[userid]</a></td></tr>
	<tr><td>
	<hr noshade size='1' color='#000080' width='100' align='left'>
	<a href='logout.php' target='_self'>�n�X $cuser[userid]</a>
	<hr noshade size='1' color='#000080' width='100' align='left'>
	</td></tr>
		";

	if(!($cuser[level] & PERM_VALID))
		print "
			<tr><td><font color='red'>���q�L�����{��</font><br>
			<a href='fillform.php' target='mainFrame'>��g���U��?</a>
			<hr size='1' noshade color='#000080' width='100' align='left'>
			</td></tr>";

	print "
	</table>
	  ";
}

?> 
	<table border="0" width="100%" align="left">
	  <tr><td align="left">
	    <img src="images/file.gif" border="0"><a href="main.php">WebBBS����</a><br>
		<img src="images/file.gif" border="0"><a href="gem.php">A)��ؤ��G��</a><br>
		<img src="images/file.gif" border="0"><a href="class.php?chn=0">B)�G�i�Q�װ�</a><br>
		<img src="images/file.gif" border="0"><a href="board.php">C)�����Q�׶�</a><br>

		<img src="images/folder.gif" name="img1"><a href="#" onclick="t(document.all.div1, document.img1); return false;">�t�ί��Ȱ�<br>
		<div id="div1" style="font-size: 10pt; display:none">
		<img src="images/link.gif" border="0"><a href="enter.php"> �n���i��</a><br>
		<img src="images/link.gif" border="0"><a href="register.php"> ���U�b��</a><br>
		<img src="images/link.gif" border="0"><a href="topwelcome.php"> �i���e��</a><br>
		<img src="images/link.gif" border="0"><a href="toppost.php"> �������D</a><br>
		<img src="images/link.gif" border="0"><a href="topusr.php"> �ӤH�Ʀ�</a><br>
		<img src="images/link.gif" border="0"><a href="topcount.php"> �έp���</a><br>
		<img src="images/link.gif" border="0"><a href="active_board.php"> �ʺA�ݪO</a><br>
		</div>

		<img src="images/folder.gif" name="img2"><a href="#" onclick="t(document.all.div2, document.img2); return false;">�𶢲�Ѧa<br>
		<div id="div2" style="font-size: 10pt; display:none">
		<img src="images/link.gif" border="0"><a href="ulist.php"> ���U�|��</a><br>
		<img src="images/link.gif" border="0"><a href="xchat.php"> ��Ѽs��</a><br>
		<img src="images/link.gif" border="0"><a href="queryform.php"> �d�ߺ���</a><br>
		<img src="images/link.gif" border="0"><a href="pal_list.php"> ����n��</a><br>
		</div>

		<img src="images/folder.gif" name="img3"><a href="#" onclick="t(document.all.div3, document.img3); return false;">�ӤH�u��{<br>
		<div id="div3" style="font-size: 10pt; display:none">
		<img src="images/link.gif" border="0"><a href="personal.php?action=plans"> �ڪ��W����</a><br>
		<img src="images/link.gif" border="0"><a href="personal.php?action=myinfo"> �ڪ��p�ɮ�</a><br>
		<img src="images/link.gif" border="0"><a href="personal.php?action=sign"> �ڪ�ñ�W��</a><br>
		<img src="images/link.gif" border="0"><a href="personal.php?action=buf"> �ڪ��Ȧs��</a><br>
		<img src="images/link.gif" border="0"><a href="usetup.php"> �ק�ߺD</a><br>
		<img src="images/link.gif" border="0"><a href="personal.php?action=passwd"> �ק�K�X</a><br>
		</div>

		<img src="images/folder.gif" name="img4"><a href="#" onclick="t(document.all.div4, document.img4); return false;">�p�H�H���<br>
		<div id="div4" style="font-size: 10pt; display:none">
		<img src="images/link.gif" border="0"><a href="maillist.php"> �\Ū�l��</a><br>
		<img src="images/link.gif" border="0"><a href="sendmail.php"> �ѿO���y</a><br>
		<img src="images/link.gif" border="0"><a href="mail_internet.php"> ���F�Ǯ�</a><br>
		<img src="images/link.gif" border="0"><a href="mail_sysop.php"> ��ѯ���</a><br>
		</div>

		<img src="images/file.gif" border="0"><a href="find_board.php?pid=<?echo $pid;?>">�j�M�Q�װ�</a><br>
		<img src="images/file.gif" border="0"><a href="find_post.php?pid=<?echo $pid;?>">���Ť峹�j��</a><br>
		<img src="images/telnet.gif" border="0"><a href="telnet://210.70.137.5">Telnet�n��</a><br>
		<hr size="1" noshade>
	  </td></tr>
     </table>
	</td>
  </tr>
</table>
</body>
</html>
