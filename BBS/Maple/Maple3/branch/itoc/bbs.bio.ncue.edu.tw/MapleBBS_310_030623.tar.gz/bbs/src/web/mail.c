/*-------------------------------------------------------*/
/* mail.c       ( NTHU CS MapleBBS Ver 3.10 )            */
/*-------------------------------------------------------*/
/* target : local/internet mail routines                 */
/* create : 95/03/29                                     */
/* update : 02/11/05                                     */
/*-------------------------------------------------------*/


#include "web.h"

static int mailHold = 0;

extern UCACHE *ushm;
extern char *err_perm;


int
m_query(userid)
  char *userid;
{
  int fd, ans, fsize;
  HDR *head, *tail;
  char folder[64];
  struct stat st;

  ans = 0;
  usr_fpath(folder, userid, fn_dir);
  if ((fd = open(folder, O_RDONLY)) >= 0)
  {
    fsize = 0;

    if (!fstat(fd, &st) && (fsize = st.st_size) >= sizeof(HDR) &&
      (head = (HDR *) malloc(fsize)))
    {
      if ((fsize = read(fd, head, fsize)) >= sizeof(HDR))
      {
	tail = (HDR *) ((char *)head + fsize);

	while (--tail >= head)
	{
	  if (!(tail->xmode & MAIL_READ))
	  {
	    ans = UFO_BIFF;
	    break;
	  }
	}
      }
      free(head);
    }

    close(fd);
    if (fsize < sizeof(HDR))
      unlink(folder);
  }

  return ans;
}


/* ----------------------------- */
/* �H�H                          */
/* ----------------------------- */


int
mail_external(addr)
  char *addr;
{
  char *str;

  str = strchr(addr, '@');
  if (!str)
    return 0;

  /* Thor.990125: MYHOSTNAME�Τ@��J str_host */
  if (str_cmp(str_host, str + 1))
    return 1;

  /* �d�I xyz@domain �� xyz.bbs@domain */

  *str = '\0';
  if (str = strchr(addr, '.'))
    *str = '\0';
  return 0;
}


void
m_biff(userno)
  int userno;
{
  UTMP *utmp, *uceil;

  utmp = ushm->uslot;
  uceil = (void *)utmp + ushm->offset;
  do
  {
    if (utmp->userno == userno)
      utmp->ufo |= UFO_BIFF;
  } while (++utmp <= uceil);
}


/* ----------------------------------------------------- */
/* BBS (sendmail) SMT                                    */
/* ----------------------------------------------------- */


#ifdef USE_SENDMAIL
int
bbs_sendmail(fpath, title, receiver, method)
  char *fpath, *title, *receiver;
  int method;
{
  char genbuf[1024];
  FILE *fin, *fout;
  time_t chrono, stamp;
  char buf[512], from[80], subject[80], msgid[80];

#ifdef HAVE_SIGNED_MAIL
  char prikey[9];
  union
  {
    char str[9];
    struct
    {
      unsigned int hash, hash2;
    }      val;
  }     sign;

  *prikey = prikey[8] = sign.str[8] = '\0';	/* Thor.990413.����: �r�굲�� */
#endif

  cuser.numemail++;		/* �O���ϥΪ̦@�H�X�X�� Internet E-mail */
  chrono = time(&stamp);


  /* --------------------------------------------------- */
  /* �����{�ҫH��                                        */
  /* --------------------------------------------------- */

  if (method == MQ_JUSTIFY)	/* hightman.010128: email�`�U�ɤ~�Ϊ�.�n�A���@�ӵ{�ǡA
				   ��mailpost,bbsmail �M��ק�sendmail���t�m */
  {
    fpath = "etc/valid";
    title = subject;
    sprintf(from, "bbs@%s", MYHOSTNAME);
    archiv32(str_hash(receiver, chrono), buf);
    sprintf(title, TAG_VALID "%s(%s) [VALID]", cuser.userid, buf);
  }
  else
  {
    sprintf(from, "%s.bbs@%s", cuser.userid, MYHOSTNAME);
  }


  archiv32(chrono, msgid);	/* �ͦ�Message ID */

  sprintf(genbuf, "/usr/sbin/sendmail -f %s %s", from, receiver);

  fout = popen(genbuf, "w");
  fin = fopen(fpath, "r");
  if (fin == NULL || fout == NULL)
    return -1;

  fprintf(fout, "Return-Path: %s\r\n", from);
  fprintf(fout, "Reply-To: %s\r\n", from);
  fprintf(fout, "From: %s\r\n", from);
  fprintf(fout, "To: %s\r\n", receiver);
  fprintf(fout, "Subject: %s\r\n", title);
  fprintf(fout, "X-Forwarded-By: %s (%s)\r\n", cuser.userid, cuser.username);
  fprintf(fout, "MessageID: <%s>\r\n", msgid);
  fprintf(fout, "X-Disclaimer: [%s] �糧�H���e�����t�d�C\r\n", MYHOSTNAME);
  fprintf(fout, "Precedence: junk\r\n");
  if (method & MQ_JUSTIFY)	/* �����{�ҫH�� */
  {
    fprintf(fout, "ID: %s (%s)  E-mail: %s\r\n\r\n",
      cuser.userid, cuser.username, receiver);
  }

  while (fgets(genbuf, 255, fin) != NULL)
  {
    if (genbuf[0] == '.' && (genbuf[1] == '\n' || genbuf[1] == '\r'))
      /* hightman.011028: \r�]�����ڡA���i��O\r\n�O�C:p */
      fputs(". \r\n", fout);
    else
      fputs(genbuf, fout);
  }

#ifdef HAVE_SIGNED_MAIL
  if (!(method & MQ_JUSTIFY) && !rec_get(FN_RUN_PRIVATE, prikey, 8, 0))
    /* Thor.990413: ���F�{�Ҩ�~, ��L�H�󳣭n�[sign */
  {
    /* Thor.990413: buf�Τ���F, �ɨӥΥ� :P */
    sprintf(buf, "%s -> %s", cuser.userid, receiver);
    sign.val.hash = str_hash(buf, stamp);
    sign.val.hash2 = str_hash2(buf, sign.val.hash);
    str_xor(sign.str, prikey);
    /* Thor.990413: ���[()����, �ɶ����ťշ|�Q�Y��(���Ү�) */
    fprintf(fout, "�� X-Info: %s\r\n�� X-Sign: %s%s (%s)\r\n",
      buf, msgid, genpasswd(sign.str), Btime(&stamp));
  }
#endif

  fprintf(fout, ".\r\n\r\n");

  fclose(fin);
  pclose(fout);

  /* --------------------------------------------------- */
  /* �O���H�H                                            */
  /* --------------------------------------------------- */

  sprintf(buf, "%s%-13s%c> %s %s %s\n\t%s\n\t%s\n", Btime(&stamp), cuser.userid,
    ((method == MQ_JUSTIFY) ? '=' : '-'), receiver, msgid,

#ifdef HAVE_SIGNED_MAIL
    *prikey ? genpasswd(sign.str) : "NoPriKey",
#else
    "",
#endif

    title, fpath);
  f_cat("run/mail.log", buf);

  return chrono;
}

#else
/* ----------------------------------------------------- */
/* BBS (batch) SMTP                                      */
/* ----------------------------------------------------- */


#ifdef  BATCH_SMTP
int
bsmtp(fpath, title, rcpt, method)
  char *fpath, *title, *rcpt;
  int method;
{
  char buf[80];
  time_t chrono;
  MailQueue mqueue;

  chrono = time(NULL);

  /* ���~�d�I */

  if (method != MQ_JUSTIFY)
  {
    /* stamp the queue file */

    strcpy(buf, "out/");

    for (;;)
    {
      archiv32(chrono, buf + 4);
      if (!f_ln(fpath, buf))
	break;
      chrono++;
    }
    fpath = buf;

    strcpy(mqueue.filepath, fpath);
    strcpy(mqueue.subject, title);
  }

  /* setup mail queue */

  mqueue.mailtime = chrono;
  mqueue.method = method;
  strcpy(mqueue.sender, cuser.userid);
  strcpy(mqueue.username, cuser.username);
  strcpy(mqueue.rcpt, rcpt);
  if (rec_add(MAIL_QUEUE, &mqueue, sizeof(mqueue)) < 0)
    return -1;

  cuser.numemail++;		/* �O���ϥΪ̦@�H�X�X�� Internet E-mail */
  return chrono;
}

#else

/* ----------------------------------------------------- */
/* (direct) SMTP                                         */
/* ----------------------------------------------------- */


int
bsmtp(fpath, title, rcpt, method)
  char *fpath, *title, *rcpt;
  int method;
{
  int sock;
  time_t chrono, stamp;
  FILE *fp, *fr, *fw;
  char *str, buf[512], from[80], subject[80], msgid[80];

#ifdef HAVE_SIGNED_MAIL
  char prikey[9];
  union
  {
    char str[9];
    struct
    {
      unsigned int hash, hash2;
    }      val;
  }     sign;

  *prikey = prikey[8] = sign.str[8] = '\0';	/* Thor.990413.����: �r�굲�� */
#endif

  cuser.numemails++;		/* �O���ϥΪ̦@�H�X�X�� Internet E-mail */
  chrono = time(&stamp);

  /* --------------------------------------------------- */
  /* �����{�ҫH��                                        */
  /* --------------------------------------------------- */

  if (method == MQ_JUSTIFY)
  {
    fpath = "etc/valid";
    title = subject;
    sprintf(from, "bbsreg@%s", MYHOSTNAME);
    archiv32(str_hash(rcpt, chrono), buf);
    /* sprintf(title, "[MapleBBS]To %s(%s) [VALID]", cuser.userid, buf); */
    /* Thor.981012: �����b config.h �޲z */
    sprintf(title, TAG_VALID "%s(%s) [VALID]", cuser.userid, buf);
  }
  else
  {
    sprintf(from, "%s.bbs@%s", cuser.userid, MYHOSTNAME);
  }

  str = strchr(rcpt, '@') + 1;
  sock = dns_smtp(str);
  if (sock >= 0)
  {
    archiv32(chrono, msgid);

    sleep(1);			/* wait for mail server response */

    fr = fdopen(sock, "r");
    fw = fdopen(sock, "w");

    fgets(buf, sizeof(buf), fr);
    if (memcmp(buf, "220", 3))
      goto smtp_error;
    if (buf[3] == '-')
      fgets(buf, sizeof(buf), fr);

    fprintf(fw, "HELO %s\r\n", MYHOSTNAME);
    fflush(fw);
    do
    {
      fgets(buf, sizeof(buf), fr);
      if (memcmp(buf, "250", 3))
	goto smtp_error;
    } while (buf[3] == '-');

    fprintf(fw, "MAIL FROM:<%s>\r\n", from);
    fflush(fw);
    do
    {
      fgets(buf, sizeof(buf), fr);
      if (memcmp(buf, "250", 3))
	goto smtp_error;
    } while (buf[3] == '-');

    fprintf(fw, "RCPT TO:<%s>\r\n", rcpt);
    fflush(fw);
    do
    {
      fgets(buf, sizeof(buf), fr);
      if (memcmp(buf, "250", 3))
	goto smtp_error;
    } while (buf[3] == '-');

    fprintf(fw, "DATA\r\n", rcpt);
    fflush(fw);
    do
    {
      fgets(buf, sizeof(buf), fr);
      if (memcmp(buf, "354", 3))
	goto smtp_error;
    } while (buf[3] == '-');

    /* ------------------------------------------------- */
    /* begin of mail header                              */
    /* ------------------------------------------------- */

    fprintf(fw, "From: %s\r\nTo: %s\r\nSubject: %s\r\nX-Sender: %s (%s)\r\n"
      "MessageID: <%s>\r\nX-Disclaimer: [%s] �糧�H���e�����t�d\r\n\r\n",
      from, rcpt, title, cuser.userid, cuser.username, msgid, str_site);

    if (method & MQ_JUSTIFY)	/* �����{�ҫH�� */
    {
      fprintf(fw, " ID: %s (%s)  E-mail: %s\r\n\r\n",
	cuser.userid, cuser.username, rcpt);
    }

    /* ------------------------------------------------- */
    /* begin of mail body                                */
    /* ------------------------------------------------- */

    if (fp = fopen(fpath, "r"))
    {
      char *ptr;

      str = buf;
      *str++ = '.';
      while (fgets(str, sizeof(buf) - 3, fp))
      {
	if (ptr = strchr(str, '\n'))
	{
	  *ptr++ = '\r';
	  *ptr++ = '\n';
	  *ptr = '\0';
	}
	fputs((*str == '.' ? buf : str), fw);
      }
      fclose(fp);
    }

#ifdef HAVE_SIGNED_MAIL
    if (!(method & MQ_JUSTIFY) && !rec_get(FN_RUN_PRIVATE, prikey, 8, 0))
      /* Thor.990413: ���F�{�Ҩ�~, ��L�H�󳣭n�[sign */
    {
      /* Thor.990413: buf�Τ���F, �ɨӥΥ� :P */
      sprintf(buf, "%s -> %s", cuser.userid, rcpt);
      sign.val.hash = str_hash(buf, stamp);
      sign.val.hash2 = str_hash2(buf, sign.val.hash);
      str_xor(sign.str, prikey);
      /* Thor.990413: ���[()����, �ɶ����ťշ|�Q�Y��(���Ү�) */
      fprintf(fw, "�� X-Info: %s\r\n�� X-Sign: %s%s (%s)\r\n",
	buf, msgid, genpasswd(sign.str), Btime(&stamp));
    }
#endif

    fputs("\r\n.\r\n", fw);
    fflush(fw);

    fgets(buf, sizeof(buf), fr);
    if (memcmp(buf, "250", 3))
      goto smtp_error;

    fputs("QUIT\r\n", fw);
    fflush(fw);
    fclose(fw);
    fclose(fr);
    goto smtp_log;

smtp_error:

    fclose(fr);
    fclose(fw);
    sprintf(msgid + 7, "\n\t%.70s", buf);
    chrono = -1;
  }
  else
  {
    chrono = -1;
    strcpy(msgid, "CONN");
  }

smtp_log:

  /* --------------------------------------------------- */
  /* �O���H�H                                            */
  /* --------------------------------------------------- */

  sprintf(buf, "%s%-13s%c> %s %s %s\n\t%s\n\t%s\n", Btime(&stamp), cuser.userid,
    ((method == MQ_JUSTIFY) ? '=' : '-'), rcpt, msgid,

#ifdef HAVE_SIGNED_MAIL
    *prikey ? genpasswd(sign.str) : "NoPriKey",
#else
    "",
#endif

    title, fpath);
  f_cat("run/mail.log", buf);

  return chrono;
}
#endif

#endif


static void
mail_hold(fpath, rcpt)		/* �Ƨѿ� */
  char *fpath;
  char *rcpt;
{
  char *title, folder[80], buf[256];
  HDR mhdr;

  if (!mailHold)
    return;			/* �ɥάݬݬO�_�n�s�ƥ� */

  usr_fpath(folder, cuser.userid, fn_dir);	/* = cmbox.dir; */
  hdr_stamp(folder, HDR_LINK, &mhdr, fpath);

  mhdr.xmode = MAIL_READ | MAIL_HOLD /* | MAIL_NOREPLY */ ;
  strcpy(mhdr.owner, "[�� �� ��]");
  strcpy(mhdr.nick, cuser.username);
  title = ve_title + 7;
  if (rcpt)
  {
    sprintf(buf, "<%s> %s", rcpt, title);
    title = buf;
    title[TTLEN] = '\0';
  }
  strcpy(mhdr.title, title);
  rec_add(folder, &mhdr, sizeof(HDR));
}


static int
mail_send(rcpt)
  char *rcpt;
{
  HDR mhdr;
  char fpath[80], folder[80], *title;
  int rc, userno;
  int internet_mail;

  if (!(internet_mail = mail_external(rcpt)))
  {
    if ((userno = acct_userno(rcpt)) <= 0)
      msg_quit("�����T�����H�H/�a�}�I");
  }

  article_edit();
  title = ve_title + 7;		/* ������D */
  usr_fpath(fpath, cuser.userid, ".tmp");

  if (internet_mail)
  {

#ifdef USE_SENDMAIL
    rc = bbs_sendmail(fpath, title, rcpt, 0);	/* bsmtp(fpath, title, rcpt,
						 * 0); */
#else
    rc = bsmtp(fpath, title, rcpt, 0);
#endif

    mail_hold(fpath, rcpt);
    unlink(fpath);
    if (rc < 0)
      msg_quit("�藍�_�A�H��L�k�H�F!");
    www_printf("result=OK&msg=�H�󦨥\\�H��%s�F\n", rcpt);
    return rc;
  }


  usr_fpath(folder, rcpt, fn_dir);
  hdr_stamp(folder, HDR_LINK, &mhdr, fpath);
  strcpy(mhdr.owner, cuser.userid);
  strcpy(mhdr.nick, cuser.username);
  strcpy(mhdr.title, title);
  rc = rec_add(folder, &mhdr, sizeof(mhdr));
  if (!rc)
    mail_hold(fpath, rcpt);

  unlink(fpath);
  m_biff(userno);
  www_printf("result=OK&msg=�H�󦨥\\�H��%s�F\n", rcpt);
  return rc;
}


static int 
m_send()
{
  char *ptr, *rcpt;

  ptr = acct_locate();
  rcpt = nextword(&ptr);

  if (!mail_external(rcpt))
  {
    if (!cuser.userlevel || HAS_PERM(PERM_DENYMAIL))
      msg_quit(err_perm);
    if (acct_userno(rcpt) <= 0)
      msg_quit("�����T�����H�H/�a�}�I");
  }
  else				/* �~���l�� xxx@yy.net */
  {
    mailHold = atoi(nextword(&ptr));	/* �ɥΥ��ݬݬO�_�n�s�ƥ� */
  }

  return mail_send(rcpt);
}


/* ----------------------------------------------------- */
/* User MailBox list				 	 */
/* ----------------------------------------------------- */


extern char xo_pool[];
static int mbox_body();

static int
mbox_init(xo)
  SXO *xo;
{
  xo_load(xo, sizeof(HDR));
  return mbox_body(xo);
}


static inline int
mbox_attr(type)
  int type;
{
  if (type & MAIL_DELETE)
    return 'D';

  if (type & MAIL_REPLIED)
    return (type & MAIL_MARKED) ? 'R' : 'r';

  return "+ Mm"[type & 3];
}


static inline void
mbox_item(pos, hdr)
  int pos;			/* sequence number */
  HDR *hdr;
{
  static char *type[2] = {"Re", "��"};
  int ch, len, i;
  uschar *title, *mark, *date, author[13];

  int xmode = hdr->xmode;

  date = hdr->date + 3;

  /* �B�zauthor */
  mark = hdr->owner;
  len = 13;
  i = 0;

  while (ch = *mark)
  {
    if ((--len == 0) || (ch == '@'))
      ch = '.';
    author[i++] = ch;

    if (ch == '.')
      break;

    mark++;
  }

  author[i] = '\0';

  /* �B�ztitle */
  title = str_ttl(mark = hdr->title);
  ch = (title == mark);		/* �O�_�u���۵��O? */

  /* ��X */
  www_printf(xmode & MAIL_DELETE ? "num=%d&attr=\033[0;5;37;41m%c\033[m"
    : xmode & MAIL_MARKED ? "num=%d&attr=\033[0;36m%c\033[m"
    : "num=%d&attr=%c", pos, mbox_attr(hdr->xmode));

  www_printf("&author=%s&date=%s&type=%s&title=%s&noreply=%d\n", author, date, type[ch], title, (xmode & MAIL_NOREPLY));
}


static int
mbox_body(xo)
  SXO *xo;
{
  HDR *mhdr;
  int num, max, tail;

  max = xo->max;
  if (max <= 0)
    www_printf("�z�S���ӫH��~\n");
  else
    www_printf("result=OK&max=%d&page=%d\n", xo->max, xo->page);

  num = xo->top;
  mhdr = (HDR *) xo_pool;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  do
  {
    mbox_item(++num, mhdr++);
  } while (num < max);

  return XO_NONE;
}


static int 
m_list()			/* mail List pid:page */
{
  char *ptr;
  char fpath[80];
  int page;
  SXO *xo;

  ptr = acct_locate();

  if (!cuser.userlevel)
    msg_quit(err_perm);

  page = atoi(nextword(&ptr));

  usr_fpath(fpath, cuser.userid, fn_dir);
  xo = xo_new(fpath);
  xo->page = page;

  mbox_init(xo);

  free(xo);

  return 1;
}


/* ------------------------------------------------ */
/* Read Special Mail				    */
/* ------------------------------------------------ */


static int
mail_read(num)
  int num;
{
  char fpath[80];
  HDR mhdr;
  int fd;

  usr_fpath(fpath, cuser.userid, fn_dir);

  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    int max, nxt, prv;
    struct stat st;
    char folder[80];

    nxt = prv = 0;

    fstat(fd, &st);
    max = st.st_size / sizeof(HDR);
    if (max <= 0)
      msg_quit("Ū�g���~�A�z�èS���ӫH�I");

    if (num > max)
      num = max;
    if (num < max)
      nxt = num + 1;
    if (num > 1)
      prv = num - 1;

    num = num - 1;		/* ����-1 */

    memset(&mhdr, 0, sizeof(HDR));

    lseek(fd, (off_t) (sizeof(HDR) * num), SEEK_SET);
    read(fd, &mhdr, sizeof(HDR));
    close(fd);

    mhdr.xmode |= MAIL_READ;
    rec_put(fpath, &mhdr, sizeof(HDR), num, NULL);

    www_printf("result=OK&max=%d&nxt=%d&prv=%d&noreply=%d\n\n", max, nxt, prv, (mhdr.xmode & MAIL_NOREPLY));

    hdr_fpath(folder, fpath, &mhdr);
    return article_show(folder);
  }
  else
    msg_quit("���}�H�c�ɵo�Ϳ��~!");

  return 1;
}


static int 
m_read()
{
  char *ptr;
  int num;

  ptr = acct_locate();

  if (!cuser.userlevel)
    msg_quit(err_perm);

  num = atoi(nextword(&ptr));
  if (num < 1)
    num = 1;

  return mail_read(num);
}


/* ------------------------------------------------ */
/* �ި��B�z					    */
/* ------------------------------------------------ */

#define	QUOTE_CHAR	'>'


/* ------------------------------------------------ */
/* Reply Special Mail				    */
/* ------------------------------------------------ */


static int
mail_reply(num)
  int num;
{
  char fpath[80];
  HDR mhdr;

  usr_fpath(fpath, cuser.userid, fn_dir);

  num = num - 1;		/* �O�o��1��~�O�u����m�� */
  memset(&mhdr, 0, sizeof(HDR));

  if (!rec_get(fpath, &mhdr, sizeof(HDR), num))
  {

    if (mhdr.xmode & MAIL_NOREPLY)
      msg_quit("���~�A�ӫH����^�_!");

    if (!mail_external(mhdr.owner))
    {
      if (acct_userno(mhdr.owner) <= 0)
	msg_quit("���~�A���_�����H�H/�a�}!");
    }


    mhdr.xmode |= MAIL_READ;
    mhdr.xmode |= MAIL_REPLIED;

    rec_put(fpath, &mhdr, sizeof(HDR), num, NULL);

    www_printf("result=OK&receiver=%s&noreply=%d&title=%s\n\n",
      mhdr.owner, (mhdr.xmode & MAIL_NOREPLY), mhdr.title);
    quote_edit(fpath, &mhdr);
  }
  else
    msg_quit("���~�A���s�b���H��!");

  return 1;
}


static int 
m_reply()
{
  char *ptr;
  int num;

  ptr = acct_locate();

  if (!cuser.userlevel || HAS_PERM(PERM_DENYMAIL))
    msg_quit(err_perm);

  num = atoi(nextword(&ptr));
  if (num < 1)
    num = 1;

  return mail_reply(num);
}


/* ------------------------------------------------ */
/* Delete Special Mail				    */
/* ------------------------------------------------ */


int
cmpchrono(hdr)
  HDR *hdr;
{
  return hdr->chrono == currchrono;
}


static int 
m_delete()
{
  char *ptr;
  int num;

  ptr = acct_locate();

  if (!cuser.userlevel)
    msg_quit(err_perm);

  num = atoi(nextword(&ptr));
  if (num < 1)
    num = 1;

  num = num - 1;

  /* �}�l�ާ@ */
  {
    char fpath[80];
    HDR mhdr;

    usr_fpath(fpath, cuser.userid, fn_dir);

    if (!rec_get(fpath, &mhdr, sizeof(HDR), num))
    {
      int xmode;

      xmode = mhdr.xmode;
      if ((xmode & (MAIL_MARKED | MAIL_DELETE)) == MAIL_MARKED)
	msg_quit("�ӫH��аO�����i�R��!");

      currchrono = mhdr.chrono;
      if (!rec_del(fpath, sizeof(HDR), num, cmpchrono))
      {
	char folder[80];

	hdr_fpath(folder, fpath, &mhdr);
	unlink(folder);
      }
    }
    www_printf("result=OK\n");
  }

  return 1;
}


/* ------------------------------------------------ */
/* Mark Special Mail				    */
/* ------------------------------------------------ */


static int 
m_mark()
{
  char *ptr;
  int num;

  ptr = acct_locate();

  if (!cuser.userlevel)
    msg_quit(err_perm);

  num = atoi(nextword(&ptr));
  if (num < 1)
    num = 1;

  num = num - 1;

  /* �}�l�ާ@ */
  {
    char fpath[80];
    HDR mhdr;

    usr_fpath(fpath, cuser.userid, fn_dir);

    if (!rec_get(fpath, &mhdr, sizeof(HDR), num))
    {
      mhdr.xmode ^= MAIL_MARKED;
      rec_put(fpath, &mhdr, sizeof(HDR), num, NULL);
    }
    www_printf("result=OK\n");
  }

  return 1;
}


WebKeyFunc mail_cb[] =
{
  {"m_send", m_send},
  {"m_list", m_list},
  {"m_read", m_read},
  {"m_reply", m_reply},
  {"m_delete", m_delete},
  {"m_mark", m_mark},
  {NULL, NULL}
};
