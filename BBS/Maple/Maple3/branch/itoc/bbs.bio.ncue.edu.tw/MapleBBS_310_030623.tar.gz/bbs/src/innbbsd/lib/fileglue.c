#include <varargs.h>

/*
  The same as sprintf, but fileglue return the new string
  fileglue("%s/%s", home, ".newsrc");
*/

char *
fileglue(va_alist)
va_dcl
{
  va_list ap;
  register char *fmt;
  static char gluebuffer[256];

  va_start(ap);
  fmt = va_arg(ap, char *);
  vsprintf(gluebuffer, fmt, ap);
  va_end(ap);
  return gluebuffer;
}
