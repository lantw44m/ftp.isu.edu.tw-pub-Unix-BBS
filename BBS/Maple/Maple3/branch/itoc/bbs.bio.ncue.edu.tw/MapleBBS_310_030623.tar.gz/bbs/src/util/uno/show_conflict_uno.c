/*-------------------------------------------------------*/
/* util/show_conflict_uno.c( NTHU CS MapleBBS Ver 3.00 ) */
/*-------------------------------------------------------*/
/* target : �⦬���Ӫ� user no. list ²����R            */
/* create :   /  /                                       */
/* update :   /  /                                       */
/* author : ernie@bbs.ee.nthu.edu.tw                     */
/*-------------------------------------------------------*/
/* syntax : show_conflict_uno	                         */
/*-------------------------------------------------------*/


#include "bbs.h"


int
main()
{
  char pool[20001][13];		/* ���] 20000 �ӨϥΪ̤w���� */
  int total, max, mynum;
  char buf[21], *myname, *ptr;
  FILE *fp;

  memset(pool, 0, sizeof(pool));
  total = max = 0;

  chdir(BBSHOME);

  if (fp = fopen("tmp/all_user_uno", "r"))
  {
    while (fgets(buf, 20, fp))
    {
      ptr = buf;
      ptr[5] = 0;

      mynum = atoi(ptr);
      if (mynum >= max)
	max = mynum;


      ptr += 6;
      myname = ptr++;
      while (*ptr)
      {
	if (*ptr == '\n' || *ptr == ' ')
	{
	  *ptr = 0;
	  break;
	}
	ptr++;
      }

      if (pool[mynum][0])
      {
	printf("%d %s <====> %s\n", mynum, pool[mynum], myname);
      }
      else
      {
	sprintf(pool[mynum], "%s", myname);
	total++;
      }
    }
    fclose(fp);
  }

#if 0
  for (mynum = 1; mynum <= max; mynum++)
  {
    if (!pool[mynum][0])
      printf("%d is null\n", mynum);
  }
#endif

  printf("\ntotal: %d\nmax uno: %d\n", total, max);
  return 0;
}
