/*-------------------------------------------------------*/
/* newbrd.c   ( YZU_CSE WindTop BBS )                    */
/*-------------------------------------------------------*/
/* target : �s�p�\��    			 	 */
/* create : 00/01/02				 	 */
/* update : 02/04/29				 	 */
/*-------------------------------------------------------*/
/* run/newbrd/_/.DIR - newbrd control header		 */
/* run/newbrd/_/@/@_ - newbrd description file		 */
/* run/newbrd/_/@/G_ - newbrd voted id loG file		 */
/*-------------------------------------------------------*/


#include "bbs.h"


#ifdef HAVE_COSIGN

extern XZ xz[];
extern char xo_pool[];
extern BCACHE *bshm;		/* itoc.010805: �}�s�O�� */

static int nbrd_add();
static int nbrd_body();
static int nbrd_head();


typedef struct
{
  char userid[IDLEN + 1];
  char email[60];
}      LOG;


static char
nbrd_attr(nbrd)
  NBRD *nbrd;
{
  char ch;

  if (nbrd->mode & NBRD_REJECT)
    ch = 'R';
  else if (nbrd->mode & NBRD_CLOSE)
    ch = 'C';
  else if (nbrd->mode & NBRD_STOP)
    ch = 'S';
  else if (nbrd->mode & NBRD_OPEN)
    ch = 'O';
  else if (nbrd->mode & NBRD_OK)
    ch = 'Y';
  else if (nbrd->mode & NBRD_START)
    ch = ' ';
  else
    ch = 'N';

  return ch;
}


static int
nbrd_stamp(folder, nbrd, fpath)
  char *folder;
  NBRD *nbrd;
  char *fpath;
{
  char *fname;
  char *family = NULL;
  int rc;
  int token;

  fname = fpath;
  while (rc = *folder++)
  {
    *fname++ = rc;
    if (rc == '/')
      family = fname;
  }

  fname = family;
  *family++ = '@';

  token = time(0);

  archiv32(token, family);

  rc = open(fpath, O_WRONLY | O_CREAT | O_EXCL, 0600);
  memset(nbrd, 0, sizeof(NBRD));
  nbrd->btime = token;
  str_stamp(nbrd->date, &nbrd->btime);
  strcpy(nbrd->xname, fname);
  return rc;
}


static void
nbrd_fpath(fpath, folder, nbrd)
  char *fpath;
  char *folder;
  NBRD *nbrd;
{
  char *str = NULL;
  int cc;

  while (cc = *folder++)
  {
    *fpath++ = cc;
    if (cc == '/')
      str = fpath;
  }
  strcpy(str, nbrd->xname);
}


static int
nbrd_init(xo)
  XO *xo;
{
  xo_load(xo, sizeof(NBRD));
  return nbrd_head(xo);
}


static int
nbrd_load(xo)
  XO *xo;
{
  xo_load(xo, sizeof(NBRD));
  return nbrd_body(xo);
}


static void
nbrd_item(num, nbrd)
  int num;
  NBRD *nbrd;
{
  if (nbrd->mode & NBRD_NBRD)
    prints("%6d %c %-5s %-13s %-13s:%-22.22s\n", 
      num, nbrd_attr(nbrd), nbrd->date + 3, nbrd->owner, nbrd->brdname, nbrd->title);
  else if (nbrd->mode & NBRD_OBRD)
    /* �Ϲ�}�s�O���^��զW������}�s�O���^��O�W�[�W - �� */
    prints("%6d %c %-5s %-13s -%-12s:%-22.22s\n", 
      num, nbrd_attr(nbrd), nbrd->date + 3, nbrd->owner, nbrd->brdname, nbrd->title);
  else if (nbrd->mode & NBRD_CANCEL)
    prints("%6d %c %-5s %-13s �o�� %s �O�O�D\n", 
      num, nbrd_attr(nbrd), nbrd->date + 3, nbrd->owner, nbrd->brdname);
  else
    prints("%6d %c %-5s %-13s %-36.36s\n", 
      num, nbrd_attr(nbrd), nbrd->date + 3, nbrd->owner, nbrd->title);
}


static int
nbrd_body(xo)
  XO *xo;
{
  NBRD *nbrd;
  int num, max, tail;

  max = xo->max;
  if (max <= 0)
  {
    if (vans("�n�s�W�s�p���ض�(Y/N)�H[N] ") == 'y')
      return nbrd_add(xo);
    return XO_QUIT;
  }

  nbrd = (NBRD *) xo_pool;
  num = xo->top;
  tail = num + XO_TALL;

  if (max > tail)
    max = tail;

  move(3, 0);  
  do
  {
    nbrd_item(++num, nbrd++);
  } while (num < max);
  clrtobot();

  /* return XO_NONE; */
  return XO_FOOT;	/* itoc.010403: �� b_lines ��W feeter */
}


static int
nbrd_head(xo)
  XO *xo;
{
  vs_head("�s�p�t��", str_site);
  outs(NECKER_COSIGN);
  return nbrd_body(xo);
}


static int
nbrd_find(xo, ptr, mode)
  XO *xo;
  char *ptr;
  int mode;
{
  int fd;
  int pos = 0;
  NBRD nbrd;

  fd = open(xo->dir, O_RDONLY);

  while (fd)
  {
    lseek(fd, (off_t) (sizeof(NBRD) * pos), SEEK_SET);
    if (read(fd, &nbrd, sizeof(NBRD)) == sizeof(NBRD))
    {
      if (!str_cmp(nbrd.brdname, ptr) && 
        !(nbrd.mode & (NBRD_REJECT | NBRD_STOP | NBRD_CLOSE | NBRD_OPEN)) && (nbrd.mode & mode))
      {
        close(fd);
	return 1;
      }
      pos++;
    }
    else
      break;
  }
  close(fd);
  return 0;
}


static int
nbrd_add(xo)
  XO *xo;
{
  int fd, mode, days, numbers;
  char *dir, fpath[80], path[80], tmp[10];
  char brdname[IDLEN + 1], title[49];
  FILE *fp;
  NBRD nbrd;
  time_t now, etime;

  if (HAS_PERM(PERM_ALLADMIN))
  {
    mode = vans("�s�p�Ҧ� 1)�}�s�O 2)�Ϲ�}�s�O 3)�o�O�D 4)�O�W 5)�L�O�W�G[Q] ") - '0';
    if (mode < 1 || mode > 5)
      return xo->max ? XO_FOOT : nbrd_body(xo);	/* itoc.020122: �p�G�S������s�p�A�n�^�� nbrd_body() */
  }
  else if (HAS_PERM(PERM_POST))
  {
    mode = vans("�s�p�Ҧ� 1)�}�s�O 2)�Ϲ�}�s�O 3)�o�O�D�G[Q] ") - '0';
    if (mode < 1 || mode > 3)
      return xo->max ? XO_FOOT : nbrd_body(xo);	/* itoc.020122: �p�G�S������s�p�A�n�^�� nbrd_body() */
  }
  else
  {
    vmsg("�藍�_�A���ݪO�O��Ū��");
    return XO_FOOT;
  }

  if (mode == 1)
  {
    if (!vget(b_lines, 0, "�^��O�W�G", brdname, sizeof(nbrd.brdname), DOECHO))
      return XO_FOOT;

    if (brd_bno(brdname) >= 0)
    {
      vmsg("�w�����O");
      return XO_FOOT;
    }

    if (!valid_brdname(brdname))	/* itoc.020726: �ˬd�O�W�O�_�X�k */
    {
      vmsg("�O�W���X�k");
      return XO_FOOT;
    }

    if (nbrd_find(xo, brdname, NBRD_NBRD))
    {
      vmsg("���b�s�p��");
      return XO_FOOT;
    }

    if (!vget(b_lines, 0, "�ݪO�D�D�G", title, sizeof(nbrd.title), DOECHO))
      return XO_FOOT;
  }
  else if (mode == 2)
  {
    if (!vget(b_lines, 0, "�^��O�W�G", brdname, sizeof(nbrd.brdname), DOECHO))
      return XO_FOOT;

    if (brd_bno(brdname) >= 0)
    {
      vmsg("�w�����O");
      return XO_FOOT;
    }

    if (!nbrd_find(xo, brdname, NBRD_NBRD))
    {
      vmsg("���O�èS���b�s�p");
      return XO_FOOT;
    }

    if (nbrd_find(xo, brdname, NBRD_OBRD))
    {
      vmsg("���b�s�p��");
      return XO_FOOT;
    }

    if (!vget(b_lines, 0, "�ݪO�D�D�G", title, sizeof(nbrd.title), DOECHO))
      return XO_FOOT;
  }
  else if (mode == 3)
  {
    if (!vget(b_lines, 0, "�^��O�W�G", brdname, sizeof(nbrd.brdname), DOECHO))
      return XO_FOOT;

    if (brd_bno(brdname) < 0)
    {
      vmsg("�L���O");
      return XO_FOOT;
    }

    if (nbrd_find(xo, brdname, NBRD_CANCEL))
    {
      vmsg("���b�s�p��");
      return XO_FOOT;
    }
  }
  else if (mode == 4 || mode == 5)
  {
    if (!vget(b_lines, 0, "�s�p�D�D�G", title, sizeof(nbrd.title), DOECHO))
      return XO_FOOT;

    /* �s�p����̦h 30 �ѡA�s�p�H�Ƴ̦h 500 �H */
    if (!vget(b_lines, 0, "�s�p�ѼơG", tmp, 5, DOECHO))
      return XO_FOOT;
    days = atoi(tmp);
    if (days > 30 || days < 1)
      return XO_FOOT;
    if (!vget(b_lines, 0, "�s�p�H�ơG", tmp, 6, DOECHO))
      return XO_FOOT;
    numbers = atoi(tmp);
    if (numbers > 500 || numbers < 1)
      return XO_FOOT;
  }

  dir = xo->dir;
  fd = nbrd_stamp(dir, &nbrd, fpath);
  if (fd < 0)
    return nbrd_head(xo);
  close(fd);

  sprintf(path, "tmp/%s.nbrd", cuser.userid);	/* �s�p��]���Ȧs�ɮ� */

  if (mode == 1)
  {
    vmsg("�}�l�s�� [�ݪO�����P�O�D��t]");
    fd = vedit(path, 0);
    if (fd)
    {
      unlink(fpath);
      vmsg(MSG_CANCEL);
      return nbrd_head(xo);
    }
    nbrd.etime = nbrd.btime + NBRD_DAY_BRD * 86400;
    time(&now);
    fp = fopen(fpath, "a+");
    fprintf(fp, "�@��: %s (%s) ����: �ݪO�s�p\n", cuser.userid, cuser.username);
    fprintf(fp, "���D: [�ݪO�s�p] %s\n", brdname);
    fprintf(fp, "�ɶ�: %s\n", ctime(&now));
    fprintf(fp, "-----------------------------------------------------------\n");
    fprintf(fp, "�^��O�W�G%s\n", brdname);
    fprintf(fp, "�ݪO�D�D�G%s\n", title);
    fprintf(fp, "�|�����G%s\n", nbrd.date);
    fprintf(fp, "����ѼơG%d\n", NBRD_DAY_BRD);
    fprintf(fp, "�O�D�W�١G%s\n", cuser.userid);
    fprintf(fp, "�q�l�l��H�c�G%s\n", cuser.email);
    fprintf(fp, "�ݳs�p�H�ơG%d\n", NBRD_NUM_BRD);
    fprintf(fp, "-----------------------------------------------------------\n");
    fprintf(fp, "�O�D��t�G\n");
    f_suck(fp, path);
    unlink(path);
    fprintf(fp, "\n");
  }
  else if (mode == 2)
  {
    nbrd.etime = nbrd.btime + NBRD_DAY_BRD * 86400;
    time(&now);
    fp = fopen(fpath, "a+");
    fprintf(fp, "�@��: %s (%s) ����: �ݪO�s�p\n", cuser.userid, cuser.username);
    fprintf(fp, "���D: [�Ϲ�}�O�s�p] %s\n", brdname);
    fprintf(fp, "�ɶ�: %s\n", ctime(&now));
    fprintf(fp, "-----------------------------------------------------------\n");
    fprintf(fp, "�O�W�G%s\n", brdname);
    fprintf(fp, "�ݪO�D�D�G%s\n", title);
    fprintf(fp, "�|�����G%s\n", nbrd.date);
    fprintf(fp, "����ѼơG%d\n", NBRD_DAY_BRD);
    fprintf(fp, "�O�D�W�١G%s\n", cuser.userid);
    fprintf(fp, "�q�l�l��H�c�G%s\n", cuser.email);
    fprintf(fp, "�ݳs�p�H�ơG%d\n", NBRD_NUM_BRD);
    fprintf(fp, "-----------------------------------------------------------\n");
    fprintf(fp, "\n\033[1;31m[�`�N] \033[33m���B�s�p���Ϲ�}�O�A�N�İΦW�覡�I\033[m\n\n");
  }
  else if (mode == 3)
  {
    vmsg("�}�l�s�� [�o�O�D��]]");
    fd = vedit(path, 0);
    if (fd)
    {
      unlink(fpath);
      vmsg(MSG_CANCEL);
      return nbrd_head(xo);
    }
    nbrd.etime = etime = nbrd.btime + NBRD_DAY_CANCEL * 86400;
    time(&now);
    fp = fopen(fpath, "a+");
    fprintf(fp, "�@��: %s (%s) ����: �ݪO�s�p\n", cuser.userid, cuser.username);
    fprintf(fp, "���D: [�o�O�D�s�p] %s\n", brdname);
    fprintf(fp, "�ɶ�: %s\n", ctime(&now));
    fprintf(fp, "-----------------------------------------------------------\n");
    fprintf(fp, "�O�W�G%s\n", brdname);
    fprintf(fp, "�|�����G%s\n", nbrd.date);
    fprintf(fp, "����ѼơG%d\n", NBRD_DAY_CANCEL);
    fprintf(fp, "�|��H�G%s\n", cuser.userid);
    fprintf(fp, "�q�l�l��H�c�G%s\n", cuser.email);
    fprintf(fp, "�ݳs�p�H�ơG%d\n", NBRD_NUM_CANCEL);
    fprintf(fp, "-----------------------------------------------------------\n");
    fprintf(fp, "�o�O�D��]�G\n");
    f_suck(fp, path);
    unlink(path);
    fprintf(fp, "-----------------------------------------------------------\n");
  }
  else /* if (mode == 4 || mode == 5) */
  {
    vmsg("�}�l�s�� [�s�p��]]");
    fd = vedit(path, 0);
    if (fd)
    {
      unlink(fpath);
      vmsg(MSG_CANCEL);
      return nbrd_head(xo);
    }
    nbrd.etime = etime = nbrd.btime + days * 86400;
    time(&now);    
    fp = fopen(fpath, "a+");
    fprintf(fp, "�@��: %s (%s) ����: �ݪO�s�p\n", cuser.userid, cuser.username);
    fprintf(fp, "���D: [�s�p] %s\n", title);
    fprintf(fp, "�ɶ�: %s\n", ctime(&now));
    fprintf(fp, "-----------------------------------------------------------\n");
    fprintf(fp, "�s�p�D�D�G%s\n", title);
    fprintf(fp, "�|�����G%s\n", nbrd.date);
    fprintf(fp, "����ѼơG%d\n", days);
    str_stamp(tmp, &etime);
    fprintf(fp, "�������G%s\n", tmp);
    fprintf(fp, "�O�D�W�١G%s\n", cuser.userid);
    fprintf(fp, "�q�l�l��H�c�G%s\n", cuser.email);
    fprintf(fp, "�ݳs�p�H�ơG%d\n", numbers);
    fprintf(fp, "-----------------------------------------------------------\n");
    fprintf(fp, "�s�p��]�G\n");
    f_suck(fp, path);
    unlink(path);
    fprintf(fp, "-----------------------------------------------------------\n");
    fprintf(fp, "�}�l�s�p�G\n");
  }

  fclose(fp);

  strcpy(nbrd.title, title);
  strcpy(nbrd.brdname, brdname);
  strcpy(nbrd.owner, cuser.userid);

  if (mode == 1)
  {
    nbrd.mode = NBRD_NBRD;
    nbrd.total = NBRD_NUM_BRD;
  }
  else if (mode == 2)
  {
    nbrd.mode = NBRD_OBRD | NBRD_ANONYMOUS | NBRD_START;
    nbrd.total = NBRD_NUM_BRD;	/* �Ϲ�M����}�s�O�s�p����ۦP */
  }
  else if (mode == 3)
  {
    nbrd.mode = NBRD_CANCEL;
    nbrd.total = NBRD_NUM_CANCEL;
  }
  else if (mode == 4)
  {
    nbrd.mode = NBRD_OTHER | NBRD_START;
    nbrd.total = numbers;
  }
  else /* if (mode == 5) */
  {
    nbrd.mode = NBRD_OTHER | NBRD_ANONYMOUS | NBRD_START;
    nbrd.total = numbers;
  }

  rec_add(dir, &nbrd, sizeof(NBRD));

  if (mode <= 3)
    vmsg("�e��ӽФF�A�е��Ԯ֭�a");
  else
    vmsg("�s�p�}�l�F�I");

  return nbrd_init(xo);
}


static int
nbrd_seek(fpath, userid, mail)
  char *fpath;
  char *userid;
  char *mail;
{
  LOG email;
  int pos = 0, fd;
  fd = open(fpath, O_RDONLY);
  while (fd)
  {
    lseek(fd, (off_t) (sizeof(email) * pos), SEEK_SET);
    if (read(fd, &email, sizeof(email)) == sizeof(email))
    {
      if (!strcmp(email.userid, userid) || !strcmp(email.email, mail))
      {
	close(fd);
	return 1;
      }
      pos++;
    }
    else
    {
      close(fd);
      break;
    }
  }
  return 0;
}


static int
nbrd_reply(xo)
  XO *xo;
{
  NBRD *nbrd;
  char *fname, fpath[80];
  LOG mail;

  nbrd = (NBRD *) xo_pool + (xo->pos - xo->top);
  fname = NULL;

  if (nbrd->mode & NBRD_REJECT)
  {
    fname = "�ڵ��ӽСA��Ƥ�����";
  }
  else if (nbrd->mode & (NBRD_CLOSE | NBRD_STOP))
  {
    fname = "����s�p";
  }
  else if (nbrd->mode & NBRD_OPEN)
  {
    fname = "�w�����}�O";
  }
  else if (nbrd->mode & NBRD_OK)
  {
    fname = "�w�F��s�p�H�ơA���R�Լf�z";
  }
  else if (!(nbrd->mode & NBRD_START))
  {
    fname = "�|���q�L�ӽ�";
  }
  else if (time(0) > nbrd->etime || nbrd->mode & NBRD_STOP)
  {
    nbrd->mode = NBRD_STOP | (nbrd->mode & NBRD_MASK);
    rec_put(xo->dir, nbrd, sizeof(NBRD), xo->pos, NULL);
    fname = "�s�p�w�g�I��F�A�ФU���A��";
  }

  if (fname)
  {
    vmsg(fname);
    return XO_FOOT;
  }

  /* --------------------------------------------------- */
  /* �ˬd�O�_�w�g�s�p�L					 */
  /* --------------------------------------------------- */

  nbrd_fpath(fpath, xo->dir, nbrd);
  fname = strrchr(fpath, '@');
  *fname = 'G';

  if (nbrd_seek(fpath, cuser.userid, cuser.email))
  {
    vmsg("�A�w�g�s�p�L�F�I");
    return XO_FOOT;
  }

  /* --------------------------------------------------- */
  /* �}�l�s�p						 */
  /* --------------------------------------------------- */

  *fname = '@';

  /* more(fpath, FOOTER_COSIGN);	/* ���w���s���e�H�s�p���p */

  if (vans("�n�[�J�s�p��(Y/N)�H[N] ") == 'y')
  {
    FILE *fp;
    int fd;
    char buf[80];

    fd = open(fpath, O_RDWR);
    f_exlock(fd);
    fp = fdopen(fd, "a+");

    rec_get(xo->dir, nbrd, sizeof(NBRD), xo->pos);
    if (fp)
    {
      if (nbrd->mode & NBRD_ANONYMOUS)		/* �ΦW */
      {
        fprintf(fp, "%3d -> �q�q�ڬO��\n", nbrd->total);
        if (vget(b_lines, 0, "�ڦ��ܭn���G", buf, 65, DOECHO))
          fprintf(fp, "    %s\n", buf);
      }
      else
      {
        fprintf(fp, "%3d -> %-12s: %s\n", nbrd->total, cuser.userid, cuser.email);
        if (vget(b_lines, 0, "�ڦ��ܭn���G", buf, 65, DOECHO))
  	  fprintf(fp, "    %s : %s\n", cuser.userid, buf);
      }
      fclose(fp);
    }

    if (--nbrd->total > 0)
    {
      sprintf(buf, "�[�J�s�p�����I�|�ݳs�p�H�� %d �H", nbrd->total);
      vmsg(buf);
    }
    else
    {
      vmsg("�w�F�s�p�зǡA���R�Լf�z");
      nbrd->mode = NBRD_OK | (nbrd->mode & NBRD_MASK);
    }

    rec_put(xo->dir, nbrd, sizeof(NBRD), xo->pos, NULL);
    f_unlock(fd);
    close(fd);

    memset(&mail, 0, sizeof(LOG));
    strcpy(mail.userid, cuser.userid);
    strcpy(mail.email, cuser.email);
    *fname = 'G';
    rec_add(fpath, &mail, sizeof(LOG));
  }

  return nbrd_head(xo);
}


static int
nbrd_start(xo)
  XO *xo;
{
  NBRD *nbrd;
  char fpath[80], buf[128], tmp[10];
  time_t etime;

  if (!HAS_PERM(PERM_ALLBOARD))
    return XO_NONE;

  nbrd = (NBRD *) xo_pool + (xo->pos - xo->top);

  if (nbrd->mode & ~(NBRD_MASK))
  {
    vmsg("�w�q�L�Τw����");
  }
  else if (vans("�нT�w�}�l�s�p(Y/N)�H[N] ") != 'y')
  {
    /* return XO_NONE; */
    return XO_FOOT;	/* itoc.010805: �� b_lines ��W feeter */
  }
  else
  {
    nbrd_fpath(fpath, xo->dir, nbrd);
    if (nbrd->mode & NBRD_NBRD)
      etime = time(0) + NBRD_DAY_BRD * 86400;
    else /* if (nbrd->mode & NBRD_CANCEL) */	/* ���ݭn�ˬd�A�]���u���G�� mode �ݭn nbrd_start */
      etime = time(0) + NBRD_DAY_CANCEL * 86400;

    str_stamp(tmp, &etime);
    f_cat(fpath, "-----------------------------------------------------------\n");
    sprintf(buf, "�}�l�s�p�G      �������G%s\n", tmp);
    f_cat(fpath, buf);
    nbrd->etime = etime;
    nbrd->mode = NBRD_START | (nbrd->mode & NBRD_MASK);
    rec_put(xo->dir, nbrd, sizeof(NBRD), xo->pos, NULL);
    vmsg("�ӽгq�L");
  }
  return nbrd_head(xo);
}


static int
nbrd_reject(xo)
  XO *xo;
{
  NBRD *nbrd;
  char path[128], fpath[128];
  int fd;
  FILE *fp;

  if (!HAS_PERM(PERM_ALLBOARD))
    return XO_NONE;

  nbrd = (NBRD *) xo_pool + (xo->pos - xo->top);

  if (nbrd->mode & ~(NBRD_MASK))
  {
    vmsg("�w�q�L�Τw����");
  }
  else if (vans("�нT�w�ڵ��s�p(Y/N)�H[N] ") != 'y')
  {
    /* return XO_NONE; */
    return XO_FOOT;	/* itoc.010805: �� b_lines ��W feeter */
  }
  else
  {
    nbrd_fpath(fpath, xo->dir, nbrd);
    vmsg("�нs��ڵ��s�p��]");
    sprintf(path, "tmp/%s", cuser.userid);	/* �s�p��]���Ȧs�ɮ� */
    fd = vedit(path, 0);
    if (fd)
    {
      unlink(path);
      vmsg(MSG_CANCEL);
      return nbrd_head(xo);
    }

    f_cat(fpath, "-----------------------------------------------------------\n");
    f_cat(fpath, "    �ڵ��s�p��]�G\n\n");
    fp = fopen(fpath, "a+");
    f_suck(fp, path);
    fclose(fp);
    f_cat(fpath, "-----------------------------------------------------------\n");
    nbrd->mode |= NBRD_REJECT | (nbrd->mode & NBRD_MASK);
    rec_put(xo->dir, nbrd, sizeof(NBRD), xo->pos, NULL);
    vmsg("�ڵ��ӽ�");
    unlink(path);
  }
  return nbrd_head(xo);
}


static int
nbrd_close(xo)
  XO *xo;
{
  NBRD *nbrd;

  if (!HAS_PERM(PERM_ALLBOARD))
    return XO_NONE;

  nbrd = (NBRD *) xo_pool + (xo->pos - xo->top);
  if (nbrd->mode & NBRD_OK)
  {
    vmsg("�w�s�s�p�����A��������");
  }
  else if (nbrd->mode & NBRD_OPEN)
  {
    vmsg("�w�����}�O");
  }
  else if (nbrd->mode & NBRD_CLOSE)
  {
    vmsg("�w�����s�p");
  }
  else
  {
    if (vans("�нT�w�����s�p(Y/N)�H[N] ") != 'y')    
    {
      /* return XO_NONE; */
      return XO_FOOT;	/* itoc.010805: �� b_lines ��W feeter */
    }
        
    nbrd->mode = NBRD_CLOSE | (nbrd->mode & NBRD_MASK);
    rec_put(xo->dir, nbrd, sizeof(NBRD), xo->pos, NULL);
    vmsg("��������");
  }
  return nbrd_head(xo);
}


static int			/* -1:����}�O  0: ���}�O  1:�}�O���\ */
nbrd_newbrd(nbrd)		/* �}�s�� */
  NBRD *nbrd;
{
  BRD newboard;
  int bno;
  char fpath[80];
  ACCT acct;

  vs_bar("�إ߷s�O");
  memset(&newboard, 0, sizeof(newboard));

  /* itoc.010805: �s�ݪO�w�] battr = ����H; postlevel = PERM_POST; �ݪO�O�D�����_�s�p�� */
  newboard.battr = BRD_NOTRAN;
  newboard.postlevel = PERM_POST;
  strcpy(newboard.brdname, nbrd->brdname);
  strcpy(newboard.title, nbrd->title);		/* �`�N�e�� BCLEN �n�O���� */
  strcpy(newboard.BM, nbrd->owner);

  prints("�ݪO�W�١G%s\n�ݪO�����G%s\n�O�D�W��G%s\n",
    newboard.brdname, newboard.title, newboard.BM);

  bitmsg(MSG_READPERM, STR_PERM, newboard.readlevel);
  bitmsg(MSG_POSTPERM, STR_PERM, newboard.postlevel);
  bitmsg(MSG_BRDATTR, STR_BATTR, newboard.battr);

  if (acct_load(&acct, nbrd->owner) > 0)
    acct_setperm(&acct, 1);		/* �O�D�W�� */

  if (m_setbrd(&newboard))
    return -1;

  if (vans(msg_sure_ny) != 'y')
    return 0;

  time(&newboard.bstamp);
  if ((bno = brd_bno("")) >= 0)
  {
    rec_put(FN_BRD, &newboard, sizeof(newboard), bno, NULL);
  }
  /* Thor.981102: ����W�Lshm�ݪO�Ӽ� */
  else if (bshm->number >= MAXBOARD)
  {
    vmsg("�W�L�t�Ωү�e�ǬݪO�ӼơA�нվ�t�ΰѼ�");
    return -1;
  }
  else if (rec_add(FN_BRD, &newboard, sizeof(newboard)) < 0)
  {
    vmsg("�L�k�إ߷s�O");
    return -1;
  }

  sprintf(fpath, "gem/brd/%s", newboard.brdname);
  mak_dirs(fpath);
  mak_dirs(fpath + 4);

  bshm->uptime = 0;            /* force reload of bcache */
  bshm_init();

  vmsg("�s�O���ߡA�O�ۭn�h Class �[�J�s�ճ�");
  return 1;
}


static int
nbrd_open(xo)
  XO *xo;
{
  NBRD *nbrd;

  if (!HAS_PERM(PERM_ALLBOARD))
    return XO_NONE;

  nbrd = (NBRD *) xo_pool + (xo->pos - xo->top);

  /* itoc.030519: �קK���ж}�O */
  if (brd_bno(nbrd->brdname) >= 0)
  {
    nbrd->mode = NBRD_OPEN;
    rec_put(xo->dir, nbrd, sizeof(NBRD), xo->pos, NULL);
    vmsg("�w�����O");
    return nbrd_init(xo);
  }

#if 0	/* itoc.010820: ���\���s�p���N�}�O */
  if (!(nbrd->mode & NBRD_OK))
  {
    vmsg("�|���s�p�����A����}�O");
  }
  else 
#endif

  if (nbrd->mode & NBRD_OPEN)
  {
    vmsg("�w�����}�O");
  }
  else
  {
    if (vans("�нT�w�}�ҬݪO(Y/N)�H[N] ") == 'y')
    {
      if (nbrd->mode & NBRD_NBRD)		/* itoc.010805: �}�s���s�p�A�s�p�����}�s�ݪO */
      {
	if (nbrd_newbrd(nbrd) > 0)
	{
	  nbrd->mode = NBRD_OPEN | (nbrd->mode & NBRD_MASK);
	  rec_put(xo->dir, nbrd, sizeof(NBRD), xo->pos, NULL);
	}
	return nbrd_init(xo);
      }
      else
      {
	nbrd->mode = NBRD_OPEN | (nbrd->mode & NBRD_MASK);
	rec_put(xo->dir, nbrd, sizeof(NBRD), xo->pos, NULL);
        vmsg("�w�]�w�B�z����");
      }
    }
    return XO_FOOT;
  }
  return nbrd_head(xo);
}


static int
nbrd_browse(xo)
  XO *xo;
{
  int key;
  NBRD *nbrd;
  char fpath[80];

#if 0
  nbrd = (NBRD *) xo_pool + (xo->pos - xo->top);
  nbrd_fpath(fpath, xo->dir, nbrd);

  more(fpath, NULL);
#endif

  /* itoc.010304: ���F���\Ū��@�b�]�i�H�[�J�s�p�A�Ҽ{ more �Ǧ^�� */
  for (;;)
  {
    nbrd = (NBRD *) xo_pool + (xo->pos - xo->top);
    nbrd_fpath(fpath, xo->dir, nbrd);

    if ((key = more(fpath, FOOTER_COSIGN)) < 0)
      break;

    if (!key)
      key = vkey();

    switch (key)
    {
    case KEY_UP:
    case KEY_PGUP:
    case '[':
    case 'k':
      key = xo->pos - 1;

      if (key < 0)
        break;

      xo->pos = key;

      if (key <= xo->top)
      {
	xo->top = (key / XO_TALL) * XO_TALL;
	nbrd_load(xo);
      }
      continue;

    case KEY_DOWN:
    case KEY_PGDN:
    case ']':
    case 'j':
    case ' ':
      key = xo->pos + 1;

      if (key >= xo->max)
        break;

      xo->pos = key;

      if (key >= xo->top + XO_TALL)
      {
	xo->top = (key / XO_TALL) * XO_TALL;
	nbrd_load(xo);
      }
      continue;

    case 'y':
    case 'r':
      nbrd_reply(xo);
      break;

    case 'h':
      xo_help("cosign");
      break;
    }
    break;
  }

  return nbrd_head(xo);
}


static int
nbrd_delete(xo)
  XO *xo;
{
  NBRD *nbrd;
  char *fname, fpath[80];
  char *list = "@G";		/* itoc.����: �M newbrd file */

  nbrd = (NBRD *) xo_pool + (xo->pos - xo->top);
  if (strcmp(cuser.userid, nbrd->owner) && !HAS_PERM(PERM_ALLBOARD))
    return XO_NONE;

  if (vans(MSG_DEL_NY) != 'y')
    return XO_FOOT;

  nbrd_fpath(fpath, xo->dir, nbrd);
  fname = strrchr(fpath, '@');
  while (*fname = *list++)
  {
    unlink(fpath);	/* Thor: �T�w�W�r�N�� */
  }

  rec_del(xo->dir, sizeof(NBRD), xo->pos, NULL);
  return nbrd_init(xo);
}


static int
nbrd_edit(xo)
  XO *xo;
{
  if (HAS_PERM(PERM_ALLBOARD))
  {
    char fpath[64];
    NBRD *nbrd;

    nbrd = (NBRD *) xo_pool + (xo->pos - xo->top);
    nbrd_fpath(fpath, xo->dir, nbrd);
    vedit(fpath, 0);
    return nbrd_head(xo);
  }

  return XO_NONE;
}


static int
nbrd_setup(xo)
  XO *xo;
{
  if (HAS_PERM(PERM_ALLBOARD))
  {
    int numbers;
    char ans[6];
    NBRD *nbrd, newnh;

    vs_bar("�s�p�]�w");
    nbrd = (NBRD *) xo_pool + (xo->pos - xo->top);
    memcpy(&newnh, nbrd, sizeof(NBRD));
    prints("�ݪO�W�١G%s\n�ݪO�����G%s\n�s�p�o�_�G%s\n",
      newnh.brdname, newnh.title, newnh.owner);
    prints("�}�l�ɶ��G%s\n", Ctime(&newnh.btime));
    prints("�����ɶ��G%s\n", Ctime(&newnh.etime));
    prints("�ٻݤH�ơG%d\n", newnh.total);

    switch (vget(8, 0, "(E)�]�w (Q)�����H[Q] ", ans, 3, LCECHO))
    {
    case 'e':
      vget(11, 0, MSG_BID, newnh.brdname, IDLEN + 1, GCARRY);
      vget(12, 0, "�ݪO�D�D�G", newnh.title, sizeof(newnh.title), GCARRY);
      sprintf(ans, "%d", newnh.total);
      vget(13, 0, "�s�p�H�ơG", ans, 6, GCARRY);
      numbers = atoi(ans);
      if (numbers <= 500 && numbers >= 1)
	newnh.total = numbers;

      if ((vans(msg_sure_ny) == 'y') && memcmp(&newnh, nbrd, sizeof(newnh)))
      {
	memcpy(nbrd, &newnh, sizeof(NBRD));
	rec_put(xo->dir, nbrd, sizeof(NBRD), xo->pos, NULL);
	return nbrd_init(xo);	/* �Y��s�h init �_�h head */
      }

    default:
      return nbrd_head(xo);
    }
  }

  return XO_NONE;
}


static int
nbrd_uquery(xo)
  XO *xo;
{
  NBRD *nbrd;

  nbrd = (NBRD *) xo_pool + (xo->pos - xo->top);

  move(1, 0);
  clrtobot();
  my_query(nbrd->owner);
  return nbrd_head(xo);
}


static int
nbrd_usetup(xo)
  XO *xo;
{
  NBRD *nbrd;
  ACCT xuser;

  if (!HAS_PERM(PERM_ALLACCT))
    return XO_NONE;

  nbrd = (NBRD *) xo_pool + (xo->pos - xo->top);
  if (acct_load(&xuser, nbrd->owner) < 0)
    return XO_NONE;

  move(3, 0);
  acct_setup(&xuser, 1);
  return nbrd_head(xo);
}


static int
nbrd_help(xo)
  XO *xo;
{
  xo_help("cosign");
  return nbrd_head(xo);
}


static KeyFunc nbrd_cb[] =
{
  XO_INIT, nbrd_init,
  XO_LOAD, nbrd_load,
  XO_HEAD, nbrd_head,
  XO_BODY, nbrd_body,

  'y', nbrd_reply,
  'r', nbrd_browse,
  'o', nbrd_open,
  's', nbrd_start,
  'R', nbrd_reject,
  'c', nbrd_close,
  'd', nbrd_delete,
  'E', nbrd_edit,
  'B', nbrd_setup,

  Ctrl('P'), nbrd_add,
  Ctrl('Q'), nbrd_uquery,
  Ctrl('O'), nbrd_usetup,

  'h', nbrd_help
};


int
XoNewBoard()
{
  XO *xo;
  char fpath[64];
  clear();
  sprintf(fpath, "run/newbrd/%s", fn_dir);
  xz[XZ_COSIGN - XO_ZONE].xo = xo = xo_new(fpath);
  xz[XZ_COSIGN - XO_ZONE].cb = nbrd_cb;
  xo->key = XZ_COSIGN;
  xover(XZ_COSIGN);
  free(xo);
  return 0;
}

#endif	/* HAVE_COSIGN */
