
cal | awk '
{
  printf("        ");

  if (NR == 1)
  {
    printf("      \033[1;33m%s \033[37m%s\033[m" , $1 , $2);1
  }
  else if (NR == 3 && NF != 7)
  {
    for (i = 0; i < 7 - NF; i++)
      printf("   ");
    printf("\033[1;37m");

    for (i = 1 ; i < NF ; i++)
      printf("%2s " , $i);
    printf("\033[1;32m%2s\033[m", $i);
  }
  else
  {
    for (i = 0; i < NF; i++)
    {
      if (i == 0)
        printf("\033[1;31m");
      else if (i == 1)
        printf("\033[1;37m");
      else if (i == 6)
        printf("\033[1;32m");

      printf("%2s ", $(1+i));
    }
  }

  printf("\033[m\n");
}'

#-------------------------------------------------------#
# calendar.sh       ( NTHU CS MapleBBS Ver 3.10 )       #
#-------------------------------------------------------#
# target : �p�ݪO��� script                            #
# create : 01/01/07                                     #
# update :   /  /                                       #
# author : sothat.bbs@TTB.twbbs.org                     #
# recast : itoc.bbs@bbs.tnfsh.tn.edu.tw                 #
#-------------------------------------------------------#

