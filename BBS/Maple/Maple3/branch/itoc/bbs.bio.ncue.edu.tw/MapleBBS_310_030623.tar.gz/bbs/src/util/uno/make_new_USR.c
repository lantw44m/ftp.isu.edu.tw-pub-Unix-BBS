/*-------------------------------------------------------*/
/* util/make_new_USR.c	( NTHU CS MapleBBS Ver 3.00 )    */
/*-------------------------------------------------------*/
/* target : ���� .USR ��	                         */
/* create :   /  /                                       */
/* update :   /  /                                       */
/* author : ernie@bbs.ee.nthu.edu.tw                     */
/*-------------------------------------------------------*/
/* syntax : make_new_USR                                 */
/*-------------------------------------------------------*/


#include "bbs.h"


#undef COMPARE			/* �� COMPARE �N�N�O�����@�ӷs�� .USR */


int
main()
{
  char pool[20001][13];
  int total, max, mynum, fd;
  char buf[30], *myname, *ptr;
  FILE *fp;
  SCHEMA slot;

  memset(pool, 0, sizeof(pool));
  total = max = 0;

  chdir(BBSHOME);

  if (fp = fopen("tmp/all_user_uno", "r"))
  {
    while (fgets(buf, 30, fp))
    {
      buf[strlen(buf) - 1] = '\0';	/* �� '\n' ���� '\0' */
      ptr = buf;
      ptr[5] = 0;

      mynum = atoi(ptr);
      if (mynum >= max)
	max = mynum;

      ptr += 6;
      myname = ptr++;
      strcpy(pool[mynum], myname);
      total++;
    }
    fclose(fp);
  }

#ifndef COMPARE
  fd = open(".USR.new", O_CREAT | O_TRUNC | O_WRONLY, 0600);
#else
  fd = open(".USR.new", O_RDONLY);
#endif

  if (fd > 0)
  {

#ifndef COMPARE
    for (mynum = 1; mynum <= max; mynum++)
    {
      memset(&slot, 0, sizeof(SCHEMA));
      strcpy(slot.userid, pool[mynum]);
      time(&slot.uptime);
      write(fd, &slot, sizeof(SCHEMA));
    }
#else
    for (mynum = 1; (mynum <= max) && read(fd, &slot, sizeof(SCHEMA)); mynum++)
    {
      if (strcmp(slot.userid, pool[mynum]))
      {
	printf("%d \"%s\", %s\n", mynum, pool[mynum], slot.userid);
	return 0;
      }
    }
#endif
  }
  close(fd);

  printf("\ntotal: %d\nmax uno: %d\n", total, max);
  return 0;
}
