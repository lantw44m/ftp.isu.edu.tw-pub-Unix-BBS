/*-------------------------------------------------------*/
/* calendar.c	( NTHU CS MapleBBS Ver 3.10 )		 */
/*-------------------------------------------------------*/
/* target : �U�~��					 */
/* create : 02/08/31					 */
/* update :   /  /  					 */
/* author : itoc.bbs@bbs.tnfsh.tn.edu.tw		 */
/*-------------------------------------------------------*/


#include "bbs.h"

#ifdef HAVE_CALENDAR

/* itoc.����: �n�ϥγo�\��A�����˦� cal �o�{���A�_�h�n�ۦ��g calendar_generate() */

static void
calendar_generate(fpath, year, month, whole)
  char *fpath;		/* file path */
  int year, month;
  int whole;		/* 1: �~�� */
{
  char cmd[128];

  if (whole)
    sprintf(cmd, "cal %d > %s", year, fpath);
  else
    sprintf(cmd, "cal %d %d > %s", month, year, fpath);
  system(cmd);
}


static void
calendar_show(fpath, whole)
  char *fpath;
  int whole;
{
  FILE *fp;
  int len;
  char buf[80];

  if (whole)	/* �~��|�W�L�@���A�� more() �� */
  {
    more(fpath, NULL);
    return;
  }

  if (fp = fopen(fpath, "r"))	/* ��� */
  {
    vs_bar("�U�~���");
    move(2, 5);
    outs("�Y����J����i�d�ߦ~��");
    move(4, 6);
    fgets(buf, 128, fp);
    prints("\033[1;36m%s\n", buf);	/* ��� */
    while (fgets(buf, 128, fp))
    {
      /* prints("      %s", buf); */
      /* itoc.020831: �W�� */
      len = strlen(buf);
      prints("      \033[1;31m%-3.3s", buf);
      if (len < 3)
	break;
      prints("\033[37m%-15.15s", buf + 3);
      if (len < 18)
	break;
      prints("\033[32m%s", buf + 18);
    }
    outs("\033[m");
    fclose(fp);
    vmsg(NULL);
  }
}


int
main_calendar()
{
  int year, month, whole;
  time_t now;
  struct tm *ptime;
  char fpath[64], ans[5];

  time(&now);
  ptime = localtime(&now);
  year = ptime->tm_year + 1900;
  month = ptime->tm_mon + 1;
  whole = 0;
  sprintf(fpath, "tmp/%s.calendar", cuser.userid);

  for (;;)
  {
    calendar_generate(fpath, year, month, whole);
    calendar_show(fpath, whole);
    unlink(fpath);

    if (!vget(b_lines, 0, "�п�J�n�d�ߪ��~���G", ans, 5, DOECHO))
      return 0;
    year = atoi(ans);
    if (year < 1 || year > 9999)
      return 0;

    if (!vget(b_lines, 0, "�п�J�n�d�ߪ�����G", ans, 3, DOECHO))
    {
      whole = 1;
    }
    else
    {
      whole = 0;
      month = atoi(ans);
      if (month < 1 || month > 12)
	return 0;
    }

  }
}
#endif	/* HAVE_CALENDAR */
