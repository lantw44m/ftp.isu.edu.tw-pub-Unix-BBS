/*-------------------------------------------------------*/
/* vote.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : boards' vote routines		 	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/
/* brd/_/.VCH - Vote Control Header			 */
/* brd/_/@/@_ - vote description file			 */
/* brd/_/@/I_ - vote selection Items			 */
/* brd/_/@/V_ - Vote choice record			 */
/* brd/_/@/O_ - users' Opinions				 */
/* brd/_/@/L_ - can vote List				 */
/* brd/_/@/G_ - voted id loG file			 */
/*-------------------------------------------------------*/


#include "bbs.h"


extern BCACHE *bshm;
extern XZ xz[];
extern char xo_pool[];
extern KeyFunc pal_cb[];


typedef struct
{
  char userid[IDLEN + 1];
}	LOG;


static int vote_add();


int
vote_result(xo)
  XO *xo;
{
  char fpath[80];

  setdirpath(fpath, xo->dir, "@/@vote");
  /* Thor.990204: ���Ҽ{more �Ǧ^�� */   
  if (more(fpath, NULL) >= 0)
    return XO_HEAD;

  vmsg("�ثe�S������}�������G");
  return XO_FOOT;
}


static void
vote_item(num, vch)
  int num;
  VCH *vch;
{
  prints("%6d %c%c%c %-9.8s%-12s %s\n",
    num, vch->vsort, vch->vpercent, vch->vprivate, vch->cdate, vch->owner, vch->title);
}


static int
vote_body(xo)
  XO *xo;
{
  VCH *vch;
  int num, max, tail;

  max = xo->max;
  if (max <= 0)
  {
    if (bbstate & STAT_BOARD)
    {
      if (vans("�n�|��벼��(Y/N)�H[N] ") == 'y')
	return vote_add(xo);
    }
    else
    {
      vmsg("�ثe�õL�벼�|��");
    }
    return XO_QUIT;
  }

  vch = (VCH *) xo_pool;
  num = xo->top;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  move(3, 0);
  do
  {
    vote_item(++num, vch++);
  } while (num < max);
  clrtobot();

  /* return XO_NONE; */
  return XO_FOOT;	/* itoc.010403: �� b_lines ��W feeter */
}


static int
vote_head(xo)
  XO *xo;
{
  vs_head(currBM, "�벼��");
  outs(NECKER_VOTE);
  return vote_body(xo);
}


static int
vote_init(xo)
  XO *xo;
{
  xo_load(xo, sizeof(VCH));
  return vote_head(xo);
}


static int
vote_load(xo)
  XO *xo;
{
  xo_load(xo, sizeof(VCH));
  return vote_body(xo);
}


static void
vch_edit(vch, item)
  VCH *vch;
  int item;		/* vlist ���X�� */
{
  int num;
  char ans[3], buf[80];

  sprintf(buf, "�аݨC�H�̦h�i��X���H([1]��%d)�G", item);
  vget(b_lines - 5, 0, buf, ans, 3, DOECHO);
  num = atoi(ans);
  if (num < 1)
    num = 1;
  else if (num > item)
    num = item;
  vch->maxblt = num;

  vget(b_lines - 4, 0, "�����벼�i��X�� (�ܤ֢���)�H", ans, 3, DOECHO);
  num = atoi(ans);
  if (num < 1)
    num = 1;
  vch->vclose = vch->chrono + num * 86400;
  str_stamp(vch->cdate, &vch->vclose);

  vch->vsort = (vget(b_lines - 3, 0, "�}�����G�O�_�Ƨ�(Y/N)�H[N] ", ans, 3, LCECHO) == 'y') ? 's' : ' ';
  vch->vpercent = (vget(b_lines - 2, 0, "�}�����G�O�_��ܦʤ����(Y/N)�H[N] ", ans, 3, LCECHO) == 'y') ? '%' : ' ';
  vch->vprivate = (vget(b_lines - 1, 0, "�O�_����벼�W��(Y/N)�H[N] ", ans, 3, LCECHO) == 'y') ? ')' : ' ';
}


static int
vlist_edit(vlist)
  vitem_t vlist[];
{
  int item;
  char buf[80];

  /* Thor.980902: lkchu patch: �w��M�e�� */
  move(0, 0);
  clrtobot();

  outs("�Ш̧ǿ�J�ﶵ (�̦h 32 ��)�A�� ENTER �����G");

  strcpy(buf, " ) ");
  for (;;)
  {
    item = 0;
    for (;;)
    {
      buf[0] = radix32[item];
      if (!vget((item & 15) + 3, (item / 16) * 40,
	  buf, vlist[item], sizeof(vitem_t), GCARRY) || (++item >= MAX_CHOICES))
	break;
    }
    if (vans("�O�_���s��J�ﶵ(Y/N)�H[N] ") != 'y')
      break;
  }
  return item;
}


static int
vlog_seek(fpath, userid)
  char *fpath;
  char *userid;
{
  LOG log;
  int pos = 0, fd;
  fd = open(fpath, O_RDONLY);
  while (fd)
  {
    lseek(fd, (off_t) (sizeof(log) * pos), SEEK_SET);
    if (read(fd, &log, sizeof(log)) == sizeof(log))
    {
      if (!strcmp(log.userid, userid))
      {
	close(fd);
	return 1;
      }
      pos++;
    }
    else
    {
      close(fd);
      break;
    }
  }
  return 0;
}


static int
vote_add(xo)
  XO *xo;
{
  VCH vch;
  int fd, item;
  char *dir, *str, fpath[80], buf[TTLEN + 1 - 5];	/* Thor.981016: �ȶW�L�ù� */
  vitem_t vlist[MAX_CHOICES];
  BRD *brd;

  if (!(bbstate & STAT_BOARD))
    return XO_NONE;

  if (!vget(b_lines, 0, "�벼�D�D�G", buf, sizeof(buf), DOECHO))
    return xo->max ? XO_FOOT : XO_BODY;		/* itoc.011125: �p�G�S������벼�A�n�^�� vote_body() */
    /* return XO_FOOT; */

  dir = xo->dir;
  fd = hdr_stamp(dir, 0, (HDR *) &vch, fpath);
  if (fd < 0)
  {
    vmsg("�L�k�إߧ벼������");
    blog("VOTE ", fpath);
    return XO_FOOT;
  }

  close(fd);
  vmsg("�}�l�s�� [�벼����]");
  fd = vedit(fpath, 0); /* Thor.981020: �`�N�Qtalk�����D */
  if (fd)
  {
    unlink(fpath);
    vmsg("�����벼");
    return XO_HEAD;
  }

  strcpy(vch.title, buf);
  str = strrchr(fpath, '@');

  /* --------------------------------------------------- */
  /* �벼�ﶵ�� : Item					 */
  /* --------------------------------------------------- */

  memset(vlist, 0, sizeof(vlist));
  item = vlist_edit(vlist);

  *str = 'I';
  fd = open(fpath, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (fd < 0)
  {
    vmsg("�L�k�إߧ벼�ﶵ��");
    blog("VOTE ", fpath);
    return XO_HEAD;
  }
  write(fd, vlist, item * sizeof(vitem_t));
  close(fd);

  vch_edit(&vch, item);

  strcpy(vch.owner, cuser.userid);

  brd = bshm->bcache + currbno;
  brd->bvote++;
  vch.bstamp = brd->bstamp;

  rec_add(dir, &vch, sizeof(vch));

  vmsg("�}�l�벼�F�I");
  return vote_init(xo);
}


static int
vote_edit(xo)
  XO *xo;
{
  int pos;
  VCH *vch, vxx;
  char *dir, fpath[80];

  /* Thor: for �ק�벼�ﶵ */
  int fd, item;
  vitem_t vlist[MAX_CHOICES];
  char *fname;

  if (!(bbstate & STAT_BOARD))
    return XO_NONE;

  pos = xo->pos;
  dir = xo->dir;
  vch = (VCH *) xo_pool + (pos - xo->top);

  /* Thor: �ק�벼�D�D */
  vxx = *vch;

  if (!vget(b_lines, 0, "�벼�D�D�G", vxx.title, TTLEN + 1 - 5 /* sizeof(vxx.title) Thor.981020: �ȶW�L�ù� */ , GCARRY))
    return XO_FOOT;

  hdr_fpath(fpath, dir, (HDR *) vch);
  vedit(fpath, 0);	/* Thor.981020: �`�N�Qtalk�����D  */

  /* Thor: �ק�벼�ﶵ */

  memset(vlist, 0, sizeof(vlist));
  fname = strrchr(fpath, '@');
  *fname = 'I';
  fd = open(fpath, O_RDONLY);

  read(fd, vlist, sizeof(vlist));
  close(fd);

  item = vlist_edit(vlist);

  fd = open(fpath, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (fd < 0)
  {
    vmsg("�L�k�إߧ벼�ﶵ��");
    blog("VOTE ", fpath);
    return XO_HEAD;
  }
  write(fd, vlist, item * sizeof(vitem_t));
  close(fd);

  vch_edit(&vxx, item);

  if (memcmp(&vxx, vch, sizeof(VCH)))
  {
    if (vans("�T�w�n�ק�o���벼��(Y/N)�H[N] ") == 'y')
    {
      *vch = vxx;
      rec_put(dir, vch, sizeof(VCH), pos, NULL);
    }
  }

  return vote_head(xo);
}


static int
vote_query(xo)
  XO *xo;
{
  char *dir, *fname, fpath[80], buf[80];
  VCH *vch;
  int cc, pos;

  if (!(bbstate & STAT_BOARD))
    return XO_NONE;

  pos = xo->pos;
  dir = xo->dir;
  vch = (VCH *) xo_pool + (pos - xo->top);

  hdr_fpath(fpath, dir, (HDR *) vch);
  more(fpath, (char *) -1);

  fname = strrchr(fpath, '@');
  *fname = 'V';
  sprintf(buf, "�@�� %d �H�ѥ[�벼�AA)�벼��� B)�����벼 C)�ߧY�}�� [Q]���}�H[Q] ",
    rec_num(fpath, sizeof(int)));
  cc = vans(buf);

  if (cc == 'a')
  {
    vget(b_lines, 0, "�Ч��}���ɶ�(-n���en��/+m����m��/0����)�G", buf, 3, DOECHO);
    if (cc = atoi(buf))
    {
      vch->vclose = vch->vclose + cc * 86400;
      str_stamp(vch->cdate, &vch->vclose);
      rec_put(dir, vch, sizeof(VCH), pos, NULL);
    }
  }
  else if (cc == 'b')
  {
    if (vans("�T�w�n�����o���벼��(Y/N)�H[N] ") == 'y')
    {
      char *list = "@IOVLG";	/* itoc.����: �M vote file */

      while (*fname = *list++)
      {
	unlink(fpath); /* Thor: �T�w�W�r�N�� */
      }

      cc = currchrono;
      currchrono = vch->chrono;
      rec_del(dir, sizeof(VCH), pos, cmpchrono);
      currchrono = cc;
      return vote_init(xo);
    }
  }
  else if (cc == 'c')	/* itoc.010926: ����U�@���] account �ߧY�}�� */
  {
    if (vans("�T�w�n�ߧY�}����(Y/N)�H[N] ") == 'y')
    {
      vch->vclose = time(0);
      str_stamp(vch->cdate, &vch->vclose);
      rec_put(dir, vch, sizeof(VCH), pos, NULL);
    }
  }

  return vote_head(xo); 
}


static int
vote_pal(xo)		/* itoc.020117: �s�譭��벼�W�� */
 XO *xo;
{
  char *fname, fpath[80];
  VCH *vch;
  XO *xt;

  if (!(bbstate & STAT_BOARD))
    return XO_NONE;

  vch = (VCH *) xo_pool + (xo->pos - xo->top);

  if (vch->vprivate != ')')
    return XO_NONE;

  hdr_fpath(fpath, xo->dir, (HDR *) vch);
  fname = strrchr(fpath, '@');
  *fname = 'L';

  /* itoc.010412: t_pal() �令�C���h�X�n�ͦW��N free�A�Ӥ��b talk_main() ���A�ҥH�n���] pal_cb */
  xz[XZ_PAL - XO_ZONE].xo = xt = xo_new(fpath);
  xz[XZ_PAL - XO_ZONE].cb = pal_cb;
  xover(XZ_PAL);		/* Thor: �ixover�e, pal_xo �@�w�n ready */

  free(xt);
  return vote_init(xo);
}


static int
vote_join(xo)
  XO *xo;
{
  VCH *vch;
  LOG log;
  int count, choice, fd;
  char *fname, fpath[80], buf[80], *slist[MAX_CHOICES];
  vitem_t vlist[MAX_CHOICES];

  vch = (VCH *) xo_pool + (xo->pos - xo->top);

  /* --------------------------------------------------- */
  /* �ˬd�O�_�w�g�����벼				 */
  /* --------------------------------------------------- */

  if (time(0) > vch->vclose)
  {
    vmsg("�벼�w�g�I��F�A���R�Զ}��");
    return XO_FOOT;
  }

  /* --------------------------------------------------- */
  /* �ˬd�O�_�w�g��L��					 */
  /* --------------------------------------------------- */

  hdr_fpath(fpath, xo->dir, (HDR *) vch);
  fname = strrchr(fpath, '@');

  *fname = 'G';
  if (vlog_seek(fpath, cuser.userid))
  {
    vmsg("�A�w�g��L���F�I");
    return XO_FOOT;
  }

  if (cutmp->userlevel & PERM_COINLOCK)
  {
    vmsg(MSG_COINLOCK);
    return XO_FOOT;
  }

  /* --------------------------------------------------- */
  /* �ˬd�O�_�b�벼�W�椤				 */
  /* --------------------------------------------------- */

  if (vch->vprivate == ')')	/* itoc.020117: �p�H�벼 */
  {
    *fname = 'L';

    if (!pal_find(fpath, cuser.userno) &&
      !(bbstate & STAT_BOARD))		/* �ѩ�ä����ۤv�[�J�n�ͦW��A�ҥH�n�h�ˬd�O�_���O�D */
    {
      vmsg("�z�S�����ܥ����p�H�벼�I");
      return XO_FOOT;
    }
  }

  /* --------------------------------------------------- */
  /* �}�l�벼�A��ܧ벼����				 */
  /* --------------------------------------------------- */

  *fname = '@';
  more(fpath, NULL);

  /* --------------------------------------------------- */
  /* ���J�벼�ﶵ��					 */
  /* --------------------------------------------------- */

  *fname = 'I';
  fd = open(fpath, O_RDONLY);
  count = read(fd, vlist, sizeof(vlist)) / sizeof(vitem_t);
  close(fd);

  for (fd = 0; fd < count; fd++)
  {
    slist[fd] = (char *) &vlist[fd];
  }

  /* --------------------------------------------------- */
  /* �i��벼						 */
  /* --------------------------------------------------- */

  choice = 0;
  sprintf(buf, "��U���t�� %d ��", vch->maxblt); /* Thor: ��̦ܳh�X�� */
  vs_bar(buf);
  outs("�벼�D�D�G");
  *buf = '\0';
  for (;;)
  {
    choice = bitset(choice, count, vch->maxblt, vch->title, slist);
    vget(b_lines - 1, 0, "�ڦ��ܭn���G", buf, 60, DOECHO);
    fd = vans("�벼 (Y)�T�w (N)���� (Q)�����H[N] ");
    if (fd == 'q' || fd == 'y')
      break;
  }

  /* --------------------------------------------------- */
  /* �O�����G�G�@���]���몺���p ==> �۷����o��	 */
  /* --------------------------------------------------- */

  if (fd != 'q')
  {
    *fname = 'V';
    fd = open(fpath, O_WRONLY | O_CREAT | O_APPEND, 0600);
    if (fd >= 0)
    {
      write(fd, &choice, sizeof(choice));
      close(fd);

      /* Thor: �g�J�ϥΪ̷N�� */

      if (*buf)
      {
	FILE *fp;

	*fname = 'O';
	if (fp = fopen(fpath, "a"))
	{
	  fprintf(fp, "%-12s: %s\n", cuser.userid, buf);
	  fclose(fp);
	}
      }

      memset(&log, 0, sizeof(LOG));
      strcpy(log.userid, cuser.userid);
      *fname = 'G';
      rec_add(fpath, &log, sizeof(LOG));

      vmsg("�벼�����I");
    }
  }

  return vote_head(xo);
}


static int
vote_help(xo)
  XO *xo;
{
  xo_help("vote");
  return vote_head(xo);
}


static KeyFunc vote_cb[] =
{
  XO_INIT, vote_init,
  XO_LOAD, vote_load,
  XO_HEAD, vote_head,
  XO_BODY, vote_body,

  'r', vote_join,	/* itoc.010901: ���k������K */
  'v', vote_join,
  'R', vote_result,

  'E', vote_edit,
  'o', vote_pal,
  Ctrl('G'), vote_pal,
  Ctrl('P'), vote_add,
  Ctrl('Q'), vote_query,

  'h', vote_help
};


int
XoVote(xo)
  XO *xo;
{
  char fpath[32];

  /* �� post �v�Q���~��ѥ[�벼 */
  /* �ӥB�n�קK guest �b sysop �O�벼 */

  if (!(bbstate & STAT_POST) || !cuser.userlevel)
    return XO_NONE;

  setdirpath(fpath, xo->dir, FN_VCH);
  if (!(bbstate & STAT_BOARD) && !rec_num(fpath, sizeof(VCH)))
  {
    vmsg("�ثe�S���벼�|��");
    return XO_FOOT;
  }

  xz[XZ_VOTE - XO_ZONE].xo = xo = xo_new(fpath);
  xz[XZ_VOTE - XO_ZONE].cb = vote_cb;
  xover(XZ_VOTE);
  free(xo);

  return XO_INIT;
}


int
vote_all()		/* itoc.010414: �벼���� */
{
  extern char brd_bits[];
  char *str;
  char fpath[64];
  int num, pageno, pagemax, redraw;
  int ch, pos;
  BRD *bhead, *btail;
  XO *xo;

  struct vbrd
  {
    char brdname[IDLEN + 1];
    char title[BTLEN + 1];
    char BM[BMLEN + 1];
    int is_BM;			/* �קK���h�ۤv���O���F STAT_BOARD �A�ӧ벼���ߥ��@�O�ܪO�D */
  }     vbrd[MAXBOARD];

  bhead = bshm->bcache;
  btail = bhead + bshm->number;
  pos = 0;
  num = 0;

  do
  {
    str = &brd_bits[pos];
    ch = *str;
    if (bhead->bvote && (ch & (BRD_L_BIT | BRD_R_BIT | BRD_W_BIT)))
    {
      strcpy(vbrd[num].brdname, bhead->brdname);
      strcpy(vbrd[num].title, bhead->title);
      strcpy(vbrd[num].BM, bhead->BM);
      vbrd[num].is_BM = ch & BRD_X_BIT;
      num++;
    }
    pos++;
  } while (++bhead < btail);

  if (!num)
  {
    vmsg("�ثe�����èS������벼");
    return XEASY;
  }

  num--;
  pagemax = num / XO_TALL;
  pageno = 0;
  pos = 0;
  redraw = 1;

  do
  {
    if (redraw)
    {
      /* itoc.����: �ɶq���o�� xover �榡 */
      vs_head("�벼����", str_site);
      outs(NECKER_VOTEALL);

      redraw = pageno * XO_TALL;	/* �ɥ� redraw */
      ch = BMIN(num, redraw + XO_TALL - 1);
      move(3, 0);
      do
      {
	/* itoc.010909: �O�W�Ӫ����R���B�[�����C��C���] BCLEN = 5 */
        prints("%6d   %-13s\033[1;3%dm%5.5s\033[m%s %-34.33s %.13s\n",
          redraw + 1, vbrd[redraw].brdname,
          ((usint) (vbrd[redraw].title[2] + vbrd[redraw].title[4])) % 7 + 1, vbrd[redraw].title,
          "\033[1;33m��\033[m", vbrd[redraw].title + BCLEN, vbrd[redraw].BM);

        redraw++;
      } while (redraw <= ch);

      outz(FEETER_VOTEALL);
      move(3 + pos, 0);
      outc('>');
      redraw = 0;
    }

    ch = vkey();
    switch (ch)
    {
    case KEY_RIGHT:
    case '\n':
    case ' ':
    case 'r':
      redraw = pos + pageno * XO_TALL;	/* �ɥ� redraw */

      strcpy(currboard, vbrd[redraw].brdname);
      str = vbrd[redraw].BM;
      sprintf(currBM, "�O�D�G%s", *str <= ' ' ? "�x�D��" : str);
      currbno = brd_bno(currboard);

      if (vbrd[redraw].is_BM)
        bbstate |= STAT_BOARD;
      else
        bbstate &= ~STAT_BOARD;

      sprintf(fpath, "brd/%s/%s", vbrd[redraw].brdname, FN_VCH);
      xz[XZ_VOTE - XO_ZONE].xo = xo = xo_new(fpath);
      xz[XZ_VOTE - XO_ZONE].cb = vote_cb;
      xover(XZ_VOTE);
      free(xo);
      redraw = 1;
      break;

    default:
      ch = xo_cursor(ch, pagemax, num, &pageno, &pos, &redraw);
      break;
    }
  } while (ch != 'q');

  return 0;
}
