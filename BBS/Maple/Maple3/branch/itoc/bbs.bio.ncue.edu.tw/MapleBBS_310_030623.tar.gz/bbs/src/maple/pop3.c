/*-------------------------------------------------------*/
/* pop3_check.c       ( NTHU CS MapleBBS Ver 3.00 )      */
/*-------------------------------------------------------*/
/* target : account / pop3 check for e-mail justify      */
/* create : 00/03/15					 */
/* update :   /  /					 */
/*-------------------------------------------------------*/


#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>


static int
Get_Socket(site, sock)		/* site for hostname, sock for port & socket */
  char *site;
  int *sock;
{
  struct sockaddr_in sin;
  struct hostent *host;

  /* Getting remote-site data */

  memset((char *)&sin, 0, sizeof(sin));
  sin.sin_family = AF_INET;
  sin.sin_port = htons(*sock);

  if ((host = gethostbyname(site)) == NULL)
    sin.sin_addr.s_addr = inet_addr(site);
  else
    memcpy(&sin.sin_addr.s_addr, host->h_addr, host->h_length);

  /* Getting a socket */

  if ((*sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    return -1;
  }

#ifdef  SET_ALARM
  signal(SIGALRM, timeout);
  alarm(SET_ALARM);
#endif

  /* perform connecting */

  if (connect(*sock, (struct sockaddr *) & sin, sizeof(sin)) < 0)
  {
    close(*sock);

#ifdef  SET_ALARM
    init_alarm();
#endif

    return -3;
  }

#ifdef  SET_ALARM
  init_alarm();
#endif

  return 0;
}


static int
POP3_Check(sock, account, passwd)
  int sock;
  char *account, *passwd;
{
  FILE *fsock;
  char buf[512];

  if (fsock = fdopen(sock, "r+"))
    sock = 2;
  else
    sock = 1;

  while (sock < 6)
  {
    switch (sock)
    {
    case 1:			/* Open Socket Fail */
      prints("\n�Ǧ^���~�� [1], �Э��մX���ݬ�\n");
      refresh();
      return sock;

    case 2:			/* Welcome Message */
      fgets(buf, 512, fsock);
      break;

    case 3:			/* Verify Account */
      fprintf(fsock, "user %s\r\n", account);
      fflush(fsock);
      fgets(buf, 512, fsock);
      break;

    case 4:			/* Verify Password */
      fprintf(fsock, "pass %s\r\n", passwd);
      fflush(fsock);
      fgets(buf, 512, fsock);
      sock = -1;
      break;

    case 0:			/* Successful Verification */
    case 5:			/* Quit */
      fprintf(fsock, "quit\r\n");
      fclose(fsock);
      return sock;
    }

    if (strncmp(buf, "+OK", 3) || strstr(buf, ".bbs"))
    {
      prints("\n\n���ݨt�ζǦ^���~�T���p�U�G\n");
      prints("%s\n", buf);
      refresh();
      sock = 5;
    }
    else
    {
      sock++;
    }
  }
  return 1;
}
