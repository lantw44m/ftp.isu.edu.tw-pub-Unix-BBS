<?php
//toppost
?>
<html>
<head>
<title>top topic</title>
<meta http-equiv="Content-Type" content="text/html;charset=big5">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #0000aa}
A:visited {color: #0000aa}
PRE {color: #ffffff}
</style>
</head>
<body leftmargin="3" topmargin="0" marginwidth="3" marginheight="0" bgcolor="#ffffff">
<table width="619" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="3"><img src="images/serv/serv_top.jpg" width="619" height="55" usemap="#Map" border="0"></td>
  </tr>
  <tr> 
    <td width="23" background="images/serv/serv_left_bg.jpg">&nbsp;</td>
    <td height="100%" width="575">
	    <table width="95%" border="0" cellspacing="3" cellpadding="3">

		<?php

		print "
			<tr>
				<td><h3 style='color: 00aa00'><u>�� �ӤH��ƱƦ�</u></h3></td>
			</tr>
			<tr>
				<td>
				[<a href='services.php'>��^�W�h</a>] �ӤH���
				<a href='$PHP_SELF?file=-toplogin'>�W��</a> | <a href='$PHP_SELF?file=-toppost'>�峹</a> | 
				<a href='$PHP_SELF?file=-topmoney'>�ȹ�</a> | <a href='$PHP_SELF?file=-topgold'>����</a>
				</td>
			</tr>
			<tr>
				<td bgcolor='#000000'>
				<pre style='color: ffffff'>\n";
		//show
		require_once("config.php");
		require_once("webbbs.class.php");
		require_once("ansi2web.inc.php");

		if(!isset($file)) $file = "-toplogin";
		$theFile = $bbshome."/gem/@/@".$file;
		//file data

		$ws = new server_class;
		$cmd = $ws->set_cmd("get_file", G_CMD, $theFile);
		$ws->connect();
		$ws->send($cmd);
		while($tmp = $ws->recv(2048)) {
			echo ansi2web(htmlspecialchars ($tmp));
		}
		$ws->close();
		print " </pre>
				</td>
			</tr>
			";
		?>
		</table>
	</td>
    <td background="images/serv/serv_right_bg.jpg" width="23">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="3" height="2"><img src="images/serv/serv_bottom.jpg" width="619" height="26"></td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="179,21,249,41" href="board.php" alt="�����Q�׶�" title="�����Q�׶�">
  <area shape="rect" coords="258,21,330,41" href="gem.php" alt="��ؤ��G��" title="��ؤ��G��">
  <area shape="rect" coords="338,22,410,40" href="personal.php" alt="�ӤH�u��{" title="�ӤH�u��{">
  <area shape="rect" coords="498,22,569,40" href="group.php" alt="�ڪ��s�հ�" title="�ڪ��s�հ�">
</map>
</body>
</html>
