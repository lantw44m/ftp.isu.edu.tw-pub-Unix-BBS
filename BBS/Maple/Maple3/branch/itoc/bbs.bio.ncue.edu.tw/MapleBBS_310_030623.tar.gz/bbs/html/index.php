<?
 require_once("config.php");
?>
 <html>
 <head>
 <title>MapleBBS WebBBS</title>
 <meta http-equiv="Content-Type" content="text/html; charset=big5">
 </head>
 <frameset rows="0,0,85,25,*" frameborder="NO" border="0" framespacing="0">
   <frame name="hideFrame" scrolling="NO" noresize src="about:blank">
   <frame name="activeFrame" scrolling="NO" noresize src="<? echo "server.php";?>" >
   <frame name="topFrame" scrolling="NO" noresize src="top.php">
   <frame name="bmwFrame" scrolling="NO" noresize src="bmw.php">
   <frameset cols="119,*" frameborder="NO" border="0" framespacing="0">
     <frame name="leftFrame" noresize src="left.php">
     <frameset rows="*,20" frameborder="NO" border="0" framespacing="0">
       <frame name="mainFrame" src="main.php">
       <frame name="bottomFrame" scrolling="NO" noresize src="bottom.php">
     </frameset>
   </frameset>
 </frameset>
 <noframes>
 <body bgcolor="#FFFFFF" text="#000000">
 Your Brwoser dont support Frames!
 </body>
 </noframes>
 </html>
