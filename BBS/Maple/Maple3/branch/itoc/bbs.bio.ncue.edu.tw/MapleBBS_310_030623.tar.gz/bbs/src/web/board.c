/*-------------------------------------------------------*/
/* board.c      ( NTHU CS MapleBBS Ver 3.10 )            */
/*-------------------------------------------------------*/
/* target : �ݪO�B�s�ե\��                               */
/* create : 95/03/29                                     */
/* update : 02/11/05                                     */
/*-------------------------------------------------------*/


#include "web.h"

extern BCACHE *bshm;

static char *class_img;

char *err_perm = "�z�S���������v��";

char brd_bits[MAXBOARD];


/* ----------------------------------------------------- */
/* �ݪO�\Ū�O�� .BRH (Board Reading History)             */
/* ----------------------------------------------------- */


typedef struct BoardReadingHistory
{
  time_t bstamp;		/* �إ߬ݪO���ɶ�, unique *//* Thor.brh_tail */
  time_t bvisit;		/* �W���\Ū�ɶ� *//* Thor.980902:�S�Ψ�? */
				/* Thor.980904:��Ū�ɩ�W��Ū���ɶ�, ��Ū�ɩ� bhno */
  int bcount;			/* Thor.980902:�S�Ψ�? */
				/* Thor.980902:���ۤv�ݪ� */
}	BRH;


#define BRH_EXPIRE      180	/* Thor.980902.����:�O�d�h�֤� */
#define BRH_MAX         200	/* Thor.980902.����:�C�O�̦h���X�Ӽ�ñ */
#define BRH_PAGE        2048	/* Thor.980902.����:�C���h�t�q, �Τ���F */
#define BRH_MASK        0x7fffffff	/* Thor.980902.����:�̤j�q��2038�~1�뤤 */
#define BRH_SIGN        0x80000000	/* Thor.980902.����:zap����final�M�� */
#define BRH_WINDOW      (sizeof(BRH) + sizeof(time_t) * BRH_MAX * 2)


static int *brh_base;		/* allocated memory */
static int *brh_tail;		/* allocated memory */
static int brh_size;		/* allocated memory size */
static time_t brh_expire;


static int *
brh_alloc(tail, size)
  int *tail;
  int size;
{
  int *base, n;

  base = brh_base;
  n = (char *)tail - (char *)base;
  size += n;
  if (size > brh_size)
  {
    size += n >> 4;		/* �h�w���@�ǰO���� */
    base = (int *)realloc((char *)base, size);

    if (base == NULL)
      abort_bbs();

    brh_base = base;
    brh_size = size;
    tail = (int *)((char *)base + n);
  }

  return tail;
}


static void
brh_put()
{
  int *list;

  /* compact the history list */

  list = brh_tail;

  if (*list)
  {
    int *head, *tail, n, item, chrono;

    n = *++list;		/* Thor.980904: ��Ū�ɬObhno */
    brd_bits[n] |= BRD_H_BIT;
    time((time_t *) list);	/* Thor.980904.����: bvisit time */

    item = *++list;
    head = ++list;
    tail = head + item;

    while (head < tail)
    {
      chrono = *head++;
      n = *head++;
      if (n == chrono)		/* Thor.980904.����: �ۦP���ɭ����_�� */
      {
	n |= BRH_SIGN;
	item--;
      }
      else
      {
	*list++ = chrono;
      }
      *list++ = n;
    }

    list[-item - 1] = item;
    *list = 0;
    brh_tail = list;		/* Thor.980904:�s����brh */
  }
}


static void
brh_get(bstamp, bhno)
  time_t bstamp;		/* board stamp */
  int bhno;
{
  int *head, *tail;
  int size, bcnt, item;
  char buf[BRH_WINDOW];

  if (bstamp == *brh_tail)	/* Thor.980904.����: �ӪO�w�b brh_tail�W */
    return;

  brh_put();

  bcnt = 0;
  tail = brh_tail;

  if (brd_bits[bhno] & BRD_H_BIT)
  {
    head = brh_base;
    while (head < tail)
    {
      item = head[2];
      size = item * sizeof(time_t) + sizeof(BRH);

      if (bstamp == *head)
      {
	bcnt = item;
	memcpy(buf, head + 3, size);
	tail = (int *)((char *)tail - size);
	if (item = (char *)tail - (char *)head)
	  memcpy(head, (char *)head + size, item);
	break;
      }
      head = (int *)((char *)head + size);
    }
  }

  brh_tail = tail = brh_alloc(tail, BRH_WINDOW);

  *tail++ = bstamp;
  *tail++ = bhno;

  if (bcnt)			/* expand history list */
  {
    int *list;

    size = bcnt;
    list = tail;
    head = (int *)buf;

    do
    {
      item = *head++;
      if (item & BRH_SIGN)
      {
	item ^= BRH_SIGN;
	*++list = item;
	bcnt++;
      }
      *++list = item;
    } while (--size);
  }

  *tail = bcnt;
}


static int
brh_unread(chrono)
  time_t chrono;
{
  int *head, *tail, item;

  if (chrono <= brh_expire)
    return 0;

  head = brh_tail + 2;
  if ((item = *head) > 0)
  {
    /* check {final, begin} history list */

    head++;
    tail = head + item;
    do
    {
      if (chrono > *head)
	return 1;

      head++;
      if (chrono >= *head)
	return 0;

    } while (++head < tail);
  }
  return 1;
}


static int
brh_add(prev, chrono, next)
  time_t prev, chrono, next;
{
  int *base, *head, *tail, item, final, begin;

  head = base = brh_tail + 2;
  item = *head++;
  tail = head + item;

  begin = BRH_MASK;

  while (head < tail)
  {
    final = *head;
    if (chrono > final)
    {
      if (prev <= final)
      {
	if (next < begin)	/* increase */
	  *head = chrono;
	else
	{			/* merge */
	  *base = item - 2;
	  base = head - 1;
	  do
	  {
	    *base++ = *++head;
	  } while (head < tail);
	}
	return;
      }

      if (next >= begin)
      {
	head[-1] = chrono;
	return;
      }

      break;
    }

    begin = *++head;
    head++;
  }

  /* insert or append */

  /* [21, 22, 23] ==> [32, 30] [15, 10] */

  if (item < BRH_MAX)
  {
    /* [32, 30] [22, 22] [15, 10] */

    *base = item + 2;
    tail += 2;
  }
  else
  {
    /* [32, 30] [22, 10] *//* Thor.980923: how about [6, 7, 8] ? [15,7]? */

    tail--;
  }

  prev = chrono;
  for (;;)
  {
    final = *head;
    *head++ = chrono;

    if (head >= tail)
      return;

    begin = *head;
    *head++ = prev;

    if (head >= tail)
      return;

    chrono = final;
    prev = begin;
  }
}


/* ----------------------------------------------------- */
/* board permission check                                */
/* ----------------------------------------------------- */


static inline int
is_bm(list)
  char *list;			/* �O�D�GBM list */
{
  int cc, len;
  char *userid;

  len = strlen(userid = cuser.userid);
  do
  {
    cc = list[len];
    if ((!cc || cc == '/') && !str_ncmp(list, userid, len))
    {
      return 1;
    }
    while (cc = *list++)
    {
      if (cc == '/')
	break;
    }
  } while (cc);

  return 0;
}


#ifdef HAVE_MODERATED_BOARD
static int		/* !=0:�O�O��  0:���b�W�椤 */
brdpal_belong(board)
  char *board;
{
  int fsize, count, result;
  char fpath[80];

  result = 0;

  brd_fpath(fpath, board, FN_FIMAGE);	/* Thor: fimage�n�� sort�L! */
  board = f_img(fpath, &fsize);

  if (board != NULL)
  {
    count = fsize / sizeof(int);
    if (count > 0)
    {
      int userno, *up;
      int datum, mid;

      userno = cuser.userno;
      up = (int *) board;

      while (count > 0)
      {
	datum = up[mid = count >> 1];
	if (userno == datum)
	{
	  result = BRD_L_BIT | BRD_R_BIT | BRD_W_BIT;
	  break;
	}
	if (userno > datum)
	{
	  up += (++mid);
	  count -= mid;
	}
	else
	{
	  count = mid;
	}
      }
    }
    free(board);
  }
  return result;
}
#endif


int
Ben_Perm(bhdr, ulevel)
  BRD *bhdr;
  usint ulevel;
{
  usint readlevel, postlevel, bits;
  char *blist, *bname;

  bname = bhdr->brdname;
  if (!*bname)
    return 0;

  readlevel = bhdr->readlevel;

#ifdef HAVE_MODERATED_BOARD

  /* �n��/���K�ݪO�G�ֹ�ݪO���n�ͦW�� */

#ifdef HAVE_BUCKET
  bits = brdpal_belong(bname);
  if (readlevel == PERM_SYSOP)		/* ���K�ݪO */
    ;
  else if (readlevel == PERM_BOARD)	/* �n�ͬݪO */
    bits |= BRD_L_BIT;
  else if (bits)			/* ���}�ݪO�b�O�ͦW�椤������ */
    bits = BRD_L_BIT | BRD_R_BIT;
#else
  if (readlevel == PERM_SYSOP)		/* ���K�ݪO */
    bits = brdpal_belong(bname);
  else if (readlevel == PERM_BOARD)	/* �n�ͬݪO */
    bits = brdpal_belong(bname) ? (BRD_L_BIT | BRD_R_BIT | BRD_W_BIT) : BRD_L_BIT;
#endif

  else
#endif

  if (!readlevel || (readlevel & ulevel))
  {
    bits = BRD_L_BIT | BRD_R_BIT;

    postlevel = bhdr->postlevel;
    if (!postlevel || (postlevel & ulevel))
      bits |= BRD_W_BIT;
  }
  else
  {
    bits = 0;
  }

  /* Thor.980813.����: �S�O�� BM �Ҷq�A�O�D���ӪO���Ҧ��v�� */

  blist = bhdr->BM;

  if ((ulevel & PERM_BM) && blist[0] > ' ' && is_bm(blist))
    bits = BRD_L_BIT | BRD_R_BIT | BRD_W_BIT | BRD_X_BIT;

  return bits;
}


/* ----------------------------------------------------- */
/* ���J currboard �i��Y�z�]�w                           */
/* ----------------------------------------------------- */


static int
bstamp2bno(stamp)
  time_t stamp;
{
  BRD *brd;
  int bno, max;

  bno = 0;
  brd = bshm->bcache;
  max = bshm->number;
  for (;;)
  {
    if (stamp == brd->bstamp)
      return bno;
    if (++bno >= max)
      return -1;
    brd++;
  }
}


static void
brh_load()
{
  BRD *brdp, *bend;
  usint ulevel;
  int n, cbno;
  char *bits;

  int size, *base;
  time_t expire;
  char fpath[64];

  ulevel = cuser.userlevel;
  n = (ulevel & PERM_ALLBOARD) ? (BRD_L_BIT | BRD_R_BIT | BRD_W_BIT | BRD_X_BIT) : 0;
  memset(bits = brd_bits, n, sizeof(brd_bits));

  if (!n)
  {
    brdp = bshm->bcache;
    bend = brdp + bshm->number;

    do
    {
      *bits++ = Ben_Perm(brdp, ulevel);
    } while (++brdp < bend);
  }

  /* --------------------------------------------------- */
  /* �N .BRH ���J memory                                 */
  /* --------------------------------------------------- */

  size = 0;
  cbno = -1;
  brh_expire = expire = time(0) - BRH_EXPIRE * 86400;

  if (ulevel)
  {
    struct stat st;

    usr_fpath(fpath, cuser.userid, FN_BRH);
    if (!stat(fpath, &st))
      size = st.st_size;
  }

  /* --------------------------------------------------- */
  /* �h�O�d BRH_WINDOW ���B�@�Ŷ�                        */
  /* --------------------------------------------------- */

  /* brh_size = n = ((size + BRH_WINDOW) & -BRH_PAGE) + BRH_PAGE; */
  brh_size = n = size + BRH_WINDOW;
  brh_base = base = (int *) malloc(n);

  if (size && ((n = open(fpath, O_RDONLY)) >= 0))
  {
    int *head, *tail, *list, bstamp, bhno;

    size = read(n, base, size);
    close(n);

    /* compact reading history : remove dummy/expired record */

    head = base;
    tail = (int *) ((char *) base + size);
    bits = brd_bits;

    while (head < tail)
    {
      bstamp = *head;

      if (bstamp & BRH_SIGN)	/* zap */
      {
	bstamp ^= BRH_SIGN;
	bhno = bstamp2bno(bstamp);
	if (bhno >= 0)
	{
	  /* itoc.001029: NOZAP��, ���|�X�{ */
	  brdp = bshm->bcache + bhno;
	  if (!(brdp->battr & BRD_NOZAP))
	    bits[bhno] |= BRD_Z_BIT;
	}
	head++;
	continue;
      }

      bhno = bstamp2bno(bstamp);
      list = head + 2;
      n = *list;
      size = n + 3;

      /* �o�ӬݪO�s�b�B�S���Q zap ���B�i�H list */

      if (bhno >= 0 && (bits[bhno] & BRD_L_BIT))
      {
	bits[bhno] |= BRD_H_BIT;/* �w���\Ū�O�� */        
	cbno = bhno;

	if (n > 0)
	{
	  list += n;	/* Thor.980904.����: �̫�@�� tag */

	  do
	  {
	    bhno = *list;
	    if ((bhno & BRH_MASK) > expire)
	      break;

	    if (!(bhno & BRH_SIGN))
	    {
	      if (*--list > expire)
		break;
	      n--;
	    }

	    list--;
	    n--;
	  } while (n > 0);

	  head[2] = n;
	}

	n = n * sizeof(time_t) + sizeof(BRH);
	if (base != head)
	  memcpy(base, head, n);
	base = (int *) ((char *) base + n);
      }
      head += size;
    }
  }

  *base = 0;
  brh_tail = base;

  /* --------------------------------------------------- */
  /* �]�w default board                                  */
  /* --------------------------------------------------- */

  strcpy(currboard, BN_NULL);
}


static void
brh_save()
{
  int *base, *head, *tail, bhno, size;
  BRD *bhdr, *bend;
  char *bits;

  /* Thor.980830: lkchu patch:  �٨S load �N���� save */
  if (!(base = brh_base))
    return;

#if 0
  base = brh_base;
#endif

  brh_put();

  /* save history of un-zapped boards */

  bits = brd_bits;
  head = base;
  tail = brh_tail;
  while (head < tail)
  {
    bhno = bstamp2bno(*head);
    size = head[2] * sizeof(time_t) + sizeof(BRH);
    if (bhno >= 0 && !(bits[bhno] & BRD_Z_BIT))
    {
      if (base != head)
	memcpy(base, head, size);
      base = (int *) ((char *) base + size);
    }
    head = (int *) ((char *) head + size);
  }

  /* save zap record */

  tail = brh_alloc(base, sizeof(time_t) * MAXBOARD);

  bhdr = bshm->bcache;
  bend = bhdr + bshm->number;
  do
  {
    if (*bits++ & BRD_Z_BIT)
    {
      *tail++ = bhdr->bstamp | BRH_SIGN;
    }
  } while (++bhdr < bend);

  /* OK, save it */

  base = brh_base;
  if ((size = (char *) tail - (char *) base) > 0)
  {
    char fpath[64];
    int fd;

    usr_fpath(fpath, cuser.userid, FN_BRH);
    if ((fd = open(fpath, O_WRONLY | O_CREAT | O_TRUNC, 0600)) >= 0)
    {
      write(fd, base, size);
      close(fd);
    }
  }
}


/* ----------------------------------------------------- */
/* BoardClass [�����s��]                                 */
/* ----------------------------------------------------- */


static int
class_find(name)	/* �ھڤ����W�j�M���� */
  char *name;
{
  short *cbase, *chead, *ctail;
  int pos, chn;

  if (!class_img)
    return -1;
  cbase = (short *) class_img;
  chn = 0;
  ctail = (short *) (cbase[0] - ((short) sizeof(short)));

  do
  {
    pos = cbase[chn];

    chead = (short *) ((char *)cbase + pos);

    if (!strncmp((char *) chead, name, strlen(name)))
    {
      if (chn > 1)
      {
	if (*((char *) (chead) + strlen(name)) == '/')
	  return chn;
      }
      else
	return chn;
    }
    chn++;
  } while ((short *) (chn * sizeof(short)) < ctail);

  return -1;
}


/* load the basic Class */

static int
class_load(xo)
  XO *xo;
{
  short *cbase, *chead, *ctail;
  int chn;			/* ClassHeader number */
  int pos, max, val;
  BRD *brd;
  char *bits;

  chn = CH_END - xo->key;

  cbase = (short *) class_img;
  chead = cbase + chn;

  strcpy(currtitle, (char *)((char *)cbase + cbase[chn]));

  pos = chead[0] + CH_TTLEN;
  max = chead[1];

  chead = (short *) ((char *) cbase + pos);
  ctail = (short *) ((char *) cbase + max);

  max -= pos;

  if (cbase = (short *) xo->xyz)
    cbase = (short *) realloc(cbase, max);
  else
    cbase = (short *) malloc(max);

  xo->xyz = (char *) cbase;

  max = 0;
  brd = bshm->bcache;
  bits = brd_bits;

  do
  {
    chn = *chead++;
    if (chn >= 0)
    {
      val = bits[chn];
      if (!(val & BRD_L_BIT) || !(brd[chn].brdname[0]))
	continue;
    }

    max++;
    *cbase++ = chn;
  } while (chead < ctail);

  xo->max = max;
  if (xo->top >= max)
    xo->top = 0;

  return max;
}


static int
class_body(xo)
  XO *xo;
{
  char *img, *bits;
  short *chp;
  BRD *bcache;
  int cnt, max, tail, page, brdpost;

  img = class_img;

  brdpost = cuser.ufo & UFO_BRDPOST;

  bcache = bshm->bcache;
  bits = brd_bits;

  max = xo->max;
  cnt = xo->top;
  page = xo->pos;

  tail = cnt + XO_TALL;
  if ((max > tail) && (page >= 0))
    max = tail;

  chp = (short *) xo->xyz + cnt;

  /* ���ܫH�� */
  www_printf("result=OK&max=%d&page=%d&title=%s\n", xo->max, page, currtitle);

  while (++cnt <= max)
  {
    int chn;
    char *str;

    chn = *chp++;
    if (chn >= 0)	/* �@��ݪO */
    {
      BRD *brd;
      int num, fd, fsize;
      char folder[64];
      struct stat st;

      /* itoc.020123: ���ަ��L UFO_BRDPOST�A�@����s�A�H�K��Ū�O���|�G */
      brd = bcache + chn;
      brd_fpath(folder, brd->brdname, fn_dir);
      if ((fd = open(folder, O_RDONLY)) >= 0 && !fstat(fd, &st))
      {
	if (st.st_mtime > brd->btime)
	{
	  brd->btime = time(0) + 45;	/* 45 �������������ˬd */
	  if ((fsize = st.st_size) >= sizeof(HDR))
	  {
#ifdef ENHANCED_BSHM_UPDATE
	    HDR hdr;
	    brd->bpost = fsize / sizeof(HDR);
	    /* itoc.020829: ��̫�@�g���Q�R��/�[�K�� HDR */
	    for (fsize -= sizeof(HDR); fsize >= sizeof(HDR); fsize -= sizeof(HDR))
	    {
	      lseek(fd, fsize, SEEK_SET);
	      read(fd, &hdr, sizeof(HDR));
	      if (!(hdr.xmode & POST_RESTRICT))
		break;
	    }
	    brd->blast = hdr.chrono;
#else
	    brd->bpost = fsize / sizeof(HDR);
	    lseek(fd, fsize - sizeof(HDR), SEEK_SET);
	    read(fd, &brd->blast, sizeof(time_t));
#endif
	  }
	  else
	  {
	    brd->blast = brd->bpost = 0;
	  }
	}
	close(fd);
      }

      num = brdpost ? brd->bpost : cnt;

#ifdef ENHANCED_VISIT
      /* itoc.010407: ��γ̫�@�g�wŪ/��Ū�ӧP�_ */
      brh_get(brd->bstamp, chn);
      str = brh_unread(brd->blast) ? "��" : "��";
#else
      /* �Y #undef ENHANCED_VISIT�A�h�����wŪ/��Ū */
      str = "��";
#endif

      www_printf("num=%d&str=%s&zap=%c&bname=%s&btitle=%s&vote=%c&BM=%s\n", 
	num, str, bits[chn] & BRD_Z_BIT ? '-' : ' ',
	brd->brdname, brd->title, brd->bvote ? 'V' : ' ', brd->BM);
    }
    else	/* �����s�� */
    {
      short *chx;

      chx = (short *)img + (CH_END - chn);
      www_printf("num=%d&title=%s&chn=%d\n", cnt, img + *chx, CH_END - chn);	/* �����Q�װ� */
    }
  }
  return XO_NONE;
}


static int
XoClass(ClassName, page, chn)
  char *ClassName;
  int page;
  int chn;
{
  XO xo;
  /* int chn; */

  page--;		/* �� 1 �� */

  xo.pos = page;
  xo.top = xo.max = 0;

  if (chn < 0)			/* �S���ǤJchn���ܴN�h�� ClassName �H�[�t :p */
    chn = class_find(ClassName);

  if (chn < 0)
    return 0;

  xo.key = CH_END - chn;

  xo.xyz = NULL;
  if (!class_load(&xo))
  {
    free(xo.xyz);
    return 0;
  }

  if (page < 0 || (page * XO_TALL) >= xo.max)
    xo.top = 0;
  else
    xo.top = page * XO_TALL;

  return class_body(&xo);
}


static int 
b_list()			/* pid, class �p�Gclass�O�šA�N�C�X����? */
/* �H�@�ӪŮ涡�}�U��class, �@�ӪO���@�� */
/* @BBS	, chn?				 */
{
  char *ptr, *ClassName;
  int page, chn, fsize;
  struct stat st;

  ptr = acct_locate();
  ClassName = nextword(&ptr);
  page = atoi(nextword(&ptr));
  if (page < 0)
    page = 0;			/* page��0����ܥ��� */

  chn = atoi(nextword(&ptr));	/* �ǤJchn���� */

  /* Board Main */

  if (stat(FN_BRD, &st) || st.st_size <= 0)
    unlink(CLASS_IMGFILE_TITLE);

  class_img = f_img(CLASS_IMGFILE_TITLE, &fsize);

  if (class_img == NULL)
    blog("CACHE", "class.img");

  bshm_init();		/* �@�ɤ��s��l�� */
  brh_load();		/* Board History Loading */

  return XoClass(ClassName, page, chn);
}


/* ----------------------------------------------------- */
/* ��} innbbsd ��X�H��B�s�u��H���B�z�{��             */
/* ----------------------------------------------------- */


static void
outgo_post(hdr, board)
  HDR *hdr;
  char *board;
{
  char *fpath, buf[256];

  if (board)
  {
    fpath = "innd/out.bntp";
  }
  else
  {
    board = currboard;
    fpath = "innd/cancel.bntp";
  }

  sprintf(buf, "%s\t%s\t%s\t%s\t%s\n",
    board, hdr->xname, hdr->owner, hdr->nick, hdr->title);
  f_cat(fpath, buf);
}


static void
cancel_post(hdr)
  HDR *hdr;
{
  if ((hdr->xmode & POST_OUTGO) &&		/* �~��H�� */
    (hdr->chrono > ap_start - 7 * 86400))	/* 7 �Ѥ������� */
  {
    outgo_post(hdr, NULL);
  }
}


extern char xo_pool[];
static int post_body();


static int
post_init(xo)
  SXO *xo;
{
  xo_load(xo, sizeof(HDR));
  return post_body(xo);
}


static int
post_attr(fhdr)
  HDR *fhdr;
{
  int mode, attr;

  mode = fhdr->xmode;

  attr = brh_unread(fhdr->chrono) ? 0 : 0x20;	/* �w�\Ū���p�g�A���\Ū���j�g */

#ifdef HAVE_REFUSEMARK
  if (mode & POST_RESTRICT)
    attr |= 'X';
  else
#endif
#ifdef HAVE_LABELMARK
  if (mode & POST_DELETE)
    attr |= 'T';
  else
#endif
  if (mode & POST_MARKED)
    attr |= 'M';
  else if (!attr)
    attr = '+';

  return attr;
}


static void
post_item(num, hdr, dir)
  int num;
  HDR *hdr;
  char *dir;
{
  static char *type[2] = {"Re", "��"};
  int ch, len, i;
  char *title, *mark, author[IDLEN + 1];
  char fpath[64];
  struct stat st;

  /* �B�zauthor */
  mark = hdr->owner;
  len = 13;
  i = 0;

  while (ch = *mark)
  {
    if ((--len == 0) || (ch == '@'))
      ch = '.';
    author[i++] = ch;

    if (ch == '.')
      break;

    mark++;
  }

  author[i] = '\0';

  /* �B�ztitle */
  title = str_ttl(mark = hdr->title);
  ch = (title == mark);		/* �O�_�u���۵��O? */

  /* �ɮפj�p */
  hdr_fpath(fpath, dir, hdr);
  stat(fpath, &st);

  /* ��X */
  www_printf("num=%d&attr=%c&date=%s&author=%s&type=%s&title=%s&size=%d\n", 
    num, post_attr(hdr), hdr->date + 3, author, type[ch], title, st.st_size);
}


static int
post_body(xo)
  SXO *xo;
{
  HDR *fhdr;
  int num, max, tail;

  max = xo->max;
  if (max <= 0)
  {
    www_printf("�ثe���O<%s>�٨S���峹��~\n", currboard);
    return XO_NONE;
  }

  www_printf("result=OK&max=%d&page=%d&bname=%s&btitle=%s&BM=%s&isbm=%d&anony=%d\n",
    xo->max, xo->page, currboard, currtitle, currBM,
    (bbstate & STAT_BOARD ? 1 : 0), (bbstate & BRD_ANONYMOUS ? 1 : 0));

  num = xo->top;
  fhdr = (HDR *) xo_pool;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  do
  {
    post_item(++num, fhdr++, xo->dir);
  } while (num < max);

  return XO_NONE;
}


#ifdef LOG_BRD_USIES		/* lkchu.981201: �ݪO�\Ū�O�� */
static void
brd_usies(void)
{
  char buf[256];

  sprintf(buf, "%s %s (%s)\n", currboard, cuser.userid, Now());
  f_cat(FN_RUN_BRDUSIES, buf);
}
#endif


static int 
p_list()
{
  char *ptr, *BrdName;
  int page, bno, bits;
  BRD *brd;
  char fpath[80], *str;
  SXO *xo;

  ptr = acct_locate();
  BrdName = nextword(&ptr);
  page = atoi(nextword(&ptr));

  /* Board Main */

  bshm_init();			/* �@�ɤ��s��l�� */
  brh_load();			/* Board History Loading */

  bno = brd_bno(BrdName);

  if (bno < 0)
    msg_quit(err_bid);

  str = &brd_bits[bno];
  bits = *str;

  brd = bshm->bcache + bno;
  bbstate = brd->battr;

  if (!(bits & BRD_R_BIT))
    msg_quit("�藍�_�A�z�S���\\Ū�v�Q!");

  if (bits & BRD_X_BIT)
    bbstate |= (STAT_BOARD | STAT_POST);
  else if (bits & BRD_W_BIT)
    bbstate |= STAT_POST;

  strcpy(currboard, brd->brdname);
  strcpy(currtitle, brd->title);
  strcpy(currBM, brd->BM);
  brh_get(brd->bstamp, bno);

  brd_fpath(fpath, BrdName, fn_dir);

  xo = xo_new(fpath);
  xo->page = page;
  xo->key = XZ_POST;

  post_init(xo);

  free(xo);

#ifdef LOG_BRD_USIES		/* lkchu.981201: �\Ū�ݪO�O�� */
  brd_usies();
#endif

  bbstate = 0;
  return 1;
}


/* ----------------------------------------------------	 */
/* Post Read						 */
/* ----------------------------------------------------	 */


static void
post_history(fhdr, num)
  HDR *fhdr;
  int num;
{
  int prev, chrono, next, pos;
  char fpath[80];
  HDR buf;

  chrono = fhdr->chrono;
  if (!brh_unread(chrono))
    return;

  brd_fpath(fpath, currboard, fn_dir);
  pos = num - 1;

  if (!rec_get(fpath, &buf, sizeof(HDR), pos))
    prev = buf.chrono;
  else
    prev = chrono;

  pos += 2;
  if (!rec_get(fpath, &buf, sizeof(HDR), pos))
    next = buf.chrono;
  else
    next = chrono;

  brh_add(prev, fhdr->chrono, next);
}


static int
post_read(num)			/* �\Ūcurrboard����num�g�峹 */
  int num;
{
  char fpath[80];
  int fd;

  brd_fpath(fpath, currboard, fn_dir);

  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    int max;
    struct stat st;
    char folder[80];
    HDR fhdr;

    fstat(fd, &st);
    max = st.st_size / sizeof(HDR);
    if (max <= 0)
      msg_quit("Ū�g���~�A���O�èS���峹�I");

    if (num > max)
      num = max;

    num = num - 1;		/* ����-1 */

    memset(&fhdr, 0, sizeof(HDR));

    lseek(fd, (off_t) (sizeof(HDR) * num), SEEK_SET);
    read(fd, &fhdr, sizeof(HDR));
    close(fd);

#ifdef HAVE_REFUSEMARK
    if ((fhdr.xmode & POST_RESTRICT) &&
      strcmp(fhdr.owner, cuser.userid) && !(bbstate & STAT_BOARD))
      msg_quit("�Ӥ峹���O�K���A");
#endif

    post_history(&fhdr, num);	/* �\Ū�O�� */
    www_printf("result=OK&max=%d&reply=%d&isbm=%d&bname=%s&btitle=%s&BM=%s&anony=%d&title=%s\n",
      max, (bbstate & STAT_POST ? 1 : 0), (bbstate & STAT_BOARD ? 1 : 0),
      currboard, currtitle, currBM, (bbstate & BRD_ANONYMOUS ? 1 : 0), fhdr.title);

    hdr_fpath(folder, fpath, &fhdr);
    return article_show(folder);
  }
  else
    msg_quit("���}�O�����ޤ��.DIR�ɵo�Ϳ��~!");

  return 1;
}


static int 
p_read()
{
  char *ptr, *BrdName, *str;
  int num, bno, bits;
  BRD *brd;

  ptr = acct_locate();
  BrdName = nextword(&ptr);
  num = atoi(nextword(&ptr));
  if (num < 1)
    num = 1;

  bshm_init();			/* �@�ɤ��s��l�� */
  brh_load();			/* Board History Loading */

  bno = brd_bno(BrdName);

  if (bno < 0)
    msg_quit(err_bid);

  str = &brd_bits[bno];
  bits = *str;

  brd = bshm->bcache + bno;

  bbstate = brd->battr;

  if (!(bits & BRD_R_BIT))
    msg_quit("�藍�_, �z�S���\\Ū�v�Q!");

  if (bits & BRD_X_BIT)
    bbstate |= (STAT_BOARD | STAT_POST);
  else if (bits & BRD_W_BIT)
    bbstate |= STAT_POST;

  strcpy(currboard, brd->brdname);
  strcpy(currtitle, brd->title);
  strcpy(currBM, brd->BM);
  brh_get(brd->bstamp, bno);
  post_read(num);

  brh_save();
  bbstate = 0;
  return 1;
}


/* ----------------------------------------------------	 */
/* Post Delete						 */
/* ----------------------------------------------------	 */


extern int cmpchrono();


static inline void
move_post(hdr, board, by_bm)	/* �N hdr �q currboard �h�� board */
  HDR *hdr;
  char *board;
  int by_bm;
{
  HDR post;
  char folder[80], fpath[80];

  brd_fpath(folder, currboard, fn_dir);
  hdr_fpath(fpath, folder, hdr);

  brd_fpath(folder, board, fn_dir);
  hdr_stamp(folder, HDR_LINK | 'A', &post, fpath);
  unlink(fpath);

  /* �����ƻs trailing data */

  memcpy(post.owner, hdr->owner, TTLEN + 140);

  if (by_bm)
    sprintf(post.title, "%-13s%.59s", cuser.userid, hdr->title);

  rec_add(folder, &post, sizeof(post));
  cancel_post(hdr);
}


static int
post_delete(num)
  int num;
{
  int pos, by_BM;
  HDR fhdr;
  char fpath[80], buf[80];

  if (!cuser.userlevel ||
    !strcmp(currboard, BN_DELETED) ||
    !strcmp(currboard, BN_JUNK))
  {
    msg_quit(err_perm);
  }

  pos = num - 1;
  brd_fpath(fpath, currboard, fn_dir);

  if (!rec_get(fpath, &fhdr, sizeof(HDR), pos))
  {
    if (fhdr.xmode & POST_MARKED)
      msg_quit("���夣�i�R��!");

    by_BM = strcmp(fhdr.owner, cuser.userid);

    if (!(bbstate & STAT_BOARD) && by_BM)
      msg_quit(err_perm);

    currchrono = fhdr.chrono;

    if (!rec_del(fpath, sizeof(HDR), pos, cmpchrono))
    {
      move_post(&fhdr, by_BM ? BN_DELETED : BN_JUNK, by_BM);	/* �ಾ */
      if (!by_BM && !(bbstate & BRD_NOCOUNT))
      {
	if (cuser.numposts > 0)
	  cuser.numposts--;
	acct_save(&cuser, ACCTSAV_POST);
	sprintf(buf, "%s�A�z���峹� %d �g", MSG_DEL_OK, cuser.numposts);
	www_printf("result=OK&msg=%s\n", buf);
      }
      else
      {
	www_printf("result=OK&msg=%s\n", MSG_DEL_OK);
      }
    }
  }
  else
  {
    msg_quit("���s�b���峹!\n");
  }

  return XO_FOOT;
}


static int 
p_delete()
{
  char *ptr, *BrdName, *str;
  int num, bno, bits;
  BRD *brd;

  ptr = acct_locate();
  BrdName = nextword(&ptr);
  num = atoi(nextword(&ptr));
  if (num < 1)
    num = 1;

  bshm_init();			/* �@�ɤ��s��l�� */
  brh_load();			/* Board History Loading */

  bno = brd_bno(BrdName);

  if (bno < 0)
    msg_quit(err_bid);

  str = &brd_bits[bno];
  bits = *str;
  brd = bshm->bcache + bno;

  strcpy(currboard, brd->brdname);

  bbstate = brd->battr;

  if (bits & BRD_X_BIT)
    bbstate |= STAT_BOARD;

  post_delete(num);

  bbstate = 0;
  return 1;
}


/* ----------------------------------------------------	 */
/* Post Mark						 */
/* ----------------------------------------------------	 */


static int 
p_mark()
{
  char *ptr, *BrdName, *str, fpath[80];
  int num, bno, bits;
  HDR fhdr;

  ptr = acct_locate();
  BrdName = nextword(&ptr);
  num = atoi(nextword(&ptr));
  if (num < 1)
    num = 1;

  bshm_init();			/* �@�ɤ��s��l�� */
  brh_load();			/* Board History Loading */

  bno = brd_bno(BrdName);

  if (bno < 0)
    msg_quit(err_bid);

  strcpy(currboard, BrdName);

  str = &brd_bits[bno];
  bits = *str;

  if (!(bits & BRD_X_BIT))
    msg_quit("�藍�_,�z���O�O�D!");

  num--;

  brd_fpath(fpath, currboard, fn_dir);

  if (!rec_get(fpath, &fhdr, sizeof(HDR), num))
  {
    fhdr.xmode ^= POST_MARKED;
    rec_put(fpath, &fhdr, sizeof(HDR), num, NULL);
  }

  www_printf("result=OK&msg=�z�w�g���\\���N<%s>�O��%d�gmark/unmark�F\n", currboard, num);

  return 1;
}


/* ----------------------------------------------------	 */
/* Post Add �o���峹					 */
/* ----------------------------------------------------	 */


#ifdef HAVE_ANONYMOUS
static void
log_anonymous(fname)
  char *fname;
{
  char buf[512];
  time_t now = time(0);
  sprintf(buf, "%s %-13s(%s) %s %s %s\n", Etime(&now), cuser.userid, fromhost, currboard, ve_title, fname);
  f_cat(FN_RUN_ANONYMOUS, buf);
}
#endif


static int
do_post()
{
  HDR post;
  char fpath[80], folder[80], *nick, *rcpt, *title;
  int mode;

  article_edit();		/* �����峹�s�� */
  title = ve_title + 7;		/* ������D */

  usr_fpath(fpath, cuser.userid, ".tmp");

  brd_fpath(folder, currboard, fn_dir);
  hdr_stamp(folder, HDR_LINK | 'A', &post, fpath);

  rcpt = cuser.userid;
  nick = cuser.username;
  mode = 0;			/* ���ѻP��H */

#ifdef HAVE_ANONYMOUS
  if (curredit & EDIT_ANONYMOUS)
  {
    rcpt = "[���i�D�A]";
    nick = "�q�q�ڬO�� ? ^o^";
    log_anonymous(post.xname);
  }
#endif

  post.xmode = mode;
  strcpy(post.owner, rcpt);
  strcpy(post.nick, nick);
  strcpy(post.title, title);

  if (!rec_add(folder, &post, sizeof(HDR)))
  {
    /* fuse: �ۤv���峹�N���n��+���F */

    if (!(bbstate & BRD_NOTRAN))
      outgo_post(&post, currboard);

    mode = post.chrono;
    brh_add(mode - 1, mode, mode + 1);

    if (bbstate & BRD_NOCOUNT)
    {
      www_printf("result=OK&msg=�峹���C�J�����A�q�Х]�[�C");
    }
    else
    {
      www_printf("result=OK&msg=�o�O�z����%d�g�峹�C", ++cuser.numposts);
      acct_save(&cuser, ACCTSAV_POST);
    }
  }
  else
  {
    www_printf("�峹�o������!�ؿ�: %s\n", folder);
  }
  unlink(fpath);
  return 1;
}


static int 
p_post()
{
  char *ptr, *str, *BrdName;
  int sign, bno, bits;
  BRD *brd;

  ptr = acct_locate();
  BrdName = nextword(&ptr);

  sign = atoi(nextword(&ptr));
  if (sign >= 0 && sign <= 3)	/* 0:���[ 1~3:ñ�W�� */
    cuser.signature = sign;

  bshm_init();			/* �@�ɤ��s��l�� */
  brh_load();			/* Board History Loading */

  bno = brd_bno(BrdName);

  if (bno < 0)
    msg_quit(err_bid);

  str = &brd_bits[bno];
  bits = *str;
  brd = bshm->bcache + bno;
  brh_get(brd->bstamp, bno);
  strcpy(currboard, brd->brdname);

  bbstate = brd->battr;

  if (!(bits & BRD_W_BIT))
    msg_quit(err_perm);

#ifdef HAVE_ANONYMOUS
  if ((bbstate & BRD_ANONYMOUS) && atoi(nextword(&ptr)))
    curredit |= EDIT_ANONYMOUS;	/* �ΦW�F�� ~ */
#endif

  do_post();

  brh_save();
  bbstate = 0;
  return 1;
}


/* ----------------------------------------------------	 */
/* Post Reply �^�_�峹					 */
/* ----------------------------------------------------	 */


static int
do_reply(num)
  int num;
{
  char fpath[80];
  HDR fhdr;

  brd_fpath(fpath, currboard, fn_dir);

  num--;		/* �O�o��1��~�O�u����m�� */
  memset(&fhdr, 0, sizeof(HDR));

  if (!rec_get(fpath, &fhdr, sizeof(HDR), num))
  {
#ifdef HAVE_REFUSEMARK
    if ((fhdr.xmode & POST_RESTRICT) &&
      strcmp(fhdr.owner, cuser.userid) && !(bbstate & STAT_BOARD))
      msg_quit("�Ӥ峹���O�K���A");
#endif

    www_printf("result=OK&board=%s&title=%s\n\n", currboard, fhdr.title);
    quote_edit(fpath, &fhdr);
  }
  else
  {
    msg_quit("���~�A���s�b���峹!");
  }

  return 1;
}


static int 
p_reply()
{
  char *ptr, *str, *BrdName;
  int num, bno, bits;

  ptr = acct_locate();
  BrdName = nextword(&ptr);
  num = atoi(nextword(&ptr));
  if (num < 1)
    num = 1;

  bshm_init();			/* �@�ɤ��s��l�� */
  brh_load();			/* Board History Loading */

  strcpy(currboard, BrdName);
  bno = brd_bno(BrdName);

  if (bno < 0)
    msg_quit(err_bid);

  str = &brd_bits[bno];
  bits = *str;

  if (!(bits & BRD_W_BIT))
    msg_quit(err_perm);

  do_reply(num);

  bbstate = 0;
  return 1;
}


/* ----------------------------------------------------	 */
/* ��ܪO���峹						 */
/* ----------------------------------------------------	 */


static int 
p_file()
{
  char *ptr, *BrdName, *file;

  ptr = myWRC.query;

  BrdName = nextword(&ptr);
  file = nextword(&ptr);

  {
    char fpath[80];

    strcpy(currboard, BrdName);
    brd_fpath(fpath, currboard, file);
    www_printf("result=OK&board=%s&file=%s\n\n", currboard, file);
    article_show(fpath);
  }
  return 1;
}


/* ----------------------------------------------------	 */
/* ��H�峹						 */
/* ----------------------------------------------------	 */


static int 
p_forward()			/* pid, board, num, rcpt */
{
  char *ptr, *argStr, rcpt[64];
  char *userid, *title, bpath[80], fpath[80], folder[80];
  int num, bno, userno, pos;
  usint level, method;
  BRD *brd;
  HDR hdr;

  ptr = acct_locate();

  level = cuser.userlevel;

  if ((level & (PERM_FORWARD | PERM_DENYMAIL)) != PERM_FORWARD)
    msg_quit(err_perm);;

  argStr = nextword(&ptr);
  strcpy(currboard, argStr);

  num = atoi(nextword(&ptr));
  if (num < 1)
    num = 1;

  argStr = nextword(&ptr);
  strcpy(rcpt, argStr);

  bshm_init();

  bno = brd_bno(currboard);
  if (bno < 0)
    msg_quit(err_bid);

  brd = bshm->bcache + bno;

  if (brd->readlevel && !(brd->readlevel & level))
    msg_quit(err_perm);

  userid = cuser.userid;

  /* �Ѧ� struct.h �� MQ_UUENCODE / MQ_JUSTIFY */
#define	MF_SELF	0x04
#define	MF_USER	0x08

  userno = 0;

  if (!mail_external(rcpt))	/* ���~�d�I */
  {
    if (!str_cmp(rcpt, userid))
    {
      method = MF_SELF;
    }
    else
    {
      if ((userno = acct_userno(rcpt)) <= 0)
	msg_quit("���W�S���ӨϥΪ�!");
      method = MF_USER;
    }
    usr_fpath(folder, rcpt, fn_dir);
  }
  else
  {
    if (not_addr(rcpt))
      msg_quit("�����T���l��a�}!");
    method = 0;
  }

  brd_fpath(bpath, currboard, fn_dir);
  pos = num - 1;
  if (rec_get(bpath, &hdr, sizeof(HDR), pos))
    msg_quit("�䤣��Ӥ峹!");

  title = hdr.title;

#ifdef HAVE_REFUSEMARK
  if ((hdr.xmode & POST_RESTRICT) &&
    strcmp(hdr.owner, cuser.userid) && !(bbstate & STAT_BOARD))
    msg_quit("�Ӥ峹���O�K���A");
#endif

  hdr_fpath(fpath, bpath, &hdr);

  if (method >= MF_SELF)
  {
    HDR mhdr;

    if (hdr_stamp(folder, HDR_LINK, &mhdr, fpath) < 0)
      msg_quit("��H����!!!");

    if (method == MF_SELF)
    {
      strcpy(mhdr.owner, "[�� �� ��]");
      mhdr.xmode = MAIL_READ | MAIL_NOREPLY;
    }
    else
    {
      strcpy(mhdr.owner, userid);
    }

    strcpy(mhdr.nick, cuser.username);
    strcpy(mhdr.title, title);
    if (rec_add(folder, &mhdr, sizeof(HDR)) < 0)
      msg_quit("��H����!!!!");
  }
  else
  {
#ifdef USE_SENDMAIL
    if (bbs_sendmail(fpath, title, rcpt, 0) < 0)
#else
    if (bsmtp(fpath, title, rcpt, 0) < 0)
#endif
      msg_quit("�H��L�k�H�F!!!");
  }

#undef  MF_SELF
#undef  MF_USER

  if (userno > 0)
    m_biff(userno);

  www_printf("result=OK&msg=�H�󦨥\\�H��<%s>", rcpt);
  return 1;
}


/* ------------------------------------------------------- */
/* �d��峹 �ĥ�mmap�覡�[�t �B������X�A���ݭn�A��php�ѪR */
/* ------------------------------------------------------- */

static int totalMatch;

#define	MAX_MATCH	200

static int 
post_match(board, author, title, title2, title3, day)
  char *board, *author;
  char *title, *title2, *title3;
  int day;
{
  int bno, bits, fsize, max, num, dt, sum;
  BRD *brd;
  char fpath[80], *str, *fimage;
  HDR *head, *tail;
  time_t now;

  bno = brd_bno(board);
  if (bno < 0)
    return -1;			/* brd_flag ? continue : msg_quit(errBoard) */

  str = &brd_bits[bno];
  bits = *str;

  brd = bshm->bcache + bno;
  brh_get(brd->bstamp, bno);

  if (!(bits & BRD_R_BIT))
    return -1;			/* �P�W */

  brd_fpath(fpath, board, fn_dir);

  fimage = f_map(fpath, &fsize);

  if (fimage == (char *)-1)
    return -1;			/* the same as up */

  max = fsize / sizeof(HDR);

  head = (HDR *) fimage;
  tail = (HDR *) (fimage + fsize);

  time(&now);
  sum = 0;
  num = max + 1;
  dt = day * 86400;
  while (tail-- >= head)
  {
    char *thisTitle;
    num--;

    if (totalMatch > MAX_MATCH)
      break;

    if ((dt > 0) && ((now - tail->chrono) > dt))
      break;			/* �L�� */

#ifdef HAVE_REFUSEMARK
    if ((tail->xmode & POST_RESTRICT) && strcmp(tail->owner, cuser.userid))
      continue;
#endif

    if (*author && str_cmp(tail->owner, author))
      continue;

    thisTitle = tail->title;
    if (STR4(thisTitle) == STR4(STR_REPLY))	/* ���� Re: ���~ */
      thisTitle += 4;

    if (*title && !str_str(thisTitle, title))
      continue;

    if (*title2 && !str_str(thisTitle, title2))
      continue;

    if (*title3 && str_str(thisTitle, title3))
      continue;

    totalMatch++;
    sum++;

    post_item(num, tail, fpath);
  }

  munmap(fimage, fsize);
  if (sum > 0)
  {
    www_printf("�H�W�峹�Ӧ�<a href='postlist.php?board=%s'>%s %s</a> �@�p%d�g \n", 
      brd->brdname, brd->brdname, brd->title, sum);
  }

  return 0;
}


static int 
p_search()			/* pid, board, day, author, title, title2, !title3 */
{
  char *ptr, *board, *author, *title, *title2, *title3;
  int day, brd_flag = 0;

  ptr = acct_locate();

  /* board == "NULL" �ɬ��Ҧ��ݪO */
  board = nextword(&ptr);
  if (!str_cmp(board, "NULL"))	/* �Ҧ��O�� */
    brd_flag = 1;

  day = atoi(nextword(&ptr));

  author = nextword(&ptr);
  if (!strncmp(author, "NULL", 4))
    *author = '\0';

  title = nextword(&ptr);
  if (!strncmp(title, "NULL", 4))
    *title = '\0';

  title2 = nextword(&ptr);
  if (!strncmp(title2, "NULL", 4))
    *title2 = '\0';

  title3 = nextword(&ptr);
  if (!strncmp(title3, "NULL", 4))
    *title3 = '\0';

  /* Board Main */
  totalMatch = 0;
  bshm_init();			/* �@�ɤ��s��l�� */
  brh_load();			/* Board History Loading */

  www_printf("result=OK&board=%s&author=%s&title=%s&title2=%s&title3=%s&day=%d\n",
    board, author, title, title2, title3, day);

  if (!brd_flag)
  {
    if (post_match(board, author, title, title2, title3, day))
      msg_quit("���~���Q�װ�");

    return 1;
  }
  else
  {
    BRD *bhdr, *tail;

    bhdr = bshm->bcache;
    tail = bhdr + bshm->number;

    do
    {
      www_printf("num=%d&brd=%s\n", -1, bhdr->brdname);
      post_match(bhdr->brdname, author, title, title2, title3, day);
      if (totalMatch > MAX_MATCH)
      {
	www_printf("�j�����G�w�g�W�L %d���A�t�Τ���j���A�п�J��[��T������r!!\n", MAX_MATCH);
	break;
      }
    } while (++bhdr < tail);
  }

  www_printf("�@���O��: %d ��!", totalMatch);
  return 1;
}


/* ------------------------------------------- */
/* �d��O��                                    */
/* ------------------------------------------- */


static int 
b_search()
{
  char *ptr, *key, *str;
  BRD *bhdr, *tail;
  int bno, max;
  usint bits;

  ptr = acct_locate();
  key = nextword(&ptr);

  if (!key[0])
    msg_quit("�S����J����r!!");

  bshm_init();			/* �@�ɤ��s��l�� */
  brh_load();			/* Board History Loading */

  bhdr = bshm->bcache;
  tail = bhdr + bshm->number;
  bno = 0;
  max = 0;

  do
  {
    str = &brd_bits[bno++];
    bits = *str;
    if (!(bits & BRD_R_BIT))
      continue;

    if (!str_str(bhdr->brdname, key) && !str_str(bhdr->title, key))
      continue;

    max++;
    www_printf("no=%d&bname=%s&btitle=%s\n", max, bhdr->brdname, bhdr->title);
  } while (++bhdr < tail);

  www_printf("result=OK&max=%d", max);

  return 1;
}


/* �\����w�q */

WebKeyFunc board_cb[] =
{
  {"b_list", b_list},
  {"p_list", p_list},
  {"p_read", p_read},
  {"p_delete", p_delete},
  {"p_mark", p_mark},
  {"p_post", p_post},
  {"p_reply", p_reply},
  {"p_file", p_file},
  {"p_forward", p_forward},
  {"p_search", p_search},
  {"b_search", b_search},
  {NULL, NULL}
};
