/*-------------------------------------------------------*/
/* xover.c	( NTHU CS MapleBBS Ver 3.10 )		 */
/*-------------------------------------------------------*/
/* target : board/mail interactive reading routines 	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#include "bbs.h"

#ifdef MY_FAVORITE
#define MSG_ZONE_SWITCH	"�ֳt�����G(A)��� (B)�峹 (C)�ݪO (F)�̷R (M)�H�� (U)�ϥΪ� (W)���y�G"
#else
#define MSG_ZONE_SWITCH	"�ֳt�����G(A)��� (B)�峹 (C)�ݪO (M)�H�� (U)�ϥΪ� (W)���y�G"
#endif


/* ----------------------------------------------------- */
/* keep xover record					 */
/* ----------------------------------------------------- */


static XO *xo_root;		/* root of overview list */


XO *
xo_new(path)
  char *path;
{
  XO *xo;
  int len;

  len = strlen(path) + 1;

  xo = (XO *) malloc(sizeof(XO) + len);

  memcpy(xo->dir, path, len);

  return (xo);
}


XO *
xo_get(path)
  char *path;
{
  XO *xo;

  for (xo = xo_root; xo; xo = xo->nxt)
  {
    if (!strcmp(xo->dir, path))
      return xo;
  }

  xo = xo_new(path);
  xo->nxt = xo_root;
  xo_root = xo;
  xo->xyz = NULL;
  xo->pos = XO_TAIL;		/* �Ĥ@���i�J�ɡA�N��Щ�b�̫᭱ */

  return xo;
}


#ifdef AUTO_JUMPPOST
XO *
xo_get_post(path, blast)	/* itoc.010910: �Ѧ� xover.c xo_get()�A�� XoPost �q�����y */
  char *path;
  time_t blast;	/* �ݪO�̫�@�g */
{
  XO *xo;
  time_t chrono;
  int fd;
  int pos, locus, mid;	/* locus:������ mid:������ pos:�k���� */

  for (xo = xo_root; xo; xo = xo->nxt)
  {
    if (!strcmp(xo->dir, path))
      return xo;
  }
   
  xo = xo_new(path);
  xo->nxt = xo_root;
  xo_root = xo;
  xo->xyz = NULL;

  /* ���ٸ귽�A�Y�̫�@�g�wŪ�A�����ݪO��Ū�L�F */
  if (!brh_unread(blast) || (fd = open(path, O_RDONLY)) < 0)
  {
    xo->pos = XO_TAIL;	/* ��Щ�b�̫᭱ */
    return xo;
  }

  /* ��Ĥ@�g��Ū binary search */
  pos = rec_num(path, sizeof(HDR)) - 1;
  if (pos <= 0)		/* �u���@�g�Τ@�g���S�� */
  {
    close(fd);
    xo->pos = XO_TAIL;
    return xo;
  }

  locus = 0;
  while (1)
  {
    if (pos <= locus + 1)
      break;

    mid = locus + ((pos - locus) >> 1);
    lseek(fd, (off_t) (sizeof(HDR) * mid), SEEK_SET);
    if (read(fd, &chrono, sizeof(time_t)) == sizeof(time_t))
    {
      if (brh_unread(chrono))
	pos = mid;
      else
	locus = mid;
    }
    else
    {
      break;
    }
  }

  /* �S��: �p�G�k���а��d�b 1�A���G�إi��A�@�O��Ū��ĤG�g�A�t�@���s�Ĥ@�g���SŪ */
  if (pos == 1)
  {
    /* �ˬd�Ĥ@�g�O�_�wŪ */
    lseek(fd, (off_t) 0, SEEK_SET);
    if (read(fd, &chrono, sizeof(time_t)) == sizeof(time_t))
    {
      if (brh_unread(chrono))	/* �Y�s�Ĥ@�g�]��Ū�Apos �զ^�h�Ĥ@�g */
	pos = 0;
    }
  }

  xo->pos = pos;	/* �Ĥ@���i�J�ɡA�N��Щ�b�Ĥ@�g��Ū */
  close (fd);

  return xo;
}
#endif


#if 0
void
xo_free(xo)
  XO *xo;
{
  char *ptr;

  if (ptr = xo->xyz)
    free(ptr);
  free(xo);
}
#endif


/* ----------------------------------------------------- */
/* interactive menu routines			 	 */
/* ----------------------------------------------------- */


char xo_pool[(t_lines - 4) * XO_RSIZ];	/* XO's data I/O pool */


void
xo_load(xo, recsiz)
  XO *xo;
  int recsiz;
{
  int fd, max;

  max = 0;
  if ((fd = open(xo->dir, O_RDONLY)) >= 0)
  {
    int pos, top;
    struct stat st;

    fstat(fd, &st);
    max = st.st_size / recsiz;
    if (max > 0)
    {
      pos = xo->pos;
      if (pos <= 0)
      {
	pos = top = 0;
      }
      else
      {
	top = max - 1;
	if (pos > top)
	  pos = top;
	top = (pos / XO_TALL) * XO_TALL;
      }
      xo->pos = pos;
      xo->top = top;

      lseek(fd, (off_t) (recsiz * top), SEEK_SET);
      read(fd, xo_pool, recsiz * XO_TALL);
    }
    close(fd);
  }

  xo->max = max;
}


static void
xo_foot(zone)			/* itoc.010403: �� b_lines ��W feeter */
  int zone;
{
  switch (zone)
  {
  case XZ_CLASS:
    outz(FEETER_CLASS);
    break;

  case XZ_ULIST:
    outz(FEETER_ULIST);
    break;

  case XZ_PAL:
    outz(FEETER_PAL);
    break;

#ifdef HAVE_ALOHA
  case XZ_ALOHA:
    outz(FEETER_ALOHA);
    break;
#endif

  case XZ_VOTE:
    outz(FEETER_VOTE);
    break;

  case XZ_BMW:
    outz(FEETER_BMW);
    break;

#ifdef MY_FAVORITE
  case XZ_MF:
    outz(FEETER_MF);
    break;
#endif

#ifdef HAVE_COSIGN
  case XZ_COSIGN:
    outz(FEETER_COSIGN);
    break;
#endif

#ifdef HAVE_SONG
  case XZ_SONG:
    outz(FEETER_SONG);
    break;
#endif

#ifdef HAVE_XYNEWS
  case XZ_NEWS:
    outz(FEETER_NEWS);
    break;
#endif

#ifdef HAVE_XYPOST
  case XZ_XPOST:
    outz(FEETER_XPOST);
    break;
#endif

  case XZ_MBOX:
    outz(FEETER_MBOX);
    break;

  case XZ_POST:
    outz(FEETER_POST);
    break;

  case XZ_GEM:
    outz(FEETER_GEM);
    break;
  }
}


/* static */
void inline
xo_fpath(fpath, dir, hdr)
  char *fpath;
  char *dir;
  HDR *hdr;
{
  if (hdr->xmode & GEM_GOPHER)
    url_fpath(fpath, dir, hdr);
  else
    hdr_fpath(fpath, dir, hdr);
}


/* ----------------------------------------------------- */
/* nhead:						 */
/* 0 ==> �̾� TagList �s��R��				 */
/* !0 ==> �̾� range [nhead, ntail] �R��		 */
/* ----------------------------------------------------- */
/* notice : *.n - new file				 */
/* *.o - old file					 */
/* ----------------------------------------------------- */


int
hdr_prune(folder, nhead, ntail)
  char *folder;
  int nhead, ntail;
{
  int count, fdr, fsize, xmode, cancel;
  HDR *hdr;
  FILE *fpw;
  char fnew[80], fold[80];

  if ((fdr = open(folder, O_RDONLY)) < 0)
    return -1;

  if (!(fpw = f_new(folder, fnew)))
  {
    close(fdr);
    return -1;
  }

  xmode = *folder;
  cancel = (xmode == 'b');

  fsize = count = 0;
  mgets(-1);
  while (hdr = mread(fdr, sizeof(HDR)))
  {
    xmode = hdr->xmode;
    count++;

    if ((xmode & POST_MARKED) ||				/* �аO */
      (nhead && (count < nhead || count > ntail)) ||		/* range */
      (!nhead && Tagger(hdr->chrono, count - 1, TAG_NIN)))	/* TagList */
    {
      if ((fwrite(hdr, sizeof(HDR), 1, fpw) != 1))
      {
	close(fdr);
	fclose(fpw);
	unlink(fnew);
	return -1;
      }
      fsize++;
    }
    else
    {
      /* �Y���ݪO�N�s�u��H */

      if (cancel)
	cancel_post(hdr);

      hdr_fpath(fold, folder, hdr);
      unlink(fold);
    }
  }
  close(fdr);
  fclose(fpw);

  sprintf(fold, "%s.o", folder);
  rename(folder, fold);
  if (fsize)
    rename(fnew, folder);
  else
    unlink(fnew);

  return 0;
}


int
xo_delete(xo)
  XO *xo;
{
  char buf[8];
  int head, tail;

  if ((bbsmode == M_READA) && !(bbstate & STAT_BOARD))
    return XO_NONE;

  vget(b_lines, 0, "[�]�w�R���d��] �_�I�G", buf, 6, DOECHO);
  head = atoi(buf);
  if (head <= 0)
  {
    zmsg("�_�I���~");
    return XO_FOOT;
  }

  vget(b_lines, 28, "���I�G", buf, 6, DOECHO);
  tail = atoi(buf);
  if (tail < head)
  {
    zmsg("���I���~");
    return XO_FOOT;
  }

  if (vget(b_lines, 41, msg_sure_ny, buf, 3, LCECHO) == 'y')
  {
    hdr_prune(xo->dir, head, tail);
    return XO_LOAD;
  }
  return XO_FOOT;
}


/* ----------------------------------------------------- */
/* Tag List ����					 */
/* ----------------------------------------------------- */


int TagNum;			/* tag's number */
TagItem TagList[TAG_MAX];	/* ascending list */


int
Tagger(chrono, recno, op)
  time_t chrono;
  int recno;
  int op;			/* op : TAG_NIN / TOGGLE / INSERT */
/* ----------------------------------------------------- */
/* return 0 : not found	/ full				 */
/* 1 : add						 */
/* -1 : remove						 */
/* ----------------------------------------------------- */
{
  int head, tail, pos, cmp;
  TagItem *tagp;

  for (head = 0, tail = TagNum - 1, tagp = TagList, cmp = 1; head <= tail;)
  {
    pos = (head + tail) >> 1;
    cmp = tagp[pos].chrono - chrono;
    if (!cmp)
    {
      break;
    }
    else if (cmp < 0)
    {
      head = pos + 1;
    }
    else
    {
      tail = pos - 1;
    }
  }

  if (op == TAG_NIN)
  {
    if (!cmp && recno)		/* �����Y�ԡG�s recno �@�_��� */
      cmp = recno - tagp[pos].recno;
    return cmp;
  }

  tail = TagNum;

  if (!cmp)
  {
    if (op != TAG_TOGGLE)
      return 0;

    TagNum = --tail;
    memcpy(&tagp[pos], &tagp[pos + 1], (tail - pos) * sizeof(TagItem));
    return -1;
  }

  if (tail < TAG_MAX)
  {
    TagItem buf[TAG_MAX];

    TagNum = tail + 1;
    tail = (tail - head) * sizeof(TagItem);
    tagp += head;
    memcpy(buf, tagp, tail);
    tagp->chrono = chrono;
    tagp->recno = recno;
    memcpy(++tagp, buf, tail);
    return 1;
  }

  /* TagList is full */

  bell();
  return 0;
}


void
EnumTagHdr(hdr, dir, locus)
  HDR *hdr;
  char *dir;
  int locus;
{
  rec_get(dir, hdr, sizeof(HDR), TagList[locus].recno);
}


int
AskTag(msg)
  char *msg;
/* ----------------------------------------------------- */
/* return value :					 */
/* -1	: ����						 */
/* 0	: single article				 */
/* o.w.	: whole tag list				 */
/* ----------------------------------------------------- */
{
  char buf[80];
  int num;

  num = TagNum;

  if (num)	/* itoc.020130: �� TagNum �~�� */
  {  
    sprintf(buf, "�� %s A)��g�峹 T)�аO�峹 Q)���}�H[%c] ", msg, num ? 'T' : 'A');
    switch (vans(buf))
    {
    case 'q':
      return -1;

    case 'a':
      return 0;
    }
  }
  return num;
}


/* ----------------------------------------------------- */
/* tag articles according to title / author		 */
/* ----------------------------------------------------- */


static int
xo_tag(xo, op)
  XO *xo;
  int op;
{
  int fsize, count;
  char *token, *fimage;
  HDR *head, *tail;

  fimage = f_map(xo->dir, &fsize);
  if (fimage == (char *) -1)
    return XO_NONE;

  head = (HDR *) xo_pool + (xo->pos - xo->top);
  if (op == Ctrl('A'))
  {
    token = head->owner;
    op = 0;
  }
  else
  {
    token = str_ttl(head->title);
    op = 1;
  }

  head = (HDR *) fimage;
  tail = (HDR *) (fimage + fsize);

  count = 0;

  do
  {
    if (!strcmp(token, op ? str_ttl(head->title) : head->owner))
    {
      if (!Tagger(head->chrono, count, TAG_INSERT))
	break;
    }
    count++;
  } while (++head < tail);

  munmap(fimage, fsize);
  return XO_BODY;
}


static int
xo_prune(xo)
  XO *xo;
{
  int num;
  char buf[80];

  if (!(num = TagNum) || ((bbsmode == M_READA) && !(bbstate & STAT_BOARD)))
    return XO_NONE;  /* Thor.990621.����: ���N�u���H�c��ݪO(�t�걵) */

  sprintf(buf, "�T�w�n�R�� %d �g���Ҷ�(Y/N)�H[N] ", num);
  if (vans(buf) != 'y')
    return XO_FOOT;

#if 1
  /* Thor.981122: �O���R���O�� */
  sprintf(buf,"(%d)%s", num, xo->dir);
  blog("PRUNE", buf);
#endif

  hdr_prune(xo->dir, 0, 0);

  TagNum = 0;
  
#ifdef HAVE_XYPOST	/* itoc.001029: ��ĳ���i XPOST */
  if (xo->key == XZ_XPOST)
  {
    vmsg("��C���g�妸�R����V�áA�Э��i�걵�Ҧ��I");
    return XO_QUIT;
  }
#endif

  return XO_LOAD;
}


/* ----------------------------------------------------- */
/* Tag's batch operation routines			 */
/* ----------------------------------------------------- */


extern BCACHE *bshm;    /* lkchu.981229 */


static int
xo_tbf(xo)
  XO *xo;
{
  char fpath[128], *dir;
  HDR *hdr, xhdr;
  int tag, locus, xmode;
  FILE *fp;

  if (!cuser.userlevel)
    return XO_NONE;

  tag = AskTag("������Ȧs��");
  if (tag < 0)
    return XO_FOOT;

  fp = tbf_open();
  if (fp == NULL)
    return XO_FOOT;

  if (tag)
    hdr = &xhdr;
  else
    hdr = (HDR *) xo_pool + xo->pos - xo->top;

  locus = 0;
  dir = xo->dir;

  do
  {
    if (tag)
    {
      fputs(STR_LINE, fp);
      EnumTagHdr(hdr, dir, locus++);
    }

    xmode = hdr->xmode;

    /* itoc.000319: �ץ�����Ť峹���o�פJ�Ȧs�� */
    /* itoc.010602: GEM_RESTRICT �M POST_RESTRICT �ǰt�A�ҥH�[�K�峹�]���o�פJ�Ȧs�� */
    if (xmode & (GEM_RESTRICT | GEM_RESERVED))
      continue;

    if (!(xmode & GEM_FOLDER))		/* �d hdr �O�_ plain text */
    {
      xo_fpath(fpath, dir, hdr);
      f_suck(fp, fpath);
    }
  } while (locus < tag);

  fclose(fp);
  zmsg("��������");

  return XO_FOOT;
}


static int
xo_forward(xo)
  XO *xo;
{
  static char rcpt[64];
  char fpath[128], folder[80], *dir, *title, *userid;
  HDR *hdr, xhdr;
  int tag, locus, userno, cc, xmode;
  usint method;			/* �O�_ uuencode */

  if (!HAS_PERM(PERM_FORWARD))
    return XO_NONE;

  if (HAS_PERM(PERM_DENYMAIL))
  {
    vmsg(MSG_DENYMAIL);
    return XO_FOOT;
  }

  tag = AskTag("��H");
  if (tag < 0)
    return XO_FOOT;

  if (!rcpt[0])
    strcpy(rcpt, cuser.email);

  if (!vget(b_lines, 0, "�ت��a�G", rcpt, sizeof(rcpt), GCARRY))
    return XO_FOOT;

  userid = cuser.userid;

  /* �Ѧ� struct.h �� MQ_UUENCODE / MQ_JUSTIFY */

#define	MF_SELF	0x04
#define	MF_USER	0x08

  userno = 0;

#if 0
  if (rcpt_local(rcpt))    /* ���~�d�I */
  /* Thor.981027: �� mail.c���� mail_external ���N */
#endif
  if (!mail_external(rcpt))    /* ���~�d�I */
  {
    if (!str_cmp(rcpt, userid))
    {
      /* userno = cuser.userno; */ /* Thor.981027: �H��ﶰ���ۤv���q���ۤv */
      method = MF_SELF;
    }
    else
    {
      if ((userno = acct_userno(rcpt)) <= 0)
      {
	sprintf(fpath, "�d�L���H�G%s", rcpt);
	zmsg(fpath);
	return XO_FOOT;
      }
      method = MF_USER;
    }

    usr_fpath(folder, rcpt, fn_dir);
  }
  else
  {
    if (not_addr(rcpt))
      return XO_FOOT;

    method = 0;

#if 0
    method = vans("�O�_�ݭn uuencode(Y/N)�H[N] ") == 'y' ?
      MQ_UUENCODE : 0;
#endif
  }

  hdr = tag ? &xhdr : (HDR *) xo_pool + xo->pos - xo->top;

  dir = xo->dir;
  title = hdr->title;
  locus = 0;
  cc = -1;

  do
  {
    if (tag)
      EnumTagHdr(hdr, dir, locus++);

    xmode = hdr->xmode;

    /* itoc.000319: �ץ�����Ť峹���o��H */
    /* itoc.010602: GEM_RESTRICT �M POST_RESTRICT �ǰt�A�ҥH�[�K�峹�]���o��H */
    if (xmode & (GEM_RESTRICT | GEM_RESERVED))
      continue;     

    if (!(xmode & GEM_FOLDER))		/* �d hdr �O�_ plain text */
    {
      xo_fpath(fpath, dir, hdr);

      if (method >= MF_SELF)
      {
	HDR mhdr;

	if ((cc = hdr_stamp(folder, HDR_LINK, &mhdr, fpath)) < 0)
	  break;

	if (method == MF_SELF)
	{
	  strcpy(mhdr.owner, "[�� �� ��]");
	  mhdr.xmode = MAIL_READ | MAIL_NOREPLY;
	}
	else
	{
	  strcpy(mhdr.owner, userid);
	}
	strcpy(mhdr.nick, cuser.username);
	strcpy(mhdr.title, title);
	if ((cc = rec_add(folder, &mhdr, sizeof(HDR))) < 0)
	  break;
      }
      else
      {
	if ((cc = bsmtp(fpath, title, rcpt, method)) < 0)
	  break;
      }
    }
  } while (locus < tag);

#undef	MF_SELF
#undef	MF_USER

  if (userno > 0 && cc >= 0)
    m_biff(userno);

  zmsg(cc < 0 ? "�����H��L�k�H�F" : "�H�H����");

  return XO_FOOT;
}


/* ----------------------------------------------------- */
/* �峹�@�̬d�ߡB�v���]�w				 */
/* ----------------------------------------------------- */


int
xo_uquery(xo)
  XO *xo;
{
  HDR *hdr;
  char *userid;

  hdr = (HDR *) xo_pool + (xo->pos - xo->top);
  if (hdr->xmode & (GEM_GOPHER | POST_INCOME | MAIL_INCOME))
    return XO_NONE;

  userid = hdr->owner;
  if (strchr(userid, '.'))
    return XO_NONE;

  move(1, 0);
  clrtobot();
  my_query(userid);
  return XO_HEAD;
}


int
xo_usetup(xo)
  XO *xo;
{
  HDR *hdr;
  char *userid;
  ACCT xuser;

  if (!HAS_PERM(PERM_ALLACCT))
    return XO_NONE;

  hdr = (HDR *) xo_pool + (xo->pos - xo->top);
  userid = hdr->owner;
  if (strchr(userid, '.') || (acct_load(&xuser, userid) < 0))
    return XO_NONE;

  move(3, 0);
  acct_setup(&xuser, 1);
  return XO_HEAD;
}


/* ----------------------------------------------------- */
/* �D�D���\Ū						 */
/* ----------------------------------------------------- */


#define RS_TITLE	0x001	/* author/title */
#define RS_FORWARD      0x002	/* backward */
#define RS_RELATED      0x004
#define RS_FIRST	0x008	/* find first article */
#define RS_CURRENT      0x010	/* match current read article */
#define RS_THREAD	0x020	/* search the first article */
#define RS_SEQUENT	0x040	/* sequential read */
#define RS_MARKED 	0x080	/* marked article */
#define RS_UNREAD 	0x100	/* unread article */
#define	RS_BOARD	0x1000	/* �Ω� RS_UNREAD�A��e�������i���| */

#define CURSOR_FIRST	(RS_RELATED | RS_TITLE | RS_FIRST)
#define CURSOR_NEXT	(RS_RELATED | RS_TITLE | RS_FORWARD)
#define CURSOR_PREV	(RS_RELATED | RS_TITLE)
#define RELATE_FIRST	(RS_RELATED | RS_TITLE | RS_FIRST | RS_CURRENT)
#define RELATE_NEXT	(RS_RELATED | RS_TITLE | RS_FORWARD | RS_CURRENT)
#define RELATE_PREV	(RS_RELATED | RS_TITLE | RS_CURRENT)
#define THREAD_NEXT	(RS_THREAD | RS_FORWARD)
#define THREAD_PREV	(RS_THREAD)

/* Thor: �e���mark�峹, ��K���D��������D���B�z */

#define MARK_NEXT	(RS_MARKED | RS_FORWARD | RS_CURRENT)
#define MARK_PREV	(RS_MARKED | RS_CURRENT)


typedef struct
{
  int key;			/* key stroke */
  int map;			/* the mapped threading op-code */
}      KeyMap;


static KeyMap keymap[] =
{
  /* search title / author */

  '?', RS_TITLE | RS_FORWARD,
  '|', RS_TITLE,
  'A', RS_FORWARD,
  'Q', 0,

  /* thread : currtitle */

  '[', RS_RELATED | RS_TITLE | RS_CURRENT,
  ']', RS_RELATED | RS_TITLE | RS_FORWARD | RS_CURRENT,
  '=', RS_RELATED | RS_TITLE | RS_FIRST | RS_CURRENT,

  /* i.e. < > : make life easier */

  ',', RS_THREAD,
  '.', RS_THREAD | RS_FORWARD,

  /* thread : cursor */

  '-', RS_RELATED | RS_TITLE,
  '+', RS_RELATED | RS_TITLE | RS_FORWARD,
  '\\', RS_RELATED | RS_TITLE | RS_FIRST,

  /* Thor: marked : cursor */
  '\'', RS_MARKED | RS_FORWARD | RS_CURRENT,
  ';', RS_MARKED | RS_CURRENT,

  /* Thor: �V�e��Ĥ@�g��Ū���峹 */
  /* Thor.980909: �V�e�䭺�g��Ū, �Υ��g�wŪ */
  '`', RS_UNREAD /* | RS_FIRST */,

  /* sequential */

  ' ', RS_SEQUENT | RS_FORWARD,
  KEY_RIGHT, RS_SEQUENT | RS_FORWARD,
  KEY_PGDN, RS_SEQUENT | RS_FORWARD,
  KEY_DOWN, RS_SEQUENT | RS_FORWARD,
  /* Thor.990208: ���F��K�ݤ峹�L�{��, ���ܤU�g, ���M�W�h�Qxover�Y���F:p */
  'j', RS_SEQUENT | RS_FORWARD,

  KEY_UP, RS_SEQUENT,
  KEY_PGUP, RS_SEQUENT,
  /* Thor.990208: ���F��K�ݤ峹�L�{��, ���ܤW�g, ���M�W�h�Qxover�Y���F:p */
  'k', RS_SEQUENT,

  /* end of keymap */

  (char) NULL, -1
};


static int
xo_keymap(key)
  int key;
{
  KeyMap *km;
  int ch;

  km = keymap;
  while (ch = km->key)
  {
    if (ch == key)
      break;
    km++;
  }
  return km->map;
}


/* itoc.010913: xo_thread() �^�ǭ�               */
/* XO_NONE: �S���δN�O��ЩҦb�A���βM b_lines */
/* XO_FOOT: �S���δN�O��ЩҦb�A�ݭn�M b_lines */
/* XO_BODY: ���F�A���b�O��                     */
/*      -1: ���F�A�N�b�����A���βM b_lines     */
/*      -2: ���F�A�N�b�����A�ݭn�M b_lines     */


static int
xo_thread(xo, op)
  XO *xo;
  int op;
{
  static char s_author[16], s_title[32], s_unread[2] = "0";
  char buf[80];

  char *tag, *query, *title;
  int pos, match, foot, near, neartop, max;	/* Thor: neartop�Pnear����� */

  int fd, top, bottom, step, len;
  HDR *pool, *fhdr;

  match = XO_NONE;
  foot = 0;		/* itoc.010913: �w�]���βM b_lines */
  pos = xo->pos;
  top = xo->top;
  pool = (HDR *) xo_pool;
  fhdr = pool + (pos - top);
  step = (op & RS_FORWARD) - 1;

  if (op & RS_RELATED)
  {
    tag = fhdr->title;

    if (op & RS_CURRENT)
    {
      query = currtitle;
      if (op & RS_FIRST)
      {
	if (!strcmp(query, tag))/* �ثe���N�O�Ĥ@���F */
	  return XO_NONE;
	near = -1;
      }
    }
    else
    {
      title = str_ttl(tag);
      if (op & RS_FIRST)
      {
	if (title == tag)
	  return XO_NONE;
	near = -1;
      }
      query = buf;
      strcpy(query, title);
    }
  }
  else if (op & RS_UNREAD)	/* Thor: �V�e��M�Ĥ@�g��Ū�峹,�M near */
  {
    /* Thor.980909: �߰� ���g��Ū �� ���g�wŪ */
    near = xo->dir[0];
    if (near != 'b' && near != 'u')	/* itoc.010913: �u���\�b�ݪO/�H�c�j�M */
      return XO_NONE;

    if (!vget(b_lines, 0, "�V�e��M (0)���g��Ū (1)���g�wŪ ", s_unread, sizeof(s_unread), GCARRY))
      return XO_FOOT;

    if (*s_unread == '0')
      op |= RS_FIRST;	/* Thor.980909: �V�e��M���g��Ū */

    if (near == 'b')		/* search board */
      op |= RS_BOARD;

    foot = 1;	/* itoc.010913: �n�M b_lines */
    near = -1;
  }
  else if (!(op & (RS_THREAD | RS_SEQUENT | RS_MARKED)))
  {
    if (op & RS_TITLE)
    {
      title = "���D";
      tag = s_title;
      len = sizeof(s_title);
    }
    else
    {
      title = "�@��";
      tag = s_author;
      len = sizeof(s_author);
    }
    query = buf;
    sprintf(query, "�j�M%s(%s)�G", title, (step > 0) ? "��" : "��");
    if (!vget(b_lines, 0, query, tag, len, GCARRY))
      return XO_FOOT;

    foot = 1;	/* itoc.010913: �n�M b_lines */
    str_lower(query, tag);
  }

  fd = -1;
  len = sizeof(HDR) * XO_TALL;
  bottom = top + XO_TALL;
  max = xo->max;
  if (bottom > max)
    bottom = max;

  for (;;)
  {
    if (step > 0)
    {
      if (++pos >= max)
	break;
    }
    else
    {
      if (--pos < 0)
	break;
    }

    /* buffer I/O : shift sliding window scope */

    if ((pos < top) || (pos >= bottom))
    {
      if (fd < 0)
      {
	fd = open(xo->dir, O_RDONLY);
	if (fd < 0)
	  return XO_QUIT;
      }

      if (step > 0)
      {
	top += XO_TALL;
	bottom = top + XO_TALL;
	if (bottom > max)
	  bottom = max;
      }
      else
      {
	bottom = top;
	top -= XO_TALL;
      }

      lseek(fd, (off_t) (sizeof(HDR) * top), SEEK_SET);
      read(fd, pool, len);

      fhdr = (step > 0) ? pool : pool + XO_TALL - 1;
    }
    else
    {
      fhdr += step;
    }

#ifdef HAVE_REFUSEMARK
    if ((fhdr->xmode & POST_RESTRICT) &&
      strcmp(fhdr->owner, cuser.userid) && !(bbstate & STAT_BM))
      continue;
#endif

    if (op & RS_SEQUENT)
    {
      match = -1;
      break;
    }

    /* Thor: �e�� search marked �峹 */

    if (op & RS_MARKED)
    {
      if (fhdr->xmode & POST_MARKED)
      {
	match = -1;
	break;
      }
      continue;
    }

    /* �V�e��M�Ĥ@�g��Ū�峹 */

    if (op & RS_UNREAD)
    {
      /* Thor.980909: ���g��Ū(RS_FIRST) �P ���g�wŪ(!RS_FIRST) */
      if (op & RS_BOARD)
      {
	/* if (!brh_unread(fhdr->chrono)) */
	if (!(op & RS_FIRST) ^ !brh_unread(fhdr->chrono))
   	  continue;
      }
      else
      {
  	/* if ((fhdr->xmode & MAIL_READ) */
  	if (!(op & RS_FIRST) == !(fhdr->xmode & MAIL_READ))
	  continue;
      }

#undef	RS_BOARD
      /* Thor.980909: ���g�wŪ(!RS_FIRST) */
      if (!(op & RS_FIRST))
      {
	match = -1;
	break;
      }

      near = pos;		/* Thor:�O�U�̱���_�I����m */
      neartop = top;
      continue;
    }

    /* ------------------------------------------------- */
    /* �H�U�j�M title / author				 */
    /* ------------------------------------------------- */

    if (op & (RS_TITLE | RS_THREAD))
    {
      title = fhdr->title;	/* title ���V [title] field */
      tag = str_ttl(title);	/* tag ���V thread's subject */

      if (op & RS_THREAD)
      {
	if (tag == title)
	{
	  match = -1;
	  break;
	}
	continue;
      }
    }
    else
    {
      tag = fhdr->owner;	/* tag ���V [owner] field */
    }

    if (((op & RS_RELATED) && !strncmp(tag, query, 40)) ||
      (!(op & RS_RELATED) && str_str(tag, query)))
    {
      if (op & RS_FIRST)
      {
	if (tag != title)
	{
	  near = pos;		/* �O�U�̱���_�I����m */
	  neartop = top;
	  continue;
	}
      }

#if 0
      if ((!(op & RS_CURRENT)) && (op & RS_RELATED) &&
	strncmp(currtitle, query, TTLEN))
      {
	str_ncpy(currtitle, query, TTLEN);
	match = XO_BODY;
      }
      else
#endif

	match = -1;
      break;
    }
  }

  bottom = xo->top;

  if (match < 0)
  {
    xo->pos = pos;
    if (bottom != top)
    {
      xo->top = top;
      match = XO_BODY;		/* ���F�A�åB�ݭn��s�e�� */
    }
  }				/* Thor: �[�W RS_FIRST�\�� */
  else if ((op & RS_FIRST) && near >= 0)
  {
    xo->pos = near;
    if (top != neartop)		/* Thor.980609: top ���ثe��buffer��top */
    {
      lseek(fd, (off_t) (sizeof(HDR) * neartop), SEEK_SET);
      read(fd, pool, len);
    }
    if (bottom != neartop)	/* Thor.980609: bottom���e����top */
    {
      xo->top = neartop;
      match = XO_BODY;		/* ���F�A�åB�ݭn��s�e�� */
    }
    else
      match = -1;
  }
  else if (bottom != top)
  {
    lseek(fd, (off_t) (sizeof(HDR) * bottom), SEEK_SET);
    read(fd, pool, len);
  }

  if (fd >= 0)
    close(fd);

  /* itoc.010913: ���ܦ^�ǭ� */
  if (foot && match != XO_BODY)
    match = (match == XO_NONE) ? XO_FOOT : -2;

  return match;
}


/* Thor.990204: ���Ҽ{more �Ǧ^��, �H�K�ݤ@�b�i�H�� []... 
                ch �����emore()���ҫ���key */   
int
xo_getch(xo, ch)
  XO *xo;
  int ch;
{
  int op;

  if (!ch)
    ch = vkey();

  op = xo_keymap(ch);
  if (op >= 0)
  {
    ch = xo_thread(xo, op);
    if (ch != XO_NONE)
      ch = XO_BODY;		/* �~���s�� */
  }

  return ch;
}


static int
xo_jump(pos, zone)
  int pos;			/* ���ʴ�Ш� number �Ҧb���S�w��m */
  int zone;			/* itoc.010403: �� zone �]�Ƕi�� */
{
  char buf[6];

  buf[0] = pos;
  buf[1] = '\0';
  vget(b_lines, 0, "���ܲĴX���G", buf, sizeof(buf), GCARRY);

#if 0
  move(b_lines, 0);
  clrtoeol();
#endif
  xo_foot(zone);	/* itoc.010403: �� b_lines ��W feeter */

  pos = atoi(buf);

  if (pos > 0)
    return XO_MOVE + pos - 1;

  return XO_NONE;
}


/* ----------------------------------------------------- */
/* ----------------------------------------------------- */

#ifdef HAVE_XYPOST
extern KeyFunc xpost_cb[];
#endif

extern KeyFunc post_cb[];


XZ xz[] =
{
  {NULL, NULL, M_BOARD},	/* XZ_CLASS */
  {NULL, NULL, M_LUSERS},	/* XZ_ULIST */
  {NULL, NULL, M_PAL},		/* XZ_PAL */
  {NULL, NULL, M_PAL},		/* XZ_ALOHA */
  {NULL, NULL, M_VOTE},		/* XZ_VOTE */
  {NULL, NULL, M_BMW},		/* XZ_BMW */	/* lkchu.981230: BMW �s���� */
  {NULL, NULL, M_MF},		/* XZ_MF */
  {NULL, NULL, M_COSIGN},	/* XZ_COSIGN */
  {NULL, NULL, M_SONG},		/* XZ_SONG */
  {NULL, NULL, M_READA},	/* XZ_NEWS */
#ifdef HAVE_XYPOST
  {NULL, xpost_cb, M_READA},	/* XZ_XPOST */
#else
  {NULL, NULL, M_READA},	/* skip XZ_XPOST */
#endif
  {NULL, NULL, M_RMAIL},	/* XZ_MBOX */
  {NULL, post_cb, M_READA},	/* XZ_POST */
  {NULL, NULL, M_GEM}		/* XZ_GEM */
};


/* ----------------------------------------------------- */
/* interactive menu routines			 	 */
/* ----------------------------------------------------- */


void
xover(cmd)
  int cmd;
{
  int pos, num, zone, sysmode;
  XO *xo;
  KeyFunc *xcmd, *cb;

  for (;;)
  {
    while (cmd != XO_NONE)
    {
      if (cmd == XO_FOOT)
      {
	xo_foot(zone);		/* itoc.010403: �� b_lines ��W feeter */
	break;
      }

      if (cmd >= XO_ZONE)
      {
	/* --------------------------------------------- */
	/* switch zone					 */
	/* --------------------------------------------- */

	zone = cmd;
	cmd -= XO_ZONE;
	xo = xz[cmd].xo;
	xcmd = xz[cmd].cb;
	sysmode = xz[cmd].mode;

	TagNum = 0;		/* clear TagList */
	cmd = XO_INIT;
	utmp_mode(sysmode);
      }
      else if (cmd >= XO_MOVE - XO_TALL)
      {
	/* --------------------------------------------- */
	/* calc cursor pos and show cursor correctly	 */
	/* --------------------------------------------- */

	/* cmd >= XO_MOVE - XO_TALL so ... :chuan: ���] cmd = -1 ?? */

	/* fix cursor's range */

	num = xo->max - 1;

	/* pos = (cmd | XO_WRAP) - (XO_MOVE + XO_WRAP); */
	/* cmd &= XO_WRAP; */
	/* itoc.020124: �ץ��b�Ĥ@���� PGUP�B�̫�@���� PGDN�B�Ĥ@���� UP�B�̫�@���� DOWN �|�� XO_WRAP �X�Ю��� */

	if (cmd > XO_MOVE + (XO_WRAP >> 1))     /* XO_WRAP >> 1 ���j�L�峹�� */
	{
	  pos = cmd - (XO_MOVE + XO_WRAP);
	  cmd = 1;				/* �� KEY_UP �� KEY_DOWN */
	}
	else
	{
	  pos = cmd - XO_MOVE;
	  cmd = 0;
	}

	/* pos: �n���h������  cmd: �O�_�� KEY_UP �� KEY_DOWN */

	if (pos < 0)
	{
	  /* pos = (bbsmode == M_READA) ? 0 : num; *//* itoc.000304: �\Ū��Ĥ@�g�� KEY_UP �� KEY_PGUP ���|½��̫� */
	  pos = num;	/* itoc.020124: ½��̫�����K�A���Ӥ��|���H�O���WŪ�� :P */
	}
	else if (pos > num)
	{
	  if (bbsmode == M_READA)
	    pos = num;	/* itoc.000304: �\Ū��̫�@�g�� KEY_DOWN �� KEY_PGDN ���|½��̫e */
	  else
	    pos = (cmd || pos == num + XO_TALL) ? 0 : num;	/* itoc.020124: �n�קK�p�G�b�˼ƲĤG���� KEY_PGDN�A
								   �ӳ̫�@���g�ƤӤַ|�������h�Ĥ@���A�ϥΪ̷|
								   �����D���̫�@���A�G���b�̫�@�����@�U */
	}

	/* check cursor's range */

	cmd = xo->pos;

	if (cmd == pos)
	  break;

	xo->pos = pos;
	num = xo->top;
	if ((pos < num) || (pos >= num + XO_TALL))
	{
	  xo->top = (pos / XO_TALL) * XO_TALL;
	  cmd = XO_LOAD;	/* ���J��ƨä��H��� */
	}
	else
	{
	  move(3 + cmd - num, 0);
	  outc(' ');

	  break;		/* �u���ʴ�� */
	}
      }

      /* ----------------------------------------------- */
      /* ���� call-back routines			 */
      /* ----------------------------------------------- */

      cb = xcmd;
      num = cmd | XO_DL; /* Thor.990220: for dynamic load */
      for (;;)
      {
	pos = cb->key;
#if 1
	/* Thor.990220: dynamic load , with key | XO_DL */
	if (pos == num)
	{
	  void *p = DL_get((char *) cb->func);
	  if (p) 
	  {
	    cb->func = p;
	    pos = cb->key = cmd;
	  }
	  else
	  {
	    cmd = XO_NONE;
	    break;
	  }
	}
#endif
	if (pos == cmd)
	{
	  cmd = (*(cb->func)) (xo);

	  if (cmd == XO_QUIT)
	    return;

	  break;
	}
	
	if (pos == 'h')		/* itoc.001029: 'h' �O�@�S�ҡA�N�� *_cb ������ */
	{
	  cmd = XO_NONE;	/* itoc.001029: �N���䤣�� call-back, ���@�F! */
	  break;
	}

	cb++;
      }

    } /* Thor.990220.����: end of while (cmd!=XO_NONE) */

    utmp_mode(sysmode); 
    /* Thor.990220:����:�ΨӦ^�_ event handle routine �^�ӫ᪺�Ҧ� */

    pos = xo->pos;

    if (xo->max > 0)		/* Thor:�Y�O�L�F��N��show�F */
    {
      num = 3 + pos - xo->top;
      move(num, 0);
      outc('>');
    }

    cmd = vkey();

    /* itoc.����: �H�U�w�q�F�򥻫���A�ҿװ򥻫���A�N�O���ʪ��������A�q�Ω�Ҧ� XZ_ ���a�� */  

    /* ------------------------------------------------- */
    /* switch Zone					 */
    /* ------------------------------------------------- */

#ifdef  EVERY_Z
    if (cmd == Ctrl('Z'))
    {
      cmd = every_Z(zone);
    }
    else if (cmd == Ctrl('U'))
    {
      cmd = every_U(zone);
    }
    else
#endif


    /* ------------------------------------------------- */
    /* �򥻪���в��� routines				 */
    /* ------------------------------------------------- */

    if (cmd == KEY_LEFT /* || cmd == 'q' */)	/* itoc.020109: �� q ����X�ӷ��D�򥻫��� */
    {
      /* cmd = XO_LAST; *//* try to load the last XO in future */
      return;
    }
    else if (xo->max <= 0)	/* Thor: �L�F��h�L�k����� */
    {
      continue;
    }
    else if (cmd == KEY_UP || cmd == 'k')
    {
      cmd = pos - 1 + XO_MOVE + XO_WRAP;
    }
    else if (cmd == KEY_DOWN || cmd == 'j')
    {
      cmd = pos + 1 + XO_MOVE + XO_WRAP;
    }
    else if (cmd == ' ' || cmd == KEY_PGDN || cmd == 'N')
    {
      cmd = pos + XO_TALL + XO_MOVE;
    }
    else if (cmd == KEY_PGUP || cmd == 'P')
    {
      cmd = pos - XO_TALL + XO_MOVE;
    }
    else if (cmd == KEY_HOME || cmd == '0')
    {
      cmd = XO_MOVE;
    }
    else if (cmd == KEY_END || cmd == '$')
    {
      cmd = xo->max - 1 + XO_MOVE;
    }
    else if (cmd >= '1' && cmd <= '9')
    {
      cmd = xo_jump(cmd, zone);
    }
    else
    {
      /* ----------------------------------------------- */
      /* keyboard mapping				 */
      /* ----------------------------------------------- */

      if (cmd == KEY_RIGHT || cmd == '\n')
      {
	cmd = 'r';
      }
#ifdef HAVE_XYPOST
      else if (zone >= XZ_XPOST)
#else
      else if (zone >= XZ_MBOX)
#endif
      {
	/* --------------------------------------------- */
	/* Tag						 */
	/* --------------------------------------------- */

	if (cmd == 'C')
	{
	  cmd = xo_tbf(xo);
	}
	else if (cmd == 'F')
	{
	  cmd = xo_forward(xo);
	}
	else if (cmd == Ctrl('C'))
	{
	  extern int TagNum;

	  if (TagNum)
	  {
	    TagNum = 0;
	    cmd = XO_BODY;
	  }
	  else
	    cmd = XO_NONE;
	}
	else if (cmd == Ctrl('A') || cmd == Ctrl('T'))
	{
	  cmd = xo_tag(xo, cmd);
	}
	else if (cmd == Ctrl('D') && zone < XZ_GEM)
	{
	  /* ��ذϭn�v�@�R��, �H�קK�~�� */

	  cmd = xo_prune(xo);
	}


	/* --------------------------------------------- */
	/* �D�D���\Ū					 */
	/* --------------------------------------------- */

#ifdef HAVE_XYPOST
	if (zone == XZ_XPOST)
	  continue;
#endif

	pos = xo_keymap(cmd);
	if (pos >= 0)			/* �p�G���O����V�� */
	{
	  cmd = xo_thread(xo, pos);	/* �h�d�d�O���@�� thread �j�M */	  

	  if (cmd < 0)		/* �b������� match */
	  {
	    move(num, 0);
	    outc(' ');
	    /* cmd = XO_NONE; */
	    /* itoc.010913: �Y�Ƿj�M�n�� b_lines ��W feeter */
	    cmd = (cmd == -1) ? XO_NONE : XO_FOOT;
	  }
	}
      }

      /* ----------------------------------------------- */
      /* ��L���浹 call-back routine �h�B�z		 */
      /* ----------------------------------------------- */

    } /* Thor.990220.����: end of vkey() handling */
  }
}


/* ----------------------------------------------------- */
/* Thor.980725: ctrl Z everywhere			 */
/* ----------------------------------------------------- */


#ifdef	EVERY_Z
static int z_status = 0;	/* �i�J�X�h */

int
every_Z(zone)
  int zone;				/* �ǤJ�Ҧb XZ_ZONE�A�Y�ǤJ 0�A���ܤ��b xover() �� */
{
  int cmd, tmpmode, tmpstate;

  /* itoc.000319: �̦h every_Z �@�h */
  if (z_status >= 1)
    return XO_NONE;
  else
    z_status++;

  cmd = zone;
  outz(MSG_ZONE_SWITCH);
  switch(vkey())
  {
  case 'a':
    cmd = XZ_GEM;
    break;

  case 'b':
    if (xz[XZ_POST - XO_ZONE].xo)	/* �Y�w��w�ݪO�A�i�J�ݪO�A�_�h��ݪO�C�� */
    {
      XoPost(currbno);
      cmd = XZ_POST;
      break;
    }

  case 'c':
    cmd = XZ_CLASS;
    break;

#ifdef MY_FAVORITE
  case 'f':
    if (HAS_PERM(PERM_BASIC))
      cmd = XZ_MF;
    break;
#endif

  case 'm':
    if (HAS_PERM(PERM_BASIC))
      cmd = XZ_MBOX;
    break;

  case 'u':
    cmd = XZ_ULIST;
    break;

  case 'w':
    if (HAS_PERM(PERM_BASIC))
      cmd = XZ_BMW;
    break;
  }

  if (cmd == zone)		/* �M�ثe�Ҧb zone �@�ˡA�Ψ��� */
  {
    z_status--;
    return XO_FOOT;		/* �Y�b xover() �������I�s every_Z() �h�e�^ XO_FOOT �Y�i��ø */
  }

  tmpmode = bbsmode;
  tmpstate = bbstate;		/* itoc.000930: �ץ� every_Z ��O�D�v�����~ */
  xover(cmd);
  bbstate = tmpstate;		/* itoc.000930: �ץ� every_Z ��O�D�v�����~ */
  utmp_mode(tmpmode);

  z_status--;
  return XO_INIT;		/* �ݭn���s���J xo_pool�A�Y�b xover() ���]�i�Ǧ���ø */
}


int
every_U(zone)
  int zone;			/* �ǤJ�Ҧb XZ_ZONE�A�Y�ǤJ 0�A���ܤ��b xover() �� */
{
  /* itoc.000319: �̦h every_Z �@�h */
  if (z_status >= 1)
    return XO_NONE;

  if (zone != XZ_ULIST)
  {
    int tmpmode;

    z_status++;
    tmpmode = bbsmode;
    xover(XZ_ULIST);
    utmp_mode(tmpmode);
    z_status--;
  }
  return XO_INIT;
}
#endif


/* ----------------------------------------------------- */
/* �� XZ_* ���c����в���				 */
/* ----------------------------------------------------- */


/* �ǤJ: ch, pagemax, num, pageno, pos, redraw */
/* �ǥX: ch, pageno, pos, redraw */
int
xo_cursor(ch, pagemax, num, pageno, pos, redraw)
  int ch, pagemax, num;
  int *pageno, *pos, *redraw;
{
  switch(ch)
  {
  case 'e':
  case KEY_LEFT:
  case 'q':
    return 'q';

  case KEY_PGUP:
    if (pagemax != 0)
    {
      if (*pageno)
      {
	(*pageno)--;
      }
      else
      {
	*pageno = pagemax;
	*pos = num % XO_TALL;
      }
      *redraw = 1;
    }
    break;

  case KEY_PGDN:
    if (pagemax != 0)
    {
      if (*pageno == pagemax)
      {
	/* �b�̫�@�����@�U */
	if (*pos != num % XO_TALL)
	{
	  *pos = num % XO_TALL;
	}
	else
	{
	  *pageno = 0;
	  *pos = 0;
	}
      }
      else
      {
	(*pageno)++;
	if (*pageno == pagemax && *pos > num % XO_TALL)
	  *pos = num % XO_TALL;
      }
      *redraw = 1;
    }
    break;

  case KEY_UP:
  case 'k':
    if (*pos == 0)
    {
      if (*pageno != 0)
      {
	*pos = XO_TALL - 1;
	*pageno = *pageno - 1;
      }
      else
      {
	*pos = num % XO_TALL;
	*pageno = pagemax;
      }
      *redraw = 1;
    }
    else
    {
      move(3 + *pos, 0);
      outc(' ');
      (*pos)--;
      move(3 + *pos, 0);
      outc('>');
    }
    break;

  case KEY_DOWN:
  case 'j':
    if (*pos == XO_TALL - 1)
    {
      *pos = 0;
      *pageno = (*pageno == pagemax) ? 0 : *pageno + 1;
      *redraw = 1;
    }
    else if (*pageno == pagemax && *pos == num % XO_TALL)
    {
      *pos = 0;
      *pageno = 0;
      *redraw = 1;
    }
    else
    {
      move(3 + *pos, 0);
      outc(' ');
      (*pos)++;
      move(3 + *pos, 0);
      outc('>');
    }
    break;

  case KEY_HOME:
  case '0':
    *pageno = 0;
    *pos = 0;
    *redraw = 1;
    break;

  case KEY_END:
  case '$':
    *pageno = pagemax;
    *pos = num % XO_TALL;
    *redraw = 1;
    break;
  }

  return ch;
}


/* ----------------------------------------------------- */
/* �������						 */
/* ----------------------------------------------------- */


void
xo_help(path)			/* itoc.021122: ������� */
  char *path;
{
  /* itoc.030510: ��� so �̭� */
  DL_func("bin/help.so:vaHelp", path);
}
