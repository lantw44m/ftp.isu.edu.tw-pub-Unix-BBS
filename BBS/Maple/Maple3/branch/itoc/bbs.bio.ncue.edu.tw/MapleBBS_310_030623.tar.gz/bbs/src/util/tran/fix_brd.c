/*-------------------------------------------------------*/
/* util/fix_brd.c                                        */
/*-------------------------------------------------------*/
/* target : �ק�ݪO�ݩʡA�D�n�ק� unique bstamp	 */
/* create : 01/09/09                                     */
/* update :   /  /                                       */
/* author : itoc.bbs@bbs.tnfsh.tn.edu.tw                 */
/*-------------------------------------------------------*/
/* syntax : fix_brd                                      */
/*-------------------------------------------------------*/


#include "bbs.h"


int
main()
{
  int num;
  BRD brd;

  chdir(BBSHOME);

  num = 0;
  while (!rec_get(FN_BRD, &brd, sizeof(BRD), num))
  {
    brd.bstamp = num + 1;   /* �n�O�����Aunique */

    /* ���K��@�U brd.title �M brd.attr */
    if (!strncmp(brd.title, " ��", BCLEN))
    {
      sprintf(brd.title, "%s %s", "��", brd.title + BCLEN);
    }
    else
    {
      brd.battr |= BRD_NOTRAN;     /* ����H */
      sprintf(brd.title, "%s %s", "��", brd.title + BCLEN);
    }

#if 0
    if (brd.readlevel == PERM_SYSOP)    /* ���K�O���C�J�έp */
      brd.battr |= BRD_NOCOUNT;
#endif

    rec_put(FN_BRD, &brd, sizeof(BRD), num, NULL);
    num++;
  }
}

