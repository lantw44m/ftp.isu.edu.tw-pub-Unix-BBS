/*-------------------------------------------------------*/
/* aloha.c	( NTHU CS MapleBBS Ver 3.10 )		 */
/*-------------------------------------------------------*/
/* target : aloha routines			 	 */
/* create : 95/03/29				 	 */
/* update : 00/01/02				 	 */
/*-------------------------------------------------------*/


#include "bbs.h"

#ifdef HAVE_ALOHA

extern XZ xz[];
extern char xo_pool[];


/* ----------------------------------------------------- */
/* �W���q���W��						 */
/* ----------------------------------------------------- */


static int
cmpbenz(benz)
  BMW *benz;
{
  return benz->recver == cuser.userno;
}


static int
aloha_find(fpath, aloha)
  char *fpath;
  ALOHA *aloha;
{
  ALOHA old;
  int pos, fd;
  
  pos = 0;
  fd = open(fpath, O_RDONLY);
  
  while (fd)
  {
    lseek(fd, (off_t) (sizeof(ALOHA) * pos), SEEK_SET);
    if (read(fd, &old, sizeof(ALOHA)) == sizeof(ALOHA))
    {
      if (aloha->userno == old.userno)
      {
	close(fd);
	return 1;
      }
      pos++;
    }
    else
    {
      close(fd);
      return 0;
    }
  }
  return 0;
}


static void
aloha_sync(fpath)
  char *fpath;
{
  int fd, size;
  struct stat st;
  char buf[64];

  if (!fpath)
  {
    fpath = buf;
    usr_fpath(fpath, cuser.userid, FN_ALOHA);
  }

  if ((fd = open(fpath, O_RDWR, 0600)) < 0)
    return;

  outz(MSG_CHKDATA);
  refresh();

  if (!fstat(fd, &st) && (size = st.st_size) > 0)
  {
    ALOHA *abase, *ahead, *atail;
    int userno;

    abase = ahead = (ALOHA *) malloc(size);
    size = read(fd, abase, size);
    if (size >= sizeof(ALOHA))
    {
      atail = (ALOHA *) ((char *) abase + size);
      while (ahead < atail)
      {
	userno = ahead->userno;
	if (userno > 0 && userno == acct_userno(ahead->userid))
	{
	  ahead++;
	  continue;
	}

	atail--;
	if (ahead >= atail)
	  break;
	memcpy(ahead, atail, sizeof(ALOHA));
      }

      size = (char *) atail - (char *) abase;
      if (size > 0)
      {
	if (size > sizeof(ALOHA))
	{
	  if (size > ALOHA_MAX * sizeof(ALOHA))
	    vmsg("�z���W���q���W��Ӥj�A�е��[��z");
	  xsort(abase, size / sizeof(ALOHA), sizeof(ALOHA), str_cmp);
	}

	lseek(fd, 0, SEEK_SET);
	write(fd, abase, size);
	ftruncate(fd, size);

      }
    }
    free(abase);
  }
  close(fd);

  if (size <= 0)
    unlink(fpath);
}


#if 0	/* itoc.001126: ���� */
  �p�G FN_FRIEND_BENZ ���áA�i�H���������� FN_FRIEND_BENZ
  rm `find /home/bbs/usr -name frienz`
  �M��a�o���{���{�����ؤ@�� (��b bbsd.c ��) 
#endif

#if 0
static void
aloha_fix()
{
  char buf[64];
  int fd;
  struct tm ptime;

  /* itoc.001126: �u�ݭn���ؤ@���A�a�W������ӧP�_ */
  /*              2001/12/25 �H�e�W���~�ഫ        */
  ptime.tm_sec = 0;
  ptime.tm_min = 0;
  ptime.tm_hour = 0;
  ptime.tm_mday = 25;
  ptime.tm_mon = 12 - 1;
  ptime.tm_year = 101;

  if (cuser.lastlogin >= mktime(&ptime))
    return;

  outz(MSG_CHKDATA);
  usr_fpath(buf, cuser.userid, FN_ALOHA);
  if ((fd = open(buf, O_RDONLY)) >= 0)
  {
    ALOHA *aloha;

    mgets(-1);
    while (aloha = mread(fd, sizeof(ALOHA)))
    {
      if (aloha->userno != cuser.userno)	/* �z�פW���|�o�͡A�٬O�ˬd�@�U */
      {
	char fpath[64];
	BMW bmw;

	bmw.recver = cuser.userno;
	strcpy(bmw.userid, cuser.userid);
	usr_fpath(fpath, pal->userid, FN_FRIEND_BENZ);
	rec_add(fpath, &bmw, sizeof(BMW));
      }
    }
    close(fd);
  }
}
#endif


/* ----------------------------------------------------- */
/* �W���q���W��G��榡�ާ@�ɭ��y�z			 */
/* ----------------------------------------------------- */


static int aloha_add();


static void
aloha_item(num, aloha)
  int num;
  ALOHA *aloha;
{
  prints("%6d    %-14s\n", num, aloha->userid);
}


static int
aloha_body(xo)
  XO *xo;
{
  ALOHA *aloha;
  int num, max, tail;

  max = xo->max;
  if (max <= 0)
  {
    if (vans("�n�s�W�W���(Y/N)�H[N] ") == 'y')
      return aloha_add(xo);
    return XO_QUIT;
  }

  aloha = (ALOHA *) xo_pool;
  num = xo->top;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  move(3, 0);
  do
  {
    aloha_item(++num, aloha++);
  } while (num < max);
  clrtobot();

  /* return XO_NONE; */
  return XO_FOOT;	/* itoc.010403: �� b_lines ��W feeter */
}


static int
aloha_head(xo)
  XO *xo;
{
  vs_head("�W���q��", str_site);
  outs(NECKER_ALOHA);
  return aloha_body(xo);
}


static int
aloha_load(xo)
  XO *xo;
{
  xo_load(xo, sizeof(ALOHA));
  return aloha_body(xo);
}


static int
aloha_init(xo)
  XO *xo;
{
  xo_load(xo, sizeof(ALOHA));
  return aloha_head(xo);
}


static int
aloha_loadpal(xo)
  XO *xo;
{
  int i, j;
  char fpath[64], path[64];
  BMW bmw;
  PAL pal;
  ALOHA aloha;
  
  if (vans("�n�ޤJ�n�ͦW���(Y/N)�H[N] ") == 'y')
  {
    usr_fpath(fpath, cuser.userid, FN_PAL);
    j = ALOHA_MAX - xo->max;

    /* itoc.001224: �ޤJ�W��u�[�� ALOHA_MAX */    
    for (i = 0; j > 0; i++)
    {
      if (rec_get(fpath, &pal, sizeof(PAL), i) >= 0)
      {
	strcpy(aloha.userid, pal.userid);
	aloha.userno = pal.userno;
	if (!aloha_find(xo->dir, &aloha))
	{
	  bmw.recver = cuser.userno;
	  strcpy(bmw.userid, cuser.userid);
	  usr_fpath(path, aloha.userid, FN_FRIEND_BENZ);
	  rec_add(path, &bmw, sizeof(BMW));
	  rec_add(xo->dir, &aloha, sizeof(ALOHA));      
	  xo->pos = XO_TAIL;
	  j--;
	}
      }
      else
	break;
    }
    return aloha_load(xo);
  }
  return XO_FOOT;
}


static int
aloha_add(xo)
  XO *xo;
{
  char path[64];
  BMW bmw;
  ACCT acct;
  ALOHA aloha;

  if (xo->max >= ALOHA_MAX)
  {
    vmsg("�z���W���q���W��Ӥj�A�е��[��z");
    return XO_FOOT;
  }

  if ((aloha.userno = acct_get(msg_uid, &acct)) <= 0)
    return XO_HEAD;

  strcpy(aloha.userid, acct.userid);
   
  if (aloha.userno == cuser.userno)   
  {
    vmsg("�ۤv�����[�J�W���q���W�椤");
    return XO_HEAD;
  }
  
  bmw.recver = cuser.userno;
  strcpy(bmw.userid, cuser.userid);
  usr_fpath(path, aloha.userid, FN_FRIEND_BENZ);
  if (!aloha_find(xo->dir, &aloha))
  {
    rec_add(path, &bmw, sizeof(BMW));
    rec_add(xo->dir, &aloha, sizeof(ALOHA));
  }
  xo->pos = XO_TAIL /* xo->max */ ;
  xo_load(xo, sizeof(ALOHA));
  
  return aloha_head(xo);
}


static int
aloha_rangedel(xo)
  XO *xo;
{
  char buf[8];
  int head, tail;

  vget(b_lines, 0, "[�]�w�R���d��] �_�I�G", buf, 6, DOECHO);
  head = atoi(buf);
  if (head <= 0)
  {
    zmsg("�_�I���~");
    return XO_FOOT;
  }

  vget(b_lines, 28, "���I�G", buf, 6, DOECHO);
  tail = atoi(buf);
  if (tail < head)
  {
    zmsg("���I���~");
    return XO_FOOT;
  }
  if (tail > xo->max)
    tail = xo->max;

  if (vget(b_lines, 41, msg_sure_ny, buf, 3, LCECHO) == 'y')
  {
    int fd, locus, pos;
    char *dir, buf[100], fpath[64];
    FILE *fpw;
    ALOHA *aloha;

    dir = xo->dir;
    if ((fd = open(dir, O_RDONLY)) < 0)
      return XO_FOOT;

    /* itoc.010726.����: ���F��� rec_del �����ơA���ؤ@�� record �Ө��N�즳�� */
    if (!(fpw = f_new(dir, buf)))
    {
      close(fd);
      return XO_FOOT;
    }

    mgets(-1);
    head--;
    tail--;
    locus = 0;

    while (aloha = mread(fd, sizeof(ALOHA)))
    {
      if (locus < head || locus > tail)	/* itoc.010726.����: �Y���b�R���d��̭��A�h�O�d�A�Ϥ����O�d */
      {
	if ((fwrite(aloha, sizeof(ALOHA), 1, fpw) != 1))
	{
	  fclose(fpw);
	  unlink(buf);
	  close(fd);
	  return XO_FOOT;
	}
      }
      else
      {
        usr_fpath(fpath, aloha->userid, FN_FRIEND_BENZ);
        while ((pos = rec_loc(fpath, sizeof(BMW), cmpbenz)) >= 0)
          rec_del(fpath, sizeof(BMW), pos, cmpbenz);
      }
      locus++;
    }
    close(fd);
    fclose(fpw);
    rename(buf, dir);
    return aloha_load(xo);
  }
  return XO_FOOT;
}


static int
aloha_delete(xo)
  XO *xo;
{
  if (vans(msg_del_ny) == 'y')
  {
    int pos;
    char fpath[64];
    ALOHA *aloha;

    aloha = (ALOHA *) xo_pool + (xo->pos - xo->top);

    usr_fpath(fpath, aloha->userid, FN_FRIEND_BENZ);

    /* itoc.030310: ����: �� frienz �̭������Ъ� */
    while ((pos = rec_loc(fpath, sizeof(BMW), cmpbenz)) >= 0)
      rec_del(fpath, sizeof(BMW), pos, cmpbenz);

    rec_del(xo->dir, sizeof(ALOHA), xo->pos, NULL);
    return aloha_init(xo);
  }
  return XO_FOOT;
}


static int
aloha_mail(xo)
  XO *xo;
{
  ALOHA *aloha;
  char *userid;

  aloha = (ALOHA *) xo_pool + (xo->pos - xo->top);
  userid = aloha->userid;
  if (*userid)
  {
    vs_bar("�H  �H");
    prints("���H�H�G%s", userid);
    my_send(userid);
  }
  return aloha_head(xo);
}


static int
aloha_write(xo)
  XO *xo;
{
  if (HAS_PERM(PERM_PAGE))
  {
    ALOHA *aloha;
    UTMP *up; 

    aloha = (ALOHA *) xo_pool + (xo->pos - xo->top);

    if (up = utmp_find(aloha->userno))
      do_write(up);
  }
  return XO_NONE;
}


static int
aloha_query(xo)
  XO *xo;
{
  ALOHA *aloha;

  aloha = (ALOHA *) xo_pool + (xo->pos - xo->top);
  move(1, 0);
  clrtobot();

  my_query(aloha->userid);
  return aloha_head(xo);
}


static int
aloha_sort(xo)
  XO *xo;
{
  aloha_sync(xo->dir);
  return aloha_init(xo);
}

      
static int
aloha_help(xo)
  XO *xo;
{
  xo_help("aloha");
  return aloha_head(xo);
}


static KeyFunc aloha_cb[] =
{
  XO_INIT, aloha_init,
  XO_LOAD, aloha_load,
  XO_HEAD, aloha_head,
  XO_BODY, aloha_body,

  'a', aloha_add,
  'd', aloha_delete,
  'm', aloha_mail,
  'w', aloha_write,
  'D', aloha_rangedel,
  'f', aloha_loadpal,

  'r', aloha_query,
  Ctrl('Q'), aloha_query,
  
  's', aloha_sort,
  'h', aloha_help
};


int
t_aloha()
{
  XO *xo;
  char fpath[64];

  usr_fpath(fpath, cuser.userid, FN_ALOHA);
  xz[XZ_ALOHA - XO_ZONE].xo = xo = xo_new(fpath);
  xz[XZ_ALOHA - XO_ZONE].cb = aloha_cb;
  xover(XZ_ALOHA);
  free(xo);
  return 0;
}

#endif	/* HAVE_ALOHA */
