<?php

/*-------------------------------------------------------*/
/* config.php     ( ZJU Shanty MapleBBS Ver 3.10 )    	 */
/*-------------------------------------------------------*/
/* target : PHP config File				 */
/* author : hightman.bbs@bbs.dot66.net			 */
/* create : 2001/09/20                                   */
/* update :                                              */
/*-------------------------------------------------------*/

$bbshome = "/home/bbs";		// BBS ���a

define("G_LOGIN", 0);
define("G_CMD", 1);
define("G_TALK", 2);
define("G_MAIL", 3);
define("G_BOARD", 4);
define("G_GEM", 5);
define("G_ACCT", 6);
define("G_OTHER", 7);

define("PERM_BASIC", 0x00000001);
define("PERM_CHAT", 0x00000002);
define("PERM_POST", 0x00000008);
define("PERM_VALID", 0x00000010);
define("PERM_BM", 0x01000000);
define("PERM_CLOAK", 0x00000040);

define("PERM_ALLADMIN", 0x80000000);
define("PERM_ALLACCT", 0xd8000000);

define("STR_GUEST", "guest");
define("STR_SYSOP", "sysop");
define("BN_DEFAULT", "sysop");
define("XO_TALL", 20);

define("FILM_MOVIE", 12);

?>
