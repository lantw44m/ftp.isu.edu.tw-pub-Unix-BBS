/*-------------------------------------------------------*/
/* util/transbrd.c                                       */
/*-------------------------------------------------------*/
/* target : Magic �� Maple 3.02 �ݪO�ഫ                 */
/*          .BOARDS => .BRD                              */
/* create : 02/09/09                                     */
/* update :   /  /                                       */
/* author : itoc.bbs@bbs.tnfsh.tn.edu.tw                 */
/*-------------------------------------------------------*/


#include "bbs.h"


#if 0
   0. �A�� Magic/FireBird �� Maple ��ذ�
   1. �� �¯��� boards/brdname ���� OLD_BOARDPATH/brdname
   2. �]�w OLD_MANPATH
   3. �{�����}�ؿ��A�ϥΫe���T�w gem/target_board/? �ؿ��s�b
      if not�A���}�s�O or transbrd

   ps. User on ur own risk.

#endif


#define FN_BOARDS	"bak/.BOARDS"
#define OLD_BOARDPATH	"bak/boards"


typedef struct		/* the BOARDS files */
{
  char filename[80];
  char owner[60];
  char BM[19];
  char flag;
  char title[80];
  unsigned level;
  unsigned char accessed[12];
} boardheader;		/* struct size = 256 bytes */


typedef struct		/* .DIR structure */
{
  char filename[80];
  char owner[80];
  char title[80];
  unsigned level;
  unsigned char accessed[12];
} fileheader;		/* struct size = 256 bytes */


static inline time_t
trans_hdr_chrono(filename)
  char *filename;
{
  char time_str[11];

  if (filename[2] == '1')		/* M.1087654321.A */
  {
    strncpy(time_str, filename + 2, 10);
    time_str[10] = '\0';
  }
  else					/* M.987654321.A */
  {
    strncpy(time_str, filename + 2, 9);
    time_str[9] = '\0';
  }

  return (time_t) atoi(time_str);
}


static inline void
trans_hdr_stamp(folder, t, hdr, fpath)
  char *folder;
  time_t t;
  HDR *hdr;
  char *fpath;
{
  FILE *fp;
  char *fname, *family;
  int rc;

  fname = fpath;
  while (rc = *folder++)
  {
    *fname++ = rc;
    if (rc == '/')
      family = fname;
  }
  fname = family + 1;
  *fname++ = '/';
  *fname++ = 'A';

  for (;;)
  {
    *family = radix32[t & 31];
    archiv32(t, fname);

    if (fp = fopen(fpath, "r"))
    {
      fclose(fp);
      t++;
    }
    else
    {
      memset(hdr, 0, sizeof(HDR));
      hdr->chrono = t;
      str_stamp(hdr->date, &hdr->chrono);
      strcpy(hdr->xname, --fname);
      break;
    }
  }
}


static void
trans_owner(hdr, old)
  HDR *hdr;
  char *old;
{
  char *left, *right;
  char owner[128];

  str_ncpy(owner, old, sizeof(owner));

  if (strchr(owner, '.'))	/* innbbsd ==> bbs */
  {
    /* itoc.bbs@bbs.tnfsh.tn.edu.tw (�ڪ��ʺ�) */

    hdr->xmode = POST_INCOME;

    left = strchr(owner, '(');
    right = strrchr(owner, ')');

    if (!left || !right)
    {
      strcpy(hdr->owner, "�H�W");
    }
    else
    {
      *(left - 1) = '\0';
      str_ncpy(hdr->owner, owner, sizeof(hdr->owner));
      *right = '\0';
      str_ncpy(hdr->nick, left + 1, sizeof(hdr->nick));
    }
  }
  else if (left = strchr(owner, '('))	/* local post */
  {
    /* itoc (�ڪ��ʺ�) */

    *(left - 1) = '\0';
    str_ncpy(hdr->owner, owner, sizeof(hdr->owner));
    if (right = strchr(owner, ')'))
    {
      *right = '\0';
      str_ncpy(hdr->nick, left + 1, sizeof(hdr->nick));
    }
  }
  else
  {
    /* itoc */

    str_ncpy(hdr->owner, owner, sizeof(hdr->owner));
  }
}


static void
trans_brd(bh, num)
  boardheader *bh;
  int num;
{
  int pos;
  BRD brd;
  char *brdname, index[128], folder[256], cmd[256];
  char fpath[128], buf[128];
  fileheader fh;
  HDR hdr;
  time_t chrono;

  brdname = bh->filename;
  if (strlen(brdname) > IDLEN + 1)
  {
    printf("%s name is too long!\n", brdname);
    return;
  }

  /* �ഫ .BRD */
  memset(&brd, 0, sizeof(BRD));
  str_ncpy(brd.brdname, brdname, IDLEN + 1);
  sprintf(cmd, "%4.4s %s", bh->title + 2, bh->title + 13);
  str_ncpy(brd.title, cmd, BTLEN + 1);
  /* str_ncpy(brd.BM, bh->BM, BMLEN + 1); */	/* �S�� bh->BM? ������ʧ� */
  brd.bstamp = num + 500;
  brd.readlevel = 0;			/* ���w�] read/post level�A�����A�ۤv��ʧ� */
  brd.postlevel = PERM_POST;
  brd.battr = BRD_NOTRAN;
  rec_add(FN_BRD, &brd, sizeof(BRD));

  /* �إؿ� */
  sprintf(buf, "gem/brd/%s", brdname);
  mak_dirs(buf);
  mak_dirs(buf + 4);

  /* �ഫ�i�O�e�� */
  sprintf(index, "%s/%s/notes", OLD_BOARDPATH, brdname);
  brd_fpath(folder, brdname, FN_NOTE);
  sprintf(cmd, "cp %s %s", index, folder);
  system(cmd);

  /* �ഫ�벼�O�� */
  sprintf(index, "%s/%s/results", OLD_BOARDPATH, brdname);
  sprintf(folder, "brd/%s/@/@vote", brdname);
  sprintf(cmd, "cp %s %s", index, folder);
  system(cmd);

  /* �ഫ .DIR */
  sprintf(index, "%s/%s/.DIR", OLD_BOARDPATH, brdname);	/* �ª� .DIR */
  brd_fpath(folder, brdname, FN_DIR);			/* �s�� .DIR */

  pos = 0;
  while (!rec_get(index, &fh, sizeof(fh), pos))
  {
    sprintf(buf, OLD_BOARDPATH "/%s/%s", brdname, fh.filename);

    chrono = trans_hdr_chrono(fh.filename);
    trans_hdr_stamp(folder, chrono, &hdr, fpath);
    trans_owner(&hdr, fh.owner);
    str_ansi(hdr.title, fh.title, sizeof(hdr.title));
    if (fh.accessed[0] & 0x8)	/* FILE_MARDKED */
      hdr.xmode |= POST_MARKED;
    rec_add(folder, &hdr, sizeof(HDR));

    /* �����ɮ� */
    sprintf(cmd, "cp %s %s", buf, fpath);
    system(cmd);

    pos++;
  }

  printf("%s transfer ok!\n", brdname);
}


int
main()
{
  boardheader bh;
  int num;

  chdir(BBSHOME);

  num = 0;
  while (!rec_get(FN_BOARDS, &bh, sizeof(bh), num))
  {
    trans_brd(&bh, num);
    num++;
  }

  return 0;
}
