/*-------------------------------------------------------*/
/* util/cola2brd.c  ( NTHU CS MapleBBS Ver 3.10 )	 */
/*-------------------------------------------------------*/
/* target : Cola �� Maple 3.02 �ݪO�ഫ			 */
/* create : 03/02/11					 */
/* update :   /  /  					 */
/* author : itoc.bbs@bbs.tnfsh.tn.edu.tw		 */
/*-------------------------------------------------------*/


#include    "cola.h"


static inline time_t
trans_hdr_chrono(filename)
  char *filename;
{
  char time_str[11];

  if (filename[2] == '1')		/* M.1087654321.A */
  {
    strncpy(time_str, filename + 2, 10);
    time_str[10] = '\0';
  }
  else					/* M.987654321.A */
  {
    strncpy(time_str, filename + 2, 9);
    time_str[9] = '\0';
  }

  return (time_t) atoi(time_str);
}


static inline void
trans_hdr_stamp(folder, t, hdr, fpath)
  char *folder;
  time_t t;
  HDR *hdr;
  char *fpath;
{
  FILE *fp;
  char *fname, *family;
  int rc;

  fname = fpath;
  while (rc = *folder++)
  {
    *fname++ = rc;
    if (rc == '/')
      family = fname;
  }
  fname = family + 1;
  *fname++ = '/';
  *fname++ = 'A';

  for (;;)
  {
    *family = radix32[t & 31];
    archiv32(t, fname);

    if (fp = fopen(fpath, "r"))
    {
      fclose(fp);
      t++;
    }
    else
    {
      memset(hdr, 0, sizeof(HDR));
      hdr->chrono = t;
      str_stamp(hdr->date, &hdr->chrono);
      strcpy(hdr->xname, --fname);
      break;
    }
  }
}


/* ----------------------------------------------------- */
/* �ഫ�D�{��                                            */
/* ----------------------------------------------------- */


static void
transbrd(bh)
  boardheader *bh;
{
  fileheader fh;
  BRD newboard;
  HDR hdr;
  char fpath[80], folder[80], index[80], buf[80], cmd[256];
  int num;

  printf("�ഫ %s �ݪO\n", bh->brdname);

  brd_fpath(buf, bh->brdname, NULL);
  if (dashd(buf))
  {
    printf("%s �w�g�����ݪO\n", bh->brdname);
    return;
  }

  /* �ഫ .BRD */

  memset(&newboard, 0, sizeof(newboard));
  strncpy(newboard.brdname, bh->brdname, IDLEN + 1);
  sprintf(cmd, "%4.4s %s", bh->title + 2, bh->title + 12);
  strncpy(newboard.title, cmd, BTLEN + 1);		/* title ������ */
  /* newboard.BM[0] = '\0'; */				/* �O�D���ഫ */
  time(&newboard.bstamp);	/* itoc.����: �Y�e�@�ӪO���ഫ���ӧ�(����@����)�A����o�O�N�|�M���e���O bstamp �ۦP */
  sleep(1);			/* idle �@���A�ϱo�줣�P bstamp */
  newboard.battr = BRD_NOTRAN;
  newboard.readlevel = 0;
  newboard.postlevel = PERM_POST;

  rec_add(FN_BRD, &newboard, sizeof(newboard));		/* �O�ѤF�� brd2gem.c ���ഫ Class */

  /* �}�s�ؿ� */

  sprintf(fpath, "gem/brd/%s", newboard.brdname);
  mak_dirs(fpath);
  mak_dirs(fpath + 4);

  /* �ഫ�i�O�e�� */

  sprintf(buf, COLABBS_BOARDS "/%s/.Welcome", bh->brdname);
  
  if (dashf(buf))
  {
    brd_fpath(fpath, newboard.brdname, FN_NOTE);
    sprintf(cmd, "cp %s %s", buf, fpath);
    system(cmd);
  }

  /* �ഫ�峹 */

  sprintf(index, COLABBS_BOARDS "/%s/.DIR", bh->brdname);	/* �ª� .DIR */
  brd_fpath(folder, newboard.brdname, ".DIR");			/* �s�� .DIR */

  num = 0;
  while (!rec_get(index, &fh, sizeof(fh), num))
  {
    sprintf(buf, COLABBS_BOARDS "/%s/%s", bh->brdname, fh.filename);
    if (dashf(buf))	/* �峹�ɮצb�~���ഫ */
    {
      time_t chrono;

      /* �ഫ�峹 .DIR */

      memset(&hdr, 0, sizeof(HDR));
      chrono = trans_hdr_chrono(fh.filename);
      trans_hdr_stamp(folder, chrono, &hdr, fpath);
      strncpy(hdr.owner, fh.owner, sizeof(hdr.owner));
      str_ansi(hdr.title, fh.title + 3, sizeof(hdr.title));
      hdr.xmode = 0;
      rec_add(folder, &hdr, sizeof(HDR));

      /* �����ɮ� */

      sprintf(cmd, "cp %s %s", buf, fpath);
      system(cmd);
    }

    num++;
  }
}


int
main(argc, argv)
  int argc;
  char *argv[];
{
  boardheader bh;
  int num;

  /* argc == 1 ������O */
  /* argc == 2 ��Y�S�w�O */

  if (argc > 2)
  {
    printf("Usage: %s [target_board]\n", argv[0]);
    exit(-1);
  }

  chdir(BBSHOME);

  if (!dashf(FN_BOARD))
  {
    printf("ERROR! Can't open " FN_BOARD "\n");
    exit(-1);
  }
  if (!dashd(COLABBS_BOARDS))
  {
    printf("ERROR! Can't open " COLABBS_BOARDS "\n");
    exit(-1);
  }

  num = 0;
  while (!rec_get(FN_BOARD, &bh, sizeof(bh), num))
  {
    bh.brdname[IDLEN] = '\0';	/* itoc.030211: Cola ���ݪO�W�i��W�L IDLEN */

    if (argc == 1)
    {
      transbrd(&bh);
    }
    else if (!strcmp(bh.brdname, argv[1]))
    {
      transbrd(&bh);
      exit(1);
    }
    num++;
  }

  exit(0);
}
