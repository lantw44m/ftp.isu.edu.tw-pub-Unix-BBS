/* ----------------------------------------------------- */
/* open client						 */
/* ----------------------------------------------------- */

#include <stdio.h>
#include <syslog.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/un.h>
#include <sys/param.h>


int
unixclient(path, protocol)
  char *path;
  char *protocol;
{
  register struct protoent *pe;	/* protocol information entry */
  struct sockaddr_un s_un;	/* unix endpoint address */
  register int s;

  bzero((char *) &s_un, sizeof(s_un));
  s_un.sun_family = AF_UNIX;

  if (!path || !protocol)
    return -1;

  strcpy(s_un.sun_path, path);

  /* map protocol name to protocol number */
  pe = getprotobyname(protocol);
  if (pe == NULL)
  {
    fprintf(stderr, "%s: Unknown protocol.\n", protocol);
    return -1;
  }
  /* Allocate a socket */
  s = socket(PF_UNIX, strcmp(protocol, "tcp") ? SOCK_DGRAM : SOCK_STREAM, 0);
  if (s < 0)
  {
    perror("socket");
    return -1;
  }
  /* Connect the socket to the server */
  if (connect(s, (struct sockaddr *) & s_un, sizeof(s_un)) < 0)
  {
    /* perror("connect"); */
    return -1;
  }
  return s;
}
