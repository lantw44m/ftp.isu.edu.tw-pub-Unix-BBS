/*-------------------------------------------------------*/
/* ctlinnbbsd.c	( NTHU CS MapleBBS Ver 3.10 )		 */
/*-------------------------------------------------------*/
/* target : ctlinnbbsd					 */
/* create : 95/04/27					 */
/* update :   /  /  					 */
/* author : skhuang@csie.nctu.edu.tw			 */
/*-------------------------------------------------------*/


#include "innbbsconf.h"
#include "bbslib.h"


static void
usage(argv)
  char *argv;
{
  fprintf(stderr, "Usage: %s commands\n", argv);
  fprintf(stderr, " where available commands:\n");
  fprintf(stderr, "  ctlinnbbsd reload   : reload datafiles for innbbsd\n");
  fprintf(stderr, "  ctlinnbbsd shutdown : shutdown innbbsd gracefully\n");
  fprintf(stderr, "  ctlinnbbsd mode     : examine mode of innbbsd\n");
  fprintf(stderr, "  ctlinnbbsd hismaint : maintain history\n");
  fprintf(stderr, "  ctlinnbbsd addhist <mid> path: add history\n");
  fprintf(stderr, "  ctlinnbbsd grephist <mid>    : query history\n");
  fprintf(stderr, "  ctlinnbbsd verboselog on|off : verboselog on/off\n");
  fprintf(stderr, "  ctlinnbbsd listnod  : list nodelist.bbs\n");
  fprintf(stderr, "  ctlinnbbsd listnews : list newsfeeds.bbs\n");
#ifdef _NoCeM_
  fprintf(stderr, "  ctlinnbbsd listncm  : list ncmperm.bbs\n");
#endif
#ifdef GETRUSAGE
  fprintf(stderr, "  ctlinnbbsd getrusage: get resource usage\n");
#endif
#ifdef MALLOCMAP
  fprintf(stderr, "  ctlinnbbsd mallocmap: get malloc map\n");
#endif
}


static char INNBBSbuffer[4096];

static FILE *innbbsin, *innbbsout;
static int innbbsfd;


static void
initsocket()
{
  innbbsfd = unixclient(LOCALDAEMON, "tcp");
  if (innbbsfd < 0)
  {
    fprintf(stderr, "Connect to %s error. You may not run innbbsd\n", LOCALDAEMON);
    exit(2);
  }
  if ((innbbsin = fdopen(innbbsfd, "r")) == NULL ||
    (innbbsout = fdopen(innbbsfd, "w")) == NULL)
  {
    fprintf(stderr, "fdopen error\n");
    exit(3);
  }
}


static void
closesocket()
{
  if (innbbsin != NULL)
    fclose(innbbsin);
  if (innbbsout != NULL)
    fclose(innbbsout);
  if (innbbsfd >= 0)
    close(innbbsfd);
}


static void
ctlinnbbsd(argc, argv)
  int argc;
  char *argv[];
{
  char *ptr;

  fgets(INNBBSbuffer, sizeof(INNBBSbuffer), innbbsin);
  printf("%s", INNBBSbuffer);

  ptr = argv[1];
  if (!strcasecmp(ptr, "shutdown") ||
    !strcasecmp(ptr, "reload") ||
    !strcasecmp(ptr, "hismaint") ||
    !strcasecmp(ptr, "mode") ||
#ifdef GETRUSAGE
    !strcasecmp(ptr, "getrusage") ||
#endif
#ifdef MALLOCMAP
    !strcasecmp(ptr, "mallocmap") ||
#endif
#ifdef _NoCeM_
    !strcasecmp(ptr, "listncm") ||
#endif
    !strcasecmp(ptr, "listnode") ||
    !strcasecmp(ptr, "listnews"))
  {
    fprintf(innbbsout, "%s\r\n", ptr);
    fflush(innbbsout);
    fgets(INNBBSbuffer, sizeof(INNBBSbuffer), innbbsin);
    printf("%s", INNBBSbuffer);
    if (!strcasecmp(ptr, "mode") ||
#ifdef GETRUSAGE
      !strcasecmp(ptr, "getrusage") ||
      !strcasecmp(ptr, "mallocmap") ||
#endif
#ifdef _NoCeM_
    !strcasecmp(ptr, "listncm") ||
#endif
      !strcasecmp(ptr, "listnode") ||
      !strcasecmp(ptr, "listnews"))
    {
      while (fgets(INNBBSbuffer, sizeof(INNBBSbuffer), innbbsin) != NULL)
      {
	if (!strcmp(INNBBSbuffer, ".\r\n"))
	  break;
	printf("%s", INNBBSbuffer);
      }
    }
  }
  else if (!strcasecmp(ptr, "grephist") || !strcasecmp(ptr, "verboselog"))
  {
    if (argc != 3)
    {
      usage(argv[0]);
    }
    else
    {
      fprintf(innbbsout, "%s %s\r\n", ptr, argv[2]);
      fflush(innbbsout);
      fgets(INNBBSbuffer, sizeof(INNBBSbuffer), innbbsin);
      printf("%s\n", INNBBSbuffer);
    }
  }
  else if (!strcasecmp(ptr, "addhist"))
  {
    if (argc != 4)
    {
      usage("ctlinnbbsd");
    }
    else
    {
      fprintf(innbbsout, "%s %s %s\r\n", ptr, argv[2], argv[3]);
      fflush(innbbsout);
      fgets(INNBBSbuffer, sizeof(INNBBSbuffer), innbbsin);
      printf("%s", INNBBSbuffer);
    }
  }
  else
  {
    fprintf(stderr, "invalid command %s\n", ptr);
  }

  if (strcasecmp(ptr, "shutdown") != 0)
  {
    fprintf(innbbsout, "QUIT\r\n");
    fflush(innbbsout);
    fgets(INNBBSbuffer, sizeof(INNBBSbuffer), innbbsin);
  }
}


int
main(argc, argv)
  int argc;
  char *argv[];
{
  if (argc < 2)
  {
    usage(argv[0]);
    return -1;
  }

  chdir(BBSHOME);

  initsocket();
  ctlinnbbsd(argc, argv);
  closesocket();

  return 0;
}
