/*-------------------------------------------------------*/
/* util/transman.c                                       */
/*-------------------------------------------------------*/
/* target : Maple Sob 2.36 �� Maple 3.02 ��ذ��ഫ      */
/* create : 98/06/15                                     */
/* update : 02/10/26                                     */
/* author : ernie@micro8.ee.nthu.edu.tw                  */
/* modify : itoc.bbs@bbs.tnfsh.tn.edu.tw                 */
/*-------------------------------------------------------*/
/* syntax : transman target_board                        */
/*-------------------------------------------------------*/


#if 0

   1. �{�����}�ؿ��A�ϥΫe���T�w gem/target_board/? �ؿ��s�b
      if not�A���}�s�O or transbrd
   2. �u�� M.*.A �� D.*.A�A��L link ���ഫ
   3. �p���ݭn�Х� chmod 644 `find PATH -perm 600`

   ps. User on ur own risk.

#endif


#define NO_RADIX


#include "sob.h"


/* ----------------------------------------------------- */
/* �ഫ��ذ�                                            */
/* ----------------------------------------------------- */


static time_t
trans_hdr_chrono(filename)
  char *filename;
{
  char time_str[11];

  if (filename[2] == '1')		/* M.1087654321.A */
  {
    strncpy(time_str, filename + 2, 10);
    time_str[10] = '\0';
  }
  else					/* M.987654321.A */
  {
    strncpy(time_str, filename + 2, 9);
    time_str[9] = '\0';
  }

  return (time_t) atoi(time_str);
}


static void
trans_man_stamp(folder, token, hdr, fpath, time)
  char *folder;
  int token;
  HDR *hdr;
  char *fpath;
  time_t time;
{
  char *fname, *family;
  int rc;

  fname = fpath;
  while (rc = *folder++)
  {
    *fname++ = rc;
    if (rc == '/')
      family = fname;
  }
  if (*family != '.')
  {
    fname = family;
    family -= 2;
  }
  else
  {
    fname = family + 1;
    *fname++ = '/';
  }

  *fname++ = token;

  *family = radix32[time & 31];
  archiv32(time, fname);

  if (rc = open(fpath, O_WRONLY | O_CREAT | O_EXCL, 0600))
  {
    memset(hdr, 0, sizeof(HDR));
    hdr->chrono = time;
    str_stamp(hdr->date, &hdr->chrono);
    strcpy(hdr->xname, --fname);
    close(rc);
  }
  return;
}


/* ----------------------------------------------------- */
/* �ഫ�D�{��                                            */
/* ----------------------------------------------------- */

         
static void
transman(index, folder)
  char *index, *folder;
{
  static int count = 100;

  int num;
  char fpath[80], buf[80], cmd[256];
  fileheader fh;
  HDR hdr;

  num = 0;
  while (!rec_get(index, &fh, sizeof(fh), num))
  {
    char *ptr;
    time_t chrono;

    strcpy(buf, index);
    ptr = strrchr(buf, '/') + 1;
    sprintf(ptr, "%s", fh.filename);

    if (*fh.filename == 'M' && dashf(buf))	/* �u�� M.xxxx.A �� D.xxxx.a */
    {
      /* �ഫ�峹 .DIR */
      memset(&hdr, 0, sizeof(HDR));
      chrono = trans_hdr_chrono(fh.filename);
      trans_man_stamp(folder, 'A', &hdr, fpath, chrono);
      hdr.xmode = 0;
      strcpy(hdr.owner, fh.owner);
      strcpy(hdr.title, fh.title + 3);
      rec_add(folder, &hdr, sizeof(HDR));

      /* �����ɮ� */
      sprintf(cmd, "cp %s", index);	
      ptr = strrchr(cmd, '/') + 1;
      sprintf(ptr, "%s %s", fh.filename, fpath);
      system(cmd);
    }
    else if (*fh.filename == 'D' && dashd(buf))
    {
      char sub_index[256];

      /* �ഫ�峹 .DIR */
      memset(&hdr, 0, sizeof(HDR));
      chrono = ++count;		/* WD ���ؿ��R�W����_�ǡA�u�n�ۤv���Ʀr */
      trans_man_stamp(folder, 'F', &hdr, fpath, chrono);
      hdr.xmode = GEM_FOLDER;
      strcpy(hdr.owner, fh.owner);
      strcpy(hdr.title, fh.title + 3);
      rec_add(folder, &hdr, sizeof(HDR));

      /* recursive �i�h�ഫ�l�ؿ� */
      strcpy(sub_index, buf);
      ptr = strrchr(sub_index, '/') + 1;
      sprintf(ptr, "%s/.DIR", fh.filename);
      transman(sub_index, fpath);
    }

    num++;
  }
}


int
main(argc, argv)
  int argc;
  char *argv[];
{
  boardheader bh;
  int num;
  char *brdname;
  char index[80], folder[80];

  /* argc == 1 ������O */
  /* argc == 2 ��Y�S�w�O */

  if (argc > 2)
  {
    printf("Usage: %s [target_board]\n", argv[0]);
    exit(-1);
  }

  chdir(BBSHOME);

  if (!dashf(FN_BOARD))
  {
    printf("ERROR! Can't open " FN_BOARD "\n");
    exit(-1);
  }
  if (!dashd(OLD_BBSHOME "/man/boards"))
  {
    printf("ERROR! Can't open " OLD_BBSHOME "/man/boards\n");
    exit(-1);
  }

  num = 0;
  if (argc == 1)
  {
    while (!rec_get(FN_BOARD, &bh, sizeof(bh), num))
    {
      brdname = bh.brdname;

      sprintf(folder, "gem/brd/%s", brdname);
      if (!dashd(folder))
      {
        printf("ERROR! %s not exist. New it first.\n", folder);
        continue;
      }

      sprintf(index, OLD_BBSHOME "/man/boards/%s/.DIR", brdname);
      sprintf(folder, "gem/brd/%s/%s", brdname, FN_DIR);

      printf("�ഫ %s ��ذ�\n", brdname);
      transman(index, folder);

      num++;
    }
  }
  else
  {
    brdname = argv[1];

    sprintf(folder, "gem/brd/%s", brdname);
    if (!dashd(folder))
    {
      printf("ERROR! %s not exist. New it first.\n", folder);
      exit(-1);
    }

    sprintf(index, OLD_BBSHOME "/man/boards/%s/.DIR", brdname);
    sprintf(folder, "gem/brd/%s/%s", brdname, FN_DIR);

    printf("�ഫ %s ��ذ�\n", brdname);
    transman(index, folder);

    exit(1);
  }

  exit(0);
}
