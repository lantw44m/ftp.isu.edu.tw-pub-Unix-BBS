/*-------------------------------------------------------*/
/* bbslink.c	( NTHU CS MapleBBS Ver 3.10 )		 */
/*-------------------------------------------------------*/
/* target : innbbsd nntp				 */
/* create : 95/04/27					 */
/* update :   /  /  					 */
/* author : skhuang@csie.nctu.edu.tw			 */
/*-------------------------------------------------------*/


#include "innbbsconf.h"
#include "bbslib.h"
#include "daemon.h"
#include "nntp.h"
#include <varargs.h>


#if 0	/* itoc.030122.����: �{���y�{ */

  0. bbsd �|��s�峹�����Y�O���b out.bntp �� cancel.bntp

  1. ���楻�{���H��A�b main() �B�z�@�U�ѼơA�M��i�J main():bntplink()

  2. bntplink():deal_bntp()
     �ѩ� out.bntp �� cancel.bntp �O��Ҧ��O���s�峹����b�@�_�A�ҥH�b
     �o�̧�o�G�� bntp �ɨ̯��x���h *.link

  3. bntplink:send_article()
     �̯��x���n *.link �H��A�b�o�̴N�� nodelist.bbs �̭������ǡA��U��
     *.link �e�H�X�h�C
     �b�e *.link ���ɭԡA�O���� *.link ��W�� *.sending�C

  4. send_article():send_nntplink():send_outgoing()
     �p�G�n�e�h�����x�s���W�A���� savefeed() ������ *.sending �K�^ *.link
     �p�G�n�e�h�����x�s���W�A����� *.sending �̭�����Ƥ@��@��Ū�X�ӡA
     �p�G�e�H�e��@�b�����_�F�A���� queuefeed() �N��ѤU�٨S�e���A�K�^ *.link

#endif


static char MYSITE[MAXBUFLEN];

static FILE *innbbsin, *innbbsout;
static char INNBBSbuffer[4096]; 
static int innbbsfd;


typedef struct SendOver_t
{
  char *board, *filename, *group, *from, *subject;
  char *date, *msgid, *control, *charset;
  time_t mtime;
}          soverview_t;


typedef struct Stat_t
{
  int sendout;
  int failed;
}      stat_t;

static stat_t *BBSLINK_STAT;	/* �έp nodelist.bbs �̭��C�ӯ��x�e�F�X�g */


/* itoc.030122.����: �H�U�o���Ӧb���w�ѼƮɤ~���� */
static int Verbose = 0;			/* show transmission status */
static int VisitOnly = 0;		/* visit only: bbspost visit */
static int KillFormerBBSLINK = 0;	/* kill the former bbslink process before started */
static char *DefaultFeedSite = NULL;	/* only process articles sent to this site */


static char MYADDR[MAXBUFLEN];

static char *BODY;


static int NNTP = -1;
static FILE *NNTPrfp = NULL;
static FILE *NNTPwfp = NULL;
static char NNTPbuffer[1024];


#define	USEIHAVE	1
#define USEPOST		2
#define USEDATA		4
static int USEPROTOCOL;		/* protocol: IHAVE POST DATA �T�ؤ��@ */


/*-------------------------------------------------------*/
/* TCP Command						 */
/*-------------------------------------------------------*/


static int
tcpcommand(va_alist)
va_dcl
{
  va_list ap;
  register char *fmt;
  char *ptr;

  va_start(ap);
  fmt = va_arg(ap, char *);
  vfprintf(NNTPwfp, fmt, ap);
  va_end(ap);
  fprintf(NNTPwfp, "\r\n");
  fflush(NNTPwfp);

  fgets(NNTPbuffer, sizeof(NNTPbuffer), NNTPrfp);
  ptr = strchr(NNTPbuffer, '\r');
  if (ptr)
    *ptr = '\0';
  ptr = strchr(NNTPbuffer, '\n');
  if (ptr)
    *ptr = '\0';

  return atoi(NNTPbuffer);
}


static char *
tcpmessage()
{
  char *ptr;

  ptr = strchr(NNTPbuffer, ' ');
  if (ptr)
    return ptr;
  return NNTPbuffer;
}


/*-------------------------------------------------------*/
/* �� Date �Ϊ�						 */
/*-------------------------------------------------------*/


static char *
Gtime(now)
  time_t now;
{
  static char datemsg[40];

  strftime(datemsg, sizeof(datemsg), "%d %b %Y %X GMT", gmtime(&now));
  return datemsg;
}


/*-------------------------------------------------------*/
/* �s�X���� msgid					 */
/*-------------------------------------------------------*/


static char *
baseN(val, base, len)
  int val, base, len;
{
  int n;
  static char str[MAXBUFLEN];
  int index;

  for (index = len - 1; index >= 0; index--)
  {
    n = val % base;
    val /= base;
    if (n < 10)
    {
      n += '0';
    }
    else if (n < 36)
    {
      n += 'A' - 10;
    }
    else if (n < 62)
    {
      n += 'a' - 36;
    }
    else
    {
      n = '_';
    }
    str[index] = n;
  }
  str[len] = '\0';
  return str;
}


static char *
hash_value(str)
  char *str;
{
  int val, n;
  char *ptr;

  if (*str)
    ptr = str + strlen(str) - 1;
  else
    ptr = str;
  val = 0;
  while (ptr >= str)
  {
    n = *ptr;
    val = (val + n * 0x100) ^ n;
    ptr--;
  }
  return baseN(val, 64, 3);
}


/*-------------------------------------------------------*/
/* �s�h�Y�ӯ�						 */
/*-------------------------------------------------------*/


static int		/* 1:success  0:failure */
open_connect(hostname, hostprot, hostport)		/* �s�h�o�ӯ� */
  char *hostname, *hostprot, *hostport;
{
  if (!strncasecmp(hostprot, "IHAVE", 5))
    USEPROTOCOL = USEIHAVE;
  else if (!strncasecmp(hostprot, "POST", 4))
    USEPROTOCOL = USEPOST;
  else if (!strncasecmp(hostprot, "DATA", 4))
    USEPROTOCOL = USEDATA;
  else
    return 0;

  if (Verbose)
    printf("<open_connect> %s %s %s\n", hostname, hostprot, hostport);

  if (USEPROTOCOL != USEDATA)
  {
    char *atsign;

    atsign = strchr(hostname, '@');
    if (atsign != NULL)
      hostname = atsign + 1;

    if (Verbose)
      printf("<inetclient> %s %s\n", hostname, hostport);
    if ((NNTP = inetclient(hostname, hostport, "tcp")) < 0)
    {
      bbslog("<bbslink> :Err: server %s %s error: cant connect\n", hostname, hostport);
      if (Verbose)
	printf(":Err: server %s %s error: cant connect\n", hostname, hostport);
      return 0;
    }
    NNTPrfp = fdopen(NNTP, "r");
    NNTPwfp = fdopen(NNTP, "w");
    fgets(NNTPbuffer, sizeof(NNTPbuffer), NNTPrfp);
    if (atoi(NNTPbuffer) != 200)
    {
      bbslog("<bbslink> :Err: server error: %s", NNTPbuffer);
      if (Verbose)
	printf(":Err: server error: %s", NNTPbuffer);
      return 0;
    }

    innbbsfd = unixclient(LOCALDAEMON, "tcp");
    if (innbbsfd < 0)
    {
      bbslog("Connect to %s error. You may not run innbbsd.\n", LOCALDAEMON);
      return 0;
    }
    if (!(innbbsin = fdopen(innbbsfd, "r")) || !(innbbsout = fdopen(innbbsfd, "w")))
    {
      bbslog("fdopen error.\n");
      return 0;
    }
    fgets(INNBBSbuffer, sizeof(INNBBSbuffer), innbbsin);
  }
  else /* if (USEPROTOCOL == USEDATA) */
  {
    if (Verbose)
      printf("<inetclient> localhost %s\n", hostport);
    if ((NNTP = inetclient("localhost", hostport, "tcp")) < 0)
    {
      bbslog("<bbslink> :Err: server %s port %s error: cant connect\n", hostname, hostport);
      if (Verbose)
	printf(":Err: server error: cant connect");
      return 0;
    }
    NNTPrfp = fdopen(NNTP, "r");
    NNTPwfp = fdopen(NNTP, "w");
    fgets(NNTPbuffer, sizeof(NNTPbuffer), NNTPrfp);
    if (strncmp(NNTPbuffer, "220", 3) != 0)
    {
      bbslog("<bbslink> :Err: server error: %s", NNTPbuffer);
      if (Verbose)
	printf(":Err: server error: %s", NNTPbuffer);
      return 0;
    }
    if (strncmp(NNTPbuffer, "220-", 4) == 0)
    {
      fgets(NNTPbuffer, sizeof(NNTPbuffer), NNTPrfp);
    }
  }
  return 1;
}


static void
close_connect()		/* �����s�h�o�ӯ� */
{
  int status;

  if (Verbose)
    printf("<close_connect>\n");

  status = tcpcommand("QUIT");
  if (status != 205 && status != 221)
  {
    bbslog("<bbslink> :Err: Cannot quit message '%d %s'\n", status, (char *) tcpmessage());
    if (Verbose)
      printf(":Err: Cannot quit message '%d %s'\n", status, (char *) tcpmessage());
  }
  fclose(NNTPwfp);
  fclose(NNTPrfp);
  close(NNTP);

  /* SoC: close innbbsd connection */
  if (innbbsin != NULL)
    fclose(innbbsin);
  if (innbbsout != NULL)
    fclose(innbbsout);
  if (innbbsfd >= 0)
    close(innbbsfd);
}


/*-------------------------------------------------------*/
/* �B�z .link file					 */
/*-------------------------------------------------------*/


#if 0	/* itoc.030122.���� */

  .link �ɬO�̯��x���n�� �ݰe(�ΰe����)�� batch
  �p�G�����@�g�e���X�h�A�N�i�H�� queuefeed() �⨺�g���[�b .link
  �p�G�O���ӯ��x�s���W�A�N�i�H�� savefeed() �����ɮת��[�b .link
  
#endif


static void
openfeed(node)
  nodelist_t *node;
{
  if (node->feedfp == NULL)
  {
    char filepath[MAXFPATHLEN];
    sprintf(filepath, "innd/%s.link", node->node);
    node->feedfp = fopen(filepath, "a");
  }
}


static void
closefeed(node)
  nodelist_t *node;
{
  if (node->feedfp)
  {
    fclose(node->feedfp);
    node->feedfp = NULL;
  }
}


static void
queuefeed(node, textline)
  nodelist_t *node;
  char *textline;
{
  openfeed(node);

  if (node->feedfp != NULL)
  {
    /* flock(fileno(node->feedfp), LOCK_EX); */
    /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
    f_exlock(fileno(node->feedfp));

    fprintf(node->feedfp, "%s", textline);
    fflush(node->feedfp);

    /* flock(fileno(node->feedfp), LOCK_UN); */
    /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
    f_unlock(fileno(node->feedfp));
  }
}


static int
savefeed(node, overview)
  nodelist_t *node;
  char *overview;
{
  FILE *fp;
  char buffer[1024];

  openfeed(node);

  if (!(fp =  fopen(overview, "r")))
    return 0;

  /* flock(fileno(node->feedfp), LOCK_EX); */
  /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
  f_exlock(fileno(node->feedfp));

  while (fgets(buffer, sizeof(buffer), fp))
  {
    fputs(buffer, node->feedfp);
  }
  fflush(node->feedfp);

  /* flock(fileno(node->feedfp), LOCK_UN); */
  /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
  f_unlock(fileno(node->feedfp));

  fclose(fp);

  if (Verbose)
    printf("<Unlinking> %s\n", overview);

  unlink(overview);

  return 1;
}


/*-------------------------------------------------------*/
/* �B�z outgoing					 */
/*-------------------------------------------------------*/


/* SoC: add sent article to history of innbbsd */
static void
add_innbbsd_history(msgid, board, filename)
  char *msgid, *board, *filename;
{
  fprintf(innbbsout, "addhist <%s> %s/%s\r\n", msgid, board, filename);
  fflush(innbbsout);
  fgets(INNBBSbuffer, sizeof(INNBBSbuffer), innbbsin);
}


static int		/* 1:success  0:failure */
post_article(node, site, sover, textline)
  nodelist_t *node;
  char *site;
  soverview_t *sover;
  char *textline;
{
  int status;
  char *bodyp, *body;

  char *board = sover->board;
  char *filename = sover->filename;
  char *msgid = sover->msgid;

  if (Verbose)
  {
    printf("<post_article> %s:%s\n", board, site);
    printf("  => %s:%s\n", filename, sover->group);
    printf("  => %s\n", sover->from);
    printf("  => %s\n", sover->subject);
    printf("  => %ld:%s\n", sover->mtime, msgid);
  }

  if (*sover->charset == 'g')
  {
    b52gb(BODY);
    b52gb(sover->from);
    b52gb(sover->subject);
    b52gb(MYSITE);
  }

  /* �g�J�峹�����Y */
  fprintf(NNTPwfp, "Path: %s\r\n", MYBBSID);
  fprintf(NNTPwfp, "From: %s\r\n", sover->from);
  fprintf(NNTPwfp, "Newsgroups: %s\r\n", sover->group);
  /* fprintf(NNTPwfp, "Subject: %s\r\n", sover->subject); */
  /* itoc.030408: news ��X RFC 2047 */
  output_rfc2047_qp(NNTPwfp, "Subject: ", sover->subject, sover->charset, "\r\n");
  fprintf(NNTPwfp, "Date: %s\r\n", sover->date);
  fprintf(NNTPwfp, "Organization: %s\r\n", MYSITE);
  fprintf(NNTPwfp, "Message-ID: <%s>\r\n", msgid);
  /* itoc.021218: news ��X RFC 2045 */
  fprintf(NNTPwfp, "Mime-Version: 1.0\r\n");
  fprintf(NNTPwfp, "Content-Type: text/plain; charset=\"%s\"\r\n", sover->charset);
  fprintf(NNTPwfp, "Content-Transfer-Encoding: 8bit\r\n");
  fprintf(NNTPwfp, "X-Filename: %s/%s\r\n", board, filename);
  if (sover->control)
    fprintf(NNTPwfp, "Control: %s\r\n", sover->control);
  fputs("\r\n", NNTPwfp);	/* ���Y�M����Ť@�� */

  /* �g�J�峹�����e */
  for (body = BODY, bodyp = strchr(body, '\n'); body && *body; bodyp = strchr(body, '\n'))
  {
    /* itoc.030127.����: ���ҥH�n�@��@��g�J�A�O�]���n�� \n ���� \r\n */

    if (bodyp)
      *bodyp = '\0';
    fputs(body, NNTPwfp);
    fputs("\r\n", NNTPwfp);
    if (!bodyp)
      break;
    *bodyp = '\n';
    body = bodyp + 1;
  }

  status = tcpcommand(".");

  if (USEPROTOCOL == USEIHAVE)
  {
    if (status == 235)				/* 235:���\����X */
    {
      add_innbbsd_history(msgid, board, filename + 1); /* SoC */
    }
    else if (status == 435 || status == 437)	/* 435:duplicated article 437:invalid header */
    {
      bbslog("<bbslink> :Warn: %d %s <%s>\n", status, (char *) tcpmessage(), msgid);
      if (Verbose)
	printf(":Warn: %d %s <%s>\n", status, (char *) tcpmessage(), msgid);
      return 0;
    }
    else					/* �e���ѤF�Aqueue �_�� */
    {
      bbslog("<bbslink> :Err: %d %s of <%s>\n", status, (char *) tcpmessage(), msgid);
      if (Verbose)
	printf(":Err: %d %s of <%s>\n", status, (char *) tcpmessage(), msgid);
      queuefeed(node, textline);
      return 0;
    }
  }
  else if (USEPROTOCOL == USEPOST)
  {
    if (status == 240)				/* 240:���\����X */
    {
      /* Thor.990304: ���F�� POST �]�ण�o�Xfake cancel, �M�Q�~�� cancel */
      add_innbbsd_history(msgid, board, filename + 1); 
    }
    else if (status == 441)			/* 441:duplicated article */
    {
      bbslog("<bbslink> :Warn: %d %s <%s>\n", status, (char *) tcpmessage(), msgid);
      if (Verbose)
	printf(":Warn: %d %s <%s>\n", status, (char *) tcpmessage(), msgid);
      return 0;
    }
    else					 /* �e���ѤF�Aqueue �_�� */
    {
      bbslog("<bbslink> :Err: %d %s of <%s>\n", status, (char *) tcpmessage(), msgid);
      queuefeed(node, textline);
      return 0;
    }
  }
  else if (USEPROTOCOL == USEDATA)
  {
    if (status == 250)				/* 250:���\����X */
    {
      if (Verbose)
	printf("<DATA Sendout> <%s> from %s/%s\n", msgid, board, filename);
    }
    else					 /* �e���ѤF�Aqueue �_�� */
    {
      bbslog("<bbslink> :Err: %d %s of <%s>\n", status, (char *) tcpmessage(), msgid);
      if (Verbose)
	printf(":Err: %d %s of <%s>\n", status, (char *) tcpmessage(), msgid);
      queuefeed(node, textline);
      return 0;
    }
  }
  return 1;
}


static int		/* 1:success  0:failure */
send_outgoing(node, site, hostname, sover, textline)
  nodelist_t *node;
  soverview_t *sover;
  char *hostname, *site;
  char *textline;
{
  int status;
  char *board, *filepath, *msgid;
  int returnstatus;

  board = sover->board;
  filepath = sover->filename;
  msgid = sover->msgid;

  if (Verbose)
  {
    printf("<send_outgoing> %s:%s:%s:%s\n", site, board, filepath, msgid);
    if (BODY == NULL)
      printf("    ==> article no BODY\n");
  }

  if (BODY == NULL)
    return 1;

  if (USEPROTOCOL == USEIHAVE)
  {
    status = tcpcommand("IHAVE <%s>", msgid);
    if (status == 335)
    {
      returnstatus = post_article(node, site, sover, textline);
    }
    else if (status == 435  || status == 437 || status == 480)
    /* Thor.990305: edwardc patch:
       435 article not wanted - do not send it
       437 article rejected - do not try again */
    {
      bbslog("<bbslink> :Warn: %d %s, IHAVE <%s>\n", status, (char *) tcpmessage(), msgid);
      if (Verbose)
	printf(":Warn: %d %s, IHAVE <%s>\n", status, (char *) tcpmessage(), msgid);
      returnstatus = 0;
    }
    else
    {
      bbslog("<bbslink> :Err: %d %s, IHAVE <%s>\n", status, (char *) tcpmessage(), msgid);
      if (Verbose)
	printf(":Err: %d %s, IHAVE <%s>\n", status, (char *) tcpmessage(), msgid);
      queuefeed(node, textline);
      returnstatus = 0;
    }
  }
  else if (USEPROTOCOL == USEPOST)
  {
    tcpcommand("MODE READER");
    status = tcpcommand("POST");
    if (status == 340)
    {
      returnstatus = post_article(node, site, sover, textline);
    }
    else if (status == 440 || status == 441 || status == 480)
    /* Thor.990305: edwardc patch:
       440 posting not allowed
       441 posting failed */
    {
      bbslog("<bbslink> :Warn: %d %s, POST <%s>\n", status, (char *) tcpmessage(), msgid);
      if (Verbose)
	printf(":Warn: %d %s, POST <%s>\n", status, (char *) tcpmessage(), msgid);
      returnstatus = 0;
    }
    else
    {
      bbslog("<bbslink> :Err: %d %s, POST <%s>\n", status, (char *) tcpmessage(), msgid);
      if (Verbose)
	printf(":Err: %d %s, POST <%s>\n", status, (char *) tcpmessage(), msgid);
      queuefeed(node, textline);
      returnstatus = 0;
    }
  }
  else if (USEPROTOCOL == USEDATA)
  {
    tcpcommand("HELO");
    tcpcommand("MAIL FROM: bbs");
    tcpcommand("RCPT TO: %s", hostname);
    status = tcpcommand("DATA");
    if (status == 354)
    {
      returnstatus = post_article(node, site, sover, textline);
    }
    else
    {
      bbslog("<bbslink> :Err: %d %s, DATA <%s>\n", status, (char *) tcpmessage(), msgid);
      if (Verbose)
	printf(":Err: %d %s, DATA <%s>\n", status, (char *) tcpmessage(), msgid);
      queuefeed(node, textline);
      returnstatus = 0;
    }
  }
  return returnstatus;
}


static int		/* 0:success  -1:�Ӥ峹�w���� */
read_outgoing(sover)
  soverview_t *sover;
{
  char *buffer, *bufferp;
  char filepath[MAXFPATHLEN];
  struct stat st;
  int fd, size;

  char *board = sover->board;
  char *filename = sover->filename;

  if (Verbose)
  {
    /* printf("-=-= �C�g�e�H�n�g�L read_outgoing �� send_outgoing �� post_article �T�B�J�~�⦨�\\ =-=-\n"); */
    printf("------------------------------\n");
    printf("<read_outgoing> %s:%s\n", board, filename);
  }

  if (sover->mtime == -1)	/* �e�X cancel message */
  {
    static char BODY_BUF[MAXBUFLEN];

    strncpy(BODY_BUF, fileglue("%s\r\n", sover->subject), sizeof(BODY_BUF));
    BODY = BODY_BUF;	/* cancel message �ɡABODY ���V BODY_BUF */
  }
  else				/* �e�X�s�峹 */
  {
    static char *FD_BUF;

    /* �ˬd�峹�٦b���b */
    sprintf(filepath, "brd/%s/%c/%s", board, filename[7], filename);
    if ((fd = open(filepath, O_RDONLY)) < 0)
      return -1;
    fstat(fd, &st);
    size = st.st_size;
    if (size <= 0)
      return -1;

    if (FD_BUF == NULL)
      FD_BUF = (char *) malloc(size + 1);
    else
      FD_BUF = (char *) realloc(FD_BUF, size + 1);
    read(fd, FD_BUF, size);
    close(fd);
    bufferp = FD_BUF + size;
    *bufferp = '\0';

    /* �@��峹�ɡABODY ���V malloc �ͥX�Ӫ��϶� */

    /* ���L�峹���e�X�����Y���n */
    for (buffer = FD_BUF;;buffer = bufferp + 1)
    {
      bufferp = strchr(buffer, '\n');
      if (!bufferp)	/* ���峹�̫�F�٧䤣��Ŧ�A�������ɮ׳��������� */
      {
        BODY = FD_BUF;
        break;
      }

      if (buffer == bufferp)	/* ���@��Ŧ�A����H�U�N���O����F */
      {
        BODY = buffer + 1;
        break;
      }
    }
  }

  return 0;
}


/*-------------------------------------------------------*/
/* �e�X�s�峹						 */
/*-------------------------------------------------------*/


static void
bbslink_un_lock(file)
  char *file;
{
  char *lockfile = fileglue("%s.LOCK", file);

  if (isfile(lockfile))
    unlink(lockfile);
}


static int
bbslink_get_lock(file)
  char *file;
{
  int lockfd;
  char LockFile[MAXFPATHLEN], buf[10];

  strncpy(LockFile, (char *) fileglue("%s.LOCK", file), sizeof(LockFile));

  if ((lockfd = open(LockFile, O_RDONLY)) >= 0)
  {
    int pid;

    /* .LOCK �w�s�b�A�N���� bbslink ���b�] */

    if (read(lockfd, buf, sizeof(buf)) > 0 && (pid = atoi(buf)) > 0 && kill(pid, 0) == 0)
    {
      if (KillFormerBBSLINK)
      {
	kill(pid, SIGTERM);
	unlink(LockFile);
      }
      else
      {
	fprintf(stderr, "���t�~�@�� bbslink �� process [%d] ���b�B�@��\n", pid);
	return 0;
      }
    }
    else
    {
      /* no process running, but lock file existed, unlinked */
      unlink(LockFile);
    }
    close(lockfd);
  }

  if ((lockfd = open(LockFile, O_RDWR | O_CREAT | O_EXCL, 0644)) < 0)
  {
    fprintf(stderr, "lock %s error: cannot create file\n", LockFile);
    return 0;
  }

  /* lock ���\�A�ç� pid �g�J .LOCK */
  sprintf(buf, "%-.8d\n", getpid());
  write(lockfd, buf, strlen(buf));
  close(lockfd);
  return 1;
}


static int
send_nntplink(node, site, hostname, hostprot, hostport, overview, nlcount)
  nodelist_t *node;	/* �n�e�h�����O�b nodelist.bbs �����@�� */
  char *site;		/* �ӯ��x�� short-name */
  char *hostname;	/* �ӯ��x�� hostname */
  char *hostprot;	/* �ӯ��x�� protocol */
  char *hostport;	/* �ӯ��x�� port */
  char *overview;	/* �n����Ǥ峹�e�h�ӯ����C�� */
  int nlcount;
{
  FILE *fp;
  char textline[1024];
  char baktextline[1024];

  if (Verbose)
  {
    printf("<send nntplink> %s %s %s %s\n", site, hostname, hostprot, hostport);
    printf("    ==> %s\n", overview);
  }

  if (!open_connect(hostname, hostprot, hostport))
  {
    savefeed(node, overview);
    return 0;
  }

  if (!(fp = fopen(overview, "r")))
  {
    if (Verbose)
      printf("open %s failed\n", overview);
    return 0;
  }

  while (fgets(textline, sizeof(textline), fp))
  {
    char *ptr;
    char *board, *filename, *group, *from, *subject, *date, *msgid, *control, *charset, *mtime;
    soverview_t soverview;

    /* itoc.030122,����: overview �o�ɮ׸̭��C�檺�榡 */
    /* %s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%ld\n
       board, filename, group, from, subject, date, msgid, control, charset, mtime */

    strcpy(baktextline, textline);
    
    /* board field */
    board = textline;
    ptr = strchr(textline, '\t');
    if (ptr == NULL)
      continue;
    *ptr++ = '\0';

    /* filename field */
    filename = ptr;
    ptr = strchr(ptr, '\t');
    if (ptr == NULL)
      continue;
    *ptr++ = '\0';

    /* group field */
    group = ptr;
    ptr = strchr(ptr, '\t');
    if (ptr == NULL)
      continue;
    *ptr++ = '\0';

    /* from field */
    from = ptr;
    ptr = strchr(ptr, '\t');
    if (ptr == NULL)
      continue;
    *ptr++ = '\0';

    /* subject field */
    subject = ptr;
    ptr = strchr(ptr, '\t');
    if (ptr == NULL)
      continue;
    *ptr++ = '\0';

    /* date field */
    date = ptr;
    ptr = strchr(ptr, '\t');
    if (ptr == NULL)
      continue;
    *ptr++ = '\0';

    /* msgid field */
    msgid = ptr;
    ptr = strchr(ptr, '\t');
    if (ptr == NULL)
      continue;
    *ptr++ = '\0';

    /* control field */
    control = ptr;
    ptr = strchr(ptr, '\t');
    if (ptr == NULL)
      continue;
    *ptr++ = '\0';

    /* charset field */
    charset = ptr;
    ptr = strchr(ptr, '\t');
    if (ptr == NULL)
      continue;
    *ptr++ = '\0';

    /* mtime field */
    mtime = ptr;
    ptr = strchr(ptr, '\n');
    if (ptr == NULL)
      continue;
    *ptr = '\0';

    soverview.board = board;
    soverview.filename = filename;
    soverview.group = group;
    soverview.from = from;
    soverview.subject = subject;
    soverview.date = date;
    soverview.msgid = msgid;
    soverview.control = strcmp(control, "nothing") ? control : NULL;
    soverview.charset = charset;
    soverview.mtime = atol(mtime);

    if (!read_outgoing(&soverview))
    {
      int sendresult, sendfailed;

#if 0	/* itoc.030109: �b�٨S maintain history ���e�A�|�]�� grephist ���Ѧӵo���X cancel msg */
      /* SoC: check cancel msg w/o article sent */
      if (soverview.mtime == -1)
      {
	/* Thor.980529: �ݬݭn�o��cmsg��cancel��MessageID���S���bhistory */
	fprintf(innbbsout, "grephist <%s>\r\n", soverview.msgid);
	fflush(innbbsout);
	fgets(INNBBSbuffer, sizeof(INNBBSbuffer), innbbsin);
	if (atoi(INNBBSbuffer) == 484)	/* article not found */
	{
	  bbslog("Redundant cancel: %s\t%s\t%s\t<%s>\t<%s>\n", 
	    soverview.from, soverview.subject, soverview.board, soverview.msgid, strchr(soverview.msgid, '.') + 1);
	  continue;	/* skip cancel msg */ 
	}
      }
#endif

      sendresult = send_outgoing(node, site, hostname, &soverview, baktextline);
      sendfailed = 1 - sendresult;

      BBSLINK_STAT[nlcount].sendout += sendresult;
      BBSLINK_STAT[nlcount].failed += sendfailed;
    }
  }
  fclose(fp);
  close_connect();

  if (Verbose)
    printf("<Unlinking> %s\n", overview);

  unlink(overview);
}


static void
send_article()
{
  char *site, *op;
  char *nntphost;
  int nlcount;

  /* �� nodelist.bbs �����Ҧ����x���H���e�@�e */
  for (nlcount = 0; nlcount < NLCOUNT; nlcount++)
  {
    nodelist_t *node;
    char linkfile[MAXFPATHLEN], sendfile[MAXFPATHLEN];
    char protocol[MAXBUFLEN], port[MAXBUFLEN];

    node = NODELIST + nlcount;
    site = node->node;
    nntphost = node->host;
    op = node->protocol;

    /* �Y�����w�u�e�Y�S�w���A����N�u�e�s�峹������ */
    if (DefaultFeedSite && *DefaultFeedSite)
    {
      if (strcmp(node->node, DefaultFeedSite))
	continue;
    }

    if (op && (!strncasecmp(op, "ihave", 5) || !strncasecmp(op, "post", 4) || !strncasecmp(op, "data", 4)))
    {
      char *left, *right;

      left = strchr(op, '(');
      right = strrchr(op, ')');
      if (left && right)
      {
	*left = '\0';
	*right = '\0';
	strncpy(protocol, op, sizeof(protocol));
	strncpy(port, left + 1, sizeof(port));
	*left = '(';
	*right = ')';
      }
      else
      {
        continue;
      }
    }
    else
    {
      continue;
    }

    sprintf(linkfile, "innd/%s.link", site);
    if (isfile(linkfile) && !iszerofile(linkfile))
    {
      if (bbslink_get_lock(linkfile))
      {
	closefeed(node);
	sprintf(sendfile, "innd/%s.sending", site);
	rename(linkfile, sendfile);
	send_nntplink(node, site, nntphost, protocol, port, sendfile, nlcount);
	bbslink_un_lock(linkfile);
      }
    }
  }
}


/*-------------------------------------------------------*/
/* �B�z bntp ��						 */
/*-------------------------------------------------------*/


static nodelist_t *
search_nodelist_bynode(node)
  char *node;
{
  nodelist_t nlt, *find;
  nlt.node = node;
  find = (nodelist_t *) bsearch((char *) &nlt, NODELIST, NLCOUNT, sizeof(nodelist_t), nl_bynodecmp);
  return find;
}


static newsfeeds_t *
search_newsfeeds_byboard(board)
  char *board;
{
  newsfeeds_t nft, *nftptr, **find;
  nft.board = board;
  nftptr = &nft;
  find = (newsfeeds_t **) bsearch((char *) &nftptr, NEWSFEEDS_BYBOARD, NFCOUNT, sizeof(newsfeeds_t *), nf_byboardcmp);
  if (find)
    return *find;
  return NULL;
}


static void
save_outgoing(sover, filename)		/* �� out.bntp �� cancel.outp ���R�n����ƨ̯��x���[�� .link */
  soverview_t *sover, *filename;
{
  newsfeeds_t *nf;
  char *group, *server;
  char *board;
  char *ptr1, *ptr2;

  if (VisitOnly)
    return;

  board = sover->board;

  nf = (newsfeeds_t *) search_newsfeeds_byboard(board);
  if (nf == NULL)
  {
    bbslog("<bbslink> save_outgoing: No such board %s\n", board);
    return;
  }

  group = nf->newsgroups;
  server = nf->path;

  for (ptr1 = server; ptr1 && *ptr1;)	/* ��h�h�ӯ��x */
  {
    nodelist_t *nl;
    char savech;

    for (; *ptr1 && *ptr1 == ','; ptr1++);
    if (!*ptr1)
      break;
    for (ptr2 = ptr1; *ptr2 && *ptr2 != ','; ptr2++);
    savech = *ptr2;
    *ptr2 = '\0';
    nl = (nodelist_t *) search_nodelist_bynode(ptr1);
    *ptr2 = savech;
    ptr1 = ptr2++;
    if (nl == NULL)
      continue;

    if (nl->host && *nl->host)
    {
      if (nl->feedfp == NULL)
      {
        char fp_link[MAXFPATHLEN];

	sprintf(fp_link, "innd/%s.link", nl->node);
	nl->feedfp = fopen(fp_link, "a");
	if (nl->feedfp == NULL)
	{
	  bbslog("<save outgoing> append failed for %s", fp_link);
	}
      }
      if (nl->feedfp != NULL)
      {
	/* flock(fileno(nl->feedfp), LOCK_EX); */
        /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
        f_exlock(fileno(nl->feedfp));

	fprintf(nl->feedfp, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%ld\n",
	  sover->board, sover->filename, group, sover->from, sover->subject, 
	  sover->date, sover->msgid, sover->control, nf->charset, sover->mtime);
	fflush(nl->feedfp);

	/* flock(fileno(nl->feedfp), LOCK_UN); */
        /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
        f_unlock(fileno(nl->feedfp));
      }
    }
    if (savech == '\0')
      break;
  }
}


static char DATE[MAXBUFLEN];		/* �� sover.date ���V���O����Ŷ� */
static char FROM[MAXBUFLEN];		/* �� sover.from ���V���O����Ŷ� */
static char SUBJECT[MAXBUFLEN];		/* �� cancel message �ɡA�� sover.subject ���V���O����Ŷ� */
static char MSGID[MAXBUFLEN];		/* �� sover.msgid ���V���O����Ŷ� */
static char CONTROL[MAXBUFLEN];		/* �� sover.control ���V���O����Ŷ� */


static void
process_article(board, filename, userid, nickname, subject)
  char *board, *filename, *userid, *nickname, *subject;
{
  char filepath[MAXFPATHLEN], times[MAXBUFLEN];
  soverview_t sover;
  struct stat st;
  time_t mtime;
  char *hash;

  /* �ˬd���o�ɮפ~�e */
  sprintf(filepath, "brd/%s/%c/%s", board, filename[7], filename);
  if (!isfile(filepath) || stat(filepath, &st))
    return;

  strncpy(FROM, fileglue("%s.bbs@%s (%s)", userid, MYADDR, nickname), sizeof(FROM));
  strncpy(times, baseN(chrono32(filename), 48, 6), sizeof(times));
  hash = hash_value(fileglue("%s.%s", filename, board));
  sprintf(MSGID, "%s$%s@%s", times, hash, MYADDR);
  mtime = st.st_mtime;
  sprintf(DATE, "%s", Gtime(mtime));
  strcpy(CONTROL, "nothing");

  sover.board = board;
  sover.filename = filename;
  sover.from = FROM;
  sover.subject = subject;
  sover.date = DATE;
  sover.msgid = MSGID;
  sover.control = CONTROL;
  sover.mtime = mtime;

  save_outgoing(&sover);
}


static void
process_cancel(board, filename, userid, nickname, subject)
  char *board, *filename, *userid, *nickname, *subject;
{
  char times[MAXBUFLEN];
  soverview_t sover;
  time_t now;
  char *hash;

  strncpy(FROM, fileglue("%s.bbs@%s (%s)", userid, MYADDR, nickname), sizeof(FROM));
  strncpy(times, baseN(chrono32(filename), 48, 6), sizeof(times));
  hash = hash_value(fileglue("%s.%s", filename, board));
  sprintf(MSGID, "%s$%s@%s", times, hash, MYADDR);
  sprintf(CONTROL, "cancel <%s>", MSGID);
  sprintf(SUBJECT, "cmsg cancel <%s>", MSGID);
  time(&now);
  sprintf(DATE, "%s", Gtime(now));

  sover.board = board;
  sover.filename = filename;
  sover.from = FROM;
  sover.subject = SUBJECT;
  sover.date = DATE;
  sover.msgid = MSGID;
  sover.control = CONTROL;
  sover.mtime = -1;

  save_outgoing(&sover);
}


static int		/* 0:success  -1:failure */
deal_bntp(fpath, mode)
  char *fpath;
  int mode;		/* 0:�e�X�s�峹  -1:cancel */
{
  static char *OUTING = "innd/.outing";
  static char *bbslink_lockfile = "innd/.bbslinking";

  FILE *fp;
  char buf[512];
  char *board, *filename, *userid, *nickname, *subject;
  char *ptr;

  /* When try to visit new post, try to lock it */
  if (!bbslink_get_lock(bbslink_lockfile))
    return -1;

  if (rename(fpath, OUTING))	/* �S���s�峹 */
  {
    bbslink_un_lock(bbslink_lockfile);
    return 0;
  }

  if (!(fp = fopen(OUTING, "r")))
  {
    bbslog("<bbslink> Err: can't open %s\n", OUTING);
    bbslink_un_lock(bbslink_lockfile);
    return -1;
  }

  while (fgets(buf, sizeof(buf), fp))
  {
    /* board field */
    board = buf;
    ptr = strchr(buf, '\t');
    if (ptr == NULL)
      continue;
    *ptr++ = '\0';

    /* filename field */
    filename = ptr;
    ptr = strchr(ptr, '\t');
    if (ptr == NULL)
      continue;
    *ptr++ = '\0';

    /* userid field */
    userid = ptr;
    ptr = strchr(ptr, '\t');
    if (ptr == NULL)
      continue;
    *ptr++ = '\0';

    /* nickname field */
    nickname = ptr;
    ptr = strchr(ptr, '\t');
    if (ptr == NULL)
      continue;
    *ptr++ = '\0';

    /* subject field */
    subject = ptr;
    ptr = strchr(ptr, '\n');
    if (ptr == NULL)
      continue;
    *ptr = '\0';

    /* �O�I�_���A�A�ˬd�@�U */
    if (!*board || !*filename || !*userid || !*nickname || !*subject)
      continue;

    if (mode == 0)
      process_article(board, filename, userid, nickname, subject);
    else
      process_cancel(board, filename, userid, nickname, subject);
  }

  fclose(fp);
  unlink(OUTING);
  bbslink_un_lock(bbslink_lockfile);

  return 0;
}


/*-------------------------------------------------------*/
/* �D�{�� (bbs nntp)					 */
/*-------------------------------------------------------*/


static int		/* 0:success  -1:failure */
bntplink()
{
  nodelist_t *nl;
  int nlcount;

  if (!initial_bbs())
    return -1;

  if (!(nl = (nodelist_t *) search_nodelist_bynode(MYBBSID)))
  {
    fprintf(stderr, "���ˬd nodelist.bbs�A�S���ۤv�����x���\n");
    return -1;
  }

  strncpy(MYADDR, nl->host, sizeof(MYADDR));
  strncpy(MYSITE, nl->comment, sizeof(MYSITE));

  if (Verbose)
    printf("MYADDR: %s\n", MYADDR);

  BBSLINK_STAT = (stat_t *) malloc(sizeof(stat_t) * (NLCOUNT + 1));
  for (nlcount = 0; nlcount < NLCOUNT; nlcount++)
  {
    BBSLINK_STAT[nlcount].sendout = 0;
    BBSLINK_STAT[nlcount].failed = 0;
  }

  if (deal_bntp("innd/out.bntp", 0))
    return -1;
  if (deal_bntp("innd/cancel.bntp", -1))
    return -1;

  for (nlcount = 0; nlcount < NLCOUNT; nlcount++)
  {
    closefeed(&NODELIST[nlcount]);
  }

  send_article();

  for (nlcount = 0; nlcount < NLCOUNT; nlcount++)
  {
    int sendout, failed;

    sendout = BBSLINK_STAT[nlcount].sendout;
    failed = BBSLINK_STAT[nlcount].failed;
    if (sendout || failed)
    {
      bbslog("<bbslink> [%s] send:%d fail:%d\n",
	NODELIST[nlcount].node, sendout, failed);
    }

    closefeed(&NODELIST[nlcount]);
  }

  if (BBSLINK_STAT);
    free(BBSLINK_STAT);

  return 0;
}


static void
terminate_bbslink(sig)
  int sig;
{
  bbslog("kill signal received %d, terminated\n", sig);
  if (Verbose)
    printf("kill signal received %d, terminated\n", sig);
  exit(0);
}


static void
usage(argv)
  char *argv;
{
  fprintf(stderr, "Usage: %s [options]\n", argv);
  fprintf(stderr, "       -v (show transmission status)\n");
  fprintf(stderr, "       -s site (only process articles sent to this site)\n");
  fprintf(stderr, "       -V (visit only: bbspost visit)\n");
  fprintf(stderr, "       -k (kill the former bbslink process before started)\n\n");
  fprintf(stderr, "���{���n���`���楲���N�H�U�ɮ׸m�� %s/innd �U:\n", BBSHOME);
  fprintf(stderr, "bbsname.bbs   �]�w�Q���� BBS ID (�о��q²�u)\n");
  fprintf(stderr, "nodelist.bbs  �]�w�����U BBS ���� ID, Address �M fullname\n");
  fprintf(stderr, "newsfeeds.bbs �]�w�����H�� newsgroup board nodelist ...\n");
}


int
main(argc, argv)
  int argc;
  char *argv[];
{
  int c, errflag = 0;
  extern char *optarg;

  chdir(BBSHOME);
  umask(077);

  signal(SIGTERM, terminate_bbslink);

  while ((c = getopt(argc, argv, "s:vVk")) != -1)
  {
    switch (c)
    {
    case 's':
      DefaultFeedSite = optarg;
      break;

    case 'v':
      Verbose = 1;
      break;

    case 'V':
      VisitOnly = 1;
      break;

    case 'k':
      KillFormerBBSLINK = 1;
      break;

    default:
      errflag++;
      break;
    }
  }

  if (errflag > 0)
  {
    usage(argv[0]);
    return -1;
  }

  bntplink();
  return 0;
}
