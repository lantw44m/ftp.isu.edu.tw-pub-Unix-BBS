/*-------------------------------------------------------*/
/* util/gem-expire.c	( NTHU CS MapleBBS Ver 3.10 )    */
/*-------------------------------------------------------*/
/* target : �p�⥼�s��ذ� & ���s�Ѽƺ�ذϱƦ�]	 */
/* create : 99/11/26                                     */
/* update : 01/08/27					 */
/* author : Jimmy.bbs@whshs.twbbs.org			 */
/* modify : itoc.bbs@bbs.tnfsh.tn.edu.tw		 */
/*-------------------------------------------------------*/
/* syntax : gem-expire					 */
/*-------------------------------------------------------*/


#include "bbs.h"

#define OUTFILE_GEMEMPTY	"gem/@/@-gem_empty"
#define OUTFILE_GEMOVERDUE	"gem/@/@-gem_overdue"


static char nostat[MAXBOARD][IDLEN + 1];	/* ���C�J�Ʀ�]���ݪO */
static int nostat_num;				/* nostat_num+1: �X�ӪO���C�J�έp */


static void
collect_nostat()
{
  FILE *fp;
  BRD brd;

  nostat_num = -1;
  if (fp = fopen(FN_BRD, "r"))
  {
    while (fread(&brd, sizeof(BRD), 1, fp) == 1)
    {
      if ((brd.readlevel | brd.postlevel) >= (PERM_VALID << 1))	/* (BASIC + ... + VALID) < (VALID << 1) */
      {
	nostat_num++;
	strcpy(nostat[nostat_num], brd.brdname);
      }
    }

    fclose(fp);
  }
}


static int	/* 1:���O���C�J�έp */
is_nostat(brdname)
  char *brdname;
{
  int i;

  for (i = 0; i <= nostat_num; i++)
  {
    if (!strcmp(brdname, nostat[i]))
      return 1;
  }
  return 0;
}


static char *
whoisbm(brdname)
  char *brdname;
{
  BRD brd;
  int pos, fd;
  static char BM[BMLEN + 1];

  pos = 0;
  fd = open(FN_BRD, O_RDONLY);

  while (fd)
  {
    lseek(fd, (off_t) (sizeof(BRD) * pos), SEEK_SET);
    if (read(fd, &brd, sizeof(BRD)) == sizeof(BRD))
    {
      if (!strcmp(brdname, brd.brdname))
      {
        strcpy(BM, brd.BM);
        break;
      }
      pos++;
    }
    else
    {
      break;
    }
  }
  close(fd);
  return BM;
}


typedef struct
{
  int day;			/* �X�ѨS��z��ذ� */
  char brdname[IDLEN + 1];	/* �O�W */
}	BRDDATA;


static int
int_cmp(a, b)
  BRDDATA *a, *b;
{
  return (b->day - a->day);	/* �Ѥj�ƨ�p */
}


int 
main()
{
  struct dirent *de;
  DIR *dirp;
  struct stat st;
  time_t now;
  struct tm *ptime;
  BRDDATA board[MAXBOARD];
  FILE *fpe, *fpo;
  int locus, i, m, n;
  char buf[64], *brdname;

  chdir(BBSHOME);

  collect_nostat();	/* itoc.020127: �������C�J�Ʀ�]���ݪO */

  if (!(dirp = opendir("gem/brd")))
    return;

  time(&now);
  ptime = localtime(&now);
  locus = 0;

  while (de = readdir(dirp))
  {
    brdname = de->d_name;
    if (*brdname <= ' ' || *brdname == '.')
      continue;

    /* ���L���C�J�Ʀ�]���ݪO */
    if (is_nostat(brdname))
      continue;

    sprintf(buf, "gem/brd/%s/@/@log", brdname);

    if (stat(buf, &st) != -1)	/* ����ذϪ��ˬd�X�ѥ��s */
    {
      strcpy(board[locus].brdname, brdname);
      board[locus].day = (now - st.st_mtime) / 86400;
    }
    else	/* �L��ذϪ� */
    {
      strcpy(board[locus].brdname, brdname);
      board[locus].day = 999;
    }

    locus++;
  }

  qsort(board, locus, sizeof(BRDDATA), int_cmp);

  fpe = fopen(OUTFILE_GEMEMPTY, "w");
  fpo = fopen(OUTFILE_GEMOVERDUE, "w");

  fprintf(fpe,
    "         \033[1;34m-----\033[37m=====\033[41m �ݪO��ذϥ��s���ݪO (�� %d �� %d ���) \033[;1;37m=====\033[34m-----\033[m\n"
    "           \033[1;42m �W�� \033[44m   �ݪO�W��   \033[42m      ��ذϥ��s      \033[44m   �O   �D    \033[m\n",
    ptime->tm_mon + 1, ptime->tm_mday);

  fprintf(fpo,
    "        \033[1;34m-----\033[37m=====\033[41m �ݪO��ذϥ��s�ѼƤ��ݪO (�� %d �� %d ���) \033[;1;37m=====\033[34m-----\033[m\n"
    "              \033[1;42m �W�� \033[44m    �ݪO�W��    \033[42m ��ذϥ��s�Ѽ� \033[44m   �O   �D    \033[m\n",
    ptime->tm_mon + 1, ptime->tm_mday);

  m = 1;
  n = 1;

  for (i = 0; i < locus; i++)
  {
    if (board[i].day == 999)
    {
      fprintf(fpe, "            %3d   %12s     %s      %-20.20s\n",
	m, board[i].brdname, "�|���s���ذ�", whoisbm(board[i].brdname));
      m++;
    }
    else
    {
      fprintf(fpo, "                %s%3d    %12s        %4d       %-20.20s\033[m\n",
	n <= 3 ? "\033[1m" : (n <= 10 ? "\033[1;31m" : "\033[m"),
	n, board[i].brdname, board[i].day, whoisbm(board[i].brdname));
      n++;
    }
  }

  fclose(fpe);
  fclose(fpo);
}
