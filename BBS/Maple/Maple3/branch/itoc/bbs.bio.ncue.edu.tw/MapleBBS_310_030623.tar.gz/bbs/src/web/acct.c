/*-------------------------------------------------------*/
/* acct.c      ( NTHU CS MapleBBS Ver 3.00 )             */
/*-------------------------------------------------------*/
/* target : Some Functions About Account		 */
/* author : hightman.bbs@bbs.dot66.net			 */
/* create : 01/09/20                                     */
/* update : 02/11/05                                     */
/*-------------------------------------------------------*/


#include "web.h"


/* ----------------------------------------------------- */
/* (.ACCT) �ϥΪ̱b�� (account) subroutines              */
/* ----------------------------------------------------- */


int
acct_load(acct, userid)
  ACCT *acct;
  char *userid;
{
  int fd;

  usr_fpath((char *)acct, userid, FN_ACCT);
  fd = open((char *)acct, O_RDONLY);
  if (fd >= 0)
  {
    /* Thor.990416: �S�O�`�N, ���� .ACCT�����׷|�O0 */
    read(fd, acct, sizeof(ACCT));
    close(fd);
  }
  return fd;
}


char *			/* �^�� myWRC.query ���U�@����� */
acct_locate()		/* �� myWRC �� pid ��Ū�� cuser */
{
  char *ptr;
  pid_t pid;

  ptr = myWRC.query;
  pid = atoi(nextword(&ptr));
  cutmp = utmp_locate(pid);

  if (!cutmp || acct_load(&cuser, cutmp->userid) < 0)
  {
    msg_quit(err_uid);
    return NULL;
  }

  return ptr;	/* �^�� nextword */
}


void
acct_save(acct, mode)
  ACCT *acct;
  usint mode;
{
  int fd;
  char fpath[80];
  ACCT tuser;

  usr_fpath(fpath, acct->userid, fn_acct);

  fd = open(fpath, O_RDWR);
  if (fd >= 0)
  {
    if (mode)
    {
      read(fd, &tuser, sizeof(ACCT));

      /* �� mode �ӨM�w�n�^�s������� */
      if (mode & ACCTSAV_ULEVEL)
      {
	tuser.userlevel = acct->userlevel;
      }
      if (mode & ACCTSAV_UFO)
      {
	tuser.ufo = acct->ufo;
      }
      if (mode & ACCTSAV_UINFO)
      {
	strcpy(tuser.passwd, acct->passwd);
	strcpy(tuser.username, acct->username);
      }
      if (mode & ACCTSAV_HOST)
      {
	strcpy(tuser.lasthost, acct->lasthost);
      }
      if (mode & ACCTSAV_EMAIL)
      {
	strcpy(tuser.email, acct->email);
      }
      if (mode & ACCTSAV_LOGIN)
      {
	tuser.numlogins = acct->numlogins;
	tuser.lastlogin = acct->lastlogin;
      }
      if (mode & ACCTSAV_POST)
      {
	tuser.numposts = acct->numposts;
      }

      lseek(fd, (off_t) 0, SEEK_SET);
      write(fd, &tuser, sizeof(ACCT));
    }
    else
    {
      write(fd, acct, sizeof(ACCT));
    }
    close(fd);
  }
}


int
acct_userno(userid)
  char *userid;
{
  int fd;
  int userno;
  char fpath[80];

  usr_fpath(fpath, userid, fn_acct);
  fd = open(fpath, O_RDONLY);
  if (fd >= 0)
  {
    read(fd, &userno, sizeof(userno));
    close(fd);
    return userno;
  }
  return 0;
}


/* ----------------------------------------------------- */
/* �ˬd�ϥΪ̱b���O�_�s�b		                 */
/* ----------------------------------------------------- */


static int
belong(flist, key)
  char *flist;
  char *key;
{
  int fd, rc;

  rc = 0;
  fd = open(flist, O_RDONLY);
  if (fd >= 0)
  {
    mgets(-1);

    while (flist = mgets(fd))
    {
      str_lower(flist, flist);
      if (str_str(key, flist))
      {
	rc = 1;
	break;
      }
    }

    close(fd);
  }
  return rc;
}


static int
is_badid(userid)
  char *userid;
{
  int ch;
  char *str;

  if (strlen(userid) < 2)
    return 1;

  if (!is_alpha(*userid))
    return 1;

  if (!str_cmp(userid, "new"))
    return 1;

  str = userid;
  while (ch = *(++str))
  {
    if (!is_alnum(ch))
      return 1;
  }
  return (belong("etc/badid", userid));
}


static int
is_fitid(userid)
  char *userid;
{
  char buf[80];

  if (is_badid(userid))
    msg_quit("�L�k�����o�ӥN���A�Шϥέ^��r���A�åB���n�]�t�Ů�");

  usr_fpath(buf, userid, NULL);
  if (dashd(buf))
    msg_quit("���N���w�g���H�ϥ�");

  www_printf("OK\n");
  return 1;
}


static int 
chk_userid()			/* �ˬd�@�U�O�_���s�b���b�� */
{
  char *ptr, *userid;

#ifndef LOGINASNEW
  msg_quit("��p�I�����Ȯɰ���s�Τ���U�I");
#endif

  ptr = myWRC.query;
  userid = nextword(&ptr);

  return is_fitid(userid);
}


/* ----------------------------------------------------- */
/* �s���U�ϥΪ̱b��			                 */
/* ----------------------------------------------------- */


static int
uniq_userno(fd)
  int fd;
{
  char buf[4096];
  int userno, size;
  SCHEMA *sp;			/* record length 16 �i�㰣 4096 */

  userno = 1;

  while ((size = read(fd, buf, sizeof(buf))) > 0)
  {
    sp = (SCHEMA *) buf;
    do
    {
      if (sp->userid[0] == '\0')
      {
	lseek(fd, -size, SEEK_CUR);
	return userno;
      }
      userno++;
      size -= sizeof(SCHEMA);
      sp++;
    } while (size);
  }

  return userno;
}


static int 
acct_apply()
{
  char *ptr, *userid;

  ptr = myWRC.query;
  userid = nextword(&ptr);

  is_fitid(userid);		/* �A���ˬd */

  /* �U���}�lŪ�J���U��� */
  {
    char buf[80], *str;
    SCHEMA slot;
    int fd;

    memset(&cuser, 0, sizeof(cuser));
    memcpy(cuser.userid, userid, IDLEN);

    while (www_gets(buf, 128) > 0)	/* ����Ŧ�N���� */
    {
      str = buf + 6;
      if (!str_ncmp(buf, "PASS", 4))
	str_ncpy(cuser.passwd, genpasswd(str), PASSLEN);
      else if (!str_ncmp(buf, "NAME", 4))
	str_ncpy(cuser.username, str, 19);
      else if (!str_ncmp(buf, "RNME", 4))
	str_ncpy(cuser.realname, str, 23);
    }

    cuser.userlevel = PERM_BASIC;
    cuser.ufo = UFO_DEFAULT_NEW;
    cuser.numlogins = 1;
    cuser.money = 0;

    cuser.firstlogin = cuser.lastlogin = cuser.tcheck = slot.uptime = ap_start;
    memcpy(slot.userid, userid, IDLEN);

    fd = open(FN_SCHEMA, O_RDWR | O_CREAT, 0600);
    {
      f_exlock(fd);
      cuser.userno = uniq_userno(fd);
      write(fd, &slot, sizeof(slot));
      f_unlock(fd);
    }
    close(fd);

    /* create directory */
    usr_fpath(buf, userid, NULL);
    mkdir(buf, 0700);
    strcat(buf, "/@");
    mkdir(buf, 0700);
    usr_fpath(buf, userid, "gem");	/* itoc.010727: �ӤH��ذ� */
    mak_links(buf);		/* itoc.010924: ��֭ӤH��ذϥؿ� */
#ifdef MY_FAVORITE
    usr_fpath(buf, userid, "MF");
    mkdir(buf, 0700);
#endif


    usr_fpath(buf, userid, fn_acct);
    fd = open(buf, O_WRONLY | O_CREAT, 0600);
    write(fd, &cuser, sizeof(cuser));
    close(fd);
    /* Thor.990416: �`�N: ���|�� .ACCT���׬O0��, �ӥB�u�� @�ؿ�, �����[� */

    sprintf(buf, "%d", cuser.userno);
    blog("APPLY", buf);
  }
  www_printf("result=OK&msg=���U���\\<%s>\n", userid);
  return 1;
}


/* ----------------------------------------------------- */
/* �s�Τ�Բ�g���U��			                 */
/* ----------------------------------------------------- */


static int
register_rqst()
{
  FILE *fn;
  RFORM rform;

  acct_locate();

  if ((cuser.userlevel & PERM_VALID) || !cuser.userlevel)
    msg_quit("�z�������T�{�w�g�����A���ݶ�g�ӽЪ�");

  if (fn = fopen(FN_RUN_RFORM, "rb"))
  {
    while (fread(&rform, sizeof(RFORM), 1, fn))
    {
      if ((rform.userno == cuser.userno) &&
       !str_cmp(rform.userid, cuser.userid))
      {
	fclose(fn);
	msg_quit("�z�����U�ӽг�|�b�B�z���A�Э@�ߵ���");
      }
    }
    fclose(fn);
  }

  www_printf("result=OK&realname=%s\n", cuser.realname);
  return 1;
}


static int
u_register()
{
  FILE *fn;
  RFORM rform;
  char buf[80], *str;

  acct_locate();

  if ((cuser.userlevel & PERM_VALID) || !cuser.userlevel)
    msg_quit("�z�������T�{�w�g�����A���ݶ�g�ӽЪ�");

  if (fn = fopen(FN_RUN_RFORM, "rb"))
  {
    while (fread(&rform, sizeof(RFORM), 1, fn))
    {
      if ((rform.userno == cuser.userno) &&
	!str_cmp(rform.userid, cuser.userid))
      {
	fclose(fn);
	msg_quit("�z�����U�ӽг�|�b�B�z���A�Э@�ߵ���");
      }
    }
    fclose(fn);
  }

  /* �U���}�lŪ�J���U��� */
  memset(&rform, 0, sizeof(RFORM));
  strcpy(rform.realname, cuser.realname);
  rform.address[0] = rform.career[0] = rform.phone[0] = '\0';

  www_printf("OK\n");
  while (www_gets(buf, 128) > 0)	/* ����Ŧ�N���� */
  {
    str = buf + 6;
    if (!str_ncmp(buf, "RNME", 4))
      str_ncpy(rform.realname, str, 23);
    else if (!str_ncmp(buf, "CARE", 4))
      str_ncpy(rform.career, str, 49);
    else if (!str_ncmp(buf, "ADDR", 4))
      str_ncpy(rform.address, str, 59);
    else if (!str_ncmp(buf, "PHON", 4))
      str_ncpy(rform.phone, str, 19);
  }

  rform.userno = cuser.userno;
  strcpy(rform.userid, cuser.userid);
  time(&rform.rtime);
  rec_add(FN_RUN_RFORM, &rform, sizeof(RFORM));

  www_printf("result=OK&msg=���U��w�g�H�X~�Э@�ߵ��ԯ������f��!\n");
  return 1;
}


/* ----------------------------------------------------- */
/* �Τ�ק���U���			                 */
/* ----------------------------------------------------- */


static int 
update_rqst()			/* �ШD�ק�A��^�즳��� */
{
  acct_locate();

  www_printf("result=OK&nickname=%s&realname=%s", cuser.username, cuser.realname);
  www_printf("&numlogins=%d&numposts=%d&firstlogin=%s",
    cuser.numlogins, cuser.numposts, Ctime(&cuser.firstlogin));
  www_printf("&lastlogin=%s&lasthost=%s\n", Ctime(&cuser.lastlogin), cuser.lasthost);

  return 1;
}


static int 
u_update()			/* ��K�X�B�ʺ� */
{
  char *ptr, *passwd, buf[128];

  ptr = acct_locate();
  passwd = nextword(&ptr);
  if (chkpasswd(cuser.passwd, passwd))
    msg_quit("ERR_PASSWD");

  /* �H�W���򥻻{�� Auth */

  www_printf("OK\n");
  while (www_gets(buf, 128) > 0)	/* ����Ŧ�N���� */
  {
    ptr = buf + 6;
    if (!str_ncmp(buf, "PASS", 4))
    {
      str_ncpy(cuser.passwd, genpasswd(ptr), PASSLEN);
    }
    else if (!str_ncmp(buf, "NAME", 4))
    {
      str_ncpy(cuser.username, ptr, 19);
      strcpy(cutmp->username, cuser.username);
    }
  }
  acct_save(&cuser, ACCTSAV_UINFO);
  www_printf("result=OK&msg=�ק令�\\!\n");

  return 1;
}


/* ----------------------------------------------------- */
/* �Τ�ק�p�H�ɮ�			                 */
/* ----------------------------------------------------- */


static int 
ufile_rqst()			/* �ШD�ק�Apid, filename */
{
  char *ptr, *filename;

  ptr = acct_locate();
  filename = nextword(&ptr);

  if (*filename)
  {
    char fpath[80];

    usr_fpath(fpath, cuser.userid, filename);
    www_printf("result=OK&msg=�i�H�ק�F�A�ɮצp�U: \n\n");
    article_show(fpath);
  }
  else
  {
    www_printf("���~�A�D�k���X�ݤ覡!\n");
  }

  return 1;
}


static void
file_edit()		/* �����ɮ׽s�� */
{
  char fpath[80], buf[128];
  FILE *fp;

  www_printf("OK\n");	/* �}�l�������e */

  usr_fpath(fpath, cuser.userid, ".tmp");
  if ((fp = fopen(fpath, "w")) == NULL)
    msg_quit("�t�Τ���, �}�ɿ��~!");

  while (www_gets(buf, 128) >= 0)
  {
    if (!str_ncmp(buf, "<--FILE-END-->", 14))
      break;
    fprintf(fp, "%s\n", buf);
  }
  fclose(fp);
}


static int 
u_file()
{
  char *ptr, *filename;

  ptr = acct_locate();
  filename = nextword(&ptr);

  if (*filename)
  {
    char fpath[80], ftmp[80];

    file_edit();
    usr_fpath(fpath, cuser.userid, filename);
    usr_fpath(ftmp, cuser.userid, ".tmp");
    f_mv(ftmp, fpath);
    unlink(ftmp);
    www_printf("result=OK&msg=�ק令�\\!!&file=%s\n", filename);
  }
  else
    www_printf("���~�A�D�k���X�ݤ覡!\n");

  return 1;
}


static int 
u_setup()
{
  char *ptr;
  int ufo, ufo2;

  ptr = acct_locate();
  ufo = atoi(nextword(&ptr));	/* �� -1 ����rqst */
  if (ufo < 0)
  {
    www_printf("result=OK&ufo=%d&ufo2=%d&msg=�^��ufo�F", cuser.ufo, cutmp->ufo);	/* �Hcuser.ufo���� */
  }
  else
  {
    ufo2 = atoi(nextword(&ptr));
    cuser.ufo = ufo;
    cutmp->ufo = ufo2;
    acct_save(&cuser, ACCTSAV_UFO);
    www_printf("result=OK&msg=�ק令�\\!!\n");
  }
  return 1;
}


/* ----------------------------------------------------- */
/* �]�w E-mail address					 */
/* ----------------------------------------------------- */


static int
ban_addr(addr)
  char *addr;
{
  int i;
  char *host, *str;
  char foo[64];			/* SoC: ��m���ˬd�� email address */

  static char *invalid[] =
  {"root@", "gopher@",		/* "bbs@", "@bbs", */
    "guest@", "@ppp", "@slip", "@dial", "unknown@", "@anon.penet.fi",
    "193.64.202.3", NULL
  };

  /* SoC: �O���� email ���j�p�g */
  str_lower(foo, addr);

  for (i = 0; str = invalid[i]; i++)
  {
    if (strstr(foo, str))
      return 1;
  }

  /* check for mail.acl (lower case filter) */

  host = (char *)strchr(foo, '@');
  *host = '\0';
  /* i = acl_has(MAIL_ACLFILE, foo, host + 1); */
  /* Thor.981223: �Nbbsreg�ڵ��������} */
  i = acl_has(UNTRUST_ACLFILE, foo, host + 1);
  /* *host = '@'; */
  if (i < 0)
    TRACE("NOACL", host);
  return i > 0;
}


static int 
mail_justify()			/* hightman.011028: �q�l�l����U */
{
  char *ptr, *email, *msg;

  ptr = acct_locate();
  email = nextword(&ptr);

  msg = "E-Mail �a�}��s";

  if (not_addr(email) || ban_addr(email))
  {
    msg = "���X�檺 E-mail address";
  }
  else
  {
#ifndef EMAIL_JUSTIFY		/* hightman.011028: ����email�{�ҴN���εo�F�a? :) */
    www_printf("result=OK&msg=%s", msg);
    return 0;
#endif

#ifndef USE_SENDMAIL
    if (bsmtp(NULL, NULL, email, MQ_JUSTIFY) < 0)
#else
    if (bbs_sendmail(NULL, NULL, email, MQ_JUSTIFY) < 0)
#endif

    {
      www_printf("result=OK&msg=�����{�ҫH��L�k�H�X�A�Х��T��g E-mail address");
      return 0;
    }
    else
    {
      cuser.userlevel &= ~(PERM_VALID | PERM_POST | PERM_PAGE | PERM_CHAT);
      strcpy(cuser.email, email);
      acct_save(&cuser, ACCTSAV_ULEVEL | ACCTSAV_EMAIL);

      www_printf("result=OK&msg=%s(%s)�z�n�A�ѩ�z��s E-mail address ���]�w�A�бz�ɧ֨� [%s] �Ҧb���u�@���^�Сy�����{�ҫH��z�C", cuser.userid, cuser.username, email);
      return 1;
    }
  }
  return 1;
}


WebKeyFunc acct_cb[] =
{
  {"chk_userid", chk_userid},
  {"acct_apply", acct_apply},
  {"register_rqst", register_rqst},
  {"u_register", u_register},
  {"update_rqst", update_rqst},
  {"u_update", u_update},
  {"ufile_rqst", ufile_rqst},
  {"u_file", u_file},
  {"u_setup", u_setup},
  {"mail_justify", mail_justify},
  {NULL, NULL}
};
