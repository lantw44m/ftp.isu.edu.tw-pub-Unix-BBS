/*-------------------------------------------------------*/
/* edit.c       ( NTHU CS MapleBBS Ver 3.10 )            */
/*-------------------------------------------------------*/
/* target : simple ANSI/Chinese editor                   */
/* create : 95/03/29                                     */
/* update : 02/11/05                                     */
/*-------------------------------------------------------*/


#include "web.h"

/* ------------------------------------------------ */
/* �ި��B�z					    */
/* ------------------------------------------------ */

#define	QUOTE_CHAR	'>'

static int
is_quoted(str)
  char *str;			/* "--\n", "-- \n", "--", "-- " */
{
  if (*str == '-')
  {
    if (*++str == '-')
    {
      if (*++str == ' ')
	str++;
      if (*str == '\n')
	str++;
      if (!*str)
	return 1;
    }
  }
  return 0;
}


static int
quote_line(str, qlimit)
  char *str;
  int qlimit;			/* ���\�X�h�ި��H */
{
  int qlevel = 0;
  int ch;

  while ((ch = *str) == QUOTE_CHAR || ch == ':')
  {
    if (*(++str) == ' ')
      str++;
    if (qlevel++ >= qlimit)
      return 0;
  }
  while ((ch = *str) == ' ' || ch == '\t')
    str++;
  if (qlevel >= qlimit)
  {
    if (!memcmp(str, "�� ", 3) || !memcmp(str, "==>", 3) || 
      strstr(str, ") ����:\n"))
      return 0;
  }
  return (*str != '\n');
}


int
article_show(fpath)		/* �q�X�峹 */
  char *fpath;
{
  int fd, nbyte;
  char buf[1024];

  if ((fd = open(fpath, O_RDONLY)) >= 0)
  {
    www_cache_init();
    while ((nbyte = read(fd, buf, 1023)) > 0)
    {
      buf[nbyte] = '\0';
      www_cache_write(buf, nbyte);
    }
    close(fd);
    www_cache_refresh();
  }
  return fd;
}


/* ----------------------------------------------------- */
/* �ɮ׳B�z�GŪ�ɡB�s�ɡB���D�Bñ�W��			 */
/* ----------------------------------------------------- */


static void
article_header(fp)		/* �[�W�@��/���D */
  FILE *fp;
{
  time_t now;

  time(&now);

#ifdef HAVE_ANONYMOUS
  if ((bbstate & BRD_ANONYMOUS) && (curredit & EDIT_ANONYMOUS))
  {
    fprintf(fp, "%s %s (%s) %s %s\n",
      str_author1, "[���i�D�A]", "�q�q�ڬO�� ? ^o^", str_post1, currboard);
  }
  else
#endif
  {
    fprintf(fp, "%s %s (%s) %s %s\n", 
      str_author1, cuser.userid, cuser.username, str_post1, currboard);
  }
  fprintf(fp, "���D: %s\n�ɶ�: %s\n", ve_title, ctime(&now));


  if (!(bbstate & BRD_NOSTAT))	/* �ݪO���ǤJ�έp */
  {
    /* ���Ͳέp��� */

    struct
    {
      char author[IDLEN + 1];
      char board[IDLEN + 1];
      char title[66];
      time_t date;		/* last post's date */
      int number;		/* post number */
    }      postlog;

    char *title;

#ifdef HAVE_ANONYMOUS
    if ((bbstate & BRD_ANONYMOUS) && (curredit & EDIT_ANONYMOUS))
      strcpy(postlog.author, "[���i�D�A]");
    else
#endif
      strcpy(postlog.author, cuser.userid);

    strcpy(postlog.board, currboard);

    title = ve_title + 7;
    str_ncpy(postlog.title, str_ttl(title), sizeof(postlog.title));
    postlog.date = now;
    postlog.number = 1;

    rec_add(FN_RUN_POST, &postlog, sizeof(postlog));
  }
}


static void
article_banner(fp)		/* �[�W�ӷ����T�� */
  FILE *fp;
{
  char op;

#ifdef HAVE_ANONYMOUS
  /* Thor.980909: gc patch: �ΦW�Ҧ�����ñ�W�� */
  if (curredit & EDIT_ANONYMOUS)
    goto OUT_ve_quote;
#endif

  if (cuser.ufo & UFO_NOSIGN)	/* itoc.000320: ���ϥ�ñ�W�� */
    goto OUT_ve_quote;

  /* ñ�W�ɳB�z */
  op = cuser.signature;
  if (op >= 1  && op <= 3)
  {
    int fd;
    char *str, fpath[64], buf[10];

    sprintf(buf, "%s.%d", FN_SIGN, op);
    usr_fpath(fpath, cuser.userid, buf);
    fd = open(fpath, O_RDONLY);
    if (fd >= 0)
    {
      op = 0;
      mgets(-1);
      while ((str = mgets(fd)) && (op < MAXSIGLINES))
      {
        if (!op)
          fprintf(fp, "--\n");

        fprintf(fp, "%s\n", str);
        op++;
      }
      close(fd);
    }
  }

OUT_ve_quote:

  /* �ӷ��B�z */
  /* itoc: banner �Ф��n�W�L�T��A�ݰ_�ӷ|�Z�h�W�� */
  fprintf(fp, "\n--\n"
    "    \033[1;32m�~�w�w Origin �� \033[33;45m%s \033[37m %s \033[32;40m �� �_�`�a �w�w�q\033[m\n"
    "    \033[1;32m�q     Author �� \033[36m%s\033[m\n",
    BBSNAME, MYHOSTNAME,
#ifdef HAVE_ANONYMOUS
    (bbstate & BRD_ANONYMOUS && curredit & EDIT_ANONYMOUS && bbsmode != M_SMAIL) ? "���i�D�A��...^(OO)^" :
#endif
    fromhost);
}


void
article_edit()			/* �����峹�s�� */
{
  char buf[128];
  FILE *fp;

  www_printf("OK\n");		/* �}�l�������e */
  if (www_gets(ve_title, 80) < 7)
    msg_quit("�t�Τ���, �������D�ɵo�Ϳ��~!");

  usr_fpath(buf, cuser.userid, ".tmp");
  if (!(fp = fopen(buf, "w")))
    msg_quit("�t�Τ���, �}�ɿ��~!");

  /* �[�J���D */
  article_header(fp);

  /* �[�J���e */
  while (www_gets(buf, 128) >= 0)
  {
    if (!str_ncmp(buf, "<--POST-END-->", 14))
      break;
    fprintf(fp, "%s\n", buf);
  }

  /* �[�J�ӷ� */
  article_banner(fp);
  fclose(fp);
}


void
quote_edit(fpath, hdr)		/* �ޥΤ��s�� */
  char *fpath;
  HDR *hdr;
{
  char folder[80];
  FILE *fp;

  hdr_fpath(folder, fpath, hdr);

  if (fp = fopen(folder, "r"))
  {
    char *str, buf[256], buf2[256];

    str = buf;
    if (hdr->nick[0])
      sprintf(buf + 128, " (%s)", hdr->nick);
    else
      buf[128] = '\0';

    www_cache_init();

    sprintf(buf2, "�� �ޭz�m%s%s�n���ʨ��G\n", hdr->owner, buf + 128);
    www_cache_write(buf2, strlen(buf2));

    while (fgets(str, 256, fp) && *str != '\n')
      ;

    *str++ = QUOTE_CHAR;
    *str++ = ' ';

    while (fgets(str, 254, fp))
    {
      if (!memcmp(str, "�� ", 3))
	continue;		/* �h���� �s�զW�� */

      if (is_quoted(str))	/* "--\n" */
	break;
      if (quote_line(str, 1))
	www_cache_write(buf, strlen(buf));
    }
    fclose(fp);
    www_cache_refresh();
  }
  else
    msg_quit("���~�A�}���ɮ׿��~!");
}
