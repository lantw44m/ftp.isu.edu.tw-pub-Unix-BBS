/*-------------------------------------------------------*/
/* gem.c        ( NTHU CS MapleBBS Ver 3.10 )            */
/*-------------------------------------------------------*/
/* target : ��ذϾ\Ū�B�s��                             */
/* create : 95/03/29                                     */
/* update : 02/11/05                                     */
/*-------------------------------------------------------*/


#include "web.h"

#undef __SUPPORT_GOPHER__

extern char *err_perm;

/* ----------------------------------------------------- */
/* URL processing routines                               */
/* ----------------------------------------------------- */


#ifdef __SUPPORT_GOHPER__

#define URL_MAX_LEN     1024
#define PROXY_HOME      "net/"
#define PROXY_EXPIRE    (30 * 86400)


static void
url_parse(folder, hdr, site, path)
/* [<][>][^][v][top][bottom][index][help] */
  char *folder;
  HDR *hdr;
  char *site;
  char *path;
{
  char *str;
  int cc;

  str = hdr->xname;

  /* parse URL's site host */

  for (;;)
  {
    cc = *str++;
    if (cc == '/')
    {
      *site = '\0';
      break;
    }
    *site++ = cc;
  }

  /* parse URL's file path */

  while (cc = *str++)
  {
    *path++ = cc;
  }

  if (hdr->xmode & GEM_EXTEND)
  {
    char buf[128];

    hdr_fpath(str = buf, folder, hdr);
    cc = readlink(path, str, URL_MAX_LEN);
    path += cc;
  }

  *path = '\0';
}


static int
url_stamp(folder, hdr, utype, host, path, port, chrono)
/* [<][>][^][v][top][bottom][index][help] */
  char *folder;
  HDR *hdr;
  int utype;
  char *host;
  char *path;
  int port;
  int chrono;
{
  int ch;
  char *head, *tail;

  /* Thor: �O�d title, �쥻�i�঳�� (from gem_title()) */

  memset(hdr, 0, sizeof(HDR) - sizeof(hdr->title));

  head = hdr->xname;
  tail = head + GEM_URLEN;

  while (ch = *host++)
  {
    if (ch >= 'A' && ch <= 'Z')	/* lower case 'host' */
      ch |= 0x20;
    else if (ch == '.' && !*host)	/* remove trailing . */
      break;
    *head++ = ch;
  }
  *head++ = '/';

  if (!chrono)
    chrono = time(NULL);

  for (;;)
  {
    *head++ = ch = *path++;
    if (!ch)
      break;

    if (head >= tail)		/* extend URL format */
    {
      *head = '\0';
      head = folder = str_dup(folder, 10);
      while (ch = *head++)
      {
	if (ch == '/')
	  tail = head;
      }

      /* hierarchy */

      if (*tail == '.')
      {
	head = tail++;
	*tail++ = '/';
      }
      else
      {
	head = tail - 2;
      }

      *tail++ = 'X';

      for (;;)
      {
	*head = radix32[chrono & 31];
	archiv32(chrono, tail);
	if (!symlink(path, folder))
	{
	  utype |= GEM_EXTEND;
	  break;
	}

	if (errno != EEXIST)
	  return 0;

	chrono++;
      }

      free(folder);
      break;
    }
  }

  hdr->chrono = chrono;
  hdr->xmode = utype;
  hdr->xid = port;

  return ++chrono;
}


/*-------------------------------------------------------*/
/* GOPHER (URL) routines                                 */
/*-------------------------------------------------------*/


static int
url_open(site, path, port)
/* [<][>][^][v][top][bottom][index][help] */
  char *site;
  char *path;
  int port;
{
  int sock;
  /* Thor.980707: ���� site�|��ip�X�{, �n�b dns_open���B�zor�~�B�z? */
  sock = dns_open(site, port);
  if (sock >= 0)
  {
    port = strlen(path);
    site = path + port;
    *site = '\n';
    port++;
    if (send(sock, path, port, 0) != port)
    {
      close(sock);
      sock = -1;
    }
    *site = '\0';
  }

  return sock;
}


static char *
go_field(str)
/* [<][>][^][v][top][bottom][index][help] */
  char *str;
{
  int cc;

  for (;;)
  {
    cc = *str;
    if (cc == '\t')
    {
      *str++ = '\0';
      return str;
    }
    if (!cc)
    {
      return NULL;
    }
    str++;
  }
}


static int
url_fpath(fpath, folder, hdr)
/* [<][>][^][v][top][bottom][index][help] */
  char *fpath;
  char *folder;
  HDR *hdr;
{
  int fd, gtype;
  time_t now;
  FILE *fp;
  char *xsite, *xpath, *ptr, *str, site[64], path[URL_MAX_LEN];
  struct stat st;

  /* --------------------------------------------------- */
  /* parse the URL                                       */
  /* --------------------------------------------------- */

  url_parse(folder, hdr, xsite = site, xpath = path);
  gtype = (*xpath == '0') ? 'A' : 'F';

  strcpy(fpath, PROXY_HOME);
  str = fpath + sizeof(PROXY_HOME) - 2;

  /* --------------------------------------------------- */
  /* host : make directory hierarchy                     */
  /* --------------------------------------------------- */

  ptr = xsite;
  do
  {
    fd = *ptr++;

    /* remove trailing [.edu.tw] */

    if (fd == '.' && !str_cmp(ptr, "edu.tw"))
      fd = 0;

    *++str = fd;
  } while (fd);

  mak_dirs(fpath);

  /* --------------------------------------------------- */
  /* path : generate (unique ?) filename by hashing      */
  /* --------------------------------------------------- */

  *str++ = '/';
  folder = str;
  *++str = '/';
  *++str = gtype;
  archiv32(hash32(xpath), ++str);
  *folder = str[6];

  /* --------------------------------------------------- */
  /* check proxy cache first                             */
  /* --------------------------------------------------- */

  now = time(0);
  if (!stat(fpath, &st))
  {
    if (S_ISREG(st.st_mode) && (st.st_mtime > now - PROXY_EXPIRE))
      return 0;
    unlink(fpath);
  }

  /* --------------------------------------------------- */
  /* well, fetch it from network                         */
  /* --------------------------------------------------- */

  www_printf("�� �إ� proxy ��Ƴs�u�� \033[5m...\033[m");

  fd = url_open(xsite, xpath, hdr->xid);
  if (fd < 0)
  {
    www_printf("�� �L�k�إ߳s�u�A�еy��A�աA�ά� SYSOP");
    return fd;
  }

  fp = fopen(fpath, "w");
  if (gtype == 'A')
  {
    st.st_mtime = now;
    fprintf(fp, "�@��: %s\n���D: %s\n�ɶ�: (%s) %s\n",
      xpath, hdr->title, xsite, ctime(&st.st_mtime));
    hdr = NULL;
  }
  else
  {
    hdr = (HDR *) xpath;	/* ie. path[], �ɨӤ@�� */
  }

  mgets(-1);

  while (str = mgets(fd))
  {
    gtype = *str;
    if (gtype == '.' && str[1] == '\0')
      break;

    if (hdr)
    {
      if (gtype == '0')
	gtype = GEM_GOPHER;
      else if (gtype == '1')
	gtype = GEM_GOPHER | GEM_FOLDER;
      else
	continue;

      if (!(xpath = go_field(++str)))
	continue;

      if (!(xsite = go_field(xpath)))
	continue;

      if (!(ptr = go_field(xsite)))
	continue;

      now = url_stamp(fpath, hdr, gtype, xsite, xpath, atoi(ptr), now);
      if (now <= 0)
	break;

      /* ----------------------------------------------- */
      /* �B�z title �����S���r��G�������� ...           */
      /* ----------------------------------------------- */

      if (*str == (char)0xa1 && str[2] == ' ' &&
	(str[1] == (char)0xba || str[1] == (char)0xbb ||
	  str[1] == (char)0xbc || str[1] == (char)0xbd))
	str += 3;

      str_ncpy(hdr->title, str, TTLEN);
      fwrite(hdr, sizeof(HDR), 1, fp);
    }
    else
    {
      fputs(str, fp);
      fputc('\n', fp);
    }
  }

  close(fd);
  fclose(fp);
  return 0;
}
#endif				/* __SUPPORT_GOPHER__ */


/* ------------------------------------------ */

static int gem_init();

static void
XoGem(folder, page, level)
  char *folder;
  int page;
  int level;
{
  SXO *xo;

  xo = xo_new(folder);
  xo->page = page;
  xo->key = level;

  gem_init(xo);
  free(xo);
}


/* ----------------------------------------------------- */
/* gem_check : attribute / permission check out          */
/* ----------------------------------------------------- */


#define GEM_READ        1	/* readable */
#define GEM_WRITE       2	/* writable */
#define GEM_FILE        4	/* �w���O�ɮ� */

static int
check_level(fpath)
  char *fpath;
{
  usint bits = 0;
  int level = 0;

  if (!strncmp(fpath, "gem/brd/", 8))	/* �O�ݪO */
  {
    BRD *brd;
    extern BCACHE *bshm;
    int bno;
    char *qtr;
    char buf[80];

    strcpy(buf, fpath + 8);
    qtr = strchr(buf, '/');
    *qtr = '\0';

    strcpy(currboard, buf);
    bshm_init();

    bno = brd_bno(buf);

    if (bno >= 0)		/* �s�b���� */
    {
      brd = bshm->bcache + bno;

      bits = Ben_Perm(brd, cuser.userlevel);
      strcpy(currBM, brd->BM);
      if (!(bits & BRD_R_BIT))
	msg_quit(err_perm);
    }
  }

  level = (HAS_PERM(PERM_SYSOP) ? GEM_SYSOP : GEM_USER);
  if ((bits & BRD_X_BIT) && !HAS_PERM(PERM_SYSOP))
    level = GEM_MANAGER;

  return level;
}


static HDR *
gem_check(xo, fpath, op)
  SXO *xo;
  char *fpath;
  int op;
{
  HDR *ghdr;
  int gtype, level, pos;
  char *folder;

  level = xo->key;

  if ((op & GEM_WRITE) && (level <= GEM_USER))
    return NULL;

  pos = xo->top - 1;
  folder = xo->dir;

  ghdr = (HDR *) malloc(sizeof(HDR));	/* �[�Wmalloc */
  rec_get(folder, ghdr, sizeof(HDR), pos);

  gtype = ghdr->xmode;

  if ((gtype & GEM_RESTRICT) && (level <= GEM_USER))
    return NULL;

  if ((op & GEM_FILE) && (gtype & GEM_FOLDER))
    return NULL;

  if (gtype & GEM_BOARD)
  {
    sprintf(fpath, "gem/brd/%s/.DIR", ghdr->xname);
  }
  else
  {
    if (gtype & GEM_GOPHER)
    {
#ifdef __SUPPORT_GOPHER__
      if (url_fpath(fpath, folder, ghdr))
	return NULL;
#else
      return NULL;
#endif
    }
    else
    {
      hdr_fpath(fpath, folder, ghdr);
    }
  }

  return ghdr;
}


static int
gem_browse()			/* �ǤJ �W��path, num, [page] */
{
  char *ptr, *fpath;
  int num, page;

  ptr = acct_locate();
  fpath = nextword(&ptr);

  num = atoi(nextword(&ptr));
  if (num < 1)
    num = 1;

  page = atoi(nextword(&ptr));	/* ���@�w���� ^-^ */

  {
    SXO xo;
    char folder[80];
    HDR *ghdr;
    int op, xmode;

    memset(&xo, 0, sizeof(SXO));
    strcpy(xo.dir, fpath);
    xo.page = page;
    xo.top = num;
    xo.key = check_level(fpath);

    op = GEM_READ;

    ghdr = gem_check(&xo, folder, op);

    if (ghdr == NULL)
      msg_quit(err_perm);

    xmode = ghdr->xmode;

    if (xmode & GEM_FOLDER)
    {
      op = xo.key;
      if (xmode & GEM_BOARD)
      {
	if (HAS_PERM(PERM_SYSOP))
	  op = GEM_SYSOP;
	else if (op | GEM_MANAGER)
	  op = GEM_MANAGER;
	else
	  op = GEM_USER;
      }
      else if (xmode & GEM_URL)
      {
	op = GEM_VISIT;
      }

      strcpy(currtitle, ghdr->title);
      XoGem(folder, page, op);
    }
    else
    {
      int max;
      max = rec_num(xo.dir, sizeof(HDR));
      www_printf("result=OK&title=%s&max=%d\n", ghdr->title, max);
      article_show(folder);
    }
    free(ghdr);			/* free����~ */
  }
  return 1;
}


/* ------------------------------------------------------ */
/* ��ذϤ�main page�G				     	  */
/* ------------------------------------------------------ */


static void
gem_item(num, ghdr)
  int num;
  HDR *ghdr;
{
  int xmode;

  /* ������������������ : A1B7 ... */
  xmode = ghdr->xmode;

  www_printf("num=%d&strict=%d&gtype=%d&title=%s&owner=%s&date=%s\n",
    num, xmode & GEM_RESTRICT ? 1 : 0, xmode & GEM_FOLDER ? 1 : 0, ghdr->title, ghdr->owner, ghdr->date);
  /* hightman: �ĥΩT�w���榡�a */
}


static int
gem_body(xo)
  SXO *xo;
{
  HDR *ghdr;
  int num, max, tail;

  max = xo->max;
  if (max <= 0)
  {
    www_printf("����ذϡ��|�b�l���Ѧa��������� :)\n");
    return 0;
  }

  www_printf("result=OK&fpath=%s&max=%d&title=%s&BM=%s\n", xo->dir, max, currtitle, currBM);
  ghdr = (HDR *) xo_pool;
  num = xo->top;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  do
  {
    gem_item(++num, ghdr++);
  } while (num < max);

  return XO_NONE;
}


static int
gem_init(xo)
  SXO *xo;
{
  xo_load(xo, sizeof(HDR));
  return gem_body(xo);
}


static int
gem_main()			/* �ǤJ: page: */
{
  char *ptr, *fpath;
  int page;
  SXO *xo;

  ptr = acct_locate();
  fpath = nextword(&ptr);
  if (!*fpath)
    fpath = "gem/.DIR";

  page = atoi(nextword(&ptr));

  xo = xo_new(fpath);
  xo->page = page;
  xo->key = check_level(fpath);
  strcpy(currtitle, "������ذ�");

  gem_init(xo);

  free(xo);

  return 1;

}


/* ----------------------------------------------------	 */
/* ��H���						 */
/* ----------------------------------------------------	 */


static int
gem_forward()			/* pid, fpath, num, rcpt */
{
  char *ptr, *fpath, *rcpt;
  int num;

  ptr = acct_locate();
  fpath = nextword(&ptr);
  num = atoi(nextword(&ptr));
  if (num < 1)
    num = 1;

  rcpt = nextword(&ptr);

  {
    SXO xo;
    char folder[80], xpath[80], *userid;
    HDR *ghdr;
    int userno, xmode, method;

    memset(&xo, 0, sizeof(SXO));
    strcpy(xo.dir, fpath);
    xo.top = num;
    xo.key = check_level(fpath);

    userno = GEM_READ;

    ghdr = gem_check(&xo, folder, userno);

    if (ghdr == NULL)
      msg_quit(err_perm);

    xmode = ghdr->xmode;

    if (xmode & (GEM_FOLDER | GEM_RESTRICT))
      msg_quit("���ɮפ�����H!!");

    userid = cuser.userid;
    userno = 0;
    /* �Ѧ� struct.h �� MQ_UUENCODE / MQ_JUSTIFY */
#define MF_SELF 0x04
#define MF_USER 0x08

    if (!mail_external(rcpt))	/* ���~�d�I */
    {
      if (!str_cmp(rcpt, userid))
      {
	method = MF_SELF;
      }
      else
      {
	if ((userno = acct_userno(rcpt)) <= 0)
	{
	  msg_quit("���W�S���ӨϥΪ�!");
	}
	method = MF_USER;
      }
      usr_fpath(xpath, rcpt, fn_dir);
    }
    else
    {
      if (not_addr(rcpt))
	msg_quit("�����T���l��a�}!");
      method = 0;
    }

    if (method >= MF_SELF)
    {
      HDR mhdr;

      if (hdr_stamp(xpath, HDR_LINK, &mhdr, folder) < 0)
	msg_quit("��H����!!!");

      if (method == MF_SELF)
      {
	strcpy(mhdr.owner, "[�� �� ��]");
	mhdr.xmode = MAIL_READ | MAIL_NOREPLY;
      }
      else
      {
	strcpy(mhdr.owner, userid);
      }
      strcpy(mhdr.nick, cuser.username);
      strcpy(mhdr.title, ghdr->title);
      if (rec_add(xpath, &mhdr, sizeof(HDR)) < 0)
	msg_quit("��H����!!!!");
    }
    else
    {
      int rc;

#ifdef USE_SENDMAIL
      rc = bbs_sendmail(folder, ghdr->title, rcpt, 0);
#else
      rc = bsmtp(folder, ghdr->title, rcpt, 0);
#endif

      if (rc < 0)
	msg_quit("�H��L�k�H�F!!!");
    }

#undef  MF_SELF
#undef  MF_USER
    if (userno > 0)
      m_biff(userno);

    www_printf("result=OK&msg=���\\�N�ɮױH��<%s>", rcpt);

    free(ghdr);			/* free����~ */
  }

  return 1;
}


WebKeyFunc gem_cb[] =
{
  {"gem_main", gem_main},
  {"gem_browse", gem_browse},
  {"gem_forward", gem_forward},
  {NULL, NULL}
};
