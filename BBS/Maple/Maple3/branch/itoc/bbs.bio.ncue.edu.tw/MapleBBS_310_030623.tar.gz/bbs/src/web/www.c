/*-------------------------------------------------------*/
/* www.c      ( NTHU CS MapleBBS Ver 3.10 )              */
/*-------------------------------------------------------*/
/* target : Some Functions Only for WWW version		 */
/* author : hightman.bbs@bbs.dot66.net			 */
/* create : 01/09/20                                     */
/* update : 02/11/05                                     */
/*-------------------------------------------------------*/


#include <varargs.h>

#include "web.h"

extern UCACHE *ushm;

/* ----------------------------------------------------- */
/* Loign LOG                                             */
/* ----------------------------------------------------- */

void
blog(mode, msg)
  char *mode, *msg;
{
  char buf[512], data[256];
  time_t now;

  time(&now);
  if (!msg)
  {
    msg = data;
    sprintf(data, "Stay: %d (%d)", (now - ap_start) / 60, currpid);
  }

  sprintf(buf, "%s %s %-13s%s\n", Etime(&now), mode, cuser.userid, msg);
  f_cat(FN_RUN_USIES, buf);
}


/* ----------------------------------------------------- */
/* Leave BBS                                             */
/* ----------------------------------------------------- */

static void
ReleaseSocket()
{
  shutdown(0, 2);
  shutdown(1, 2);
}


void
user_save()
{
  blog("AXXED", NULL);

#ifdef LOG_BMW			/* lkchu.981201: �i�b config.h �]�w */
  bmw_save();			/* lkchu.981201: ���T�O���B�z */
#endif

  if (time(&cuser.lastlogin) - ap_start >= 60)
    acct_save(&cuser, ACCTSAV_LOGIN);
}


void
abort_bbs()
{
  if (bbstate & STAT_STARTED)
  {
    user_save();
    utmp_free();
  }
  ReleaseSocket();
  exit(0);
}


void
msg_quit(msg)
  char *msg;
{
  bbstate = 0;
  www_printf("%s\n", msg);
  abort_bbs();
}


/* ----------------------------------------------------- */
/* Web Request Command                                   */
/* ----------------------------------------------------- */


static int
IsSplitChar(ch)
  int ch;
{
  return (ch == '\t' || ch == KEY_ENTER || ch == ' ');
}


char *				/* �^�� head */
nextword(str)
  char **str;			/* �̫� str �令 nextword */
{
  char *head, *tail;
  int ch;

  head = *str;
  for (;;)
  {
    ch = *head;
    if (!ch)
    {
      *str = head;
      return head;
    }
    if (!IsSplitChar(ch))
      break;
    head++;
  }

  tail = head + 1;
  while (ch = *tail)
  {
    if (IsSplitChar(ch))
    {
      *tail++ = '\0';
      break;
    }
    tail++;
  }
  *str = tail;

  return head;
}


/* ----------------------------------------------------- */
/* more ������                                           */
/* ----------------------------------------------------- */


#define MORE_BUFSIZE    4096

static uschar more_pool[MORE_BUFSIZE];
static int more_base, more_size;


char *
mgets(fd)
  int fd;
{
  char *pool, *base, *head, *tail;
  int ch;

  if (fd < 0)
  {
    more_base = more_size = 0;
    return NULL;
  }

  pool = more_pool;
  base = pool + more_base;
  tail = pool + more_size;
  head = base;

  for (;;)
  {
    if (head >= tail)
    {
      if (ch = head - base)
	memcpy(pool, base, ch);

      head = pool + ch;
      ch = read(fd, head, MORE_BUFSIZE - ch);

      if (ch <= 0)
	return NULL;

      base = pool;
      tail = head + ch;
      more_size = tail - pool;
    }

    ch = *head;

    if (ch == '\n')
    {
      *head++ = '\0';
      more_base = head - pool;
      return base;
    }

    if (ch == '\r')
      *head = '\0';

    head++;
  }
}



void *
mread(fd, len)
  int fd, len;
{
  char *pool;
  int base, size;

  base = more_base;
  size = more_size;
  pool = more_pool;

  if (size < len)
  {
    if (size)
    {
      memcpy(pool, pool + base, size);
    }

    base = read(fd, pool + size, MORE_BUFSIZE - size);

    if (base <= 0)
      return NULL;

    size += base;
    base = 0;
  }

  more_base = base + len;
  more_size = size - len;

  return pool + base;
}


/* ----------------------------------------------------- */
/* webIO ������                                          */
/* ----------------------------------------------------- */


static char www_cache[MAX_CACHE_SIZE];
static int www_cache_count;


static int
www_write(buf, nbyte)
  char *buf;
  int nbyte;
{
  int count, relwrite;

  count = 0;
  while (count < nbyte)		/* ���Τ@�`�@�`���g�a */
  {
    relwrite = write(1, &buf[count], nbyte - count);
    if (relwrite < 0 && errno != EINTR)	/* �D���_���~ */
      abort_bbs();
    else
      count += relwrite;
  }

  return count;
}


int
www_gets(buf, maxlen)
  char *buf;
  int maxlen;
{
  int i, j;
  char c;

  i = 0;
  maxlen--;
  while (i < maxlen)
  {

    j = read(0, &c, 1);
    if (j < 0)
      return -2;
    else if (c == '\n')
      break;
    else if (c != '\r')
      buf[i++] = c;
  }
  buf[i] = '\0';
  return i;
}


int
www_printf(va_alist)
va_dcl
{
  va_list args;
  char *format;
  int len;
  int ret = 0;
  char printstr[MAX_BUF_SIZE];

  va_start(args);
  format = va_arg(args, char *);
  vsprintf(printstr, format, args);
  va_end(args);

  len = strlen(printstr);
  if (len > 0)
    ret = www_write(printstr, len);
  return ret;
}


void
www_cache_init()
{
  www_cache_count = 0;
  memset(www_cache, 0, MAX_CACHE_SIZE);
}


int
www_cache_write(buf, buflen)
  char *buf;
  int buflen;
{
  if (MAX_CACHE_SIZE - www_cache_count < buflen)
    www_cache_refresh();

  if (buflen > MAX_CACHE_SIZE)
    return -1;

  memcpy(&www_cache[www_cache_count], buf, buflen);
  www_cache_count += buflen;
}


void
www_cache_refresh()
{
  if (www_cache_count == 0)
    return;
  www_write(www_cache, www_cache_count);
  www_cache_count = 0;
}
