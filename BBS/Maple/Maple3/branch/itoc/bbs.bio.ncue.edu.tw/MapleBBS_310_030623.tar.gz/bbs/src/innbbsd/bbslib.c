/*-------------------------------------------------------*/
/* bbslib.c	( NTHU CS MapleBBS Ver 3.10 )		 */
/*-------------------------------------------------------*/
/* target : innbbsd library				 */
/* create : 95/04/27					 */
/* update :   /  /  					 */
/* author : skhuang@csie.nctu.edu.tw			 */
/*-------------------------------------------------------*/


#include "innbbsconf.h"
#include "bbslib.h"
#include <varargs.h>

#ifdef _NoCeM_
#include "nocem.h"
#endif


/* ----------------------------------------------------- */
/* read bbsname.bbs					 */
/* ----------------------------------------------------- */


char MYBBSID[32];


static int		/* 0:success  -1:fail */
readnamefile()
{
  FILE *fp;

  MYBBSID[0] = '\0';
  if (fp = fopen("innd/bbsname.bbs", "r"))
  {
    while (fscanf(fp, "%s", MYBBSID) != EOF)
      ;
    fclose(fp);
    if (strlen(MYBBSID) >= 2)	/* �ܤ֭n�G�Ӧr */
      return 0;
  }
  return -1;
}


/* ----------------------------------------------------- */
/* read nodelist.bbs					 */
/* ----------------------------------------------------- */


int NLCOUNT;
nodelist_t *NODELIST = NULL;


int
nl_bynodecmp(a, b)
  nodelist_t *a, *b;
{
  return strcasecmp(a->node, b->node);
}


static int		/* 0:success  -1:fail */
readnlfile()
{
  FILE *fp;
  char buff[1024];
  struct stat st;
  register int i, count;
  register char *ptr, *nodelistptr;
  static lastcount = 0;
  static char *NODELIST_BUF = NULL;

  if (!(fp = fopen("innd/nodelist.bbs", "r")))
    return -1;
  if (fstat(fileno(fp), &st) != 0)
    return -1;

  i = st.st_size + 1;
  if (NODELIST_BUF == NULL)
  {
    NODELIST_BUF = (char *) malloc(i);
  }
  else
  {
    NODELIST_BUF = (char *) realloc(NODELIST_BUF, i);
  }

  i = count = 0;
  while (fgets(buff, sizeof(buff), fp))
  {
    if (buff[0] != '#' && buff[0] != '\n')
    {
      strcpy(NODELIST_BUF + i, buff);
      i += strlen(buff);
      count++;
    }
  }
  fclose(fp);

  i = sizeof(nodelist_t) * (count + 1);
  if (NODELIST == NULL)
  {
    NODELIST = (nodelist_t *) malloc(i);
  }
  else
  {
    NODELIST = (nodelist_t *) realloc(NODELIST, i);
  }
  for (i = lastcount; i < count; i++)
  {
    NODELIST[i].feedfp = NULL;
  }

  lastcount = count;
  NLCOUNT = 0;

  for (ptr = NODELIST_BUF; nodelistptr = (char *) strchr(ptr, '\n'); ptr = nodelistptr + 1)
  {
    register char *nptr;

    *nodelistptr = '\0';
    NODELIST[NLCOUNT].node = "";
    NODELIST[NLCOUNT].host = "";
    NODELIST[NLCOUNT].protocol = "";
    NODELIST[NLCOUNT].comment = "";

    /* ���T�� nodelist.bbs �榡 */
    /* Maple           bbs.cs.nthu.edu.tw      POST(119)       �����毸\n */
    /* node            host                    protocol        comment    */

    /* �Ĥ@��GNODELIST[NLCOUNT].node */
    for (nptr = ptr; (i = *nptr) && isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    NODELIST[NLCOUNT].node = nptr;
    for (nptr++; (i = *nptr) && !isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    *nptr = '\0';

    /* �ĤG��GNODELIST[NLCOUNT].host */
    for (nptr++; (i = *nptr) && isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    NODELIST[NLCOUNT].host = nptr;
    for (nptr++; (i = *nptr) && !isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    *nptr = '\0';

    /* �ĤT��GNODELIST[NLCOUNT].protocol */
    for (nptr++; (i = *nptr) && isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    NODELIST[NLCOUNT].protocol = nptr;
    for (nptr++; (i = *nptr) && !isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    *nptr = '\0';

    /* �ĥ|��GNODELIST[NLCOUNT].comment */
    for (nptr++; (i = *nptr) && isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    NODELIST[NLCOUNT].comment = nptr;

    /* �즹���\�aŪ�����o�� */
    NLCOUNT++;
  }

  /* �N NODELIST[] �� node �ƧǡA����b search_nodelist_bynode() �i�H��֤@�I */
  qsort(NODELIST, NLCOUNT, sizeof(nodelist_t), nl_bynodecmp);
  return 0;
}


/* ----------------------------------------------------- */
/* read newsfeeds.bbs					 */
/* ----------------------------------------------------- */


int NFCOUNT;
newsfeeds_t *NEWSFEEDS = NULL;
newsfeeds_t **NEWSFEEDS_BYBOARD = NULL;


int
nf_bygroupcmp(a, b)
  newsfeeds_t *a, *b;
{
  return strcasecmp(a->newsgroups, b->newsgroups);
}


int
nf_byboardcmp(a, b)
  newsfeeds_t **a, **b;
{
  return strcasecmp((*a)->board, (*b)->board);
}


static int		/* 0:success  -1:fail */
readnffile()
{
  FILE *fp;
  char buff[1024];
  struct stat st;
  register int i, count;
  register char *ptr, *newsfeedsptr;
  static char *NEWSFEEDS_BUF = NULL;

  if (!(fp = fopen("innd/newsfeeds.bbs", "r")))
    return -1;
  if (fstat(fileno(fp), &st) != 0)
    return -1;

  i = st.st_size + 1;
  if (NEWSFEEDS_BUF == NULL)
  {
    NEWSFEEDS_BUF = (char *) malloc(i);
  }
  else
  {
    NEWSFEEDS_BUF = (char *) realloc(NEWSFEEDS_BUF, i);
  }

  i = count = 0;
  while (fgets(buff, sizeof(buff), fp) != NULL)
  {
    if (buff[0] != '#' && buff[0] != '\n')
    {
      strcpy(NEWSFEEDS_BUF + i, buff);
      i += strlen(buff);
      count++;
    }
  }
  fclose(fp);

  i = sizeof(newsfeeds_t) * (count + 1);
  if (NEWSFEEDS == NULL)
  {
    NEWSFEEDS = (newsfeeds_t *) malloc(i);
    NEWSFEEDS_BYBOARD = (newsfeeds_t **) malloc(i);
  }
  else
  {
    NEWSFEEDS = (newsfeeds_t *) realloc(NEWSFEEDS, i);
    NEWSFEEDS_BYBOARD = (newsfeeds_t **) realloc(NEWSFEEDS_BYBOARD, i);
  }

  NFCOUNT = 0;

  for (ptr = NEWSFEEDS_BUF; newsfeedsptr = (char *) strchr(ptr, '\n'); ptr = newsfeedsptr + 1)
  {
    register char *nptr;

    *newsfeedsptr = '\0';
    NEWSFEEDS[NFCOUNT].newsgroups = "";
    NEWSFEEDS[NFCOUNT].board = "";
    NEWSFEEDS[NFCOUNT].path = NULL;
    NEWSFEEDS_BYBOARD[NFCOUNT] = NEWSFEEDS + NFCOUNT;

    /* ���T�� newsfeeds.bbs �榡 */
    /* nthu.cs.bbs.plan                plan            Maple    big5\n */
    /* newsgroups                      board           path     charset */

    /* �Ĥ@��GNEWSFEEDS[NFCOUNT].newsgroups */
    for (nptr = ptr; (i = *nptr) && isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    NEWSFEEDS[NFCOUNT].newsgroups = nptr;
    for (nptr++; (i = *nptr) && !isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    *nptr = '\0';

    /* �ĤG��GNEWSFEEDS[NFCOUNT].board */
    for (nptr++; (i = *nptr) && isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    NEWSFEEDS[NFCOUNT].board = nptr;
    for (nptr++; (i = *nptr) && !isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    *nptr = '\0';

    /* �ĤT��GNEWSFEEDS[NFCOUNT].path */
    for (nptr++; (i = *nptr) && isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    NEWSFEEDS[NFCOUNT].path = nptr;
    for (nptr++; (i = *nptr) && !isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    *nptr = '\0';

    /* �ĥ|��GNEWSFEEDS[NFCOUNT].charset */
    for (nptr++; (i = *nptr) && isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    NEWSFEEDS[NFCOUNT].charset = nptr;

    /* �즹���\�aŪ�����o�� */
    NFCOUNT++;
  }

  /* �N NEWSFEEDS[] �� group �ƧǡA����b search_newsfeeds_bygroup() �i�H��֤@�I */
  qsort(NEWSFEEDS, NFCOUNT, sizeof(newsfeeds_t), nf_bygroupcmp);
  /* �N NEWSFEEDS[] �� board �ƧǡA����b search_newsfeeds_byboard() �i�H��֤@�I */
  qsort(NEWSFEEDS_BYBOARD, NFCOUNT, sizeof(newsfeeds_t *), nf_byboardcmp);

  return 0;
}


#ifdef _NoCeM_
/* ----------------------------------------------------- */
/* read ncmperm.bbs					 */
/* ----------------------------------------------------- */


ncmperm_t *NCMPERM = NULL;
int NCMCOUNT = 0;


int			/* 0:success  -1:fail */
readNCMfile()
{
  FILE *fp;
  char buff[1024];
  struct stat st;
  int i, count;
  char *ptr, *ncmpermptr;
  static char *NCMPERM_BUF;

  if (!(fp = fopen("innd/ncmperm.bbs", "r")))
    return -1;
  if (fstat(fileno(fp), &st) != 0)
    return -1;

  i = st.st_size + 1;
  if (NCMPERM_BUF == NULL)
  {
    NCMPERM_BUF = (char *) malloc(i);
  }
  else
  {
    NCMPERM_BUF = (char *) realloc(NCMPERM_BUF, i);
  }

  i = count = 0;
  while (fgets(buff, sizeof(buff), fp) != NULL)
  {
    if (buff[0] == '#')
      continue;
    if (buff[0] == '\n')
      continue;
    strcpy(NCMPERM_BUF + i, buff);
    i += strlen(buff);
    count++;
  }
  fclose(fp);

  if (NCMPERM == NULL)
  {
    NCMPERM = (ncmperm_t *) malloc(sizeof(ncmperm_t) * (count + 1));
  }
  else
  {
    NCMPERM = (ncmperm_t *) realloc(NCMPERM, sizeof(ncmperm_t) * (count + 1));
  }

  NCMCOUNT = 0;

  for (ptr = NCMPERM_BUF; (ncmpermptr = (char *) strchr(ptr, '\n')) != NULL; ptr = ncmpermptr + 1)
  {
    char *nptr;

    *ncmpermptr = '\0';
    NCMPERM[NCMCOUNT].issuer = "";
    NCMPERM[NCMCOUNT].type = "";
    NCMPERM[NCMCOUNT].perm = 0;

    /* ���T�� ncmperm.bbs �榡 */
    /* news@news.math.nctu.edu.tw       spam    yes\n */
    /* issuer                           type    perm*/

    /* �Ĥ@��GNCMPERM[NCMCOUNT].issuer */
    for (nptr = ptr; (i = *nptr) && isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    NCMPERM[NCMCOUNT].issuer = nptr;
    for (nptr++; (i = *nptr) && !isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    *nptr = '\0';

    /* �ĤG��GNCMPERM[NCMCOUNT].spam */
    for (nptr++; (i = *nptr) && isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    NCMPERM[NCMCOUNT].type = nptr;
    for (nptr++; (i = *nptr) && !isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    *nptr = '\0';

    /* �ĤT��GNCMPERM[NCMCOUNT].perm */
    for (nptr++; (i = *nptr) && isspace(i);)
      nptr++;
    if (*nptr == '\0')
      return -1;
    NCMPERM[NCMCOUNT].perm = (*nptr == 'y');

    /* �즹���\�aŪ�����o�� */
    NCMCOUNT++;
  }

  return 0;
}
#endif	/* _NoCeM_ */


/* ----------------------------------------------------- */
/* initail INNBBSD					 */
/* ----------------------------------------------------- */


int			/* 1:success  0:failure */
initial_bbs()
{
  chdir(BBSHOME);		/* chdir to bbs_home first */

  /* ���J MYBBSID */
  if (readnamefile() != 0)
  {
    fprintf(stderr, "���ˬd bbsname.bbs�AMYBBSID �ܤ֭n�G�Ӧr��\n");
    return 0;
  }

  /* ���J nodelist.bbs */
  if (readnlfile() != 0)
  {
    fprintf(stderr, "���ˬd nodelist.bbs�A�̭�����줣����\n");
    return 0;
  }

  /* ���J newsfeeds.bbs */
  if (readnffile() != 0)
  {
    fprintf(stderr, "���ˬd newsfeeds.bbs�A�̭�����줣����\n");
    return 0;
  }

#ifdef _NoCeM_
  /* ���J ncmperm.bbs */
  if (readNCMfile() != 0)
  {
    fprintf(stderr, "���ˬd ncmperm.bbs�A�̭�����줣����\n");
    return 0;
  }
#endif

  return 1;
}
