#!/bin/sh
# lynx �����|�Цۦ��A�q�`�O /bin/lynx �� /usr/local/bin/lynx
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W041.txt > gem/@/@W41
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W031.txt > gem/@/@W31
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W001.txt > gem/@/@W01
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W002.txt > gem/@/@W02
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W003.txt > gem/@/@W03
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W016.txt > gem/@/@W16
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W020.txt > gem/@/@W20
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W042.txt > gem/@/@W42
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W043.txt > gem/@/@W43
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W010.txt > gem/@/@W10
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W018.txt > gem/@/@W18
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W011.txt > gem/@/@W11
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W012.txt > gem/@/@W12
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W044.txt > gem/@/@W44
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W015.txt > gem/@/@W15
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W014.txt > gem/@/@W14
/usr/local/bin/lynx --source ftp://ftpsv.cwb.gov.tw/pub/forecast/W032.txt > gem/@/@W32
