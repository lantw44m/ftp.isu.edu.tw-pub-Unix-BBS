/*-------------------------------------------------------*/
/* web.h	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : all header files			 	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#ifndef	_WEB_H_
#define	_WEB_H_


#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <errno.h>
#include <string.h>
#include <dirent.h>
#include <time.h>
#include <sgtty.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <sys/time.h>


/* ----------------------------------------------------- */
/* �M bbsd �ۦP��                                        */
/* ----------------------------------------------------- */


#define TRACE	blog


#define dashd(fpath)	S_ISDIR(f_mode(fpath))
#define dashf(fpath)	S_ISREG(f_mode(fpath))


#define STR4(x)		((x[0] << 24) + (x[1] << 16) + (x[2] << 8) + x[3])
		/* Thor.980913: �O��precedence */


/* Flags to getdata input function */
#define NOECHO		0x0000		/* ����ܡA�Ω�K�X���o */
#define DOECHO		0x0100		/* �@����� */
#define LCECHO		0x0200		/* low case echo�A�����p�g */
#define GCARRY		0x0400		/* �|��ܤW�@��/�ثe���� */

#define	GET_LIST	0x1000		/* ���o Link List */
#define	GET_USER	0x2000		/* ���o user id */
#define	GET_BRD		0x4000		/* ���o board id */


/* Flags to account save */
#define ACCTSAV_ALL	0x0000		/* �^�s��� ACCT */
#define ACCTSAV_ULEVEL	0x0001		/* �^�s userlevel */
#define ACCTSAV_UFO	0x0002		/* �^�s ufo */
#define ACCTSAV_UINFO	0x0004		/* �^�s passwd username */
#define ACCTSAV_HOST	0x0008		/* �^�s lasthost */
#define ACCTSAV_EMAIL	0x0010		/* �^�s email */
#define ACCTSAV_LOGIN	0x0020		/* �^�s numlogins lastlogin */
#define ACCTSAV_POST	0x0040		/* �^�s numposts */


#include "config.h"		/* User-configurable stuff */
#include "dao.h"
#include "perm.h"		/* user/board permission */
#include "ufo.h"		/* user flag option */
#include "modes.h"		/* The list of valid user modes */
#include "struct.h"		/* data structure */
#include "global.h"		/* global variable & definition */


/* ----------------------------------------------------- */
/* WebBBS �W����                                         */
/* ----------------------------------------------------- */


#include "webconf.h"
#include "web.p"

#endif				/* _WEB_H_ */
