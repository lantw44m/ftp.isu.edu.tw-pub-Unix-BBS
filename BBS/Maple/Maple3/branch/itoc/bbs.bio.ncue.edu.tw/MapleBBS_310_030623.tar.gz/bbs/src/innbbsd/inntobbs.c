/*-------------------------------------------------------*/
/* inntobbs.c	( NTHU CS MapleBBS Ver 3.10 )		 */
/*-------------------------------------------------------*/
/* target : innbbsd INN to BBS				 */
/* create : 95/04/27					 */
/* update :   /  /  					 */
/* author : skhuang@csie.nctu.edu.tw			 */
/*-------------------------------------------------------*/


#include "daemon.h"
#include "bbslib.h"
#include "inntobbs.h"


typedef struct Header
{
  char *name;
  int id;
}      header_t;


enum HeaderValue	/* �Ҧ����Ψ쪺 header */
{
  SUBJECT_H,
  FROM_H,
  SITE_H,
  DATE_H,
  POSTHOST_H1,
  POSTHOST_H2,
  PATH_H,
  GROUPS_H,
  MSGID_H,
  CONTROL_H,

  LASTHEADER
};


static header_t headertable[LASTHEADER] = 
{
  "Subject",			SUBJECT_H,
  "From",			FROM_H,
  "Organization",		SITE_H,
  "Date",			DATE_H,
  "NNTP-Posting-Host",		POSTHOST_H1,
  "X-Auth-From",		POSTHOST_H2,
  "Path",			PATH_H,
  "Newsgroups",			GROUPS_H,
  "Message-ID",			MSGID_H,
  "Control",			CONTROL_H,
};


char *BODY;
char *SUBJECT, *FROM, *SITE, *DATE, *POSTHOST, *PATH, *GROUPS, *MSGID, *CONTROL;


static int 
header_cmp(a, b)
  header_t *a, *b;
{
  return strcasecmp(a->name, b->name);
}


static int 
header_value(inputheader)
  char *inputheader;
{
  header_t key, *findkey;
  static int already_init = 0;

  if (!already_init)
  {
    qsort(headertable, sizeof(headertable) / sizeof(header_t), sizeof(header_t), header_cmp);
    already_init = 1;
  }

  key.name = inputheader;
  findkey = (header_t *) bsearch((char *) &key, (char *) headertable, sizeof(headertable) / sizeof(header_t), sizeof(key), header_cmp);
  if (findkey != NULL)
    return findkey->id;

  return -1;
}


int 
readlines(client)			/* Ū�J���Y�M���� */
  ClientType *client;
{
  register char *front, *ptr, *hptr;
  register int i;
  static char *HEADER[LASTHEADER];

  for (i = 0; i < LASTHEADER; i++)
    HEADER[i] = NULL;
  BODY = NULL;

  ptr = client->in.data + 2;

  for (;;)
  {
    front = ptr + 1;
    if (*front == '\n')
    {
      /* skip leading empty lines */

      do
      {
	front++;
      } while (*front == '\n');

      BODY = front;
      break;
    }

    ptr = (char *) strchr(front, '\n');
    if (!ptr)
      break;

    *ptr = '\0';
    hptr = (char *) strchr(front, ':');
    if (hptr && hptr[1] == ' ')
    {
      *hptr = '\0';
      i = header_value(front);
      if (i >= 0)
      {
	HEADER[i] = hptr + 2;

	/* merge multi-line header */

	hptr = ptr;

	/* while (ptr[1] == ' ') */
        /* Thor.990110: �����O�� \t �N���٦� */
	while (ptr[1] == ' ' || ptr[1] == '\t')
	{
          /* while (*++ptr == ' ') ; */
          do 
          {
            ++ptr;
          } while (*ptr == ' ' || *ptr == '\t');

	  for (;;)
	  {
	    i = *ptr;
	    if (i == '\n')
	    {
	      break;
	    }
	    if (i == '\0')
	    {
	      ptr--;
	      break;
	    }
	    ptr++;
	    *hptr++ = i;
	  }

	  *hptr = '\0';
	}

	/* well, ptr point to end of line */
      }
    }


    front = ptr;
  }

  SUBJECT = HEADER[SUBJECT_H];
  FROM = HEADER[FROM_H];
  SITE = HEADER[SITE_H];
  DATE = HEADER[DATE_H];
  POSTHOST = HEADER[POSTHOST_H1] ? HEADER[POSTHOST_H1] : HEADER[POSTHOST_H2];
  PATH = HEADER[PATH_H];
  GROUPS = HEADER[GROUPS_H];
  MSGID = HEADER[MSGID_H];
  CONTROL = HEADER[CONTROL_H];
}
