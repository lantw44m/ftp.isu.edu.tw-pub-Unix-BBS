<?php
//sort my friend

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
$level = $cuser[level];
if(!$pid || !($level & PERM_BASIC)) {
	echo "<html>�v������! <a href='pal_list.php'> [������^] </a></html>";
	exit; 
}

if($num < 1) $num = 1;
$page = intval($num / XO_TALL) + 1;

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
 
<html>
<head>
<title>ReplySpecialMail</title>
<meta http-equiv="Content-Type" content="text/html;charset=big5">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #000080}
A:visited {color: #444480}
PRE {color: #c0c0c0}
</style>
<script language="JavaScript">
<!--
//-->
</script>
</head>
<body bgcolor="#ffffff" leftmargin="3" topmargin="0" marginwidth="3" marginheight="0">
<table width="635" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="55" align="center"><img src="images/pal.gif" width="289" height="55" border="0"></td>
  </tr>
  <tr>
    <td valign="top">
	<hr size="2" color="green" noshade width="95%">
	
	<?php
	//pal edit

	if (isset($userid) && !isset($submit)) { //�ݭn�ˬd!

		require_once('webbbs.class.php');
	
		$ws = new server_class;
		$ws->connect();

		if(!isset($ftype)) $ftype = 0;
		$cmd = $ws->set_cmd("pal_add_rqst", G_TALK, $pid, $userid);
		$ws->query($cmd);
		
		$check = substr($ws->data, 0, 2);
		if($check != 'OK') 			
		{
			$data = $ws->data;
			echo "<br><br><center>";
			echo alertMsg($data);
			echo "<br><br><a href='javascript:window.history.back()'>[������^]</a></center>";	
		} else {

		print "<form method='post' action='$PHP_SELF'>
			�b���N��: <input type='text' size='15' name='userid' value='$userid'> <br>
			�ͽ˴y�z: <input type='text' size='20' name='ship' maxlength='30'> (10�Ӧr���k)<br>
			�O�_�l��: <input type='radio' name='ftype' value='0' checked>�n��  <input type='radio' name='ftype' value='1'>�l�� <br>
			<input type='submit' name='submit' value='�T�w'> <input type='button' value='��^' onclick='window.history.back()'>
			</form>
					";
		}
	}
	else if(!isset($ship) && !isset($ftype)) {
		print "<form method='post' action='$PHP_SELF'>
			�b���N��: <input type='text' size='15' name='userid'> <br>
			�ͽ˴y�z: <input type='text' size='20' name='ship' maxlength='30'> (10�Ӧr���k)<br>
			�O�_�l��: <input type='radio' name='ftype' value='0' checked>�n��  <input type='radio' name='ftype' value='1'>�l�� <br>
			<input type='submit' name='submit' value='�T�w'> <input type='button' value='��^' onclick='window.history.back()'>
			</form>
				";

	} else {
		require_once('webbbs.class.php');
	
		$ws = new server_class;
		$ws->connect();

		if(!isset($ftype)) $ftype = 0;
		if(!$ship) $ship = " ";
		$cmd = $ws->set_cmd("pal_add", G_TALK, $pid, $userid, $ship, $ftype);
		$ws->query($cmd);
		
		$ret = $ws->parse();
		if($ret[result] != 'OK') 
			$data = $ws->data;
		else
			$data = $ret[msg];

		echo "<br><br><center>";
		echo alertMsg($data);
		echo "<br><br><a href='pal_list.php'>[������^]</a></center>";
	}

	?>	
	</td>
  </tr>
</table>
</body>
</html>
