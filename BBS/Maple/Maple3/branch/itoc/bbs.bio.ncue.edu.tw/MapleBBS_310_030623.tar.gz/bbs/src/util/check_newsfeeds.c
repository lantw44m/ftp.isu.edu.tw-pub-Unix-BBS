/*-------------------------------------------------------*/
/* util/check_newsfeeds.c( NTHU CS MapleBBS Ver 3.10 )	 */
/*-------------------------------------------------------*/
/* target : �ˬd newsfeeds.bbs �O�_�u�����O		 */
/* create : 02/06/13					 */
/* update :   /  /					 */
/* author : itoc.bbs@bbs.tnfsh.tn.edu.tw		 */
/*-------------------------------------------------------*/


#include "bbs.h"


static char *
str_strip(group)	/* �� newfeeds.bbs ���C�檺 group �� brdname ���R�X�� */
  char *group;
{
  int ch;
  char *str, *brdname;

  str = group;
  while (ch = *str)
  {
    if (ch == ' ' || ch == '\t')
      break;

    str++;
  }
  *str = '\0';		/* �즹�o�� group */

  str++;
  while (ch = *str)
  {
    if (ch != ' ' && ch != '\t')
      break;

    str++;
  }
  brdname = str;

  str++;
  while (ch = *str)
  {
    if (ch == ' ' || ch == '\t')
      break;

    str++;
  }
  *str = '\0';		/* �즹�o�� brdname */

  return brdname;
}


static int			/* -1:�L�o�ݪO  0:���ݪO�s�b */
check_brd(brdname)		/* �ˬd�O�_�u�����o�ݪO */
  char *brdname;
{
  int num;
  BRD brd;
  char title[30];

  num = 0;
  sprintf(title, "[%s] deleted by ", brdname);
  while (!rec_get(FN_BRD, &brd, sizeof(BRD), num))
  {
    if (!strcmp(brdname, brd.brdname) && !strstr(brd.title, title) &&
      !(brd.battr & BRD_NOTRAN))
      return 0;
    num++;
  }

  return -1;
}


int 
main()
{
  char group[128], *brdname;
  FILE *fp;

  chdir(BBSHOME);

  if (!(fp = fopen("innd/newsfeeds.bbs", "r")))
    return -1;

  while (fgets(group, 128, fp))
  {
    if (group[0] != '#')
    {
      group[strlen(group) - 1] = '\0';	/* �� '\n' ���� '\0' */
      brdname = str_strip(group);
      if (check_brd(brdname))
	printf("�ݪO [%s] �w�g���s�b�Τ���H�A���O���b newsfeeds.bbs ��\n", brdname);
    }
  }

  fclose(fp);
}
