/*-------------------------------------------------------*/
/* song.c	( YZU_CSE WindTop BBS )			 */
/*-------------------------------------------------------*/
/* target : song ordering routines			 */
/* create :   /  /  					 */
/* update : 01/12/18					 */
/*-------------------------------------------------------*/


#include "bbs.h"


#ifdef HAVE_SONG

extern BCACHE *bshm;
extern XZ xz[];
extern char xo_pool[];


static void XoSong();


#define GEM_READ	1	/* readable */
#define GEM_WRITE	2	/* writable */
#define GEM_FILE	4	/* �w���O�ɮ� */


#define	SONG_SRC	"<~Src~>"
#define SONG_DES	"<~Des~>"
#define SONG_SAY	"<~Say~>"
#define SONG_END	"<~End~>"


#ifdef LOG_SONG_USIES
static int			/* -1: �S���  >=0: pos */
song_usies_find(fpath, chrono)
  char *fpath;
  time_t chrono;
{
  time_t chro;
  int pos, fd;

  pos = 0;
  fd = open(fpath, O_RDONLY);

  while (fd)
  {
    lseek(fd, (off_t) (sizeof(SONGDATA) * pos), SEEK_SET);
    if (read(fd, &chro, sizeof(time_t)) == sizeof(time_t))
    {
      if (chro == chrono)
      {
        close(fd);
        return pos;
      }
      pos++;
    }
    else
    {
      close(fd);
      return -1;
    }
  }
  return -1;
}


static void
song_usies_log(chrono, title)
  time_t chrono;
  char *title;
{
  SONGDATA songdata;
  int pos;
  char *dir;

  dir = FN_RUN_SONGUSIES;

  if ((pos = song_usies_find(dir, chrono)) >= 0)
  {
    rec_get(dir, &songdata, sizeof(SONGDATA), pos);
    songdata.count++;
    rec_put(dir, &songdata, sizeof(SONGDATA), pos, NULL);
  }
  else
  {
    songdata.chrono = chrono;
    songdata.count = 1;
    strcpy(songdata.title, title);
    rec_add(dir, &songdata, sizeof(SONGDATA));
  }
}
#endif


static int swaped;		/* ����O�_�� <~Src~> �� */

static int
song_swap(str, src, des)
  char *str;
  char *src;
  char *des;
{
  char *ptr, *tmp, buf[256];

  ptr = strstr(str, src);
  if (ptr)
  {
    *ptr = '\0';
    tmp = ptr + strlen(src);
    sprintf(buf, "%s%s%s", str, des, tmp);
    strcpy(str, buf);
    /* return 1; */
    return ++swaped;
  }
  else
    return 0;
}


static void
song_quote(fpr, fpw, src, des, say)	/* �q fpr Ū�X����A�� <~Src~> ���������A�g�J fpw */
  FILE *fpr, *fpw;
  char *src, *des, *say;
{
  char buf[256];

  swaped = 0;
  while (fgets(buf, 256, fpr))
  {
    if (strstr(buf, SONG_END))
      break;

    while (song_swap(buf, SONG_SRC, src));
    while (song_swap(buf, SONG_DES, des));
    while (song_swap(buf, SONG_SAY, say));
    fputs(buf, fpw);
  }

  if (!swaped)	/* itoc.011115: �p�G����S�� <~Src~>�A�h�b�̫�[�W */
  {
    /* �b�̫�@��[�W <~Src~> �Q�� <~Des~> �� <~Say~> */
    strcpy(buf, "\033[1;33m" SONG_SRC " �Q�� " SONG_DES " �� " SONG_SAY "\033[m\n");
    song_swap(buf, SONG_SRC, src);
    song_swap(buf, SONG_DES, des);
    song_swap(buf, SONG_SAY, say);
    fputs(buf, fpw);
  }

  /* �b�ɮ׳̫�[�W�I�q�ɶ� */
  fprintf(fpw, "\n--\n%s\n", Now());
}


static HDR *
song_check(xo, fpath)
  XO *xo;
  char *fpath;
{
  HDR *ghdr;
  int gtype;
  char *folder;

  ghdr = (HDR *) xo_pool + (xo->pos - xo->top);
  gtype = ghdr->xmode;

  if ((gtype & GEM_RESTRICT) && (xo->key <= GEM_USER))
    return NULL;

  if (fpath)
  {
    if (gtype & GEM_BOARD)
    {
      sprintf(fpath, "gem/brd/%s/.DIR", ghdr->xname);
    }
    else
    {
      folder = xo->dir;
      if (gtype & GEM_GOPHER)
      {
	return NULL;
      }
      else
      {
	hdr_fpath(fpath, folder, ghdr);
      }
    }
  }
  return ghdr;
}


static HDR *
song_get(xo, fpath)
  XO *xo;
  char *fpath;
{
  HDR *ghdr;
  int gtype;
  char *folder;

  ghdr = (HDR *) xo_pool + (xo->pos - xo->top);
  gtype = ghdr->xmode;

  if ((gtype & GEM_RESTRICT) && (xo->key <= GEM_USER))
    return NULL;

  if (fpath)
  {
    folder = xo->dir;
    if (gtype & (GEM_GOPHER | GEM_FOLDER | GEM_RESERVED))
    {
      return NULL;
    }
    else
    {
      hdr_fpath(fpath, folder, ghdr);
    }
  }
  return ghdr;
}


static void
song_item(num, ghdr)
  int num;
  HDR *ghdr;
{
  int xmode, gtype;

  xmode = ghdr->xmode;
  gtype = (char)0xba;
  if (xmode & GEM_FOLDER)
    gtype += 1;
  if (xmode & GEM_GOPHER)
    gtype += 2;
  prints("%6d%c \241%c ", num, (xmode & GEM_RESTRICT) ? ')' : ' ', gtype);

  gtype = 0;

  if (!HAS_PERM(PERM_ALLADMIN) && (xmode & GEM_RESTRICT))
    prints(MSG_DATA_CLOAK);
  else if ((gtype == 0) || (xmode & GEM_GOPHER))
    prints("%-.64s\n", ghdr->title);
}


static int
song_body(xo)
  XO *xo;
{
  HDR *ghdr;
  int num, max, tail;

  max = xo->max;
  if (max <= 0)
  {
    outs("\n\n�m�q���n�|�b�l���Ѧa��������� :)");
    vmsg(NULL);
    return XO_QUIT;
  }

  ghdr = (HDR *) xo_pool;
  num = xo->top;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  move(3, 0);
  do
  {
    song_item(++num, ghdr++);
  } while (num < max);
  clrtobot();

  /* return XO_NONE; */
  return XO_FOOT;	/* itoc.010403: �� b_lines ��W feeter */  
}


static int
song_head(xo)
  XO *xo;
{
  vs_head("��ؤ峹", xo->xyz);
  outs(NECKER_SONG);
  return song_body(xo);
}


static int
song_init(xo)
  XO *xo;
{
  xo_load(xo, sizeof(HDR));
  return song_head(xo);
}


static int
song_load(xo)
  XO *xo;
{
  xo_load(xo, sizeof(HDR));
  return song_body(xo);
}


/* ----------------------------------------------------- */
/* ��Ƥ��s�W�Gappend / insert				 */
/* ----------------------------------------------------- */


static int
song_browse(xo)
  XO *xo;
{
  HDR *ghdr;
  int xmode, op = 0;
  char fpath[80], title[TTLEN + 1];

  do
  {
    ghdr = song_check(xo, fpath);
    if (ghdr == NULL)
      break;

    xmode = ghdr->xmode;

    /* browse folder */

    if (xmode & GEM_FOLDER)
    {
      op = xo->key;
      if (xmode & GEM_BOARD)
      {
	op = brd_bno(ghdr->xname);
	if (HAS_PERM(PERM_SYSOP))	/* itoc.001029: sysop �h�� GEM_SYSOP */
	  op = GEM_SYSOP;
	else
	  op = GEM_USER;
      }
      else if (xmode & GEM_GOPHER)
      {
	return XO_NONE;
      }

      strcpy(title, ghdr->title);
      XoSong(fpath, title, op);
      return song_init(xo);
    }

    /* browse article */

    /* Thor.990204: ���Ҽ{more �Ǧ^�� */
    if ((xmode = more(fpath, FOOTER_GEM)) < 0)
      break;

    op = GEM_READ | GEM_FILE;

    xmode = xo_getch(xo, xmode);

  } while (xmode == XO_BODY);

  if (op != GEM_READ)
    return song_head(xo);

  return XO_FOOT;
}


static int
count_ktv()	/* itoc.021102: ktv �O�̭��w���X�g���I�q�O�� */
{
  int count, fd;
  time_t yesterday;
  char folder[64];
  HDR *hdr;

  brd_fpath(folder, BN_KTV, fn_dir);
  if ((fd = open(folder, O_RDONLY)) < 0)
    return 0;

  mgets(-1);
  count = 0;
  yesterday = time(0) - 86400;
  while (hdr = mread(fd, sizeof(HDR)))
  {
    if (!strcmp(hdr->nick, cuser.userid) &&
      hdr->chrono > yesterday)
    {
      if (++count >= 3)		/* �����I�T�� */
        break;
    }
  }
  close(fd);

  return count;
}


static int
song_order(xo)
  XO *xo;
{
  int fd, annoy;
  char fpath[64], des[20], say[57], buf[64];
  HDR *hdr, xpost;
  FILE *fpr, *fpw;

  /* itoc.����: song_order ���P post */
  if (!HAS_PERM(PERM_POST))
    return XO_NONE;

  /* itoc.010831: �I�q�n���A�ҥH�n�T�� multi-login */
  if (cutmp->userlevel & PERM_COINLOCK)
  {
    vmsg(MSG_COINLOCK);
    return XO_FOOT;
  }

  if (count_ktv() >= 3)		/* �����I�T�� */
  {
    vmsg("�L�h�G�Q�|�p�ɤ��z�w�I��L�h�q��");
    return XO_FOOT;
  }

  if (cuser.gold < 1)
  {
    vmsg("�n 1 �����~���I�q��ݪO��");
    return XO_FOOT;
  }

  if (!(hdr = song_get(xo, fpath)))
    return XO_NONE;

  if (!vget(b_lines, 0, "�I�q���֡G", des, sizeof(des), DOECHO))
    return XO_FOOT;
  if (!vget(b_lines, 0, "�Q�����ܡG", say, sizeof(say), DOECHO))
    strcpy(say, ".........");

  annoy = vans("�Q�n�ΦW��(Y/N)�H[N] ") == 'y';

  if (vans("�T�w�I�q��(Y/N)�H[Y] ") == 'n')
    return XO_FOOT;

  cuser.gold--;

#ifdef LOG_SONG_USIES
  song_usies_log(hdr->chrono, hdr->title);
#endif

  /* �[�J .DIR record */

  brd_fpath(fpath, BN_KTV, fn_dir);
  fd = hdr_stamp(fpath, 'A', &xpost, buf);

  strcpy(xpost.owner, annoy ? "[���i�D�A]" : cuser.userid);
  strcpy(xpost.nick, cuser.userid);	/* �Y�ϬO�ΦW�I�q�Auserid ���O���b hdr.nick */
  sprintf(xpost.title, "%s �I�� %s", xpost.owner, des);
  rec_add(fpath, &xpost, sizeof(HDR));

  /* �[�J�峹�ɮ� */

  xo_fpath(fpath, xo->dir, hdr);
  fpr = fopen(fpath, "r+");
  fpw = fdopen(fd, "w");
  song_quote(fpr, fpw, annoy ? "�Y�H" : cuser.userid, des, say);

  fclose(fpr);
  fclose(fpw);
  close(fd);

  return XO_FOOT;
}


static int
song_send(xo)
  XO *xo;
{
  int fd;
  char fpath[64], say[57], buf[64];
  HDR *hdr, xpost;
  FILE *fpr, *fpw;
  ACCT acct;

  /* itoc.����: song_send ���P mail */
  if (!HAS_PERM(PERM_BASIC))
    return XO_NONE;

  if (!(hdr = song_get(xo, fpath)))
    return XO_NONE;

  if (acct_get("�I�q���֡G", &acct) < 1)	/* acct_get �i��| clear�A�ҥH�n��ø */
    return song_head(xo);

  if (!vget(b_lines, 0, "�Q�����ܡG", say, sizeof(say), DOECHO))
    strcpy(say, ".........");

  if (vans("�T�w�I�q��(Y/N)�H[Y] ") == 'n')
    return XO_FOOT;

#ifdef LOG_SONG_USIES
  song_usies_log(hdr->chrono, hdr->title);
#endif

  /* �[�J .DIR record */

  usr_fpath(fpath, acct.userid, fn_dir);
  fd = hdr_stamp(fpath, 0, &xpost, buf);

  strcpy(xpost.owner, cuser.userid);
  strcpy(xpost.nick, cuser.username);
  sprintf(xpost.title, "%s �I�q���z", cuser.userid);
  rec_add(fpath, &xpost, sizeof(HDR));

  /* �[�J�峹�ɮ� */

  xo_fpath(fpath, xo->dir, hdr);
  fpr = fopen(fpath, "r+");
  fpw = fdopen(fd, "w");
  song_quote(fpr, fpw, cuser.userid, acct.userid, say);

  fclose(fpr);
  fclose(fpw);
  close(fd);

  m_biff(acct.userno);		/* �Y���b�u�W�A�h�n�q�����s�H */

  return song_head(xo);
}


static int
song_edit(xo)
  XO *xo;
{
  char fpath[80];

  if (song_get(xo, fpath) != NULL)
  {
    if (HAS_PERM(PERM_ALLBOARD))
      vedit(fpath, 0);
    else
      vedit(fpath, -1);		/* itoc.010403: ���@��ϥΪ̤]�i�H edit �ݱ���X */
  }

  return song_head(xo);
}


static int
song_title(xo)
  XO *xo;
{
  HDR *ghdr, xhdr;
  int num;
  char *dir;
  char fpath[128];

  if (!HAS_PERM(PERM_ALLBOARD))
    return XO_NONE;
  
  ghdr = song_get(xo, fpath);
  if (ghdr == NULL)
    return XO_NONE;

  xhdr = *ghdr;
  vget(b_lines, 0, "���D�G", xhdr.title, TTLEN + 1, GCARRY);
  vget(b_lines, 0, "�@�̡G", xhdr.owner, IDLEN + 2, GCARRY);
  vget(b_lines, 0, "�ɶ��G", xhdr.date, 9, GCARRY);

  dir = xo->dir;
  if (memcmp(ghdr, &xhdr, sizeof(HDR)) &&
    vans("�T�w�n�ק��(Y/N)�H[N] ") == 'y')
  {
    *ghdr = xhdr;
    num = xo->pos;
    rec_put(dir, ghdr, sizeof(HDR), num, NULL);
    num++;
    move(num - xo->top + 2, 0);
    song_item(num, ghdr);

  }
  return XO_FOOT;
}


static int
song_help(xo)
  XO *xo;
{
  xo_help("song");
  return song_head(xo);
}


static KeyFunc song_cb[] =
{
  XO_INIT, song_init,
  XO_LOAD, song_load,
  XO_HEAD, song_head,
  XO_BODY, song_body,

  'r', song_browse,
  'o', song_order,
  'm', song_send,

  'E', song_edit,
  'T', song_title,

  'h', song_help
};


static void
XoSong(folder, title, level)
  char *folder;
  char *title;
  int level;
{
  XO *xo, *last;

  last = xz[XZ_SONG - XO_ZONE].xo;	/* record */

  xz[XZ_SONG - XO_ZONE].xo = xo = xo_new(folder);
  xz[XZ_SONG - XO_ZONE].cb = song_cb;
  xo->pos = 0;
  xo->key = level;
  xo->xyz = "�I�q�t��";
  strcpy(currBM, "�O�D�G�t�κ޲z��");

  xover(XZ_SONG);

  free(xo);

  xz[XZ_SONG - XO_ZONE].xo = last;	/* restore */
}


int
XoSongMain()
{
  char fpath[64];

  bbstate = STAT_STARTED;

  sprintf(fpath, "gem/brd/%s/%s", BN_KTV, FN_DIR);
  XoSong(fpath, "�I�q�t��", HAS_PERM(PERM_SYSOP) ? GEM_SYSOP : GEM_USER);
  return 0;
}


int
XoSongSub()
{
  int chn;

  chn = brd_bno(BN_REQUEST);
  XoPost(chn);
  xover(XZ_POST);
  return 0;
}


int
XoSongLog()
{
  int chn;

  chn = brd_bno(BN_KTV);
  XoPost(chn);
  xover(XZ_POST);
  return 0;
}
#endif	/* HAVE_SONG */
