/* ----------------------------------------------------- */
/* open client						 */
/* ----------------------------------------------------- */

#include <stdio.h>
#include <syslog.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/un.h>
#include <sys/param.h>


int
inetclient(server, service, protocol)
  char *server;
  char *protocol;
  char *service;
{
  register struct servent *se;	/* service information entry */
  register struct hostent *he;	/* host information entry */
  register struct protoent *pe;	/* protocol information entry */
  struct sockaddr_in sin;	/* Internet endpoint address */
  register int port, s;

  bzero((char *) &sin, sizeof(sin));
  sin.sin_family = AF_INET;

  if (!service || !protocol || !server)
    return -1;

  /* map service name to port number */
  /* service ---> port */
  se = getservbyname(service, protocol);
  if (se == NULL)
  {
    port = htons((u_short) atoi(service));
    if (port == 0)
    {
      fprintf(stderr, "%s/%s: Unknown service.\n", service, protocol);
      return -1;
    }
  }
  else
    port = se->s_port;
  sin.sin_port = port;

  /* map server hostname to IP address, allowing for dotted decimal */
  he = gethostbyname(server);
  if (he == NULL)
  {
    sin.sin_addr.s_addr = inet_addr(server);
    if (sin.sin_addr.s_addr == INADDR_NONE)
    {
      fprintf(stderr, "%s: Unknown host.\n", server);
      return -1;
    }
  }
  else
  {
    bcopy(he->h_addr, (char *) &sin.sin_addr, he->h_length);
  }

  /* map protocol name to protocol number */
  pe = getprotobyname(protocol);
  if (pe == NULL)
  {
    fprintf(stderr, "%s: Unknown protocol.\n", protocol);
    return -1;
  }

  /* Allocate a socket */
  s = socket(PF_INET, strcmp(protocol, "tcp") ? SOCK_DGRAM : SOCK_STREAM, pe->p_proto);
  if (s < 0)
  {
    perror("socket");
    return -1;
  }

  /* Connect the socket to the server */
  if (connect(s, (struct sockaddr *) & sin, sizeof(sin)) < 0)
  {
    /* perror("connect"); */
    return -1;
  }

  return s;
}
