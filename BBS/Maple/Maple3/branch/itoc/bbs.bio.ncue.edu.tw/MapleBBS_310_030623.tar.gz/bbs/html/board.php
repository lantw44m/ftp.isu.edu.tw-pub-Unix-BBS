<?php
//Class List

require_once('config.php');

unset($cuser);
session_start();

$pid = $cuser[pid];
if(!$pid) {
	echo "<html>�z�w�g�_�}�s��! �Ы�F5��s����!</html>";
	exit; 
}

if(!isset($page)) $page = 1;

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
 
<html>
<head>
<title>Class List</title>
<meta http-equiv="Content-Type" content="text/html;charset=big5">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #00a000}
A:visited {color: #00a000}
</style>
</head>
<body leftmargin="3" topmargin="0" marginwidth="3" marginheight="0" bgcolor="#FFFFFF">
<table width="617" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="3"><img src="images/brd/brd_top.jpg" width="618" height="54" usemap="#Map" border="0"></td>
  </tr>
  <tr> 
    <td width="20" background="images/brd/brd_left_bg.jpg">&nbsp;</td>
    <td height="100%" width="585">
	  <table width="76%" border="0" cellspacing="0" cellpadding="0" height="140" align="center">
        <tr> 
          <td colspan="2" align="center">�������������Q�װ�</a></td>
        </tr>
		<?php
		//��ܹ�
		require_once('webbbs.class.php');

		$ws = new server_class;
		$ws->connect();		

		$cmd = $ws->set_cmd("b_list", G_BOARD, $pid, "Class", $page, 1);
		$ws->query($cmd);
		
		$list = split("\n", $ws->data); /* \n�@�j�} */

		$ret = $ws->parse($list[0]);
		if($ret[result] != 'OK') {
			echo "<br><br>";
			echo alertMsg($ws->data);
			echo "<br><br><a href='main.php'>[������^]</a>";
			exit;
		}

		$totalpage = intval($ret[max]/XO_TALL);  /* 20�OXo_TALL���� */
		if($ret[max] % XO_TALL) $totalpage ++;
	
		$page = intval($ret[page]) + 1;
		$prv = $page-1;
		$nxt = $page+1;
		
		/* �]�mGoTo Page */
		$gotoString  = "�����Q�װϡG �� <font color=a00000>".$page."</font> / ".$totalpage." ��";
		if($prv > 0)
			$gotoString .= " | <a href=\"".$PHP_SELF."?page=".$prv."\">�W�@��</a>";

		if($nxt <= $totalpage)
			$gotoString .= " | <a href=\"".$PHP_SELF."?page=".$nxt."\">�U�@��</a>";

		if($totalpage > 1) {

			$gotoString .= " | �䥦�U��: ";

			for($i=1; $i<=$totalpage; $i++) {

				if($i == $page)
					$gotoString .= $i." ";
				else
					$gotoString .= "<a href=\"".$PHP_SELF."?page=".$i."\">$i</a> ";
			}
		}
		$gotoString  .= " | <a href='#' onclick='window.history.back()'>��^�W��</a>";
		
        print "
			<tr bgcolor='#dddddd' height='20'> 
	          <td width='40'>�s��</td><td>�����W��</td>
		    </tr>
		";
		for($i=1; $i<= XO_TALL; $i++) {
			if($i%2)
				$bgcolor = "#fefefe";
			else
				$bgcolor = "#efefef";

			$tmp = $ws->parse($list[$i]);

			$tmp[num] = intval($tmp[num]);
			if($tmp[num] <= 0) 
				break;
			
			$chn = intval($tmp[chn]); /* intval($tmp[num])+1; */
			$submitUrl = "class.php?chn=$chn";

			$tmp[title] = str_replace(" ", "&nbsp;", $tmp[title]);

			/* show the title */			
			print "
				<tr bgcolor='$bgcolor' height='20'>
				<td> $tmp[num] </td>
				<td> <a href='$submitUrl'>$tmp[title]</a> </td>
				</tr>
				";
		}
		
		print "
		<tr bgcolor='$bgcolor' height='20'>
		<td>".count($list)."</td>
		<td> <a href='class.php?chn=0&page=1'>AllBoard/&nbsp;&nbsp;&nbsp;&nbsp;�i ��ܩҦ��ݪO �j</a></td> 
		</tr> ";

		print "
		<tr bgcolor='#dddddd' height='20'><td colspan='2'>
		 $gotoString	
		</td></tr>
		";

		?>
      </table>		
	</td>
    <td background="images/brd/brd_right_bg.jpg" width="20">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="3" height="2"><img src="images/brd/brd_bottom.jpg" width="618" height="25"></td>
  </tr>
</table>
<map name="Map"> 
  <area shape="rect" coords="47,18,117,38" href="services.php" alt="�����A�Ȱ�" title="�����A�Ȱ�">
  <area shape="rect" coords="258,20,327,39" href="gem.php" alt="��ؤ��G��" title="��ؤ��G��">
  <area shape="rect" coords="336,20,408,40" href="personal.php" alt="�ӤH�u��{" title="�ӤH�u��{">
  <area shape="rect" coords="416,20,488,40" href="talk.php" alt="�𶢲�Ѧa" title="�𶢲�Ѧa">
  <area shape="rect" coords="497,19,567,39" href="group.php" alt="�ڪ��s�հ�" title="�ڪ��s�հ�">
</map>
</body>
</html>
