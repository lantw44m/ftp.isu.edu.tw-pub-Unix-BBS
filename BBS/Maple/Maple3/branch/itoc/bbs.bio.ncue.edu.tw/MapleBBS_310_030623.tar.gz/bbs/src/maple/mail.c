/*-------------------------------------------------------*/
/* mail.c	( NTHU CS MapleBBS Ver 2.36 )		 */
/*-------------------------------------------------------*/
/* target : local/internet mail routines	 	 */
/* create : 95/03/29				 	 */
/* update : 95/12/15				 	 */
/*-------------------------------------------------------*/


#include "bbs.h"


extern XZ xz[];
extern char xo_pool[];


extern int TagNum;
extern UCACHE *ushm;
static int m_count();


/* ----------------------------------------------------- */
/* Link List routines					 */
/* ----------------------------------------------------- */


#define	MSG_MULTIREPLY	"�z�T�w�n�s�զ^�H(Y/N)�H[N] "


LinkList *ll_head;		/* head of link list */
static LinkList *ll_tail;	/* tail of link list */


void
ll_new()
{
  LinkList *list, *next;

  list = ll_head;

  while (list)
  {
    next = list->next;
    free(list);
    list = next;
  }

  ll_head = ll_tail = NULL;
}


void
ll_add(name)
  char *name;
{
  LinkList *node;
  int len;

  len = strlen(name) + 1;
  node = (LinkList *) malloc(sizeof(LinkList) + len);
  node->next = NULL;
  memcpy(node->data, name, len);

  if (ll_head)
    ll_tail->next = node;
  else
    ll_head = node;
  ll_tail = node;
}


int
ll_del(name)
  char *name;
{
  LinkList *list, *prev, *next;

  prev = NULL;
  for (list = ll_head; list; list = next)
  {
    next = list->next;
    if (!strcmp(list->data, name))
    {
      if (prev == NULL)
	ll_head = next;
      else
	prev->next = next;

      if (list == ll_tail)
	ll_tail = prev;

      free(list);
      return 1;
    }
    prev = list;
  }
  return 0;
}


int
ll_has(name)
  char *name;
{
  LinkList *list;

  for (list = ll_head; list; list = list->next)
  {
    if (!strcmp(list->data, name))
      return 1;
  }
  return 0;
}


void
ll_out(row, column, msg)
  int row, column;
  char *msg;
{
  int len;
  LinkList *list;

  move(row, column);
  clrtobot();
  outs(msg);

  column = 80;
  for (list = ll_head; list; list = list->next)
  {
    msg = list->data;
    len = strlen(msg) + 1;
    if (column + len > 78)
    {
      if (++row > b_lines - 2)
      {
	move(b_lines, 60);
	outs("���c���γƸ�...");
	break;
      }
      else
      {
	column = len;
	outc('\n');
      }
    }
    else
    {
      column += len;
      outc(' ');
    }
    outs(msg);
  }
}


/* ----------------------------------------------------- */
/* Internet E-mail routines				 */
/* ----------------------------------------------------- */


int
m_internet()
{
  char rcpt[60];

  if (m_count())
    return 0;

  move(MENU_XPOS, 0);
  clrtobot();

  while (vget(15, 0, "���H�H�G", rcpt, sizeof(rcpt), DOECHO))
  {
    if (not_addr(rcpt))
    {
      vmsg("E-mail �����T");
      continue;
    }

    if (vget(17, 0, "�D  �D�G", ve_title, TTLEN, DOECHO))
    {
#if 0
      mail_send(rcpt, ve_title);
#endif
#if 1
      char *msg;
      switch(mail_send(rcpt, ve_title))
      {
      case -1:
        msg = err_uid;
        break;

      case -2:
        msg = msg_cancel;
        break;

      case -3:  /* Thor.980707: �������p�ܡH */
        msg = "�ϥΪ̵L�k���H";
        break;

      default:
        msg = "�H�w�H�X"; 
        break;
      }
      vmsg(msg);
#endif
    }
    break;
  }
  return 0;
}


/* ----------------------------------------------------- */
/* (direct) SMTP					 */
/* ----------------------------------------------------- */


int
bsmtp(fpath, title, rcpt, method)
  char *fpath, *title, *rcpt;
  int method;
{
  int sock;
  time_t chrono, stamp;
  FILE *fp, *fr, *fw;
  char *str, buf[512], from[80], msgid[80];
#ifdef EMAIL_JUSTIFY
  char subject[80];
#endif
#ifdef HAVE_SIGNED_MAIL
  char prikey[9];
  union
  {
    char str[9];
    struct
    {
      usint hash, hash2;
    } val;
  } sign;

  *prikey = prikey[8] = sign.str[8] = '\0'; /* Thor.990413:����: �r�굲�� */
#endif

  cuser.numemails++;		/* �O���ϥΪ̦@�H�X�X�� Internet E-mail */
  chrono = time(&stamp);

#ifdef EMAIL_JUSTIFY

  /* --------------------------------------------------- */
  /* �����{�ҫH��					 */
  /* --------------------------------------------------- */

  if (method == MQ_JUSTIFY)
  {
    fpath = FN_ETC_VALID;
    title = subject;
    sprintf(from, "bbsreg@%s", str_host);
    /* archiv32(str_hash(rcpt, chrono), buf); */
    /* itoc.010820: �� cuser.tvalid �Ӱ� time-seed�A�i�H�ٱ� cuser.vtime ���A
       �٥i�H�Ϧb�P�@���{�ҮɡA�ҵo�X�h���{�ҫH���D���ۦP�A�קK���H�ѬO�����D�n�^�̫�@�� */
    archiv32(str_hash(rcpt, cuser.tvalid), buf);
    sprintf(title, TAG_VALID " %s(%s) [VALID]", cuser.userid, buf);
  }
  else
#endif
  {
    sprintf(from, "%s.bbs@%s", cuser.userid, str_host);
  }

  str = strchr(rcpt, '@') + 1;
  sock = dns_smtp(str);
  if (sock >= 0)
  {
    archiv32(chrono, msgid);

    move(b_lines, 0);
    clrtoeol();
    prints("�� �H�H�� %s \033[5m...\033[m", rcpt);
    refresh();

    sleep(1);			/* wait for mail server response */

    fr = fdopen(sock, "r");
    fw = fdopen(sock, "w");

    fgets(buf, sizeof(buf), fr);
    if (memcmp(buf, "220", 3))
      goto smtp_error;
    /* if (buf[3] == '-') */
    while (buf[3] == '-')	/* itoc.000512: maniac patch */
      fgets(buf, sizeof(buf), fr);

    fprintf(fw, "HELO %s\r\n", str_host);
    fflush(fw);
    do
    {
      fgets(buf, sizeof(buf), fr);
      if (memcmp(buf, "250", 3))
	goto smtp_error;
    } while (buf[3] == '-');

    fprintf(fw, "MAIL FROM:<%s>\r\n", from);
    fflush(fw);
    do
    {
      fgets(buf, sizeof(buf), fr);
      if (memcmp(buf, "250", 3))
	goto smtp_error;
    } while (buf[3] == '-');

    fprintf(fw, "RCPT TO:<%s>\r\n", rcpt);
    fflush(fw);
    do
    {
      fgets(buf, sizeof(buf), fr);
      if (memcmp(buf, "250", 3))
	goto smtp_error;
    } while (buf[3] == '-');

    fprintf(fw, "DATA\r\n", rcpt);
    fflush(fw);
    do
    {
      fgets(buf, sizeof(buf), fr);
      if (memcmp(buf, "354", 3))
	goto smtp_error;
    } while (buf[3] == '-');

    /* ------------------------------------------------- */
    /* begin of mail header				 */
    /* ------------------------------------------------- */

    /* Thor.990125: ���i�઺�� RFC 822 �� sendmail ���@�k, �K�o�O�H����:p */
#ifdef EMAIL_JUSTIFY
    fprintf(fw, "From: \"%s\" <%s>\r\nTo: %s\r\n", method & MQ_JUSTIFY ? "BBS Register" : cuser.username, from, rcpt);
#else
    fprintf(fw, "From: \"%s\" <%s>\r\nTo: %s\r\n", cuser.username, from, rcpt);
#endif
    /* itoc.030411: mail ��X RFC 2047 */
    output_rfc2047_qp(fw, "Subject: ", title, MYCHARSET, "\r\n");
    /* itoc.030323: mail ��X RFC 2045 */
    fprintf(fw, "X-Sender: %s (%s)\r\n"
      "Date: %s\r\nMessage-Id: <%s@%s>\r\n"
      "Mime-Version: 1.0\r\n"
      "Content-Type: text/plain; charset=%s\r\n"
      "Content-Transfer-Encoding: 8bit\r\n"
      "X-Disclaimer: [%s] �糧�H���e�����t�d\r\n\r\n",
      cuser.userid, cuser.username,
      Atime(&stamp), msgid, str_host,
      MYCHARSET, 
      str_site);

#ifdef EMAIL_JUSTIFY
    if (method & MQ_JUSTIFY)	/* �����{�ҫH�� */
    {
      fprintf(fw, " ID: %s (%s)  E-mail: %s\r\n\r\n",
	cuser.userid, cuser.username, rcpt);
    }
#endif

    /* ------------------------------------------------- */
    /* begin of mail body				 */
    /* ------------------------------------------------- */

    if (fp = fopen(fpath, "r"))
    {
      char *ptr;

      str = buf;
      *str++ = '.';
      while (fgets(str, sizeof(buf) - 3, fp))
      {
	if (ptr = strchr(str, '\n'))
	{
	  *ptr++ = '\r';
	  *ptr++ = '\n';
	  *ptr = '\0';
	}
	fputs((*str == '.' ? buf : str), fw);
      }
      fclose(fp);
    }
#ifdef HAVE_SIGNED_MAIL
    if (!(method & MQ_JUSTIFY) && !rec_get(FN_RUN_PRIVATE, prikey, 8, 0))
    /* Thor.990413: ���F�{�Ҩ�~, ��L�H�󳣭n�[sign */
    {
      /* Thor.990413: buf�Τ���F, �ɨӥΥ� */
      sprintf(buf,"%s -> %s", cuser.userid, rcpt);
      sign.val.hash = str_hash(buf, stamp);
      sign.val.hash2 = str_hash2(buf, sign.val.hash);
      str_xor(sign.str, prikey);
      /* Thor.990413: ���[()����, �ɶ����ťշ|�Q�Y��(���Ү�) */
      fprintf(fw,"�� X-Info: %s\r\n�� X-Sign: %s%s (%s)\r\n", 
        buf, msgid, genpasswd(sign.str), Btime(&stamp));
    }
#endif
    fputs("\r\n.\r\n", fw);
    fflush(fw);

    fgets(buf, sizeof(buf), fr);
    if (memcmp(buf, "250", 3))
      goto smtp_error;

    fputs("QUIT\r\n", fw);
    fflush(fw);
    fclose(fw);
    fclose(fr);
    goto smtp_log;

smtp_error:

    fclose(fr);
    fclose(fw);
    sprintf(msgid + 7, "\n\t%.70s", buf);
    chrono = -1;
  }
  else
  {
    chrono = -1;
    strcpy(msgid, "CONN");
  }

smtp_log:

  /* --------------------------------------------------- */
  /* �O���H�H						 */
  /* --------------------------------------------------- */

  sprintf(buf, "%s%-13s%c> %s %s %s\n\t%s\n\t%s\n", Btime(&stamp), cuser.userid,
    ((method == MQ_JUSTIFY) ? '=' : '-'), rcpt, msgid, 
#ifdef HAVE_SIGNED_MAIL
      *prikey ? genpasswd(sign.str): "NoPriKey",
#else
      "",
#endif
      title, fpath);
  f_cat(FN_RUN_MAIL_LOG, buf);

  return chrono;
}


#ifdef HAVE_MAIL_ZIP

/* ----------------------------------------------------- */
/* Zip mbox & board gem                                  */
/* ----------------------------------------------------- */


static int				/* 0:����  -1:�����T����} */
do_forward(fhdr, mode)
  HDR *fhdr;
  int mode;
{
  int rc;
  char *userid;
  char addr[64], fpath[64], cmd[256];

  strcpy(addr, cuser.email);

  if (!vget(b_lines - 1, 0, "�п�J��H�a�}�G", addr, 60, GCARRY))
    return 0;

  sprintf(fpath, "�T�w�H�� [%s] ��(Y/N)�H[N] ", addr);
  if (vans(fpath) != 'y')
    return 0;

  if (not_addr(addr))
    return -1;

#if 1	/* itoc.����: ���M bsmtp() �]�|���A���O�o������A�H�K���Y���~���D�O�L�Ī��u�@���a�} */
  userid = strchr(addr, '@') + 1;
  if (dns_smtp(userid) < 0)
    return -1;
#endif

  userid = cuser.userid;

  if (mode == 'M')		/* ���]�p�H��� */
  {
    usr_fpath(fpath, userid, "@");
  }
  else if (mode == 'B')		/* ���]�ݪO */
  {
    brd_fpath(fpath, currboard, NULL);
  }
  else if (mode == 'G')		/* ���]�ݪO��ذ� */
  {
    sprintf(fpath, "gem/brd/%s", currboard);
  }
  else if (mode == 'Z')		/* �ӤH��ذ� */
  {
    usr_fpath(fpath, userid, "gem");
  }

  sprintf(cmd, "tar cfz - %s | uuencode %s.tgz > tmp/%s.tgz", fpath, userid, userid);
  system(cmd);

  sprintf(fpath, "tmp/%s.tgz", userid);
  rc = bsmtp(fpath, fhdr->title, addr, 0);
  unlink(fpath);

  return rc;
}


int
m_zip()			/* itoc.010228: ���]��� */
{
  int ans;
  char buf[50];
  HDR fhdr;

  ans = vans("���]��� 1)�ӤH�H�� 2)�\\Ū�ݪO 3)�\\Ū�ݪO����ذ� 4)�ӤH��ذ� [Q] ");

  if (ans == '1')
  {
    sprintf(buf, "���] %s ���H��", cuser.userid);
    vmsg(buf);
    sprintf(fhdr.title, "�i" BBSNAME "�j%s �p�H���", cuser.userid);
    do_forward(&fhdr, 'M');
  }
  else if (ans == '2')
  {
    /* itoc.����: ���w�u�ॴ�]�ثe�\Ū���ݪO�A����\Ū���K�ݪO���H�N���ॴ�]�ӪO */
    /* itoc.020612: ���F���� POST_RESTRICT ���峹�~�y�A�D�O�D�N���ॴ�] */

    if (currbno >= 0 && (bbstate & STAT_BM))
    {
      sprintf(buf, "���]�ثe�\\Ū�ݪO %s", currboard);
      vmsg(buf);
      sprintf(fhdr.title, "�i" BBSNAME "�j%s �O", currboard);
      do_forward(&fhdr, 'B');
    }
  }
  else if (ans == '3')
  {
    /* itoc.����: ���w�u�ॴ�]�ثe�\Ū���ݪO�A����\Ū���K�ݪO���H�N���ॴ�]�ӪO����ذ� */
    /* itoc.020612: ���F���� GEM_RESTRICT ���峹�~�y�A�D�O�D�N���ॴ�] */

    if (currbno >= 0 && (bbstate & STAT_BOARD))
    {
      sprintf(buf, "���]�ثe�\\Ū�ݪO %s ����ذ�", currboard);
      vmsg(buf);
      sprintf(fhdr.title, "�i" BBSNAME "�j%s �O��ذ�", currboard);
      do_forward(&fhdr, 'G');
    }
  }
  else if (ans == '4')
  {
    sprintf(buf, "���] %s ����ذ�", cuser.userid);
    vmsg(buf);
    sprintf(fhdr.title, "�i" BBSNAME "�j%s �ӤH���", cuser.userid);
    do_forward(&fhdr, 'Z');
  }
  else
  {
    return XEASY;
  }

  return 0;
}
#endif	/* HAVE_MAIL_ZIP */


#ifdef HAVE_SIGNED_MAIL		/* Thor.990413: �������ҥ\�� */
int
m_verify()
{
  time_t chrono; 
  char info[79], *p;
  char sign[79], *q;
  char buf[160];

  char prikey[9];
  union
  {
    char str[9];
    struct
    {
      usint hash, hash2;
    } val;
  } s;

  prikey[8] = s.str[8] = '\0'; /* Thor.990413:����: �r�굲�� */

  if (rec_get(FN_RUN_PRIVATE, prikey, 8, 0))
  {
    zmsg("���t�ΨõL�q�lñ���A�Ь�����");
    return XEASY;
  }

  move(13, 0); 
  clrtobot();
  move(15, 0); 
  outs("�Ш̧ǿ�J�H����� X-Info X-Sign �H�i������");

  if (!vget(17, 0, ":", info, sizeof info, DOECHO) ||
     !vget(18, 0, ":", sign, sizeof sign, DOECHO))
    return 0;

  str_trim(info); /* Thor: �h����, for ptelnet�۰ʥ[�ť� */
  str_trim(sign);

  if (!memcmp("�� X-Info: ", p = info, 11))
    p += 11;
  while (*p == ' ') p++; /* Thor: �h�e�Y */

  if (!memcmp("�� X-Sign: ", q = sign, 11))
    q += 11;
  while (*q == ' ') q++;

  if (strlen(q) < 7 + 13) 
  {
    vmsg("�q�lñ�����~");
    return 0;
  }
      
  str_ncpy(s.str + 1, q, 8);	/* Thor: �ȭɤ@�U s.str */
  chrono = chrono32(s.str);	/* prefix 1 char */ 

  q += 7;		/* real sign */
  q[PASSLEN - 1] = 0;	/* �ɧ�0 */

  s.val.hash = str_hash(p, chrono);
  s.val.hash2 = str_hash2(p, s.val.hash);
  str_xor(s.str, prikey);

  sprintf(buf,"(%s)", Btime(&chrono));

  if (chkpasswd(q, s.str) || strcmp(q + PASSLEN, buf)) 
  { 
    /* Thor.990413: log usage */
    sprintf(buf,"%s@%s - XInfo:%s", rusername, fromhost, p);
    blog("VRFY", buf);
    /* Thor: fake sign */
    move(20, 25);
    outs("\033[41;37;5m *�`�N* �o�O�@�ʰ��H�I \033[m");
    vmsg("���H�ëD�ѥ����ҵo�A�Ьd��");
    return 0;
  }

  sprintf(buf,"%s@%s + XInfo:%s", rusername, fromhost, p);
  blog("VRFY", buf);

  vmsg("���H�ѥ����ҵo�X");
  return 0;
}
#endif

/* ----------------------------------------------------- */
/* mail routines					 */
/* ----------------------------------------------------- */


static struct
{
  XO mail_xo;
  char dir[32];
}      cmbox;


#ifdef OVERDUE_MAILDEL
usint
m_quota()
{
  usint ufo;
  int fd, count, fsize, limit, xmode;
  time_t mail_due, mark_due;
  struct stat st;
  HDR *head, *tail;
  char *base, *folder, date[9];

  if ((fd = open(folder = cmbox.dir, O_RDWR)) < 0)
    return 0;

  ufo = 0;
  fsize = 0;

  if (!fstat(fd, &st) && (fsize = st.st_size) >= sizeof(HDR) &&
    (base = (char *) malloc(fsize)))
  {

    /* flock(fd, LOCK_EX); */
    /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
    f_exlock(fd);

    if ((fsize = read(fd, base, fsize)) >= sizeof(HDR))
    {
      int prune;		/* number of pruned mail */

      limit = time(0);
      mail_due = limit - MAIL_DUE * 86400;
      mark_due = limit - MARK_DUE * 86400;
      st.st_mtime = limit + CHECK_PERIOD;
      str_stamp(date, &st.st_mtime);

      limit = cuser.userlevel;
      if (limit & (PERM_ALLADMIN | PERM_MBOX))
	limit = MAX_BBSMAIL;
      else
	limit = limit & PERM_VALID ? MAX_VALIDMAIL : MAX_NOVALIDMAIL;

      count = fsize / sizeof(HDR);

      head = (HDR *) base;
      tail = (HDR *) (base + fsize);

      prune = 0;

      do
      {
	/* itoc.011013.����: �o���[�W�F MAIL_DELETE�A�n�L CHECK_PERIOD �U�@���~�|�u���R�� */
	/* itoc.011013.����: ���F m_quota() �H�~�A�b bpop3.c �̭��A�Y���H�ɭn�D�q���A���W�R���A�]�|�[�W MAIL_DELETE ���X�� */

	xmode = head->xmode;
	if (xmode & MAIL_DELETE)
	{
	  char fpath[64];

	  hdr_fpath(fpath, folder, head);
	  unlink(fpath);
	  prune--;
	  continue;
	}

	if (!(xmode & MAIL_READ))
	  ufo |= UFO_BIFF;

	if ((count > limit) ||
	  (head->chrono <= (xmode & MAIL_MARKED ? mark_due : mail_due)))
	{
	  count--;
	  head->xmode = xmode | MAIL_DELETE;
	  strcpy(head->date, date);
	  ufo |= UFO_MQUOTA;
	}

	if (prune)
	  head[prune] = head[0];

      } while (++head < tail);

      fsize += (prune * sizeof(HDR));
      if ((fsize > 0) && (prune || (ufo & UFO_MQUOTA)))
      {
	lseek(fd, 0, SEEK_SET);
	write(fd, base, fsize);
	ftruncate(fd, fsize);
      }
    }

    /* flock(fd, LOCK_UN); */
    /* Thor.981205: �� fcntl ���Nflock, POSIX�зǥΪk */
    f_unlock(fd);

    free(base);
  }

  close(fd);
  if (fsize < sizeof(HDR))
    unlink(folder);

  return ufo;
}
#endif


usint
m_query(userid)
  char *userid;
{
  int fd, ans, fsize;
  HDR *head, *tail;
  char folder[64];
  struct stat st;

  ans = 0;
  usr_fpath(folder, userid, fn_dir);
  if ((fd = open(folder, O_RDONLY)) >= 0)
  {
    fsize = 0;

    if (!fstat(fd, &st) && (fsize = st.st_size) >= sizeof(HDR) &&
      (head = (HDR *) malloc(fsize)))
    {
      if ((fsize = read(fd, head, fsize)) >= sizeof(HDR))
      {
	tail = (HDR *) ((char *) head + fsize);

	while (--tail >= head)
	{
	  if (!(tail->xmode & MAIL_READ))
	  {
	    ans = UFO_BIFF;
	    break;
	  }
	}
      }
      free(head);
    }

    close(fd);
    if (fsize < sizeof(HDR))
      unlink(folder);
  }

  return ans;
}


void
m_biff(userno)
  int userno;
{
  UTMP *utmp, *uceil;

  utmp = ushm->uslot;
  uceil = (void *) utmp + ushm->offset;
  do
  {
    if (utmp->userno == userno)
    {
      utmp->ufo |= UFO_BIFF;

#ifdef	BELL_ONCE_ONLY
      return;
#endif
    }
  } while (++utmp <= uceil);
}


static int
m_count()
{
  int quota;
  usint ulevel;
  struct stat st;

  ulevel = cuser.userlevel;

  /* Thor.980806.����: DENYMAIL�b�g��Ȥ����ɷ|�blogin�۰ʳ]�w */
  if (ulevel & PERM_DENYMAIL)
  {
    vmsg(MSG_DENYMAIL);
    return 1;
  }

  if (stat(cmbox.dir, &st))
    return 0;

  if (ulevel & (PERM_ALLADMIN | PERM_MBOX))
    quota = MAX_BBSMAIL * sizeof(HDR);
  else if (ulevel & PERM_VALID)
    quota = MAX_VALIDMAIL * sizeof(HDR);
  else
    quota = MAX_NOVALIDMAIL * sizeof(HDR);

  if (st.st_size <= quota)
    return 0;

  more("etc/mail.over", NULL);
  return 1;
}


static void
mail_hold(fpath, rcpt)
  char *fpath;
  char *rcpt;
{
  char *title, *folder, buf[256];
  HDR mhdr;

  if (vans("�O�_�ۦs���Z(Y/N)�H[N] ") != 'y')
    return;

  folder = cmbox.dir;
  hdr_stamp(folder, HDR_LINK, &mhdr, fpath);

  mhdr.xmode = MAIL_READ | MAIL_HOLD;
  strcpy(mhdr.owner, "[�� �� ��]");
  strcpy(mhdr.nick, cuser.username);
  title = ve_title;
  if (rcpt)
  {
    sprintf(buf, "<%s> %s", rcpt, title);
    title = buf;
    title[TTLEN] = '\0';
  }
  strcpy(mhdr.title, title);
  rec_add(folder, &mhdr, sizeof(HDR));
}


#ifdef HAVE_AUTOFORWARD
int
m_setforward()
{
  char fpath[50], ip[50];
  FILE *fp;

  usr_fpath(fpath, cuser.userid, "forward");
  if (fp = fopen(fpath, "r"))
  {
    fscanf(fp, "%s", ip);
    fclose(fp);
  }
  else
  {
    ip[0] = '\0';
  }

  if (vget(b_lines - 1, 0, "�п�J�H��۰���H��E-mail��}:", ip, 41, 
GCARRY))
  {
    if (!not_addr(ip) && vans("�T�w�}�Ҧ۰���H�\\��(Y/N)�H[N] ") == 'y')
    {
      if (fp = fopen(fpath, "w"))
      {
        fprintf(fp, "%s", ip);
        fclose(fp);
        vmsg("�]�w����");
        return XEASY;
      }
    }
  }

  unlink(fpath);
  vmsg("�����۰���H�εL�� E-mail");
  return XEASY;
}


static void
forward_mail(fpath, userid)
  char *fpath, *userid;
{
  FILE *fp;
  char buf[50], title[50], ip[50];

  usr_fpath(buf, userid, "forward");
  if (fp = fopen(buf, "r"))
  {
    fscanf(fp, "%s", ip);
    fclose(fp);

    if (ip[0])
    {
      sprintf(title, "�۰���H�� �i%s�j%s ���H�c", BBSNAME, userid);
      bsmtp(fpath, title, ip, 0);
    }
  }
}
#endif	/* HAVE_AUTOFORWARD */


/* ----------------------------------------------------- */
/* in boards/mail �^�H����@�̡A��H����i		 */
/* ----------------------------------------------------- */


int
hdr_reply(row, hdr)
  int row;
  HDR *hdr;
{
  char *title, *str;

  title = str = ve_title;

  if (hdr)
  {
    sprintf(title, "Re: %s", str_ttl(hdr->title));
    str += TTLEN;
  }
  *str = '\0';

  return vget(row, 0, "���D�G", title, TTLEN + 1, GCARRY);
}


static inline int
is_host_alias(addr)
  char *addr;
{
  int i;
  char *str;
  static char *alias[] = HOST_ALIASES;

  /* check the aliases */

  for (i = 0; str = alias[i]; i++)
  {
    if (*str && !strcasecmp(addr, str))
      return 1;
  }
  return 0;
}


/* static inline */
int				/* 1:internet mail   0:�����H�H(�Ǧ^addr��userid) */
mail_external(addr)
  char *addr;
{
  char *str;

  str = strchr(addr, '@');	/* itoc.020125.����: email ��}�u���� ID�A���ܬO�����H�H */
  if (!str)
    return 0;

  if (!is_host_alias(str + 1))	/* itoc.020125: �p�G���b HOST_ALIAS ���A�����~�H�H */
    return 1;

  /* �����H�H: �d�I xyz@mydomain �� xyz.bbs@mydomain */

  *str = '\0';
  if (str = strchr(addr, '.'))
    *str = '\0';
  return 0;
}


int
mail_send(rcpt, title)
  char *rcpt, *title;
{
  HDR mhdr;
  char fpath[80], folder[80];
  int rc, userno;
  int internet_mail;

  if (!(internet_mail = mail_external(rcpt)))
  {
    if ((userno = acct_userno(rcpt)) <= 0)
      return -1;

    if (!title)
      vget(2, 0, "�D�D�G", ve_title, TTLEN, DOECHO);

    /* Thor.981105: �]���� internet_mail�i�Dvedit�A�ҥH��� curredit�����w�]�O�S�t�աA���L�Y�O��b�U���|��n */
    /* curredit |= EDIT_MAIL; */
  }

  utmp_mode(M_SMAIL);
  fpath[0] = '\0';

  curredit = EDIT_MAIL;		/* Thor.981105: �������w�g�H */

  if (vedit(fpath, internet_mail + 1) == -1)
  {
    unlink(fpath);
    clear();
    return -2;
  }

  if (internet_mail)
  {
    clear();
    prints("�H��Y�N�H�� %s\n���D���G%s\n�T�w�n�H�X��(Y/N)�H[Y] ", rcpt, title);
    switch (vkey())
    {
    case 'n':
    case 'N':
      outs("N\n�H��w����");
      refresh();
      rc = -2;
      break;

    default:
      outs("Y\n�еy��, �H��ǻ���...\n");
      refresh();
      rc = bsmtp(fpath, title, rcpt, 0);
      if (rc < 0)
	vmsg("�H��L�k�H�F");
      mail_hold(fpath, rcpt);
    }
    unlink(fpath);
    return rc;
  }

  usr_fpath(folder, rcpt, fn_dir);
  hdr_stamp(folder, HDR_LINK, &mhdr, fpath);
  strcpy(mhdr.owner, cuser.userid);
  strcpy(mhdr.nick, cuser.username);	/* :chuan: �[�J nick */
  strcpy(mhdr.title, ve_title);
  rc = rec_add(folder, &mhdr, sizeof(mhdr));
  if (!rc)
  {
    mail_hold(fpath, rcpt);
  }

#ifdef HAVE_AUTOFORWARD
  /* Internet �۰���H */
  forward_mail(fpath, rcpt);
#endif

  unlink(fpath);
  m_biff(userno);

  return rc;
}


void
mail_reply(hdr)
  HDR *hdr;
{
  int xmode, prefix;
  char *msg, buf[80];

  if ((hdr->xmode & MAIL_NOREPLY) || m_count())
    return;

  vs_bar("�^  �H");

  /* find the author */

  strcpy(quote_user, hdr->owner);
  strcpy(quote_nick, hdr->nick);

  /* make the title */

  if (!hdr_reply(3, hdr))
    return;

  prints("\n���H�H: %s (%s)\n��  �D: %s\n", quote_user, quote_nick, ve_title);

  /* Thor: ���F�٤@�� rec_put �^�H�h���]�ݹL���e */

  xmode = hdr->xmode | MAIL_READ;
  prefix = quote_file[0];

  /* edit, then send the mail */

  switch (mail_send(quote_user, ve_title))
  {
  case -1:
    msg = err_uid;
    break;

  case -2:
    msg = msg_cancel;
    break;

  case -3:  /* Thor.980707: �������p�� ?*/
    sprintf(msg = buf, "[%s] �L�k���H", quote_user);
    break;

  default:
    xmode |= MAIL_REPLIED;
    msg = "�H�w�H�X";  /* Thor.980705: mail_send()�w�g��ܹL�@���F.. �����ܡH */
    break;
  }

  if (prefix == 'u')  /* user mail �ݫH�ɤ~�� r */
  {
    hdr->xmode = xmode;
  }

  vmsg(msg);
}


void
my_send(rcpt)
  char *rcpt;
{
  int result;
  char *msg;

  if (m_count())
    return;

  msg = "�H�w�H�X";

  if (result = mail_send(rcpt, NULL))
  {
    switch (result)
    {
    case -1:
      msg = err_uid;
      break;

    case -2:
      msg = msg_cancel;
      break;

    case -3:  /* Thor.980707: �������p�� ?*/
      msg = "�ϥΪ̵L�k���H";
    }
  }
  vmsg(msg);
}


int
m_send()
{
  ACCT muser;

  vs_bar("�H  �H");

  if (acct_get(msg_uid, &muser) > 0)
    my_send(muser.userid);
  return 0;
}


int
mail_sysop()
{
  int fd;

  if ((fd = open(FN_ETC_SYSOP, O_RDONLY)) >= 0)
  {
    int i, j;
    char *ptr, *str;

    struct SYSOPLIST
    {
      char userid[IDLEN + 1];
      char duty[40];
    }         sysoplist[7];	/* ���] 7 �Ө��o */

    j = 0;
    mgets(-1);
    while (str = mgets(fd))
    {
      if (ptr = strchr(str, ':'))
      {
	*ptr = '\0';
	do
	{
	  i = *++ptr;
	} while (i == ' ' || i == '\t');

	if (i)
	{
	  strcpy(sysoplist[j].userid, str);
	  strcpy(sysoplist[j++].duty, ptr);
	}
      }
    }
    close(fd);

    move(12, 0);
    clrtobot();
    prints("%16s   %-18s�v�d����\n%s\n", "�s��", "���� ID", msg_seperator);

    for (i = 0; i < j; i++)
    {
      prints("%15d.   \033[1;%dm%-16s%s\033[m\n",
	i + 1, 31 + i, sysoplist[i].userid, sysoplist[i].duty);
    }
    prints("%-14s0.   \033[1;%dm���}\033[m", "", 31 + j);

    i = vans("�п�J�N�X�G[0] ") - '1';
    if (i >= 0 && i < j)
    {
      clear();
      mail_send(sysoplist[i].userid, NULL);
    }
  }
  return 0;
}


void
mail_self(fpath, owner, title, xmode)		/* itoc.011115: �H�ɮ׵��ۤv */
  char *fpath;		/* �ɮ׸��| */
  char *owner;		/* �H��H */
  char *title;		/* �l����D */
  usint xmode;
{
  HDR fhdr;
  char folder[64];

  usr_fpath(folder, cuser.userid, fn_dir);
  hdr_stamp(folder, HDR_LINK, &fhdr, fpath);
  strcpy(fhdr.owner, owner);
  strcpy(fhdr.title, title);
  fhdr.xmode = xmode;
  rec_add(folder, &fhdr, sizeof(HDR));
}


/* ----------------------------------------------------- */
/* �s�ձH�H�B�^�H : multi_send, multi_reply		 */
/* ----------------------------------------------------- */


#ifdef MULTI_MAIL	/* Thor.981009: ����R�����B�H */

static int
multi_send(title)
  char *title;
{
  FILE *fp;
  HDR mhdr;
  char buf[128], fpath[64], *userid;
  int userno, reciper, listing;
  LinkList *wp;

  vs_bar(title ? "�s�զ^�H" : "�s�ձH�H");

  ll_new();
  listing = reciper = 0;

  /* �^�H��Ū�� mail list �W�� */

  if (*quote_file)
  {
    ll_add(quote_user);
    reciper = 1;

    fp = fopen(quote_file, "r");
    while (fgets(buf, sizeof(buf), fp))
    {
      if (memcmp(buf, "�� ", 3))
      {
	if (listing)
	  break;
      }
      else
      {
	userid = buf + 3;
	if (listing)
	{
	  strtok(userid, " \n\r");
	  do
	  {
	    if ((userno = acct_userno(userid)) && (userno != cuser.userno) &&
	      !ll_has(userid))
	    {
	      ll_add(userid);
	      reciper++;
	    }
	  } while (userid = (char *) strtok(NULL, " \n\r"));
	}
	else if (!memcmp(userid, "[�q�i]", 6))
	  listing = 1;
      }
    }
    fclose(fp);
    ll_out(3, 0, MSG_LL);
  }

  /* �]�w mail list ���W�� */

  reciper = pal_list(reciper);

  /* �}�l�H�H */

  move(1, 0);
  clrtobot();

  if (reciper == 1)
  {
    mail_send(ll_head->data, title);
  }
  else if (reciper >= 2 && ve_subject(2, title, "[�q�i] "))
  {
    usr_fpath(fpath, cuser.userid, fn_note);

    if (fp = fopen(fpath, "w"))
    {
      fprintf(fp, "�� [�q�i] �@ %d �H����", reciper);
      listing = 80;
      wp = ll_head;

      do
      {
	userid = wp->data;
	reciper = strlen(userid) + 1;

	if (listing + reciper > 75)
	{
	  listing = reciper;
	  fprintf(fp, "\n��");
	}
	else
	{
	  listing += reciper;
	}

	fprintf(fp, " %s", userid);
      } while (wp = wp->next);

      memset(buf, '-', 75);
      buf[75] = '\0';
      fprintf(fp, "\n%s\n\n", buf);
      fclose(fp);
    }

    utmp_mode(M_SMAIL);
    curredit = EDIT_MAIL | EDIT_LIST;

    if (vedit(fpath, 1) == -1)
    {
      vmsg(msg_cancel);
      unlink(fpath);
      return -1;
    }
    else
    {
      vs_bar("�H�H��...");

      listing = 80;
      wp = ll_head;
      title = ve_title;
      userno = 2;	/* �ɥ� userno ���L����@�� */

      do
      {
	userid = wp->data;
	if (userno < b_lines)	/* �̦h�L�� b_lines - 1 */
	{
	  /* �L�X�ثe�H����@�� id */
	  reciper = strlen(userid) + 1;
	  if (listing + reciper > 75)
	  {
	    listing = reciper;
	    outc('\n');
	    userno++;
	  }
	  else
	  {
	    listing += reciper;
	    outc(' ');
	  }
	  outs(userid);
	}

	usr_fpath(buf, userid, fn_dir);
	hdr_stamp(buf, HDR_LINK, &mhdr, fpath);
	strcpy(mhdr.owner, cuser.userid);
	strcpy(mhdr.title, title);
	mhdr.xmode = MAIL_MULTI;
	rec_add(buf, &mhdr, sizeof(HDR));
      } while (wp = wp->next);

      mail_hold(fpath, NULL);
      vmsg("�H�w�H�X");
      unlink(fpath);
    }
  }
  else
  {
    vmsg(msg_cancel);
    return -1;
  }
  
  return 0;
}


static void
multi_reply(mhdr)
  HDR *mhdr;
{
  strcpy(quote_user, mhdr->owner);
  strcpy(quote_nick, mhdr->nick);
  if (!multi_send(mhdr->title))
    mhdr->xmode |= (MAIL_REPLIED | MAIL_READ);
}


int
mail_list()
{
  if (!m_count())
    multi_send(NULL);

  return 0;
}

#endif


/* ----------------------------------------------------- */
/* Mail Box call-back routines				 */
/* ----------------------------------------------------- */


static inline int
mbox_attr(type)
  int type;
{
#ifdef OVERDUE_MAILDEL
  if (type & MAIL_DELETE)
    return 'D';
#endif

  if (type & MAIL_REPLIED)
    return (type & MAIL_MARKED) ? 'R' : 'r';

  return "+ Mm"[type & 3];
}


static void
mbox_item(num, hdr)
  int num;			/* sequence number */
  HDR *hdr;
{
#ifdef OVERDUE_MAILDEL
  int xmode;

  xmode = hdr->xmode;
  prints(xmode & MAIL_DELETE ? "%6d%c\033[1;5;37;41m%c\033[m " : "%6d%c%c ",
    num, tag_char(hdr->chrono), mbox_attr(xmode));
#else
  prints("%6d%c%c ", num, tag_char(hdr->chrono), mbox_attr(hdr->xmode));
#endif

  hdr_outs(hdr, 47);
}


static int
mbox_body(xo)
  XO *xo;
{
  HDR *mhdr;
  int num, max, tail;

  max = xo->max;
  if (max <= 0)
  {
    vmsg("�z�S���ӫH");
    return XO_QUIT;
  }

  num = xo->top;
  mhdr = (HDR *) xo_pool;
  tail = num + XO_TALL;
  if (max > tail)
    max = tail;

  move(3, 0);
  do
  {
    mbox_item(++num, mhdr++);
  } while (num < max);
  clrtobot();

  /* return XO_NONE; */
  return XO_FOOT;	/* itoc.010403: �� b_lines ��W feeter */
}


static int
mbox_head(xo)
  XO *xo;
{
  if (cutmp->ufo & UFO_BIFF)	/* �@�i�J�H�c�N���� UFO_BIFF */
    cutmp->ufo ^= UFO_BIFF;

  vs_head("�l����", str_site);
  outs(NECKER_MBOX);
  return mbox_body(xo);
}


static int
mbox_load(xo)
  XO *xo;
{
  xo_load(xo, sizeof(HDR));
  return mbox_body(xo);
}


static int
mbox_init(xo)
  XO *xo;
{
  xo_load(xo, sizeof(HDR));
  return mbox_head(xo);
}


static int
mbox_delete(xo)
  XO *xo;
{
  int pos;
  HDR *hdr;
  char fpath[64], *dir;

  pos = xo->pos;
  hdr = (HDR *) xo_pool + (pos - xo->top);

#ifdef OVERDUE_MAILDEL
  /* Thor.980901: mark ��Y�Q'D'�_�ӡA�h�@�˥i�H delete�A�u�� MARK & no delete �~�|�L�� */
  if ((hdr->xmode & (MAIL_MARKED | MAIL_DELETE)) == MAIL_MARKED)
#else
  if (hdr->xmode & MAIL_MARKED)
#endif
    return XO_NONE;

  if (vans(msg_del_ny) == 'y')
  {
    dir = xo->dir;
    currchrono = hdr->chrono;
    if (!rec_del(dir, sizeof(HDR), pos, cmpchrono))
    {
      hdr_fpath(fpath, dir, hdr);
      unlink(fpath);
      return XO_LOAD;
    }
  }
  return XO_FOOT;
}


static int
mbox_forward(xo)
  XO *xo;
{
  if (!m_count())
    return post_forward(xo);	/* itoc.011230: �P post_forward() �@�� */    

  return XO_NONE;      
}


static int      /* itoc.000513: ���HŪ��@�b�]�� reply mark delete */
mbox_browse(xo)
  XO *xo;
{
  HDR *mhdr;
  int pos, xmode, nmode;
  char *dir, *fpath;

  dir = xo->dir;

  for (;;)
  {
    pos = xo->pos;
    fpath = quote_file;
    mhdr = (HDR *) xo_pool + (pos - xo->top);
    strcpy(currtitle, str_ttl(mhdr->title));
    xmode = mhdr->xmode;
    hdr_fpath(fpath, dir, mhdr);

    if ((nmode = more(fpath, FOOTER_MAILER)) < 0)
      break;

    /* itoc.010324: �q���ӽg�����H��n�]���wŪ�A�H�K�@�����ťթ��UŪ�A�u��̫�@�g�]�wŪ */
    if (nmode == 0 && !(xmode & MAIL_READ))
    {
      mhdr->xmode = xmode | MAIL_READ;
      rec_put(dir, mhdr, sizeof(HDR), pos, NULL);
    }

    switch (xo_getch(xo, nmode))
    {
    case XO_BODY:
      continue;

    /* itoc.001125: �� [r]�^�H [y]�s�զ^�H ���} */
    case 'y':
      if (!(xmode & MAIL_NOREPLY) && !m_count())
      {
#ifdef MULTI_MAIL
	if (xmode & MAIL_MULTI && vans(MSG_MULTIREPLY) == 'y')
	  multi_reply(mhdr);
	else
#endif
	  mail_reply(mhdr);
      }
      break;
    
    case 'r':
      if (!(xmode & MAIL_NOREPLY) && !m_count())
        mail_reply(mhdr);
      break;

    case 'd':
      if (mbox_delete(xo) == XO_LOAD)
      {
        *fpath = '\0';
        return mbox_init(xo);
      }
      break;

    case 'm':
      /* mhdr->xmode ^= MAIL_MARKED; */
      /* �b mbox_browse �ɬݤ��� m �O���A�ҥH����u�� mark */
      mhdr->xmode |= MAIL_MARKED;
      break;

    case 'x':	/* itoc.011231: mbox_browse �ɥi����H�h�ݪO */
      post_cross(xo);
      break;


    case 'X':
      mbox_forward(xo);
      break;

    case 'C':	/* itoc.000515: mbox_browse �ɥi�s�J�Ȧs�� */
      {
        FILE *fp;
        if (fp = tbf_open())
        { 
          f_suck(fp, fpath); 
          fclose(fp);
        }
      }
      break;

    case 'h':
      xo_help("mbox");
      break;                

    }
    break;
  }

  nmode = mhdr->xmode | MAIL_READ;
  if (xmode != nmode)
  {
    mhdr->xmode = nmode;
    rec_put(dir, mhdr, sizeof(HDR), pos, NULL);
  }
  *fpath = '\0';

  return mbox_head(xo);
}


static int
mbox_reply(xo)
  XO *xo;
{
  int pos, xmode;
  HDR *mhdr;

  if (m_count())
    return mbox_head(xo);

  pos = xo->pos;
  mhdr = (HDR *) xo_pool + pos - xo->top;

  xmode = mhdr->xmode;
  if (xmode & MAIL_NOREPLY)
    return XO_NONE;

  hdr_fpath(quote_file, xo->dir, mhdr);

#ifdef MULTI_MAIL
  /* itoc.001125: �`���H�~���s�ձH�H�A�T�w�@�U */
  if (xmode & MAIL_MULTI && vans(MSG_MULTIREPLY) == 'y')
    multi_reply(mhdr);
  else
#endif
    mail_reply(mhdr);

  *quote_file = '\0';

  if (mhdr->xmode != xmode)
    rec_put(xo->dir, mhdr, sizeof(HDR), pos, NULL);

  return mbox_head(xo);
}


static int
mbox_edit(xo)		/* itoc.010301: �i�H�s��ۤv�H�c�����H */
  XO *xo;
{
  char fpath[64];
  HDR *mhdr;

  mhdr = (HDR *) xo_pool + (xo->pos - xo->top);
  hdr_fpath(fpath, xo->dir, mhdr);

  if (!strcmp(mhdr->owner, cuser.userid) || HAS_PERM(PERM_ALLBOARD))	/* �ۤv�H���ۤv���H�άO���� */
    vedit(fpath, 0);
  else
    vedit(fpath, -1);	/* �u��s�褣�i�x�s */

  return mbox_head(xo);
}


static int
mbox_title(xo)		/* itoc.020113: �i�H��ۤv�H�c�������D */
  XO *xo;
{
  HDR *fhdr, mhdr;
  int pos, cur;

  pos = xo->pos;
  cur = pos - xo->top;
  fhdr = (HDR *) xo_pool + cur;
  mhdr = *fhdr;

  if (strcmp(cuser.userid, mhdr.owner) && !HAS_PERM(PERM_ALLBOARD))
    return XO_NONE;

  vget(b_lines, 0, "���D�G", mhdr.title, sizeof(mhdr.title), GCARRY);

  if (HAS_PERM(PERM_ALLBOARD))	/* itoc.000213: ��@�̥u�����D */
  {
    vget(b_lines, 0, "�@�̡G", mhdr.owner, 74 /* sizeof(mhdr.owner)*/, GCARRY);
    		/* Thor.980727: sizeof(mhdr.owner) = 80 �|�W�L�@�� */
    vget(b_lines, 0, "�ʺ١G", mhdr.nick, sizeof(mhdr.nick), GCARRY);
    vget(b_lines, 0, "����G", mhdr.date, sizeof(mhdr.date), GCARRY);
  }

  if (memcmp(fhdr, &mhdr, sizeof(HDR)) && vans(msg_sure_ny) == 'y')
  {
    *fhdr = mhdr;
    rec_put(xo->dir, fhdr, sizeof(HDR), pos, NULL);
    move(3 + cur, 0);
    mbox_item(++pos, fhdr);

    /* itoc.010709: �ק�峹���D���K�ק鷺�媺���D */
    header_replace(xo, fhdr);
  }
  return XO_FOOT;
}

 
static int
mbox_mark(xo)
  XO *xo;
{
  HDR *mhdr;
  int cur, pos;

  pos = xo->pos;
  cur = pos - xo->top;
  mhdr = (HDR *) xo_pool + cur;
  move(3 + cur, 7);
  outc(mbox_attr(mhdr->xmode ^= MAIL_MARKED));
  rec_put(xo->dir, mhdr, sizeof(HDR), pos, NULL);
  return XO_NONE;
}


static int
mbox_tag(xo)
  XO *xo;
{
  HDR *hdr;
  int tag, pos, cur;

  pos = xo->pos;
  cur = pos - xo->top;
  hdr = (HDR *) xo_pool + cur;

  if (tag = Tagger(hdr->chrono, pos, TAG_TOGGLE))
  {
    move(3 + cur, 6);
    outc(tag > 0 ? '*' : ' ');
  }

  /* return XO_NONE; */
  return xo->pos + 1 + XO_MOVE; /* lkchu.981201: ���ܤU�@�� */
}


static int
mbox_send(xo)
  XO *xo;
{
  m_send();
  return mbox_head(xo);
}


static int
mbox_visit(xo)
  XO *xo;
{
  int pos, fd;
  char *dir;
  HDR *mhdr;

  pos = vans("�]�w�Ҧ��H�� (V)�wŪ (Q)�����H[Q] ");
  if (pos == 'v')
  {
    if (cutmp->ufo & UFO_BIFF)
      cutmp->ufo ^= UFO_BIFF;

    dir = xo->dir;
    if ((fd = open(dir, O_RDONLY)) < 0)
      return XO_FOOT;

    pos = 0;
    mgets(-1);
    while (mhdr = mread(fd, sizeof(HDR)))
    {
      if (!(mhdr->xmode & MAIL_READ))
      {
	mhdr->xmode |= MAIL_READ;
	rec_put(dir, mhdr, sizeof(HDR), pos, NULL);
      }
      pos++;
    }
    close(fd);

    return mbox_init(xo);
  }
  return XO_FOOT;
}


static int
mbox_sysop(xo)	/* itoc.001029.����: ��K SYSOPs �� sysop/guest ���H */
  XO *xo;
{
  if ((xo == (XO *) & cmbox) && HAS_PERM(PERM_SYSOP))
  {
    XO *xx;
    char fpath[64];

#ifdef SYSOP_CHECK_MAIL	/* itoc.001029: SYSOPs �i�H�� user �H�c */
    char uid[IDLEN + 1];
    ACCT acct;

    vget(1, 0, msg_uid, uid, IDLEN + 1, DOECHO);
    if (*uid && (acct_load(&acct, uid) > 0))
    {
      usr_fpath(fpath, uid, fn_dir);
      xz[XZ_MBOX - XO_ZONE].xo = xx = xo_new(fpath);
    }
    else
    {
      vmsg(err_uid);
      return mbox_init(xo);	/* itoc.010311: ��J���~ id �H�ᤣ xover */
    }
#else
    int ch;

    sprintf(fpath, "�i�J (1)%s (2)%s ���H�c�H[1] ", str_sysop, STR_GUEST);
    ch = vans(fpath);
    usr_fpath(fpath, ch == '2' ? STR_GUEST : str_sysop, fn_dir);
    xz[XZ_MBOX - XO_ZONE].xo = xx = xo_new(fpath);
#endif
    xover(XZ_MBOX);
    free(xx);

    xz[XZ_MBOX - XO_ZONE].xo = xo;
    return mbox_init(xo);
  }

  return XO_NONE;
}


static int
mbox_gem(xo)		/* itoc.010727: �N�ӤH��ذϩM�ݪO��ذϾ�X */
  XO *xo;
{
  char fpath[64];

  usr_fpath(fpath, cuser.userid, "gem/.DIR");
  /* �ӤH��ذϥu���� GEM_MANAGER�A���ݭn GEM_SYSOP */
  XoGem(fpath, "�ӤH��ذ�", GEM_MANAGER);
  return mbox_init(xo);
}


static int
mbox_copy(xo)		/* itoc.011025: ���N gem_gather */
  XO *xo;
{
  int tag;

  tag = AskTag("�H�c�峹����");

  if (tag < 0)
    return XO_FOOT;

  gem_buffer(xo->dir, tag ? NULL : (HDR *) xo_pool + (xo->pos - xo->top));

  zmsg("�ɮ׼аO�����C[�`�N] ������~��R�����I");
  return mbox_gem(xo);		/* �����������i��ذ� */
}


static int
mbox_help(xo)
  XO *xo;
{
  xo_help("mbox");
  return mbox_head(xo);
}


static KeyFunc mbox_cb[] =
{
  XO_INIT, mbox_init,
  XO_LOAD, mbox_load,
  XO_HEAD, mbox_head,
  XO_BODY, mbox_body,

  'r', mbox_browse,
  's', mbox_send,
  'd', mbox_delete,
  'x', post_cross,	/* �b post/mbox �����O�p�g x ��ݪO�A�j�g X ��ϥΪ� */
  'X', mbox_forward,
  'E', mbox_edit,
  'T', mbox_title,
  'm', mbox_mark,
  'R', mbox_reply,
  'y', mbox_reply,
  'v', mbox_visit,

#ifdef CHECK_ONLINE
  'w', post_write,	/* itoc.010408: �ɥ� post_write �Y�i */
#endif

  KEY_TAB, mbox_sysop,
  'z', mbox_gem,
  'c', mbox_copy,
  'g', gem_gather,

  't', mbox_tag,

  'D', xo_delete,

  Ctrl('Q'), xo_uquery,
  Ctrl('O'), xo_usetup,

  'h', mbox_help
};


void
mbox_main()
{
  cmbox.mail_xo.pos = XO_TAIL;
  usr_fpath(cmbox.dir, cuser.userid, fn_dir);
  xz[XZ_MBOX - XO_ZONE].xo = (XO *) &cmbox;
  xz[XZ_MBOX - XO_ZONE].cb = mbox_cb;
}
