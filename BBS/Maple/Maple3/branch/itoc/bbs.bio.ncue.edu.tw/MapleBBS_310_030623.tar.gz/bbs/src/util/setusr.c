/*-------------------------------------------------------*/
/* util/setusr.c	( NTHU CS MapleBBS Ver 3.10 )    */
/*-------------------------------------------------------*/
/* target : �]�w�ϥΪ̸��                               */
/* author : itoc.bbs@bbs.tnfsh.tn.edu.tw                 */
/* create : 01/07/16                                     */
/* update :                                              */
/*-------------------------------------------------------*/


#if 0
  �]�w itoc �� �m�W�����j�� �ʺ٬��j�� �ȹ���1000 ������500
  setusr -r ���j�� -n �j�� -m 1000 -g 500 itoc

  �]�w itoc ���v��
  setusr -p 11100...1101 itoc
            ^^^^^ 32 �� 0 �M 1  (32 �O�]���v���� 32 = strlen(STR_PERM) ��)

  �]�w itoc ���ߺD
  setusr -f 11100...1101 itoc
            ^^^^^ 26 �� 0 �M 1  (26 �O�]���ߺD�� 26 = strlen(STR_UFO) ��)
#endif


#include "bbs.h"


#define MAXUSIES	9	/* �@�� 9 �إi�H�諸 */

static void
usage(msg)
  char *msg;
{
  int i, len;
  char buf[80];
  char *usies[MAXUSIES] =
  {
    "r realname", "n username", "m money", "g gold", "# userno", 
    "e email", "j 1/0(justify)", "p userlevel", "f ufo"
  };


  printf("Usage: %s [-%s] [-%s] [-%s] ... [-%s] UserID\n", 
    msg, usies[0], usies[1], usies[2], usies[MAXUSIES - 1]);
  len = strlen(msg);
  sprintf(buf, "%%%ds-%%s\n", len + MAXUSIES);
  for (i = 0; i < MAXUSIES; i++)
    printf(buf, "", usies[i]);

  exit(1);
}


static usint
bitcfg(len, msg, str)	/* config bits */
  int len;		/* ����쪺���� */
  char *msg;		/* argv[0] �� usage() �Ϊ� */
  char *str;		/* argv[i + 1] */
{
  int i;
  usint bits;

  if (strlen(str) != len)
  {
    bits = (usint) atoi(str);
  }
  else
  {
    char c;

    bits = 0;
    for (i = 0; i < len; i++)
    {
      c = str[i];

      if (c != '0' && c != '1')
        usage(msg);

      bits <<= 1;
      bits |= c - '0';
    }
  }

  return bits;
}


int
main(argc, argv)
  int argc;
  char *argv[];
{
  ACCT cuser;
  int i;
  char fpath[64];
  char ch;

  if (argc < 4 || argc % 2)	/* argc �n�O���� */
    usage(argv[0]);

  chdir(BBSHOME);
  usr_fpath(fpath, argv[argc - 1], FN_ACCT);
  if (rec_get(fpath, &cuser, sizeof(cuser), 0) < 0)
  {
    printf("%s: read error (maybe no such id?)\n", argv[argc - 1]);
    exit(1);
  }

  for (i = 1; i < argc - 1; i += 2)
  {
    if (argv[i][0] == '-')
    {
      ch = argv[i][1];
      if (ch == 'r')		/* -r : realname */
      {
	strcpy(cuser.realname, argv[i + 1]);
      }
      else if (ch == 'n')	/* -n : username */
      {
	strcpy(cuser.username, argv[i + 1]);
      }
      else if (ch == 'm')	/* -m : money */
      {
	cuser.money = (usint) atoi(argv[i + 1]);
      }
      else if (ch == 'g')	/* -g : gold */
      {
	cuser.gold = (usint) atoi(argv[i + 1]);
      }
      else if (ch == '#')	/* -# : userno */
      {
	cuser.userno = atoi(argv[i + 1]);
      }
      else if (ch == 'e')	/* -e : email */
      {
	strcpy(cuser.email, argv[i + 1]);
      }
      else if (ch == 'j')      /* -j : justify */
      {
        if (atoi(argv[i + 1])) /* justify �q�L */
        {
          cuser.userlevel |= PERM_VALID;
          time(&cuser.tvalid);
        }
        else
        {
          cuser.userlevel &= ~PERM_VALID;
        }
      }
      else if (ch == 'p')	/* -p : userlevel */
      {
	cuser.userlevel = bitcfg(NUMPERMS, argv[0], argv[i + 1]);
      }
      else if (ch == 'f')	/* -f : ufo */
      {
	cuser.ufo = bitcfg(strlen(STR_UFO), argv[0], argv[i + 1]);
      }
      else
      {
	usage(argv[0]);
      }
    }
  }

  if (rec_put(fpath, &cuser, sizeof(cuser), 0, NULL) < 0)
    printf("%s: write error\n", argv[argc - 1]);
}
