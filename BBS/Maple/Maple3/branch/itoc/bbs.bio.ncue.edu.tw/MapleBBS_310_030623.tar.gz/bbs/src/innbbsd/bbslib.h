#ifndef _BBSLIB_H_
#define _BBSLIB_H_


typedef struct nodelist_t
{
  char *node;		/* �ӯ��� short-name */
  char *host;		/* �ӯ��� host */
  char *protocol;	/* �ӯ��� protocol */
  char *comment;	/* �ӯ��� ���� */
  FILE *feedfp;
} nodelist_t;


typedef struct newsfeeds_t
{
  char *newsgroups;
  char *board;
  char *path;
  char *charset;
} newsfeeds_t;


/* bbslib.c */
extern char MYBBSID[];

/* innbbsd library */
extern int inetclient();
extern int unixclient();
extern int isfile();
extern int iszerofile();
extern char *fileglue();
extern void verbosefile();
extern void setverboseon();
extern void setverboseoff();
extern int isverboselog();
extern void verboselog();
extern void bbslog();

/* bbslib.c */
extern int NLCOUNT;
extern nodelist_t *NODELIST;
extern int nl_bynodecmp();

/* bbslib.c */
extern int NFCOUNT;
extern newsfeeds_t *NEWSFEEDS;
extern newsfeeds_t **NEWSFEEDS_BYBOARD;
extern int nf_bygroupcmp();
extern int nf_byboardcmp(); 

/* bbslib.c */
extern int initial_bbs();

#endif	/* _BBSLIB_H_ */
