#include "daemon.h"


static daemoncmd_t *dcmdp = NULL;
static char *startupmessage = NULL;
static int startupcode = 100;


void 
installdaemon(cmds, code, startupmsg)
  daemoncmd_t *cmds;
  int code;
  char *startupmsg;
{
  dcmdp = cmds;
  startupcode = code;
  startupmessage = startupmsg;
}


daemoncmd_t *
searchcmd(cmd)
  char *cmd;
{
  register daemoncmd_t *p;
  register char *name;

  for (p = dcmdp; name = p->name; p++)
  {
    if (!strncasecmp(name, cmd, 1024))
      return p;
  }
  return NULL;
}


#define MAX_ARG 16
#define MAX_ARG_SIZE 1024	/* 16384 */

int 
argify(line, argvp)
  char *line, ***argvp;
{
  static char *argvbuffer[MAX_ARG + 2];
  register char **argv = argvbuffer;
  register int i;
  static char argifybuffer[MAX_ARG_SIZE];
  register char *p;

  while (strchr("\t\n\r ", *line))
    line++;
  p = argifybuffer;
  strncpy(p, line, sizeof(argifybuffer));
  for (*argvp = argv, i = 0; *p && i < MAX_ARG;)
  {
    for (*argv++ = p; *p && !strchr("\t\r\n ", *p); p++);
    if (*p == '\0')
      break;
    for (*p++ = '\0'; strchr("\t\r\n ", *p) && *p; p++);
  }
  *argv = NULL;
  return argv - *argvp;
}
