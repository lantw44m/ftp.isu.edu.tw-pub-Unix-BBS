<html>
<head><title>SendMsg</title></head>
<body>

<?php
require_once('config.php');
require_once('webbbs.class.php');

function error_quit($msg)
{
 $msg = addslashes($msg);
 echo "<html>��k�����\!</html>\n";
 exit;
}

if(!$pid || !$uno || !$msg)  error_quit("�եο��~�I");

$ws = new server_class;
$ws->connect();

$cmd = $ws->set_cmd("bmw_send", G_TALK, $pid, $uno, $msg);

$ws->query($cmd);
$ret = $ws->parse();

if($ret[result] != "OK")
 $ws->alert($ws->data);
?>
</body>
</html>

<?php
 exit();
?>
