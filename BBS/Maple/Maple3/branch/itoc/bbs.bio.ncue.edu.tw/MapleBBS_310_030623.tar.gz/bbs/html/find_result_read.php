<?php
//Post Read
require_once('config.php');

unset($cuser);
session_start();

if(!isset($num)) $num = 1;

$pid = $cuser[pid];
if(!$pid) {
	echo "<html>�z�w�g�_�}�s��! �Ы�F5��s����!</html>";
	exit; 
}

function alertMsg($msg) {
	return "<font color=red><b>".$msg."</b></font>";
}

?>
 
<html>
<head>
<title>Post List</title>
<meta http-equiv="Content-Type" content="text/html;charset=big5">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
A {color: #0000a0}
A:visited {color: #0000a0}
PRE {color: #c0c0c0}
</style>
<script language="javascript">
<!--
 function do_go() {
	 var num = document.go.num.value;
	 var page = num / 20;

	 if(num % 20) page++;
	 document.go.page.value = page;
}
//-->
</script>
</head>
<body leftmargin="3" topmargin="0" marginwidth="3" marginheight="0" bgcolor="#FFFFFF">
<table width="617" border="0" cellspacing="0" cellpadding="0">
  <tr><td>
    &nbsp;&nbsp;<font size=3 color=green> �� �峹�j�����G�\Ū </font>  [<a href='javascript: window.history.back()'>��^�W��</a>]
  </td></tr>
  <tr> 
    <td height="100%" width="100%">
	  <table width="96%" border="0" cellspacing="0" cellpadding="3" align="center">
		<?php
		//��ܹ�
		require_once('webbbs.class.php');

		$ws = new server_class;
		$ws->connect();

		$cmd = $ws->set_cmd("p_read", G_BOARD, $pid, $board, $num);
		$ws->query($cmd);
		
		$data = split("\n", $ws->data, 2); /* \n�@�j�} */
		$ret = $ws->parse($data[0]);
		if($ret[result] != 'OK') {
			echo "<br><br>";
			echo alertMsg($ws->data);
			echo "<br><br><a href='postlist.php?board=$board&page=$page&num=$num'>[������^]</a>";
			exit;
		}
	
		$prv = $num-1;
		$nxt = $num+1;
		
		/* �]�mGoTo Page */
		$gotoString  = "�j�����G�G [<a href='postlist.php?board=$board'>$board</a>]�� <font color=a00000>".$num."</font>/".$ret[max]." �g";

		if(intval($ret[reply]) == 1) {
			$gotoString .= " | <a href=\"post_reply.php?board=".$board."&num=".$num."&anony=".intval($ret[anony])."\">�^��</a>";
		}
		else
			$gotoString .= " | �^��";
		
		if($cuser[level] & PERM_VALID)
			$gotoString .= " | <a href=\"post_forward.php?board=".$board."&title=".urlencode($ret[title])."&num=".$num."\">��H</a>";
		else
			$gotoString .= " | ��H";

		if(intval($ret[isbm]) == 1) {
			$gotoString .= " | <a href=\"post_mark.php?board=".$board."&num=".$num."\">m</a>";
			$gotoString .= " <a href=\"post_delete.php?board=".$board."&num=".$num."\">d</a>";
		} else
			$gotoString .= " | m d";

		$gotoString .= " | <a href=\"javascript: window.history.back()\">��^�W��</a>";

		/* �O�D�B�z */
			
		$ret[BM] = ltrim($ret[BM]);
		if($ret[BM] != '') {
			$BMs = split("/", $ret[BM]);
			$ret[BM] = "";
			$len = count($BMs);
			
			for($j=0; $j<$len; $j++) {
				$ret[BM] .= "<a href='query.php?userid=$BMs[$j]'>$BMs[$j]</a>/";
			}
			$ret[BM] = substr($ret[BM], 0, -1);
		} 

		print "
			<tr height='20'> 
			  <td align='left'><b>
				�ݪO: $ret[bname] $ret[btitle] �O�D: $ret[BM]
				</b>
			  </td>
	        </tr>
			<tr bgcolor='#dddddd' height='20'> 
	          <td> $gotoString </td>
		    </tr>
		";

		require('ansi2web.inc.php');

		/* show the title */			
		print "<tr width='100%' height='300'>
				<td align='left' valign='top' bgcolor='#000000'>
				<pre style='color: c0c0c0'>\n";
		echo ansi2web(htmlspecialchars($data[1]));
		print "</pre></td></tr>\n";

		print "
			<tr bgcolor='#dddddd' height='20'> 
	          <td> $gotoString </td>
		    </tr>
		";

		?>
      </table>		
	</td>
  </tr>
</table>
</body>
</html>
